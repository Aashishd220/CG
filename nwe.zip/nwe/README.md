## Features

- Uses [npm](https://npmjs.com)
- No transpilers, just vanilla javascript with ES2018 latest features like Async/Await
- Express + MongoDB ([Mongoose](http://mongoosejs.com/))
- CORS enabled and uses [helmet](https://github.com/helmetjs/helmet) to set some HTTP headers for security
- Load environment variables from .env files with [dotenv](https://github.com/rolodato/dotenv-safe)
- Request validation with [joi](https://github.com/hapijs/joi)
- Logging with winston [winston](https://github.com/winstonjs/winston)
- Consistent coding styles with [editorconfig](http://editorconfig.org)
- Gzip compression with [compression](https://github.com/expressjs/compression)
- Authentication and Authorization with [passport](http://passportjs.org)
- Linting with [eslint](http://eslint.org)
- [Docker](https://www.docker.com/) support
- Monitoring with [pm2](https://github.com/Unitech/pm2)

## Prerequisites

- [Node v12.0+](https://nodejs.org/en/download/current/) or [Docker](https://www.docker.com/)

- [npm v6.0+](https://www.npmjs.com)

## Getting Started

1. Clone the repo and make it yours:

```bash
git clone https://positive-proton@bitbucket.org/positive-proton/expeditions-backend.git expeditions-backend
cd expeditions-backend
rm -rf .git
```

2. Install dependencies:

```bash
npm install
```

3. Set environment variables:

```bash
cp .env.example .env
```

## Running Locally

```bash
npm run dev
```

## Running in Production

```bash
npm run start
```