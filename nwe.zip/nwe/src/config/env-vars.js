require('dotenv').config();

const MONGO_OPTIONS = {
  useNewUrlParser: true,
  useCreateIndex: true,
  useUnifiedTopology: true,
  useFindAndModify: false,
};

module.exports = {
  NODE_ENV: process.env.NODE_ENV,
  PORT: process.env.PORT,

  // JWT config
  JWT_SECRET: process.env.JWT_SECRET,
  JWT_EXPIRATION: process.env.JWT_EXPIRATION,

  // MongoDB Config
  MONGO_URI: process.env.NODE_ENV === 'production' ? process.env.MONGO_URI : process.env.MONGO_URI_DEV,
  MONGO_OPTIONS,

  // Winston Log Level
  LEVEL: process.env.NODE_ENV === 'production' ? 'error' : 'debug',

  // Password Reset URL
  RESET_URL: 'https://www.expeditionsconnect.com/reset-password',
  VERIFY_URL: 'https://www.expeditionsconnect.com/verify-email',
  ADMIN_PROFILE_EXPORTS_URL: 'http://expeditions-connect-admin.s3-website.eu-central-1.amazonaws.com/experts',

  // SMTP Config
  EMAIL_USER: process.env.EMAIL_USER,
  EMAIL_PASS: process.env.EMAIL_PASS,

  // AWS KEYS
  AWS_ACCESS_KEY: process.env.AWS_ACCESS_KEY,
  AWS_SECRET_KEY: process.env.AWS_SECRET_KEY,


  SITE_URL: process.env.NODE_ENV === 'production' ? 'https://www.expeditionsconnect.com' : 'http://ec-connect.s3-website.eu-central-1.amazonaws.com',

};
