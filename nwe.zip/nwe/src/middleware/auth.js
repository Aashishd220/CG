const passport = require('passport');
const {
  ROLES, FORBIDDEN, FORBIDDEN_ACCESS, ACCOUNT_SUSPENDED,
} = require('../utils/constants');
const { JwtError } = require('../utils/helper');

const handleJWT = (req, res, next, roles) => async (err, user, info) => {
  const apiError = JwtError(err || info);
  if (err || !user) {
    return next(apiError);
  }
  if (!roles.includes(user.role)) {
    apiError.status = FORBIDDEN;
    apiError.message = FORBIDDEN_ACCESS;
    return next(apiError);
  }
  if (!user.active) {
    apiError.status = FORBIDDEN;
    apiError.message = ACCOUNT_SUSPENDED;
    return next(apiError);
  }
  req.user = user;
  return next();
};

exports.Authorize = (roles = ROLES) => (req, res, next) => passport.authenticate('jwt',
  { session: false },
  handleJWT(req, res, next, roles))(req, res, next);
