const Cookie = require('universal-cookie');
const { getConversionRate } = require("../api/services/currency");

exports.convertCurrency = async (fromCurrency = "USD", toCurrency= "USD", value) => {
  const currencies = await getConversionRate([fromCurrency, toCurrency, "USD"]);
  const conversionRates = currencies.reduce(
    (rates, currency) => ({
      ...rates,
      [currency.currencyCode]: currency.rate,
    }),
    {},
  );
  const toCurrencyValue = (value / conversionRates[fromCurrency]) * conversionRates[toCurrency];
  return toCurrencyValue.toFixed();
};

exports.getPreferredCurrency = (req) => {
  // const cookie = new Cookie(req.headers.cookie);
  // return cookie.get('preferredCurrency') || "USD";
  return req.headers.preferredcurrency || "USD";
}
