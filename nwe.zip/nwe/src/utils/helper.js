/* eslint-disable consistent-return */
/* eslint-disable no-plusplus */
const { Types: { ObjectId } } = require('mongoose');
const { S3 } = require('aws-sdk');

const APIError = require('./APIError');
const { UNAUTHORIZED } = require('./constants');
const { AWS_ACCESS_KEY, AWS_SECRET_KEY } = require('../config/env-vars');

const s3bucket = new S3({
  accessKeyId: AWS_ACCESS_KEY,
  secretAccessKey: AWS_SECRET_KEY,
  region: 'eu-central-1',
  signatureVersion: 'v4',
});

exports.ValidateID = (id) => ObjectId.isValid(id);

const obj = {
  message: 'Unauthorized',
  status: UNAUTHORIZED,
};

exports.uploadFileOnAWS=(params) => new Promise((resolve, reject) => {
  s3bucket.upload(params, (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error uploading file', status: 500 }));
    }
    setTimeout(() => {
      return resolve(data.Key);
    }, 2000);
  });
})

const JwtError = (error) => {
  switch (error) {
    case 'jwt expired':
      obj.message = 'Your auth token is expired, Please Login again';
      break;
    case 'No auth token':
      obj.message = 'Please provide an auth token';
      break;
    case 'invalid signature':
      obj.message = 'Invalid auth token provided';
      break;
    default:
      obj.message = error.message;
      break;
  }
};

exports.JwtError = (error) => {
  const msg = error ? error.message : 'No Case';
  JwtError(msg);
  return new APIError(obj);
};

exports.UploadFile = (key, files) => new Promise((resolve, reject) => {
  
  const name = `${new Date().getTime().toString()}${getExtension(files.name)}`;
  const params = {
    Bucket: `expeditions-connect-bucket/${key}`,
    Key: name,
    ContentType: files.mimetype,
    Body: files.data,
  };

  s3bucket.upload(params, (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error uploading file', status: 500 }));
    }
    setTimeout(() => {
      return resolve(data.Key);
    }, 2000);
  });
});

exports.getSignedUrl = (key) => `https://expeditions-connect-bucket.s3.eu-central-1.amazonaws.com/${key}`;

const getExtension = (filename) => {
  const i = filename.lastIndexOf('.');
  return (i < 0) ? '' : filename.substr(i);
};

exports.UploadFiles = (key, files) => new Promise((resolve, reject) => {
  const photos = [];
  for (let i = 0; i < files; i++) {
    const name = `${new Date().getTime().toString()}${getExtension(files[i].name)}`;
    const params = {
      Bucket: `expeditions-connect-bucket/${key}`,
      Key: name,
      ContentType: files[i].mimetype,
      Body: files[i].data,
    };

    s3bucket.upload(params, (err, data) => {
      if (err) {
        return reject(new APIError({ message: 'Error uploading file', status: 500 }));
      }
      photos.push(data.Key);
    });
  }
  return resolve(photos);
});

exports.UploadAccommoFiles = (key, files) => new Promise((resolve, reject) => {
  const photos = [];
  for (let i = 0; i < files.length; i++) {
    const name = `${new Date().getTime().toString()}${getExtension(files[i].name)}`;
    const params = {
      Bucket: `expeditions-connect-bucket/${key}`,
      Key: name,
      ContentType: files[i].mimetype,
      Body: files[i].data,
    };

    s3bucket.upload(params, (err, data) => {
      if (err) {
        return reject(new APIError({ message: 'Error uploading file', status: 500 }));
      }
      photos.push(data.Key);
    });
  }

  setTimeout(() => {
    return resolve(photos);
  }, 2000);
});
