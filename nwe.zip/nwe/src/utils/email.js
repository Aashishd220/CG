const nodemailer = require('nodemailer');
const ejs = require('ejs');
const path = require('path');
const { EMAIL_PASS, EMAIL_USER, SITE_URL } = require('../config/env-vars');
const { EC_ADMIN_EMAIL } = require("../utils/constants");


/**
 * App Imports
 */
const APIError = require('./APIError');

const emailConfig = {
  host: 'smtp.zoho.eu',
  secure: true,
  secureConnection: false,
  port: 465,
  requireTLS: true,
  auth: {
    user: EMAIL_USER,
    pass: EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false,
  },
};

exports.ResetEmail = (name, email, link) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/reset_password.ejs'), { name, link }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'Password Reset Request',
      text: `Hey there, reset your password of your Expedition Connect Account using this link ${link}`,
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.VerificationEmail = (email, link) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/verification.ejs'), { email, link }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'Verify your email address',
      text: `Hey there, please verify your Expeditions Connect Account using this link ${link}`,
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});


exports.ConfirmEmail = (name, email, link) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/change_email.ejs'), { name, email, link }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'Verify your email address',
      text: `Hey there, please verify your email using this link ${link}`,
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.AdminVerificationEmail = (username) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/admin_verification.ejs'), { username }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: 'noreply@expeditionsconnect.com',
      subject: 'New Signup',
      text: `Hey there, please verify your Expeditions Connect Account using this link`,
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.AdminNewProfileEmail = (link, firstName, email) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/new_profile_admin_email.ejs'), { link, firstName, email }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: 'info@expeditionsconnect.com',
      subject: 'New expert profile created',
      text: `Hey there, please verify your Expeditions Connect Account using this link`,
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.ApprovalEmail = (name, email) => new Promise((resolve, reject) => {
  let siteURL = SITE_URL;
  ejs.renderFile(path.join(__dirname, '../views/approved.ejs'), { email, name, siteURL }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'Your profile has been approved',
      text: 'Hey there, Congratulations your expeditions profile has been approved',
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.MessageEmail = (name, email, message, profile, messageName, dateString) => new Promise((resolve, reject) => {
  let siteURL = SITE_URL;
  ejs.renderFile(path.join(__dirname, '../views/message.ejs'), { name, message, profile, messageName, dateString, siteURL }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'You have a new message',
      text: 'Hey there, There is some inquiry for your trips',
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.ReplyEmail = (name, email, message, reply) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/reply.ejs'), {
    email, name, message, reply,
  }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'You have a reply of your message',
      text: 'Hey there, There is some inquiry for your trips',
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});


exports.subscribeEmail = (email) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/subscribers.ejs'), { email }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: EC_ADMIN_EMAIL,
      subject: 'New Subscription',
      text: 'Hey there',
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});

exports.ChangePassword = (name, email, link) => new Promise((resolve, reject) => {
  ejs.renderFile(path.join(__dirname, '../views/change_password.ejs'), { name, link }, async (err, data) => {
    if (err) {
      return reject(new APIError({ message: 'Error Rendering email template', status: 500 }));
    }
    const mailOptions = {
      from: 'noreply@expeditionsconnect.com',
      to: email,
      subject: 'Password Reset Request',
      text: `Hey there, your password has been changed successfully`,
      html: data,
    };
    try {
      const transporter = nodemailer.createTransport(emailConfig);
      await transporter.sendMail(mailOptions);
      return resolve('Email sent success');
    } catch (error) {
      return reject(new APIError({ message: `Error sending email ${error}`, status: 500 }));
    }
  });
});