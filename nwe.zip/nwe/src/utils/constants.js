module.exports = {
  // HTTP Status Codes
  ACCEPTED: 202,
  BAD_GATEWAY: 502,
  BAD_REQUEST: 400,
  CONFLICT: 409,
  CREATED: 201,
  FORBIDDEN: 403,
  GATEWAY_TIMEOUT: 504,
  INTERNAL_SERVER_ERROR: 500,
  NOT_FOUND: 404,
  NOT_IMPLEMENTED: 501,
  OK: 200,
  PAYMENT_REQUIRED: 402,
  PRECONDITION_FAILED: 412,
  PROXY_AUTHENTICATION_REQUIRED: 407,
  REQUEST_TOO_LONG: 413,
  REQUEST_URI_TOO_LONG: 414,
  SERVICE_UNAVAILABLE: 503,
  TOO_MANY_REQUESTS: 429,
  UNAUTHORIZED: 401,
  UNPROCESSABLE_ENTITY: 422,

  // Modal Defaults
  ROLES: ['expert', 'enthusiasts', 'admin', 'user'],
  LOGIN_TYPE: ['facebook', 'google', 'email'],
  LOGGED_IN: 'login__in',
  ENUM_SUITABLE: ['families', 'couples', 'groups', 'individual'],
  ENUM_DIFFICULTIES: ['difficult', 'light', 'moderate', 'tough'],

  // Messages
  INVALID_CREDENTIALS: 'Incorrect email address or password',
  NO_RECORD_FOUND: 'No record found for given details',
  LINK_EXPIRED: 'Oops, Link has been expired',
  EMAIL_EXISTS: 'Oops, new email is already exists, Please try with new email',
  EMAIL_NOT_EXISTS: 'Oops, current email is mismatch. Please update current email',
  VALIDATION_ERROR: 'Validation Error',
  FORBIDDEN_ACCESS: 'You are not authorized to access this resource',
  ACCOUNT_SUSPENDED: 'Your account has been suspended, please contact expedition connect help center for more information',
  INVALID_PASSWORD: 'Invalid Current password',
  INVALID_FILE_TYPE: 'Invalid file type',
  FB_GOOGLE_ERROR: 'Invalid credentials, Please signin using your Facebook/Google account',

  //EC admin email address / currently used for send subscriber notification
  EC_ADMIN_EMAIL: 'info@expeditionsconnect.com',
};
