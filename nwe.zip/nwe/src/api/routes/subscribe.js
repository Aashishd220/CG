const app = require('express').Router();

const { subscribe } = require('../controllers/subscribe');

app.route('/').post(subscribe);

module.exports = app;
