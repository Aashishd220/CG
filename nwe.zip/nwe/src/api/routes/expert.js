const app = require('express').Router();

const { CreateExpert, UpdateExpert } = require('../validations/expert');
const {
  createExpert, updateExpert,
  getExpert, getExperts,
  approveExpertProfile,
  getListOfExperts, getExpertForEdit,
  getMyAllMessages, replyToMyMessage,
  uploadCover, getAllMessages, getAllTripMessages,
  getMyAllMessagesSession, getSessionMessages, sendMessage,
  readMessage, deleteMessages, hideMessages, starMessages,
  unReadMessage, uploadMessage, editMessage, deleteMessage,
  confirmBooking, getUnreadCount,uploadBookCover, updateExpertLocation,updateExpertOriginalCover
} = require('../controllers/expert');


const { Authorize } = require('../../middleware/auth');

/**
 * User Routes
 */
app.route('/')
  .post(Authorize(['expert', 'user']), CreateExpert, createExpert)
  .put(Authorize('expert'), UpdateExpert, updateExpert)
  .get(Authorize('expert'), getExpertForEdit);

app.route('/all')
  .get(getExperts);

  //Run once to update the experts location for existing records
app.route('/update-expert-locations')
  .get(updateExpertLocation);

//Run once to update the experts originalCover for existing records
app.route('/update-expert-originalCover').
  get(updateExpertOriginalCover)
  
app.route('/messages')
  .post(Authorize('expert'), replyToMyMessage)
  .get(Authorize('expert'), getMyAllMessages);

app.route('/getAllMessages/:id').get(Authorize('expert'), getAllMessages);

app.route('/getAllTripMessages/:id/:trip_id').get(Authorize('expert'), getAllTripMessages);

app.route('/messages/session').get(Authorize('expert'), getMyAllMessagesSession);

app.route('/messages/session').post(Authorize('expert'), getSessionMessages);

app.route('/messages/send').post(Authorize('expert'), sendMessage);

app.route('/messages/read').post(Authorize('expert'), readMessage);

app.route('/messages/hide').post(Authorize('expert'), hideMessages);

app.route('/messages/remove').post(Authorize('expert'), deleteMessages);

app.route('/messages/star').post(Authorize('expert'), starMessages);

app.route('/messages/unreadsidebar').post(Authorize('expert'), unReadMessage);

app.route('/messages/upload').post(Authorize('expert'), uploadMessage);

app.route('/messages/edit').post(Authorize('expert'), editMessage);

app.route('/messages/delete').post(Authorize('expert'), deleteMessage);

app.route('/messages/confirm').post(Authorize('expert'), confirmBooking);

app.route('/messages/count').get(Authorize('expert'), getUnreadCount);

app.route('/cover').post(Authorize('expert'), uploadCover);

app.route('/bookcover').post(Authorize('expert'), uploadBookCover);

app.route('/admin').get(Authorize('admin'), getListOfExperts);

app.route('/:id')
  .get(getExpert)
  .put(Authorize('admin'), approveExpertProfile);

module.exports = app;
