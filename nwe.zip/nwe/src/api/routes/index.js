const express = require('express');

const app = express.Router();

app.use('/auth', require('./auth'));

app.use('/expert', require('./expert'));

app.use('/enthusiasts', require('./enth'));

app.use('/lists', require('./comman'));

app.use('/trips', require('./trips'));

app.use('/learnings', require('./learning'));

app.use('/album', require('./album'));

app.use('/albumComment', require('./albumComment'));

app.use('/bookings', require('./bookings'));

app.use('/currency', require('./currency'));

app.use('/subscribe', require('./subscribe'));

app.get('/status', (req, res) => {
    console.log('Running on version 1.0.0.4');
    res.send("Running on version 1.0.0.4");
});

module.exports = app;
