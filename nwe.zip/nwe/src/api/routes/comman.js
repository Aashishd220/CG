const express = require('express');

const { Authorize } = require('../../middleware/auth');

const { createLists, getLists } = require('../controllers/common');
const { CreateLists } = require('../validations/comman');

const app = express.Router();

app.route('/')
  .post(Authorize('admin'), CreateLists, createLists)
  .get(getLists);

module.exports = app;
