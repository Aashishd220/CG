const app = require('express').Router();

/**
 * App Imports
 */
const {
  login, logout, register,
  Oauth, forgotPassword, CheckToken,
  resetPassword, changePassword, adminLogin, confirmEmail,
  updatePreferredCurrency,
  verifyProfile, status, updateLogin, confirmPassword, updateRole
} = require('../controllers/auth');

const {
  Login,
  OAuth, ForgotPassword,
  ResetPassword, ChangePassword
} = require('../validations/user');

const { Authorize } = require('../../middleware/auth');


app.route("/register").post(Login, register);

app.route('/login').post(Login, login);

app.route('/facebook').post(OAuth, Oauth);

app.route('/google').post(OAuth, Oauth);

app.route('/forgot-password').post(ForgotPassword, forgotPassword);

app.route('/change-password').post(Authorize(), ChangePassword, changePassword);

app.route('/confirm-password').post(Authorize(), confirmPassword);
app.route('/confirm-email').post(Authorize(), confirmEmail);
app.route('/preferred-currency/:currency').post(Authorize(), updatePreferredCurrency);

app.route('/verify-profile/:token').post(verifyProfile);

app.route('/reset-password/:token')
  .get(CheckToken)
  .post(ResetPassword, resetPassword);

app.route('/admin').post(Login, adminLogin);

app.route('/logout').post(logout);

app.route('/activity').post(Authorize(), updateLogin);

app.route('/updateRole').post(Authorize(), updateRole);

module.exports = app;
