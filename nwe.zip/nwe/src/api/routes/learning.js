const app = require('express').Router();

const {
  loadLearning, createLearning, getDetails, GetLearnings,
  GetMyLearnings, GetSimilarLearning, updateLearnings,
  getUpcomingExpertLearnings, InActiveLearning, ActiveLearning, copyLearning,
  sendMessage,
  GetLearningPlusTrip,
  addLikeOnLearnings,
  updateCurrency,updateExpertLearningOriginalCover
} = require('../controllers/learning');
const { Authorize } = require('../../middleware/auth');

app.param('learningId', loadLearning);

app.route('/')
  .post(Authorize('expert'), createLearning)
  .get(GetLearnings);

//Run once to update the experts originalCover for existing records
app.route('/update-expert-learning-originalCover').
  get(updateExpertLearningOriginalCover)

app.route('/get-similar-trips').get(GetSimilarLearning);
app.route('/learnings-plus-trips').get(GetLearningPlusTrip);

app.route('/my').get(Authorize('expert'), GetMyLearnings);

app.route('/upcoming/:id').get(getUpcomingExpertLearnings);
app.route('/inActive/:id').put(InActiveLearning);
app.route('/active/:id').put(ActiveLearning);

app.route('/:learningId')
  .get(getDetails)
  .put(Authorize('expert'), updateLearnings);

app.route('/copy')
  .post(Authorize('expert'), copyLearning);

app.route('/send-message/:learningId').post(Authorize('enthusiasts'), sendMessage);

app.route('/likes/add-like-on-learning').post(Authorize(['expert', 'user', 'enthusiasts']), addLikeOnLearnings);


//Run once to add the priceUSD field trip and workshop
app.route('/learning/update-currency-for-learning-and-trip').get(updateCurrency);

module.exports = app;
