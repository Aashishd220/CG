const app = require('express').Router();

const { Authorize } = require('../../middleware/auth');

const { CreateAlbum } = require('../validations/album');
const {
  createAlbum,
  getAlbums,
  GetMyAlbums,
  getDetails,
  deleteAlbum,
  getExpertAlbums,
  InActiveAlbum,
  ActiveAlbum,
  updateAlbums,
  addLikeOnAlbum
} = require('../controllers/album');

/**
 * Albums Routes
 */
app.route('/').post(Authorize(['expert', 'user']), createAlbum);

app.route('/all').get(getAlbums);
app.route('/expertAlbums/:id').get(getExpertAlbums);

app.route('/my').get(Authorize(['expert', 'user']), GetMyAlbums);

app.route('/:albumId').get(getDetails);
app.route('/:albumId').put(Authorize('expert'), updateAlbums);
app.route('/:albumId').delete(Authorize(['expert', 'user']), deleteAlbum);

app.route('/inActive/:id').put(InActiveAlbum);
app.route('/active/:id').put(ActiveAlbum);

app.route('/likes/add-like-on-album').post(Authorize(['expert', 'user', 'enthusiasts']), addLikeOnAlbum);

module.exports = app;
