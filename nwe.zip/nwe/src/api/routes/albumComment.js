const app = require('express').Router();

const { Authorize } = require('../../middleware/auth');

const {
  createAlbumComment,
  getAlbumComment,
  updateAlbumComment,
} = require('../controllers/albumComment');

/**
 * Albums Routes
 */
app.route('/').post(Authorize(['expert', 'user']), createAlbumComment);

app.route('/:albumId').get(getAlbumComment);

app.route('/:id').put(Authorize('expert'), updateAlbumComment);

module.exports = app;
