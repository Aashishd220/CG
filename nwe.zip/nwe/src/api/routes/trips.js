const app = require('express').Router();

const {
  createTrips, addLikeOnTrips, loadTrips,
  updateTrips, getTrips,
  getAllTrips, getDetails,
  sendMessage, getUpcomingExpertTrips, InActiveTrip, UploadTripsAccomodationPhotos,UploadTripsAccomodationPhotosUpload,
  getTravelMap, GetSimilarTrips, GetRecentTrips, ActiveTrip, copyTrip,updateAccommo, updatePhotosAndVideo,updateTripsOriginalCover
} = require('../controllers/trips');
const { Authorize } = require('../../middleware/auth');

app.param('tripId', loadTrips);

app.route('/')
  .post(Authorize('expert'), createTrips)
  .get(Authorize('expert'), getTrips);


  //Run once to update the experts originalCover for existing records
app.route('/update-expert-trips-originalCover').
get(updateTripsOriginalCover)

app.route('/all').get(getAllTrips);

app.route('/recent').get(GetRecentTrips);

app.route('/get-similar-trips').get(GetSimilarTrips);

app.route('/upcoming/:id').get(getUpcomingExpertTrips);

app.route('/travel-map/:id').get(getTravelMap);

app.route('/send-message/:tripId').post(Authorize('enthusiasts'), sendMessage);

app.route('/copy')
  .post(Authorize('expert'), copyTrip);

app.route('/:id').post(Authorize('expert'), UploadTripsAccomodationPhotos);

app.route('/accomo/:id').post(Authorize('expert'), UploadTripsAccomodationPhotosUpload);

app.route('/:tripId')
  .get(getDetails)
  .put(Authorize('expert'), updateTrips);

app.route('/inActive/:id').put(InActiveTrip);
app.route('/active/:id').put(ActiveTrip);

app.route('/accommoupdate/:albumId').put(Authorize('expert'), updateAccommo);

app.route('/photosAndVideo/:id').put(Authorize('expert'), updatePhotosAndVideo);

app.route('/likes/add-like-on-trip').post(Authorize(['expert', 'user', 'enthusiasts']), addLikeOnTrips);


module.exports = app;
