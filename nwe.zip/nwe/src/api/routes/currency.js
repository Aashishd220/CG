const app = require('express').Router();

const { getAllCurrency } = require('../controllers/currency');

app.route('/').get(getAllCurrency);

module.exports = app;
