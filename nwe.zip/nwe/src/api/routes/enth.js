const app = require('express').Router();

const { CreateEnthusiest, UpdateEnthusiest } = require('../validations/enthusiest');
const {
  createEnth, updateEnth, getEnt,
  getEnthuPublicProfile, uploadCover,
  getMyAllMessages, getMyAllMessagesSession, getSessionMessages,
  sendMessage,readMessage, deleteMessages, hideMessages, starMessages,
  unReadMessage, uploadMessage, editMessage, deleteMessage,
  confirmBooking, getUnreadCount
} = require('../controllers/enth');
const { Authorize } = require('../../middleware/auth');

app.route('/')
  .get(Authorize('enthusiasts'), getEnt)
  .post(Authorize(['enthusiasts', 'user']), CreateEnthusiest, createEnth)
  .put(Authorize('enthusiasts'), UpdateEnthusiest, updateEnth);


app.route('/messages').get(Authorize('enthusiasts'), getMyAllMessages);

app.route('/messages/session').get(Authorize('enthusiasts'), getMyAllMessagesSession);

app.route('/messages/session').post(Authorize('enthusiasts'), getSessionMessages);

app.route('/messages/send').post(Authorize('enthusiasts'), sendMessage);

app.route('/messages/read').post(Authorize('enthusiasts'), readMessage);

app.route('/messages/hide').post(Authorize('enthusiasts'), hideMessages);

app.route('/messages/remove').post(Authorize('enthusiasts'), deleteMessages);

app.route('/messages/star').post(Authorize('enthusiasts'), starMessages);

app.route('/messages/unreadsidebar').post(Authorize('enthusiasts'), unReadMessage);

app.route('/messages/upload').post(Authorize('enthusiasts'), uploadMessage);

app.route('/messages/edit').post(Authorize('enthusiasts'), editMessage);

app.route('/messages/delete').post(Authorize('enthusiasts'), deleteMessage);

app.route('/messages/confirm').post(Authorize('enthusiasts'), confirmBooking);

app.route('/messages/count').get(Authorize('enthusiasts'), getUnreadCount);

app.route('/cover').post(Authorize('enthusiasts'), uploadCover);

app.route('/:id').get(getEnthuPublicProfile);

module.exports = app;
