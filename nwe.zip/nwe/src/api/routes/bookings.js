const app = require('express').Router();

const {
  sendMessage, getAllBooking, getBookingForTrip, starBookings, deleteBookings, hideBookings,
} = require('../controllers/bookings');
const { Authorize } = require('../../middleware/auth');

app.route('/star').post(Authorize('expert'), starBookings);
app.route('/delete').post(Authorize('expert'), deleteBookings);
app.route('/hide').post(Authorize('expert'), hideBookings);

app.route('/:tripId').post(Authorize('enthusiasts'), sendMessage);

app.route('/getAllBooking/:id').get(Authorize('expert'), getAllBooking);
app.route('/details/:id').get(Authorize('expert'), getBookingForTrip);

module.exports = app;
