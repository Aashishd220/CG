const Joi = require('@hapi/joi');

const ValidateBody = (schema, body, next) => {
  const { error } = schema.validate(body, { abortEarly: false });
  if (error) return next(error);
  return next();
};

const validateAwardObj = Joi.object({
  name: Joi.string().optional(),
  authority: Joi.string().optional(),
  year: Joi.number().optional(),
});

const validateProfessionalQualificationsObj = Joi.object({
  name: Joi.string().optional(),
  authority: Joi.string().optional(),
  year: Joi.number().optional(),
});

const validateProfessionalExperienceObj = Joi.object({
  name: Joi.string().optional(),
  role: Joi.string().optional(),
  year: Joi.string().allow('').optional(),
});

const validateSocialContributionsObj = Joi.object({
  name: Joi.string().optional(),
  url: Joi.string().allow('').optional(),
  description: Joi.string().allow('').optional(),
});

const validatebooksAndPublicationsObj = Joi.object({
  name: Joi.string().optional(),
  url: Joi.string().allow('').optional(),
  cover: Joi.object().optional(),
});

exports.CreateExpert = async (req, res, next) => {
  try {
    req.body.experties = JSON.parse(req.body.experties);
    req.body.speaks = JSON.parse(req.body.speaks);
    req.body.awards = JSON.parse(req.body.awards);
    req.body.skills = JSON.parse(req.body.skills);
    req.body.professionalExperience = JSON.parse(req.body.professionalExperience);
    req.body.professionalQualifications = JSON.parse(req.body.professionalQualifications);
    req.body.socialContributions = JSON.parse(req.body.socialContributions);
    req.body.booksAndPublications = JSON.parse(req.body.booksAndPublications);

    const schema = Joi.object({
      firstName: Joi.string().min(2).max(255).required(),
      lastName: Joi.string().min(2).max(255).required(),
      country: Joi.string().required(),
      city: Joi.string().required(),
      speaks: Joi.array().items(Joi.string()).required(),
      experties: Joi.array().items(Joi.string()).required(),
      skills: Joi.array().items(Joi.string()).required(),
      bio: Joi.string().min(10).required(),
      awards: Joi.array().items(validateAwardObj).optional(),
      professionalExperience: Joi.array()
        .items(validateProfessionalExperienceObj)
        .optional(),
      professionalQualifications: Joi.array()
        .items(validateProfessionalQualificationsObj)
        .optional(),
      socialContributions: Joi.array()
        .items(validateSocialContributionsObj)
        .optional(),
      booksAndPublications: Joi.array()
        .items(validatebooksAndPublicationsObj)
        .optional(),
      companyname: Joi.string().min(2).max(255).required(),
      address: Joi.string().min(2).required(),
      website: Joi.string().required(),
      phone: Joi.number().required(),
      businessEmail: Joi.string().required(),
    });
    return ValidateBody(schema, req.body, next);
  } catch (err) {
    return next(err);
  }
};

exports.UpdateExpert = async (req, res, next) => {
  try {
    req.body.experties = JSON.parse(req.body.experties);
    req.body.speaks = JSON.parse(req.body.speaks);
    req.body.awards = JSON.parse(req.body.awards);
    req.body.skills = JSON.parse(req.body.skills);
    req.body.professionalExperience = JSON.parse(req.body.professionalExperience);
    req.body.professionalQualifications = JSON.parse(req.body.professionalQualifications);
    req.body.socialContributions = JSON.parse(req.body.socialContributions);
    req.body.booksAndPublications = JSON.parse(req.body.booksAndPublications);

    const schema = Joi.object({
      firstName: Joi.string().min(2).max(255),
      lastName: Joi.string().min(2).max(255),
      country: Joi.string(),
      city: Joi.string().required(),
      speaks: Joi.array().items(Joi.string()),
      experties: Joi.array().items(Joi.string()),
      skills: Joi.array().items(Joi.string()).required(),
      bio: Joi.string().min(10),
      awards: Joi.array().items(validateAwardObj).optional(),
      professionalExperience: Joi.array()
        .items(validateProfessionalExperienceObj)
        .optional(),
      professionalQualifications: Joi.array()
        .items(validateProfessionalQualificationsObj)
        .optional(),
      socialContributions: Joi.array()
        .items(validateSocialContributionsObj)
        .optional(),
      booksAndPublications: Joi.array()
        .items(validatebooksAndPublicationsObj)
        .optional(),
      companyname: Joi.string().min(2).max(255),
      address: Joi.string().min(2),
      website: Joi.string(),
      phone: Joi.number(),
      businessEmail: Joi.string().required(),
    });
    return ValidateBody(schema, req.body, next);
  } catch (err) {
    return next(err);
  }
};

const validateDate = Joi.object({
  from: Joi.date().required(),
  to: Joi.date().required(),
  price: Joi.number().min(1).required(),
});

const validateItinerary = Joi.object({
  day: Joi.string().required(),
  description: Joi.string().required(),
});

exports.CreateTrip = async (req, res, next) => {
  try {
    req.body.dates = JSON.parse(req.body.dates);
    req.body.itinerary = JSON.parse(req.body.itinerary);
    req.body.coordinates = JSON.parse(req.body.coordinates);
    req.body.activity = JSON.parse(req.body.activity);
    req.body.type = JSON.parse(req.body.type);
    req.body.suitable = req.body.suitable.toLowerCase();
    const schema = Joi.object({
      title: Joi.string().min(2).max(1024).required(),
      duration: Joi.number().required(),
      price: Joi.number().min(1).required(),
      type: Joi.array().items(Joi.string()).required(),
      suitable: Joi.string().valid('individual', 'families', 'couples', 'groups').required(),
      activity: Joi.array().items(Joi.string()).required(),
      difficulty: Joi.string().valid('difficult', 'light', 'moderate', 'tough').required(),
      dates: Joi.array().items(validateDate).required(),
      meetingPoint: Joi.string().min(2).required(),
      coordinates: Joi.array().items(Joi.number()).required(),
      itinerary: Joi.array().items(validateItinerary).required(),
      idesc: Joi.string().required(),
      overview: Joi.string().optional(),
      inclusion: Joi.string().optional(),
      exclusion: Joi.string().optional(),
      cancellations: Joi.string().optional(),
      extras: Joi.string().optional(),
    });
    return ValidateBody(schema, req.body, next);
  } catch (err) {
    return next(err);
  }
};
