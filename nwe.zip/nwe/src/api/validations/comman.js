const Joi = require('@hapi/joi');

const ValidateBody = (schema, body, next) => {
  const { error } = schema.validate(body, { abortEarly: false });
  if (error) return next(error);
  return next();
};

exports.CreateLists = (req, res, next) => {
  try {
    const schema = Joi.object({
      title: Joi.string().required(),
      type: Joi.string().valid('experties', 'trips', 'activities').required(),
    });
    return ValidateBody(schema, req.body, next);
  } catch (err) {
    return next(err);
  }
};
