const Joi = require('@hapi/joi');

const ValidateBody = (schema, body, next) => {
  const { error } = schema.validate(body, { abortEarly: false });
  if (error) return next(error);
  return next();
};

exports.CreateAlbum = async (req, res, next) => {
  try {
    // caption = req.body.caption;
    // date = req.body.date;
    req.body.location = JSON.parse(req.body.location);


    const schema = Joi.object({
      name: Joi.string().min(2).max(255).required(),
      description: Joi.string().min(2).max(255).required(),
      date: Joi.string().min(2).max(255).required(),
      country: Joi.string().min(2).max(255).required(),
      location: Joi.object(),
      address: Joi.string().min(2).max(255).required(),
    });
    return ValidateBody(schema, req.body, next);
  } catch (err) {
    return next(err);
  }
};
