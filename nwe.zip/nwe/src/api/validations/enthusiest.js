const Joi = require('@hapi/joi');

const ValidateBody = (schema, body, next) => {
  
  const { error } = schema.validate(body, { abortEarly: false });
  
  if (error) return next(error);
  return next();
};

exports.CreateEnthusiest = (req, res, next) => {
  try {
    req.body.interested = JSON.parse(req.body.interested);
    req.body.speaks = JSON.parse(req.body.speaks);
    req.body.activity = JSON.parse(req.body.activity);
    
  } catch (err) {
    next(err);
  }
  const schema = Joi.object({
    firstName: Joi.string().min(2).max(255).required(),
    lastName: Joi.string().min(2).max(255).required(),
    country: Joi.string().required(),
    city: Joi.string().required(),
    address: Joi.string().optional().allow(""),
    address2: Joi.string().optional().allow(""),
    phone: Joi.number().optional().allow(""),	
    dob: Joi.date().required(),
    interested: Joi.array().items(Joi.string()).required(),
    speaks: Joi.array().items(Joi.string()).optional(),	
    aboutme: Joi.string().optional().allow(""),	   
    activity: Joi.array().items(Joi.string()),
  });
  return ValidateBody(schema, req.body, next);
};

exports.UpdateEnthusiest = (req, res, next) => {
  // console.log('-------------------------');
  // console.log('req.body-->',req.body);
  // console.log('-------------------------');
  // return;
  try {
    req.body.interested = JSON.parse(req.body.interested);
    req.body.speaks = JSON.parse(req.body.speaks);
    req.body.activity = JSON.parse(req.body.activity);
  } catch (err) {
    next(err);
  }
  const schema = Joi.object({
    firstName: Joi.string().min(2).max(255),	
    lastName: Joi.string().min(2).max(255),	
    country: Joi.string(),	
    city: Joi.string(),	
    address: Joi.string().optional().allow(""),	
    address2: Joi.string().optional().allow(""),	
    phone: Joi.number().optional().allow(""),	
    dob: Joi.date().optional(),	
    interested: Joi.array().items(Joi.string()),
    speaks: Joi.array().items(Joi.string()).optional(),	
    aboutme: Joi.string().optional().allow(""),	   
    activity: Joi.array().items(Joi.string()),
  });
  return ValidateBody(schema, req.body, next);
};
