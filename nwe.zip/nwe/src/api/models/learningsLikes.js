const { Schema, model, Types: { ObjectId } } = require('mongoose');

const LearningsLikesSchema = new Schema({
  userId: {
    type: ObjectId,
    ref: 'users',
    required: true,
  },
  learningId: {
    type: ObjectId,
    ref: 'learnings',
    required: true,
  },
  createdAt: {
    type: String,
  },
}, { timestamps: true, versionKey: false });

module.exports = model('learningLikes', LearningsLikesSchema);
