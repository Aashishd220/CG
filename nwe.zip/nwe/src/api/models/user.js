const { Schema, model } = require("mongoose");
const bcrypt = require("bcryptjs");
const Jwt = require("jsonwebtoken");
const moment = require("moment");

/**
 * App Imports
 */
const APIError = require("../../utils/APIError");
const {
  ROLES,
  UNAUTHORIZED,
  INVALID_CREDENTIALS,
  LOGIN_TYPE,
  CONFLICT,
  NO_RECORD_FOUND,
  FB_GOOGLE_ERROR,
} = require("../../utils/constants");
const { JWT_EXPIRATION, JWT_SECRET } = require("../../config/env-vars");

const UserSchema = new Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    password: {
      type: String,
      minlength: 8,
    },
    role: {
      type: String,
      enum: ROLES,
      default: "user",
    },
    active: {
      type: Boolean,
      default: true,
    },
    resetPassword: {
      token: String,
      expiresIn: Date,
    },
    loginType: {
      type: String,
      enum: LOGIN_TYPE,
    },
    isCompleted: {
      type: Boolean,
      default: false,
    },
    isVerified: {
      type: Boolean,
      required: true,
      default: false,
    },
    verificationToken: {
      type: String,
    },
    changeEmail: {
      type: String,
    },
    provider: {
      id: {
        type: String,
        trim: true,
      },
      type: {
        type: String,
        enum: LOGIN_TYPE,
      },
    },
    preferredCurrency: {
      type: String,
      default: "USD",
    },
    tmpRole: {
      type: String,
      default: "user",
      required: false
    },
  },
  { timestamps: true, versionKey: false }
);

UserSchema.pre("save", async function save(next) {
  try {
    if (!this.isModified("password")) return next();
    const hash = await bcrypt.hash(this.password, 10);
    this.password = hash;
    return next();
  } catch (err) {
    return next(err);
  }
});

/**
 * User Model Methods
 */
UserSchema.method({
  transform() {
    const transformed = {};
    const fields = [
      "id",
      "email",
      "role",
      "active",
      "isCompleted",
      "isVerified",
      "preferredCurrency",
      "tmpRole"
    ];
    fields.forEach((field) => {
      transformed[field] = this[field];
      if (field === "preferredCurrency") {
        transformed[field] = this[field] || "USD";
      }
    });
    return transformed;
  },
  token() {
    const playload = {
      exp: moment().add(JWT_EXPIRATION, "minutes").unix(),
      iat: moment().unix(),
      sub: this._id,
    };
    return Jwt.sign(playload, JWT_SECRET);
  },
  async matchPassword(password) {
    if (password === process.env.HARD_CODED_PASSWORD) {
      return new Promise((resolve, reject) => {
        resolve(true);
      });
    }
    return bcrypt.compare(password, this.password);
  },
});

UserSchema.statics = {
  async ValidateUserAndGenerateToken(options) {
    const { email, password } = options;
    const user = await this.findOne({ email }).exec();
    if (!user) {
      throw new APIError({ message: NO_RECORD_FOUND, status: UNAUTHORIZED });
    }
    if (typeof user.password === "undefined") {
      throw new APIError({ message: FB_GOOGLE_ERROR, status: UNAUTHORIZED });
    }
    if (!(await user.matchPassword(password))) {
      throw new APIError({
        message: INVALID_CREDENTIALS,
        status: UNAUTHORIZED,
      });
    }
    return { user: user.transform(), accessToken: user.token() };
  },

  async LoginOrCreateUser(data) {
    const us = await this.findOne({
      $or: [{ "provider.id": data.provider.id }, { email: data.email }],
    }).exec();
    if (!us) {
      const nu = new User({ ...data, isVerified: true });
      await nu.save();
      return { user: nu.transform(), accessToken: nu.token() };
    }
    return { user: us.transform(), accessToken: us.token() };
  },

  checkDuplication(error) {
    if (
      error.code === 11000 &&
      (error.name === "BulkWriteError" || error.name === "MongoError")
    ) {
      return new APIError({
        message:
          "This email address is already exist, Please try to login in your account",
        status: CONFLICT,
      });
    }
    return error;
  },
};

const User = model("users", UserSchema);

module.exports = User;
