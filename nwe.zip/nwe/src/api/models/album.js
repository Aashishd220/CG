/* eslint-disable no-param-reassign */
const {
  Schema,
  model,
  Types: { ObjectId },
} = require('mongoose');

const AlbumSchema = new Schema({
  user: {
    type: ObjectId,
    ref: 'users',
    required: true,
  },
  expert: {
    type: ObjectId,
    ref: "expert",
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    required: false,
  },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point',
      required: false,
    },
    coordinates: {
      type: [Number],
      required: false,
    },
  },
  images: {
    type: Array,
    required: true,
  },
  country: {
    type: String,
    required: false,
    lowercase: true,
  },
  address: {
    type: String,
    required: false,
  },
  description: {
    type: String,
    required: false,
  },
  isVideo: {
    type: Boolean,
    required: false,
  },
  isActive: {
    type: Boolean,
    required: false,
  },
  isDelete: {
    type: Boolean,
    required: false,
  },
});

AlbumSchema.index({ location: '2dsphere' });

AlbumSchema.method({
  transform() {
    const transformed = {};
    const fields = ['caption', 'date', 'location'];
    fields.forEach((field) => {
      transformed[field] = this[field];
    });
    return transformed;
  },
});

module.exports = model('albums', AlbumSchema);
