/* eslint-disable no-param-reassign */
const {
  Schema,
  model,
  Types: { ObjectId },
} = require('mongoose');

const LoginDetails = new Schema({
	user: {
		type: Object,
		ref: 'user',
		required: true,
	},
	last_activity:{
		type: Date,
	}
}, { timestamps: true, versionKey: false });

module.exports = model('loginDeatils', LoginDetails);
