const { Schema, model } = require('mongoose');

const SubscribersSchema = new Schema(
    {
        email: {
            type: String,
            required: true,
        },
        subscribe: {
            type: Boolean,
            required: true,
            default: true,
        }        
    },
    { timestamps: true, versionKey: false, collection: 'subscribers' },
);

module.exports = model('subscribers', SubscribersSchema);
