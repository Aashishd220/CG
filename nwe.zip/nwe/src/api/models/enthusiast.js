const { model, Schema, Types: { ObjectId } } = require('mongoose');

const APIError = require('../../utils/APIError');
const { NOT_FOUND, NO_RECORD_FOUND, CONFLICT } = require('../../utils/constants');
const { getSignedUrl } = require('../../utils/helper');

const EnthSchema = new Schema({
  user: {
    type: ObjectId,
    ref: 'users',
    required: true,
    unique: true,
  },
  cover: {
    type: String,
    default: null,
  },
  originalCover: {
    type: String,
    default: null,
  },
  profile: {
    type: String,
    default: null,
  },
  originalProfile: {
    type: String,
    default: null,
  },
  firstName: {
    type: String,
    required: true,
    minlength: 2,
    maxlength: 1024,
  },
  lastName: {
    type: String,
    required: true,
    minlength: 2,
    maxlength: 1024,
  },
  country: {
    type: String,
    required: true,
  },
  interested: [
    {
      type: String,
      required: true,
    },
  ],
  address: {
    type: String,
    required: false,
  },
  phone: {
    type: String,
    required: false,
  },
  dob: {
    type: Date,
    required: false,
    default: null,
  },
  city: {
    type: String,
    required: true,
  },
  speaks: [
    {
      type: String,
      required: false
    },
  ],
  activity: [
    {
      type: String,
      required: true,
    },
  ],
  aboutme: {
    type: String,
    required: false,
  },
  active: {
    type: Boolean,
    required: true,
    default: true,
  },
  approved: {
    type: Boolean,
    required: true,
    default: true,
  },
  deleted: {
    type: Boolean,
    required: true,
    default: false,
  },
}, { timestamps: true, versionKey: false });

EnthSchema.method({
  transform() {
    let transformed = {};
    const fields = ['user', 'profile','originalProfile', 'cover','originalCover', 'interested', 'firstName', 'lastName', 'country', 'dob', 'address', 'phone', 'approved', 'active', 'city', 'speaks', 'aboutme', 'activity'];
    fields.forEach(async (field) => {
      transformed[field] = this[field];
    });
    
    transformed = {
      ...transformed,
      profile: transformed.profile ? getSignedUrl(transformed.profile) : null,
      originalProfile: transformed.originalProfile ? getSignedUrl(transformed.originalProfile) : null,
      cover: transformed.cover ? getSignedUrl(transformed.cover) : null,
      originalCover: transformed.originalCover ? getSignedUrl(transformed.originalCover) : null,
    };
    return transformed;
  },
});

EnthSchema.statics = {
  async saveEnthusiast(data) {
    const enth = new Enthusiast(data);
    const ex = await enth.save();
    return ex.transform();
  },
  async get(id) {
    const enth = await this.findOne({ user: id });
    if (!enth) throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    return enth.transform();
  },
  checkDuplication(error) {
    if (error.code === 11000 && (error.name === 'BulkWriteError' || error.name === 'MongoError')) {
      return new APIError({ message: 'Enthusiast profile of user already exists', status: CONFLICT });
    }
    return error;
  },
};

const Enthusiast = model('enthusiast', EnthSchema);

module.exports = Enthusiast;