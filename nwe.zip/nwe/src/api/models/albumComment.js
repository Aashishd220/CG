const { Schema, model, Types: { ObjectId } } = require('mongoose');

const AlbumCommentSchema = new Schema({
  user: {
    type: ObjectId,
    ref: 'users',
    required: true,
  },
  album: {
    type: ObjectId,
    ref: 'albums',
    required: true,
  },
  userName: {
    type: String,
    required: true,
  },
  thumbnail: {
    type: String,
    required: true,
  },
  comment: {
    type: String,
    required: true,
  },
}, { timestamps: true, versionKey: false });

module.exports = model('albumComments', AlbumCommentSchema);
