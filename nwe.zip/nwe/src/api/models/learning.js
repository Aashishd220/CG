const {
  Schema,
  model,
  Types: { ObjectId },
} = require("mongoose");

const LearningSchema = new Schema({
  expert: {
    type: ObjectId,
    ref: "expert",
    required: true,
  },
  cover: {
    type: String,
    // required: true,
  },
  originalCover: {
    type: String,
    // required: true,
  },
  title: {
    type: String,
    required: true,
  },
  duration: {
    type: Number,
  },
  durationType: {
    type: String,
    required: false,
  },
  price: {
    type: Number,
    required: true,
  },
  priceCurrency: {
    type: String,
    default: 'USD',
  },
  skill: {
    type: String,
    required: true,
  },
  activity: [
    {
      type: String
    },
  ],
  langauges: [
    {
      type: String,
      required: true
    },
  ],
  participants: {
    type: Number,
  },
  workshopType: {
    type: String,
    required: true,
  },
  workshopMedium: {
    type: String,
    required: true,
  },
  country: {
    type: String,
    required: false
  },
  address: {
    type: String,
    required: false,
  },
  meetingPoint: {
    type: String,
    required: false,
  },
  description: {
    type: String,
  },
  whatLearn: {
    type: String,
  },
  attend: {
    type: String,
  },
  accomodation: {
    type: String,
  },
  itenary: [
    {
      day: {
        type: String,
      },
      value: {
        type: String,
      },
    },
  ],
  inclusion: {
    type: String,
  },
  exclusion: {
    type: String,
  },
  cancellantion: {
    type: String,
  },
  extras: {
    type: String,
  },
  images: {
    type: Array,
    required: false,
  },
  likes: {
    type: Array,
    required: false,
  },
  location: {
    type: {
      type: String,
      enum: ["Point"],
      default: "Point",
      required: true,
    },
    coordinates: {
      type: [Number],
      required: true,
    },
  },
  dateType: {
    type: Number,
    required: true,
  },
  dateTime: [
    {
      fromDate: {
        type: Date,
      },
      fromTime: {
        type: Date,
      },
      toDate: {
        type: Date,
      },
      toTime: {
        type: Date,
      },
      price: {
        type: Number,
      },
      priceCurrency: {
        type: String,
        default: 'USD',
      },
    },
  ],
  accomodationPhotos: [String],
  active: {
    type: Boolean,
  },
  priceUSD: {
    type: Number,
    required: false
  }
});

LearningSchema.index({ location: "2dsphere" });

module.exports = model("learnings", LearningSchema);
