/* eslint-disable no-param-reassign */
const { Schema, model, Types: { ObjectId } } = require('mongoose');

const APIError = require('../../utils/APIError');
const { NOT_FOUND, NO_RECORD_FOUND, CONFLICT } = require('../../utils/constants');
const { getSignedUrl } = require('../../utils/helper');

const ExpertSchema = new Schema({
  user: {
    type: ObjectId,
    ref: 'users',
    required: true,
    unique: true,
  },
  profile: {
    type: String,
    // required: true,
  },
  originalProfile: {
    type: String,
    // required: true,
  },
  cover: {
    type: String,
    default: null,
  },
  originalCover: {
    type: String,
    default: null,
  },
  firstName: {
    type: String,
    required: true,
    index: true,
    minlength: 2,
    maxlength: 1024,
  },
  lastName: {
    type: String,
    required: true,
    index: true,
    minlength: 2,
    maxlength: 1024,
  },
  country: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  speaks: [
    {
      type: String,
      required: true,

    },
  ],
  experties: [
    {
      type: String,
      required: true,

    },
  ],
  skills: [
    {
      type: String,
      required: true,

    },
  ],
  bio: {
    type: String,
    minlength: 10,
    required: true,
  },
  awards: [
    {
      name: {
        type: String,
      },
      authority: {
        type: String,
      },
      year: {
        type: Number,
      },
    },
  ],
  professionalQualifications: [
    {
      name: {
        type: String,
      },
      authority: {
        type: String,
      },
      year: {
        type: Number,
      },
    },
  ],
  professionalExperience: [
    {
      name: {
        type: String,
      },
      role: {
        type: String,
      },
      year: {
        type: String,
      },
    },
  ],
  socialContributions: [
    {
      name: {
        type: String,
      },
      url: {
        type: String,
        required: false,
      },
      description: {
        type: String,
        required: false,
        default: '',
      },
    },
  ],
  booksAndPublications: [
    {
      name: {
        type: String,
      },
      url: {
        type: String,
      },
      cover: {
        type: String,
      },
    },
  ],
  company: {
    name: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    website: {
      type: String,
    },
    phone: {
      type: String,
    },
    businessEmail: {
      type: String,
    },
  },
  active: {
    type: Boolean,
    required: true,
    default: true,
  },
  approved: {
    type: Boolean,
    required: true,
    default: false,
  },
  deleted: {
    type: Boolean,
    required: true,
    default: false,
  },
  location: {
    type: {
      type: String,
      enum: ["Point"],
      default: "Point",
      required: false,
    },
    coordinates: {
      type: [Number],
      required: false,
    },
  },
}, { timestamps: true, versionKey: false });

ExpertSchema.method({
  transform() {
    let transformed = {};
    const fields = ['id', 'user', 'profile','originalProfile', 'lastName', 'firstName', 'country', 'city', 'speaks', 'experties', 'skills', 'bio', 'awards', 'professionalExperience', 'professionalQualifications', 'socialContributions', 'booksAndPublications', 'company', 'approved', 'active', 'cover', 'originalCover'];
    fields.forEach((field) => {
      transformed[field] = this[field];
    });
    // const add = transformed.company.address.split('+');
    let booksAndPublications = [];
    if (transformed.booksAndPublications && Array.isArray(transformed.booksAndPublications)) {
      booksAndPublications = transformed.booksAndPublications.map((book) => ({
        _id: book._id,
        name: book.name,
        url: book.url,
        cover: book.cover ? getSignedUrl(book.cover) : null,
      }));
    }


    transformed = {
      ...transformed,
      // company: {
      //   ...transformed.company,
      //   // address: { line1: add[0], line2: add[1] },
      // },
      profile: getSignedUrl(transformed.profile),
      originalProfile: getSignedUrl(transformed.originalProfile),
      cover: transformed.cover ? getSignedUrl(transformed.cover) : null,
      originalCover: transformed.originalCover ? getSignedUrl(transformed.originalCover) : null,
      booksAndPublications,
    };
    return transformed;
  },
});

ExpertSchema.statics = {
  async saveExpert(data) {
    const {
      // eslint-disable-next-line prefer-const
      address, website, companyname, phone, businessEmail,
      awards,
    } = data;

    const expert = new Expert({
      ...data,
      company: {
        phone,
        awards,
        website,
        address,
        businessEmail,
        name: companyname,
      },
    });
    const ex = await expert.save();
    return ex.transform();
  },
  async get(id) {
    const ex = await this.findById(id);
    if (!ex) throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    return ex.transform();
  },

  checkDuplication(error) {
    if (error.code === 11000 && (error.name === 'BulkWriteError' || error.name === 'MongoError')) {
      return new APIError({ message: 'Expert profile of user already exists', status: CONFLICT });
    }
    return error;
  },
};

const Expert = model('expert', ExpertSchema);

module.exports = Expert;