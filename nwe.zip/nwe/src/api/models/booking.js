const { Schema, model, Types: { ObjectId } } = require('mongoose');

const BookingSchema = new Schema({
  trip: {
    type: ObjectId,
    ref: 'trips',
  },
  learning: {
    type: ObjectId,
    ref: 'learnings',
  },
  type: {
    type: String,
  },
  expert: {
    type: ObjectId,
    ref: 'expert',
    required: true,
  },
  message: {
    type: String,
    required: false,
  },
  phone: {
    type: String,
    required: false,
  },
  people: {
    type: String,
    required: false,
  },
  date: {
    type: String,
    required: false,
  },
  user: {
    type: ObjectId,
    ref: 'users',
    required: true,
  },
  payment: {
    type: Boolean,
    default: false,
  },
  confirm: {
    type: Boolean,
    default: false,
  },
  slot: {
    type: Number,
    default: 0
  },
  paymentDate: {
    type: Date
  },
  confirmDate: {
    type: Date
  },
  bookmark: {
    type: Boolean,
    default: false
  },
  hide: {
    type: Boolean,
    default: false
  }
}, { timestamps: true, versionKey: false });

module.exports = model('bookings', BookingSchema);
