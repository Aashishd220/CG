const {
  Schema,
  model,
  Types: { ObjectId },
} = require("mongoose");

const { getSignedUrl } = require("../../utils/helper");

const TripSchema = new Schema({
  expert: {
    type: ObjectId,
    ref: "expert",
    required: true,
  },
  cover: {
    type: String
  },
  originalCover: {
    type: String
  },
  images: {
    type: Array,
    required: false,
  },
  likes: {
    type: Array,
    required: false,
  },
  title: {
    type: String,
    required: true,
  },
  activity: [String],
  price: Number,
  priceCurrency: {
    type: String,
    default: 'USD',
  },
  duration: Number,
  durationType: {
    type: String,
    required: false,
  },
  type: [String],
  suitable: String,
  participants: Number,
  language: String,
  difficulty: String,
  skill: String,
  description: String,
  whatLearn: String,
  attend: String,
  dateTime: [
    {
      fromDate: String,
      toDate: String,
      fromTime: String,
      toTime: String,
      price: Number,
      priceCurrency: {
        type: String,
        default: 'USD',
      },
    },
  ],
  country: String,
  address: {
    type: String,
    required: false,
  },
  dateType: {
    type: Number,
    required: true,
  },
  meetingPoint: String,
  location: {
    type: {
      type: String,
      enum: ["Point"],
      default: "Point",
      required: true,
    },
    coordinates: {
      type: [Number],
      required: true,
    },
  },
  accomodation: {
    type: String,
  },
  itenary: [
    {
      day: {
        type: String,
      },
      value: {
        type: String,
      },
    },
  ],
  inclusion: {
    type: String,
  },
  exclusion: {
    type: String,
  },
  cancellations: {
    type: String,
  },
  extras: {
    type: String,
  },
  accomodationPhotos: [String],
  active: {
    type: Boolean,
  },
  priceUSD: {
    type: Number,
    required: false
  }
});

TripSchema.index({ location: "2dsphere" });

TripSchema.method({
  transform() {
    const transformed = {};
    const fields = [
      "expert",
      "cover",
      "originalCover",
      "extras",
      "cancellations",
      "exclusion",
      "inclusion",
      "overview",
      "itinerary",
      "location",
      "meetingPoint",
      "title",
      "duration",
      "durationType",
      "price",
      "priceCurrency",
      "type",
      "suitable",
      "activity",
      "difficulty",
      "dates",
      "id",
    ];
    fields.forEach((field) => {
      transformed[field] = this[field];
    });
    transformed.cover = getSignedUrl(transformed.cover);
    transformed.originalCover = getSignedUrl(transformed.originalCover);
    return transformed;
  },
});

module.exports = model("trips", TripSchema);
