const { Schema, model } = require('mongoose');

const ListSchema = new Schema({
  title: {
    type: String,
    required: true,
    lowercase: true,
  },
  type: {
    type: String,
    index: true,
    enum: ['experties', 'trips', 'activities'],
    required: true,
  },
  active: {
    type: Boolean,
    default: true,
    required: true,
  },
}, { timestamps: true, versionKey: false });

ListSchema.method({
  transform() {
    const transformed = {};
    const fields = ['id', 'title', 'type', 'active', 'createdAt'];
    fields.forEach((field) => {
      transformed[field] = this[field];
    });
    return transformed;
  },
});

module.exports = model('lists', ListSchema);
