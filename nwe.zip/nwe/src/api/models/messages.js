const { Schema, model, Types: { ObjectId } } = require('mongoose');

const MessageSchema = new Schema({
  trip: {
    type: ObjectId,
    ref: 'trips',
  },
  learning: {
    type: ObjectId,
    ref: 'learnings',
  },
  type: {
    type: String,
  },
  expert: {
    type: ObjectId,
    ref: 'expert',
    required: true,
  },
  message: {
    type: String,
    required: false,
  },
  media: {
    type: Array,
    required: false,
  },
  reply: {
    type: String,
  },
  user: {
    type: ObjectId,
    ref: 'users',
    required: true,
  },
  sender_userid: {
    type: ObjectId,
  },
  receiver_userid: {
    type: ObjectId,
  },
  status: {
    type: Boolean,
    default: false,
  },
  expert_hide: {
    type: Boolean,
    default: false,
  },
  enthusiast_hide: {
    type: Boolean,
    default: false,
  },
  expert_bookmark: {
    type: Boolean,
    default: false,
  },
  enthusiast_bookmark: {
    type: Boolean,
    default: false,
  },
  enthusiast_delete :{
    type: Boolean,
    default: false,
  },
  expert_delete: {
    type: Boolean,
    default: false,
  }
}, { timestamps: true, versionKey: false });

module.exports = model('messages', MessageSchema);
