const { Schema, model } = require('mongoose');

const CurrencySchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    alpha2Code: {
      type: String,
      required: true,
    },
    alpha3Code: {
      type: String,
      required: true,
    },
    nativeName: {
      type: String,
      required: true,
    },
    region: {
      type: String,
      required: true,
    },
    subRegion: {
      type: String,
      required: true,
    },
    latitude: {
      type: String,
      required: true,
    },
    longitude: {
      type: String,
      required: true,
    },
    area: {
      type: Number,
      required: true,
    },
    numericCode: {
      type: Number,
      required: true,
    },
    nativeLanguage: {
      type: String,
      required: true,
    },
    currencyCode: {
      type: String,
      required: true,
    },
    currencyName: {
      type: String,
      required: true,
    },
    currencySymbol: {
      type: String,
      required: true,
    },
    flag: {
      type: String,
      required: true,
    },
    flagPng: {
      type: String,
      required: true,
    },
    base: {
      type: String,
      required: true,
      default: 'USD',
    },
    rate: {
      type: Number,
      required: true,
    },
  },
  { timestamps: true, versionKey: false, collection: 'currency' },
);

CurrencySchema.method({
  transform() {
    const transformed = {};
    const fields = ['currencyName', 'currencyCode', 'currencySymbol', 'base', 'rate'];
    fields.forEach((field) => {
      transformed[field] = this[field];
    });
    return transformed;
  },
});

module.exports = model('currency', CurrencySchema);
