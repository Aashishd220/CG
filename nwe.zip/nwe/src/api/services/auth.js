const crypto = require('crypto');

/**
 * App Imports
 */
const User = require('../models/user');
const Experts = require('../models/expert');
const Enthusiast = require('../models/enthusiast');
const LoginDeatils = require('../models/loginDetails');
const path = require("path");
const APIError = require('../../utils/APIError');
const { ResetEmail, VerificationEmail, AdminVerificationEmail, ConfirmEmail, ChangePassword } = require('../../utils/email');
const { RESET_URL, VERIFY_URL } = require('../../config/env-vars');
const {
  NOT_FOUND, NO_RECORD_FOUND, ACCEPTED,
  LINK_EXPIRED, BAD_REQUEST, EMAIL_NOT_EXISTS, EMAIL_EXISTS,
  INVALID_PASSWORD, UNAUTHORIZED, INVALID_CREDENTIALS,
} = require('../../utils/constants');

exports.Register = async (userData, origin) => {
  try {
    const us = new User({ ...userData, role: userData.type });
    const token = `${us.id}.${crypto.randomBytes(40).toString("hex")}`;
    us.verificationToken = token;
    const savedUser = await us.save();
    const link = `${origin}/verify-email/${token}`;
    await VerificationEmail(us.email, link);
    await AdminVerificationEmail(us.email);
    return { token: us.token(), user: savedUser.transform() };
  } catch (err) {
    throw User.checkDuplication(err);
  }
};

exports.Login = async (userData) => {
  const { user, accessToken } = await User.ValidateUserAndGenerateToken(userData);
  await LoginDeatils.deleteMany({user: user.id});
  const d = new LoginDeatils({user: user.id, last_activity: new Date()});
  await d.save();
  return { token: accessToken, user };
};

exports.oAuth = async (data) => {
  try {
    const us = {
      ...data,
      provider: { id: data.id, type: data.provider },
      loginType: data.provider,
    };
    const { user, accessToken } = await User.LoginOrCreateUser(us);
    return { token: accessToken, user };
  } catch (err) {
    throw User.checkDuplication(err);
  }
};

exports.ForgotPassword = async (email, origin) => {
  const us = await User.findOne({ email });
  if (!us) throw new APIError({ status: NOT_FOUND, message: NO_RECORD_FOUND });
  let userData = await User.findById(us._id);
  if (us.role === "enthusiasts") {
    userData = await Enthusiast.findOne({ user: us._id });
  } else if (us.role === "expert") {
    userData = await Experts.findOne({ user: us._id });
  }
  const token = `${us._id}.${crypto.randomBytes(40).toString("hex")}`;
  us.resetPassword = {
    token,
    expiresIn: new Date().getTime() + 30 * 60 * 1000,
  };
  await us.save();
  const link = `${origin}/reset-password/${token}`;
  await ResetEmail(
    userData && userData.firstName ? userData.firstName : email,
    email,
    link
  );
};

exports.CheckTokenExpiration = async (data) => {
  const us = await User.findOne({ "resetPassword.token": data });
  if (!us) throw new APIError({ status: NOT_FOUND, message: NO_RECORD_FOUND });
  console.log("checking expiry ...");

  const {
    resetPassword: { expiresIn },
  } = us;
  if (+expiresIn < new Date().getTime()) {

    console.log("EXPIRED TOKEN");
    throw new APIError({ status: BAD_REQUEST, message: LINK_EXPIRED });
  }
  return true;
};

exports.ResetPassword = async (token, password) => {
  const us = await User.findOne({ 'resetPassword.token': token });
  if (!us) throw new APIError({ status: NOT_FOUND, message: NO_RECORD_FOUND });
  us.password = password;
  us.resetPassword.token = null;
  us.resetPassword.expiresIn = 0;
  await us.save();
  return true;
};

exports.ChangePassword = async (id, data, origin) => {
  const { opassword, npassword } = data;
  const us = await User.findById(id);
  const isValid = await us.matchPassword(opassword);
  if (!isValid) throw new APIError({ message: INVALID_PASSWORD, status: UNAUTHORIZED });
  let userData = {};
  if (us.role === 'enthusiasts') {
    userData = await Enthusiast.findOne({user: us._id});
  } else if (us.role === 'expert') {
    userData = await Experts.findOne({user: us._id});
  }
  us.password = npassword;
  const link = `${origin}/login`;
  await ChangePassword(userData.firstName, us.email, link);
  await us.save();
  return us.transform();
};

exports.ConfirmEmail = async (id, data) => {
  const { cemail, nemail } = data;
  const us = await User.findOne({email: nemail});
  const oldus = await User.findById(id);
  console.log("111324567897654321`2345678", oldus, cemail);
  if (oldus && (oldus.email !== cemail)){
    throw new APIError({ message: EMAIL_NOT_EXISTS, status: ACCEPTED });
  } else if (us && us.email){
    throw new APIError({ message: EMAIL_EXISTS, status: ACCEPTED });
  }
};

exports.updatePreferredCurrency = async (id, currency) => {
  const data = User.findByIdAndUpdate(id, { $set: { preferredCurrency: currency } });
  return data;
};

exports.ConfirmPassword = async (id, data, origin) => {
  const { password, email } = data;
  const us = await User.findById(id);
  const token = `${us.id}.${crypto.randomBytes(40).toString("hex")}`;
  us.verificationToken = token;
  us.changeEmail = email;
  const link = `${origin}/verify-email/${token}`;
  let userData = await User.findById(id);
  if (us.role === "enthusiasts") {
    userData = await Enthusiast.findOne({ user: us._id });
  } else if (us.role === "expert") {
    userData = await Experts.findOne({ user: us._id });
  }
  const isValid = await us.matchPassword(password);
  let name = email;
  if (userData && (userData.firstName || userData.lastName)) {
    name =
      (userData.firstName ? userData.firstName : "") +
      " " +
      (userData.lastName ? userData.lastName : "");
  }
  if (!isValid)
    throw new APIError({ message: INVALID_PASSWORD, status: UNAUTHORIZED });
  await ConfirmEmail(name, email, link);
  await us.save();
  return us.transform();
};

exports.VerifyProfile = async (token) => {
  const us = await User.findOne({ verificationToken: token });
  if (!us) throw new APIError({ status: NOT_FOUND, message: NO_RECORD_FOUND });
  if (us.changeEmail) {
    us.email = us.changeEmail;
  }
  us.verificationToken = null;
  us.changeEmail = null;
  us.isVerified = true;
  await us.save();
  return true;
};

exports.AdminLogin = async (data) => {
  const { email, password } = data;
  const us = await User.findOne({ email, role: 'admin' });
  if (!us) throw new APIError({ message: NO_RECORD_FOUND, status: UNAUTHORIZED });
  if (!await us.matchPassword(password)) {
    throw new APIError({ message: INVALID_CREDENTIALS, status: UNAUTHORIZED });
  }
  return { user: us.transform(), accessToken: us.token() };
};

exports.Logout = async (userId) => {
  let id = '';

  const expert = await Experts.findOne({ _id: userId });
  if(expert) {
    id = expert.user.toString();
  }
  const enthus = await Enthusiast.findOne({ user: userId });
  if(enthus) {
    id = enthus.user.toString();
  }
  const data = await LoginDeatils.deleteMany({ user: id});
  return { data };
};

exports.removeLoginDeatils = async (id) => {
  const data = await LoginDeatils.updateMany( { user: id }, {last_activity: new Date()});
  return data;
}


exports.updateRole = async (id, data) => {
  const us = await User.findById(id);
  us.tmpRole = data.role;
  await us.save();
  return us.transform();
};
