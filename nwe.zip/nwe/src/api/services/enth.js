const Enthusiest = require('../models/enthusiast');
const Expert = require('../models/expert');
const Trip = require('../models/trips');
const Messages = require('../models/messages');
const User = require('../models/user');
const LoginDeatils = require('../models/loginDetails');
const Learning = require('../models/learning');
const APIError = require('../../utils/APIError');
const { NO_RECORD_FOUND, NOT_FOUND } = require('../../utils/constants');
const { getSignedUrl } = require('../../utils/helper');
const logger = require('../../config/logger');

exports.create = async (data) => {
  try {
    const en = { ...data };
    const enth = await Enthusiest.saveEnthusiast(en);
    await User.findByIdAndUpdate(data.user, {
      $set: { role: 'enthusiasts', isCompleted: true },
    });
    return enth;
  } catch (err) {
    throw Enthusiest.checkDuplication(err);
  }
};

exports.update = async (id, data) => {
  const enth = await Enthusiest.findOneAndUpdate(
    { user: id },
    {
      $set: {
        ...data
      },
    },
    { new: true },
  );
  if (!enth)
    throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });

  return enth.transform();
};

exports.get = async (id) => {
  const data = await Enthusiest.get(id);
  return data;
};

exports.UploadCover = async (id, cover,check) => {
  if(check==='upload'){
    const data = await Enthusiest.findOneAndUpdate({ user: id }, { $set: { cover,originalCover:cover } }, { new: true });
    return getSignedUrl(data.cover);
  }
 else if(check==='delete'){
	 const data = await Enthusiest.findOneAndUpdate({ user: id }, { $set: { cover:'',originalCover:'' } }, { new: true });
	 return '';
 } 
  else{
    const data = await Enthusiest.findOneAndUpdate({ user: id }, { $set: { cover:cover } }, { new: true });
    return getSignedUrl(data.cover);
  }
};

exports.getAllMessagesEnthu = async (id) => {
  const msg = await Messages.find({ user: id });
  const allMsgs = await Promise.all(
    msg.map(async (m) => {
      const enth = await Expert.findById(m.expert);
      return {
        id: m._id,
        message: m.message,
        user: {
          name: `${enth.firstName} ${enth.lastName}`,
          profile: enth.profile ? getSignedUrl(enth.profile) : null,
        },
        reply: m.reply,
        createdAt: m.createdAt,
      };
    })
  );
  return allMsgs;
};

exports.getAllChatSession = async (id, name, status) => {

  let flag = false;
  if (status === 'hidden') {
    flag = true;
  }
  const query = {
    $or: [{ sender_userid: id }, { receiver_userid: id }], enthusiast_hide: flag, enthusiast_delete: false
  };

  if (status === 'fav') {
    query.enthusiast_bookmark = true;
  }

  const msg = await Messages.find(query).populate('trip').populate('learning').populate('expert').sort({ createdAt: -1 });

  const allMsgs = await Promise.all(
    msg.map(async (m) => {
      const status = await LoginDeatils.findOne({ user: m.expert.user.toString() });

      return {
        id: m._id,
        message: m.message,
        user: {
          name: `${m.expert.firstName} ${m.expert.lastName}`,
          profile: m.expert.profile ? getSignedUrl(m.expert.profile) : null,
          id: m.expert.user,
          country: m.expert.country,
        },
        status,
        trip: m.trip,
        learning: m.learning,
        reply: m.reply,
        createdAt: m.createdAt,
        bookmark: m.enthusiast_bookmark,
        type: m.type,
        sender_userid: m.sender_userid,
        receiver_userid: m.receiver_userid,
      };
    }),
  );
  const finalMsg = [];
  allMsgs.forEach((msgA) => {
    let index;
    if (msgA.type === 'trip') {
      index = finalMsg.findIndex((f) => (f.trip && f.trip.id === msgA.trip.id));
    }
    if (msgA.type === 'learning') {
      index = finalMsg.findIndex((f) => (f.learning && f.learning.id === msgA.learning.id));
    }
    if (index < 0) {
      finalMsg.push(msgA);
    }
  });

  let messages = [];
  for (let i = 0; i < finalMsg.length; i++) {
    const msg = finalMsg[i];
    const condition = msg.type === 'learning' ? { learning: msg.learning._id } : { trip: msg.trip._id };
    const rows = await Messages.find({
      $and: [
        { sender_userid: msg.user.id },
        { receiver_userid: id },
        condition,
        { status: false }
      ],
    });
    msg.unread = rows.length;
    messages.push(msg);
  }
  if (name && name.trim().length > 0) {
    messages = messages.filter((msg) => {
      const string = msg.type === 'trip' ? msg.trip.title : msg.learning.title;
      return msg.user.name.toLowerCase().includes(name.trim().toLowerCase()) || string.toLowerCase().includes(name.trim().toLowerCase());
    })
  }
  return messages.sort((a, b) => b.unread - a.unread);
};

exports.getChatMessages = async (enthuId, expertId, tripId, type, learning) => {
  const condition = type === 'trip' ? { trip: tripId } : { learning: learning };
  const msg = await Messages.find({
    $or: [
      {
        $and: [
          { sender_userid: enthuId },
          { receiver_userid: expertId },
        ],
      },
      {
        $and: [
          { sender_userid: expertId },
          { receiver_userid: enthuId },
        ],
      },
    ],
    $and: [condition],
  }).sort({ createdAt: 1 });
  const allMsgs = await Promise.all(
    msg.map(async (m) => {
      let type = '';
      if (m.sender_userid.toString() === enthuId.toString()) {
        type = 'send';
      }
      if (m.receiver_userid.toString() === enthuId.toString()) {
        type = 'receive';
      }
      const enth = await Expert.findById(m.expert);
      const trip = m.type === 'trip' ? await Trip.findById(m.trip) : null;
      const learning = m.type === 'learning' ? await Learning.findOne({ _id: m.learning }) : null;
      return {
        id: m._id,
        message: m.message,
        user: {
          name: `${enth.firstName} ${enth.lastName}`,
          profile: enth.profile ? getSignedUrl(enth.profile) : null,
          originalProfile: enth.originalProfile ? getSignedUrl(enth.originalProfile) : null,
          country: enth.country,
        },
        trip,
        reply: m.reply,
        createdAt: m.createdAt,
        type,
        status: m.status,
        media: m.media,
        learning
      };
    }),
  );
  return allMsgs;
};

exports.getAllChatSessionCount = async (id) => {
  const msg = await Messages.find({
    receiver_userid: id, enthusiast_hide: false, status: false,
  }).sort({ createdAt: 1 });
  return msg.length;
};