/* eslint-disable radix */
const Booking = require('../models/booking');
const Expert = require('../models/expert');
const Trip = require('../models/trips');
const Learning = require('../models/learning');
const Enthusiast = require('../models/enthusiast');

const { getSignedUrl } = require('../../utils/helper');

exports.SendMessage = async (data) => {
  const messages = new Booking(data);
  const smsg = await messages.save();
  return smsg;
};

exports.getEnthBooking = async (id, name, status) => {
  const expert = await Expert.findOne({ _id: id });

  const obj = { expert: id, payment:true, confirm: true};

  if(status === 'hidden') {
    obj.hide = true;
  } 
  if(status === 'fav') {
    obj.bookmark = true;
  }

  const msg = await Booking.find(obj).populate('trip').populate('learning').populate('expert').populate('enthusiast').sort({ createdAt: -1 });

  const allMsgs = await Promise.all(msg.map(async (m) => {
    const enthusiast = await Enthusiast.findOne({ user: m.user });
    const d = m.trip || m.learning;
    const image = getSignedUrl(d.cover);
    return {
      bookmark: m.bookmark,
      id: m._id,
      message: m.message,
      slot: m.slot,
      paymentDate: m.paymentDate,
      confirmDate: m.confirmDate,
      phone: m.phone,
      people: m.people,
      date: m.date,
      trip: m.trip,
      learning: m.learning,
      image: image,
      user: {
        name: enthusiast ? enthusiast.firstName : enthusiast.firstName,
        profile: enthusiast ? enthusiast.profile ? getSignedUrl(enthusiast.profile) : null : getSignedUrl(m.expert.cover),
      },
      createdAt: m.createdAt,
    };
  }));
  
  let finalBooking = [];

  allMsgs.forEach((msgA) => {
    let index;
    if(msgA.trip) {
      index = finalBooking.findIndex((f) => ( f.trip && f.trip._id === msgA.trip._id ) );  
    }
    if(msgA.learning) {
      index = finalBooking.findIndex((f) => ( f.learning && f.learning._id === msgA.learning._id ) );  
    }
    if (index < 0) {

      finalBooking.push(msgA);
    }
  });

  if(name && name.trim().length > 0) {
     finalBooking = finalBooking.filter((msg) => {
      const string = msg.trip ? msg.trip.title : msg.learning.title;
      return string.includes(name.trim());
    })  
  }

  return finalBooking.sort((a, b) => b.createdAt - a.createdAt);
};

exports.getSlotsData = async (id) => {
  const bookings = await Booking.find({$or: [ {learning: id}, {trip: id}], payment: true, confirm:true }).populate('learning').populate('trip').populate('expert').sort({ createdAt: -1 });

  const books = await Promise.all(bookings.map(async (m) => {

    const enthusiast = await Enthusiast.findOne({ user: m.user });
    return {
      id: m._id,
      expert: m.expert || null,
      slot: m.slot,
      paymentDate: m.paymentDate,
      confirmDate: m.confirmDate,
      phone: m.phone,
      people: m.people,
      user: {
         id: enthusiast.user,
         name: enthusiast.firstName,
         profile: getSignedUrl(enthusiast.profile),
      },
      date: m.date,
      // enthusiast: enthusiast,
      createdAt: m.createdAt,
      trip: m.trip || null,
      learning: m.learning || null,
    };
  }));  

  const slotData = [];
  for (let index = 0; index < books.length; index++) {
    let book = books[index];

    const findex = slotData.findIndex( (s) => s.slot === book.slot);
    if(findex !== -1) {
      slotData[findex].peoples += book.people ? parseInt(book.people) : 0;
      slotData[findex].data.push(book);
    } else {
      const object = {slot: book.slot, peoples: parseInt(book.people), data: []};
      object.data.push(book);
      slotData.push(object);
    }
  }  
  
  return slotData;
}