/* eslint-disable radix */
const Subscribe = require('../models/subscribe');
const { subscribeEmail } = require('../../utils/email');
const { EC_ADMIN_EMAIL } = require("../../utils/constants");
exports.checkEmailExistOrSave = async (data) => {

  let response = "";
  //Conditon is check wheter the email is already exists or not
  const isExists = await Subscribe.findOne({ email: data.email });
  if (isExists) {
    if (isExists.subscribe == true) {
      response = "exists";
    } else {
      //If Email already exist with the subscribe status false, it will update to true
      const updated = await Subscribe.findOneAndUpdate({ _id: isExists._id }, { subscribe: true });
      response = updated;
    }
  } else {
    //Add new subscribe entry to database with subscribe status true
    const subscribe = new Subscribe(data);
    const subs = await subscribe.save();

    const resp = await subscribeEmail(data.email);

    response = resp;
  }
  return response;
};

