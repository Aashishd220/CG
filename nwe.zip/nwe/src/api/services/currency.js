const Currency = require("../models/currency");

exports.getAllCurrency = async () => {
  const currencies = await Currency.find({});
  return currencies.map((currency) => currency.transform());
};

exports.getConversionRate = async (currencyCodes) => {
  const currencies = await Currency.find({
    currencyCode: { $in: currencyCodes },
  });
  return currencies.map((currency) => currency.transform());
};
