const AlbumComment = require('../models/albumComment');

exports.create = async (data) => {
  const res = new AlbumComment(data);
  const sa = await res.save();
  return sa;
};

exports.update = async (data) => {
  const savedData = await AlbumComment.findByIdAndUpdate(data.id, { $set: data });
  return savedData
};

exports.getAllComment = async (data) => {
  const albums = await AlbumComment.find({ album: data.albumId });
  return albums
};
