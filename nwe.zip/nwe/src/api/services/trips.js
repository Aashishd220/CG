/* eslint-  able radix */
const moment = require('moment');
const Trip = require('../models/trips');
const TripLikes = require('../models/tripsLikes');
const Message = require('../models/messages');
const Enthusiast = require('../models/enthusiast');
const User = require('../models/user');
const Learning = require('../models/learning');
const { getSignedUrl, UploadFiles, UploadAccommoFiles, UploadFile } = require('../../utils/helper');
const { MessageEmail } = require('../../utils/email');
const logger = require('../../config/logger');
const { convertCurrency } = require('../../utils/currency');

exports.create = async (data) => {
  const trip = {
    ...data,
    dateTime: JSON.parse(data.dateTime),
    activity: JSON.parse(data.activity),
    itenary: JSON.parse(data.itenary),
    location: {
      type: 'Point',
      coordinates: JSON.parse(data.coordinates),
    },
    active: data.active,
  };
  if (data.type != "undefined") {
    trip.type = JSON.parse(data.type)
  }

  const res = new Trip(trip);
  const savedTrip = await res.save();
  return savedTrip.transform();
};

exports.tripLikeCreate = async (data) => {
  const tripLike = {
    ...data,
  };
  const like = await TripLikes.find(tripLike);
  let res;
  if (like && like[0]) {
    res = await TripLikes.findOneAndDelete(tripLike);
    return { ans: "dislike" };
  }
  res = new TripLikes(tripLike);

  const savedTripLikes = await res.save();
  return { ans: "like" };
};

exports.update = async (trip, data) => {

  delete data.accomodationPhotos;

  const obj2Update = {
    ...data,
    dateTime: JSON.parse(data.dateTime),
    activity: JSON.parse(data.activity),
    // type: JSON.parse(data.type),
    itenary: JSON.parse(data.itenary),
    location: {
      type: 'Point',
      coordinates: JSON.parse(data.coordinates),
    },
  };
  if (data.type != "undefined") {
    obj2Update.type = JSON.parse(data.type)
  }
  const updatedData = Object.assign(trip, obj2Update);
  logger.info(`Values to update ${updatedData}`);
  const savedData = await updatedData.save();
  return savedData.transform();
};

exports.inActive = async (id) => {
  const savedData = await await Trip.findByIdAndUpdate(id, { $set: { active: false } });
  return savedData
};

exports.active = async (id) => {
  const savedData = await await Trip.findByIdAndUpdate(id, { $set: { active: true } });
  return savedData
};

exports.getMyTrips = async (id, preferredCurrency) => {
  const trips = await Trip.find({ expert: id });
  // return trips.map((t) => ({ cover: getSignedUrl(t.cover), ...t }));
  return Promise.all(trips.map(async (t) => ({
    id: t._id,
    cover: getSignedUrl(t.cover),
    title: t.title,
    duration: t.duration,
    durationType: t.durationType,
    price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
    priceCurrency: preferredCurrency,
    location: t.meetingPoint,
    difficulty: t.difficulty,
    activity: t.activity,
    active: t.active,
    dateTime: t.dateTime,
    dateType: t.dateType,
    address: t.address,
    country: t.country,
    likes: await TripLikes.find({ tripId: t._id }),
    images: t.images.map((image) => getSignedUrl(image)),
    accomodationPhotos: t.accomodationPhotos.map((image) => getSignedUrl(image)),
    pageType: 'trip'
  })))
};

exports.getRecentTrips = async (preferredCurrency = 'USD') => {
  const trips = await Trip.find({ active: { $eq: true } }).sort({ createdAt: -1 });
  const parsedTrips = await Promise.all(trips.map(async (t) => ({
    id: t._id,
    cover: getSignedUrl(t.cover),
    title: t.title,
    duration: t.duration,
    durationType: t.durationType,
    price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
    priceCurrency: preferredCurrency,
    location: t.meetingPoint,
    difficulty: t.difficulty,
    activity: t.activity,
    active: t.active,
    dateTime: t.dateTime,
    dateType: t.dateType,
    address: t.address,
    country: t.country,
    skill: t.skill,
    likes: await TripLikes.find({ tripId: t._id }),
    images: t.images.map((image) => getSignedUrl(image)),
    accomodationPhotos: t.accomodationPhotos.map((image) => getSignedUrl(image)),
    pageType: 'trip'
  })));
  return {
    trips: parsedTrips,
  };
};

exports.updateTripsOriginalCover=async (trip)=>{
  if(trip.unsignedCover){
		const data = await Trip.findOneAndUpdate({ _id: trip.id },{originalCover:trip.unsignedCover}  , function (err, result) {
			if (err) {
				console.log(err)
			}
			else {
				return result;
			}
		});
	}
}
exports.getTripsAll = async (data, preferredCurrency) => {
  let {
    activity, type, month, price, suitable, difficulty, perPage, currentPage, sortBy, country,
  } = data;

  let Obj = {};
  if (price) {
    const p = price.split('-');
    Obj.price = {
      $gte: parseInt(p[0]),
      $lte: parseInt(p[1]),
    };
  }
  if (type) {
    type = JSON.parse(type);
    type.forEach(function (opt) {
      type.push(new RegExp(opt, "i"));
    });
    Obj.type = { $in: type };
  }

  if (activity && activity.length) {
    activity = JSON.parse(activity);
    activity.forEach(function (opt) {
      activity.push(new RegExp(opt, "i"));
    });
    Obj.activity = { $in: activity };
  }

  if (difficulty) {
    const diffi = difficulty.split('-');
    Obj.difficulty = {
      $gte: parseInt(diffi[0]),
      $lte: parseInt(diffi[1]),
    };
  }

  if (suitable && suitable.length) {
    suitable = JSON.parse(suitable);
    suitable.forEach(function (opt) {
      suitable.push(new RegExp(opt, "i"));
    });
    Obj.suitable = { $in: suitable };
  }

  if (country) {
    Obj.country = { '$regex': country, $options: 'i' };

  }

  if (month) {
    const dates = month.split('-');
    Obj = {
      ...Obj,
      $or: [
        {
          'dates.from': {
            $gte: new Date(`${dates[1]}-${dates[2]}-${dates[3]}`).toISOString(),
            $lte: new Date(`${dates[1]}-${dates[2]}-${dates[0]}`).toISOString(),
          },
        },
      ],
    };
  }

  Obj.active = { $eq: true }

  currentPage = parseInt(currentPage);
  perPage = parseInt(perPage);

  const trips = await Trip.find(Obj)
    .skip(currentPage > 0 ? ((currentPage - 1) * perPage) : 0)
    .limit(perPage)
    .sort({ title: sortBy });

  const count = await Trip.find(Obj).countDocuments();

  const parsedTrips = await Promise.all(trips.map(async (t) => ({
    id: t._id,
    cover: getSignedUrl(t.cover),
    title: t.title,
    duration: t.duration,
    durationType: t.durationType,
    price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
    priceCurrency: preferredCurrency,
    location: t.country,
    difficulty: t.difficulty,
    activity: t.activity,
    active: t.active,
    dateTime: t.dateTime,
    dateType: t.dateType,
    address: t.address,
    country: t.country,
    skill: t.skill,
    likes: await TripLikes.find({ tripId: t._id }),
    images: t.images.map((image) => getSignedUrl(image)),
    accomodationPhotos: t.accomodationPhotos.map((image) => getSignedUrl(image)),
    pageType: 'trip',
    unsignedCover:t.cover
  })));
  return {
    trips: parsedTrips,
    count,
  };
};

exports.SendMessage = async (data) => {
  const messages = new Message(data);
  const smsg = await messages.save();
  let messageName = '';

  if (smsg.type === 'trip') {
    const trip = await Trip.findOne({ _id: data.trip });
    messageName = trip.title;
  }
  if (smsg.type === 'learning') {
    const learning = await Learning.findOne({ _id: data.learning });
    messageName = learning.title;
  }
  const mailData = await smsg.populate({
    path: 'expert',
    model: 'expert',
    select: {
      _id: 1, firstName: 1, lastName: 1, user: 1, profile: 1, country: 1,
    },
    populate: {
      path: 'user',
      model: 'users',
      select: { email: 1 },
    },
  }).execPopulate();
  const name = `${mailData.expert.firstName} ${mailData.expert.lastName}`;
  const profile = getSignedUrl(mailData.expert.profile);
  const dateString = moment(smsg.createdAt).format('DD, MMMM YY, h:mm a') + ',' + mailData.expert.country;

  if (mailData.message.trim().length === 0 && mailData.media.length > 0) {
    mailData.message = 'You have an unopened attachment in this message. Please login in your account to view it.'
  }

  await MessageEmail(name, mailData.expert.user.email, mailData.message, profile, messageName, dateString);
  return smsg;
};

exports.SendMessageEnthus = async (data) => {
  const messages = new Message(data);
  const smsg = await messages.save();
  const enthusiast = await Enthusiast.findOne({ user: data.receiver_userid });
  const user = await User.findOne({ _id: data.receiver_userid });
  let messageName = '';
  if (data.type === 'trip') {
    const trip = await Trip.findOne({ _id: smsg.trip });
    messageName = trip.title;
  }
  if (data.type === 'learning') {
    const learning = await Learning.findOne({ _id: smsg.learning });
    messageName = learning.title;
  }
  const mailData = await smsg.populate({
    path: 'expert',
    model: 'expert',
    select: {
      _id: 1, firstName: 1, lastName: 1, user: 1,
    },
    populate: {
      path: 'receiver_userid',
      model: 'users',
      select: { email: 1 },
    },
  }).execPopulate();

  const name = `${enthusiast.firstName}`;
  const profile = getSignedUrl(enthusiast.profile);
  const dateString = moment(smsg.createdAt).format('DD, MMMM YY, h:mm a') + ',' + enthusiast.country;
  if (mailData.message.trim().length === 0 && mailData.media.length > 0) {
    mailData.message = 'You have an unopened attachment in this message. Please login in your account to view it.'
  }
  await MessageEmail(name, user.email, mailData.message, profile, messageName, dateString);
  return smsg;
};

exports.UpcomingTrips = async (id, preferredCurrency) => {
  const trips = await Trip.find({ expert: id }).sort({ createdAt: -1 });
  return Promise.all(
    trips.map(async (t) => ({
      id: t._id,
      cover: getSignedUrl(t.cover),
      title: t.title,
      duration: t.duration,
      durationType: t.durationType,
      price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
      priceCurrency: preferredCurrency,
      type: t.type,
      difficulty: t.difficulty,
      suitable: t.suitable,
      overview: t.overview,
      dateTime: await Promise.all(
        t.dateTime.map(async (d) => ({
          ...d,
          price: await convertCurrency(
            d.priceCurrency,
            preferredCurrency,
            d.price,
          ),
          priceCurrency: preferredCurrency,
        })),
      ),
      country: t.country,
      activity: t.activity,
      active: t.active,
      dateType: t.dateType,
      address: t.address,
      likes: await TripLikes.find({ tripId: t._id }),
      images: t.images.map((image) => getSignedUrl(image)),
      accomodationPhotos: t.accomodationPhotos.map((image) => getSignedUrl(image)),
      pageType: "trip",
    })),
  );
};

exports.GetTravelMaps = async (id) => {
  const mapCoord = await Trip.find({ expert: id }).select('location.coordinates');
  return mapCoord.map((c) => ({ coordinates: c.location.coordinates, id: c._id }));
};

exports.getSimilarTrips = async (activity, type, preferredCurrency = "USD") => {
  const similarTrips = await Trip.find({
    $or: [
      {
        activity: { $in: JSON.parse(activity) },
      },
      {
        type: { $in: JSON.parse(type) },
      },
    ],
    active: true
  })
    .sort({ createdAt: -1 })
    .limit(12)
    .lean();
  return Promise.all(
    similarTrips.map(async (t) => ({
      id: t._id,
      ...t,
      pageType: "trip",
      cover: getSignedUrl(t.cover),
      likes: await TripLikes.find({ tripId: t._id }),
      price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
      priceCurrency: preferredCurrency,
      pageType: "trip",
      dateTime: await Promise.all(
        t.dateTime.map(async (d) => ({
          ...d,
          price: await convertCurrency(
            d.priceCurrency,
            preferredCurrency,
            d.price,
          ),
          priceCurrency: preferredCurrency,
        })),
      ),
    })),
  );
};

exports.UploadAccommoPhotos = async (id, photos, type) => {

  let urls = [];

  if (typeof photos.length !== "undefined") {
    urls = await UploadAccommoFiles('photos', photos);
  } else {
    urls = await UploadFile('photos', photos);
  }

  let tripById = "";
  let trips = "";
  if (type == "trip") {

    tripById = await Trip.findById(id);
    trips = await Trip.findByIdAndUpdate(id, { $set: { accomodationPhotos: tripById.accomodationPhotos.concat(urls) } },
      { new: true });

  } else {

    tripById = await Learning.findById(id);
    trips = await Learning.findByIdAndUpdate(id, { $set: { accomodationPhotos: tripById.accomodationPhotos.concat(urls) } },
      { new: true });

  }

  return trips.accomodationPhotos.map((u) => getSignedUrl(u));
};


exports.updateAccommoImage = async (body, data) => {

  let savedData = "";
  if (body.type == "trip") {
    savedData = await Trip.findByIdAndUpdate(body.id, { $set: { accomodationPhotos: data } },
      { new: true });
  } else {
    savedData = await Learning.findByIdAndUpdate(body.id, { $set: { accomodationPhotos: data } },
      { new: true });
  }

  return savedData.accomodationPhotos.map((u) => getSignedUrl(u));

};

exports.updatePhotosAndVideo = async (body, data) => {

  let savedData = "";
  if (body.type == "trip") {
    savedData = await Trip.findByIdAndUpdate(body.id, { $set: { images: JSON.parse(body.images) } },
      { new: true });
  } else {
    savedData = await Learning.findByIdAndUpdate(body.id, { $set: { images: JSON.parse(body.images) } },
      { new: true });
  }

  return savedData.accomodationPhotos.map((u) => getSignedUrl(u));;

};
