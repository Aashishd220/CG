const Learning = require('../models/learning');
const Message = require('../models/messages');
const LearningsLikes = require('../models/learningsLikes');
const { MessageEmail } = require('../../utils/email');
const Trip = require('../models/trips');
const TripLikes = require('../models/tripsLikes');

const { getSignedUrl, UploadFiles } = require('../../utils/helper');
const { convertCurrency } = require('../../utils/currency');

exports.create = async (data) => {
  const learning = {
    ...data,
    dateTime: data.dateTime ? JSON.parse(data.dateTime) : [],
    activity: JSON.parse(data.activity),
    langauges: JSON.parse(data.langauge),
    itenary: JSON.parse(data.itenary),
    location: {
      type: 'Point',
      coordinates: JSON.parse(data.coordinates),
    },
    active: data.active,
  };
  const res = new Learning(learning);
  const sl = await res.save();
  return sl;
};

exports.update = async (learnings, data) => {
  const obj2Update = {
    ...data,
    dateTime: data.dateTime ? JSON.parse(data.dateTime) : [],
    activity: JSON.parse(data.activity),
    langauges: JSON.parse(data.langauge),
    itenary: JSON.parse(data.itenary),
    location: {
      type: 'Point',
      coordinates: JSON.parse(data.coordinates),
    },
  };
  const updatedData = Object.assign(learnings, obj2Update);
  const savedData = await updatedData.save();
  return savedData;
};

exports.update = async (learnings, data) => {
  const obj2Update = {
    ...data,
    dateTime: data.dateTime ? JSON.parse(data.dateTime) : [],
    activity: JSON.parse(data.activity),
    langauges: JSON.parse(data.langauge),
    itenary: JSON.parse(data.itenary),
    location: {
      type: 'Point',
      coordinates: JSON.parse(data.coordinates),
    },
  };
  const updatedData = Object.assign(learnings, obj2Update);
  const savedData = await updatedData.save();
  return savedData;
};

exports.inActive = async (id) => {
  const updatedData = await Learning.findByIdAndUpdate(id, { $set: { active: false } });
  return updatedData;
};

exports.active = async (id) => {
  const updatedData = await Learning.findByIdAndUpdate(id, { $set: { active: true } });
  return updatedData;
};

exports.updateExpertLearningOriginalCover=async (learning)=>{
  if(learning.unsignedCover){
		const data = await Learning.findOneAndUpdate({ _id: learning.id },{originalCover:learning.unsignedCover}  , function (err, result) {
			if (err) {
				console.log(err)
			}
			else {
				return result;
			}
		});
	}
}

exports.getLearnings = async (data, preferredCurrency = 'USD') => {
  let Obj = {};

  let {
    perPage, currentPage
  } = data;

  Obj.active = { $eq: true }

  if (data.activity) {
    let optactivity = [];
    JSON.parse(data.activity).forEach(function (opt) {
      optactivity.push(new RegExp(opt, "i"));
    });
    Obj.activity = { $in: optactivity };
  }

  if (data.country) {
    Obj.country = { '$regex': data.country, $options: 'i' };
  }

  if (data.langauges) {
    let optlangauges = [];
    JSON.parse(data.langauges).forEach(function (opt) {
      optlangauges.push(new RegExp(opt, "i"));
    });
    Obj.langauges = { $in: optlangauges };
  }

  if (data.workshopType) {
    let optworkshopType = [];
    JSON.parse(data.workshopType).forEach(function (opt) {
      optworkshopType.push(new RegExp(opt, "i"));
    });
    Obj.workshopType = { $in: optworkshopType };
  }

  if (data.workshopMedium) {
    let optworkshopMedium = [];
    JSON.parse(data.workshopMedium).forEach(function (opt) {
      optworkshopMedium.push(new RegExp(opt, "i"));
    });
    Obj.workshopMedium = { $in: optworkshopMedium };
  }

  if (data.suitable) {
    let optsuitable = [];
    JSON.parse(data.suitable).forEach(function (opt) {
      optsuitable.push(new RegExp(opt, "i"));
    });
    Obj.suitable = { $in: optsuitable };
  }

  if (data.skill) {
    const p = data.skill.split('-');
    Obj.skill = {
      $gte: parseInt(p[0], 0),
      $lte: parseInt(p[1], 0),
    };
  }
  if (data.price) {
    const p = data.price.split('-');
    Obj.price = {
      $gte: parseInt(p[0], 0),
      $lte: parseInt(p[1], 0),
    };
  }
  if (data.month) {
    const dates = data.month.split('-');
    Obj = {
      ...Obj,
      $or: [
        {
          'dateTime.fromDate': {
            $gte: new Date(`${dates[1]}-${dates[2]}-${dates[3]}`).toISOString(),
            $lte: new Date(`${dates[1]}-${dates[2]}-${dates[0]}`).toISOString(),
          },
        },
      ],
    };
  }

  currentPage = parseInt(currentPage);
  perPage = parseInt(perPage);

  const learnings = await Learning.find(Obj)
    .skip(currentPage > 0 ? ((currentPage - 1) * perPage) : 0)
    .limit(perPage)
    .sort({ title: data.sortBy });

  const count = await Learning.find(Obj).countDocuments();

  const parsedLearnings = await Promise.all(
    learnings.map(async (l) => ({
      id: l._id,
      country: l.country,
      title: l.title,
      activity: l.activity,
      duration: l.duration,
      durationType: l.durationType,
      price: await convertCurrency(l.priceCurrency, preferredCurrency, l.price),
      priceCurrency: preferredCurrency,
      type: l.workshopType,
      medium: l.workshopMedium,
      cover: getSignedUrl(l.cover),
      skill: l.skill,
      likes: await LearningsLikes.find({ learningId: l._id }),
      active: l.active,
      dateType: l.dateType,
      dateTime: l.dateTime,
      address: l.address,
      suitable: l.suitable,
      pageType: "workshop",
      unsignedCover:l.cover
    }))
  );

  return { data: parsedLearnings, count: count };
};


exports.getMyLearnings = async (id, preferredCurrency = "USD") => {
  const learnings = await Learning.find({ expert: id }).sort({ createdAt: -1 });
  return Promise.all(learnings.map(async (l) => ({
    id: l._id,
    location: l.location,
    activity: l.activity,
    langauges: l.langauges,
    title: l.title,
    duration: l.duration,
    durationType: l.durationType,
    price: await convertCurrency(l.priceCurrency, preferredCurrency, l.price),
    priceCurrency: preferredCurrency,
    skill: l.skill,
    likes: await LearningsLikes.find({ learningId: l._id }),
    dateTime: l.dateTime,
    type: l.workshopType,
    medium: l.workshopMedium,
    country: l.country,
    meetingPoint: l.meetingPoint,
    description: l.description,
    whatLearn: l.whatLearn,
    attend: l.attend,
    accomodation: l.accomodation,
    itenary: l.itenary,
    inclusion: l.inclusion,
    exclusion: l.exclusion,
    extras: l.extras,
    cancellantion: l.cancellantion,
    participants: l.participants,
    dateType: l.dateType,
    cover: getSignedUrl(l.cover),
    expert: l.expert,
    active: l.active,
    address: l.address,
    pageType: "workshop"
  })));
};

exports.getSimilarLearnings = async (activity, preferredCurrency) => {
  const similarLearnings = await Learning.find({
    $or: [
      {
        activity: { $in: JSON.parse(activity) },
      },
    ],
    active: true
  }).sort({ createdAt: -1 });

  return Promise.all(similarLearnings.map(async (t) => ({
    id: t._id,
    cover: getSignedUrl(t.cover),
    title: t.title,
    price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
    priceCurrency: preferredCurrency,
    activity: t.activity,
    skill: t.skill,
    likes: await LearningsLikes.find({ learningId: t._id }),
    active: t.active,
    dateTime: t.dateTime,
    dateType: t.dateType,
    address: t.address,
    duration: t.duration,
    durationType: t.durationType,
    country: t.country,
    medium: t.workshopMedium,
    pageType: "workshop"
  })));
};

exports.UpcomingLearnings = async (id, preferredCurrency) => {
  const learning = await Learning.find({ expert: id });
  return Promise.all(learning.map(async (l) => ({
    id: l._id,
    country: l.country,
    title: l.title,
    activity: l.activity,
    duration: l.duration,
    durationType: l.durationType,
    price: await convertCurrency(l.priceCurrency, preferredCurrency, l.price),
    priceCurrency: preferredCurrency,
    type: l.workshopType,
    medium: l.workshopMedium,
    cover: getSignedUrl(l.cover),
    skill: l.skill,
    likes: await LearningsLikes.find({ learningId: l._id }),
    dateTime: l.dateTime,
    active: l.active,
    dateType: l.dateType,
    address: l.address,
    pageType: "workshop"
  })));
};

exports.UploadAccomodationPhotos = async (id, photos) => {
  const urls = await UploadFiles('photos', photos);
  const learning = await Learning.findByIdAndUpdate(id, { $set: { accomodationPhotos: urls } },
    { new: true });
  return learning.accomodationPhotos.map((u) => getSignedUrl(u));
};

exports.SendMessage = async (data) => {
  const messages = new Message(data);
  const smsg = await messages.save();
  const mailData = await smsg.populate({
    path: 'expert',
    model: 'expert',
    select: {
      _id: 1, firstName: 1, lastName: 1, user: 1,
    },
    populate: {
      path: 'user',
      model: 'users',
      select: { email: 1 },
    },
  }).execPopulate();
  const name = `${mailData.expert.firstName} ${mailData.expert.lastName}`;
  await MessageEmail(name, mailData.expert.user.email, mailData.message);
  return smsg;
};


exports.getLearningPlusTrip = async (data, preferredCurrency) => {

  let limit = 0;
  let Obj = {};
  let sortByOpt = {};
  if (data.sortBy === 'created_at') {
    limit = 3;
    sortByOpt = { createdAt: -1 };
  } else {
    let {
      activity,
      type,
      month,
      price,
      suitable,
      difficulty,
      page,
      sortBy,
      country,
      langauges,
      workshopType,
      workshopMedium,
      skill,
    } = data;
    const skip = page || 1;

    sortByOpt = { title: (sortBy === "asc" || sortBy == "") ? 1 : -1 };
    
    if (price) {
      const p = price.split('-');
      if (preferredCurrency !== "USD" || preferredCurrency !== "usd") {
        p[0] = await convertCurrency(preferredCurrency, "USD", parseInt(p[0]));
        p[1] = await convertCurrency(preferredCurrency, "USD", parseInt(p[1]));
      }

      Obj.priceUSD = {
        $gte: parseInt(p[0]),
        $lte: parseInt(p[1]),
      };
    }
    if (type) {
      type = JSON.parse(type);
      type.forEach(function (opt) {
        type.push(new RegExp(opt, "i"));
      });
      Obj.type = { $in: type };
    }

    if (activity && activity.length) {
      activity = JSON.parse(activity);
      activity.forEach(function (opt) {
        activity.push(new RegExp(opt, "i"));
      });
      Obj.activity = { $in: activity };
    }

    if (difficulty) {
      Obj.difficulty = { $in: new RegExp(difficulty, "i") };

    }


    if (workshopType) {
      workshopType = JSON.parse(workshopType);
      workshopType.forEach(function (opt) {
        workshopType.push(new RegExp(opt, "i"));
      });
      Obj.workshopType = { $in: workshopType };
    }

    if (workshopMedium) {
      workshopMedium = JSON.parse(workshopMedium);
      workshopMedium.forEach(function (opt) {
        workshopMedium.push(new RegExp(opt, "i"));
      });
      Obj.workshopMedium = { $in: workshopMedium };
    }

    if (data.adventure == "online") {
      Obj.workshopMedium = { $in: ['online'] };
    }

    if (suitable) {
      suitable = JSON.parse(suitable);
      suitable.forEach(function (opt) {
        suitable.push(new RegExp(opt, "i"));
      });
      Obj.suitable = { $in: suitable };
    }

    if (country) {
      Obj.country = { '$regex': country, $options: 'i' };
    }

    if (month) {
      const dates = month.split('-');
      Obj = {
        ...Obj,
        $or: [
          {
            'dateTime.fromDate': {
              $gte: new Date(`${dates[1]}-${dates[2]}-${dates[3]}`).toISOString(),
              $lte: new Date(`${dates[1]}-${dates[2]}-${dates[0]}`).toISOString(),
            },
          },
          { dateType: 2 }
        ],
      };
    }

    if (langauges) {
      langauges = JSON.parse(langauges);
      langauges.forEach(function (opt) {
        langauges.push(new RegExp(opt, "i"));
      });
      Obj.langauges = { $in: langauges };
    }
    console.log(Obj)

    if (skill) {
      Obj.skill = { $in: new RegExp(skill, "i") };

    }
  }


  Obj.active = { $eq: true }

  data.currentPage = parseInt(data.currentPage);
  data.perPage = parseInt(data.perPage);

  let trips = [];
  let countTrip = 0;
  if (data.adventure === "group") {

    trips = await Trip.find(Obj)
      .skip(data.currentPage > 0 ? ((data.currentPage - 1) * parseInt(data.perPage / 2)) : 0)
      .limit(parseInt(data.perPage / 2))
      .sort(sortByOpt);

    countTrip = await Trip.find(Obj).countDocuments();

  } else if (data.adventure === "trip") {

    trips = await Trip.find(Obj)
      .skip(data.currentPage > 0 ? ((data.currentPage - 1) * data.perPage) : 0)
      .limit(data.perPage)
      .sort(sortByOpt);


    countTrip = await Trip.find(Obj).countDocuments();

  }



  let tripData = await Promise.all(
    trips.map(async (t) => ({
      id: t._id,
      cover: getSignedUrl(t.cover),
      title: t.title,
      duration: t.duration,
      description: t.description,
      durationType: t.durationType,
      price: await convertCurrency(t.priceCurrency, preferredCurrency, t.price),
      priceCurrency: preferredCurrency,
      location: t.country,
      difficulty: t.difficulty,
      activity: t.activity,
      active: t.active,
      dateTime: t.dateTime,
      dateType: t.dateType,
      address: t.address,
      country: t.country,
      skill: t.skill,
      likes: await TripLikes.find({ tripId: t._id }),
      images: t.images.map((image) => getSignedUrl(image)),
      accomodationPhotos: t.accomodationPhotos.map((image) => getSignedUrl(image)),
      suitable: t.suitable,
      pageType: 'trip',
      location: t.location,
    })),
  );


  let learnings = [];
  let countLearning = 0;
  if (data.adventure === "group") {
    learnings = await Learning.find(Obj)
      .skip(data.currentPage > 0 ? ((data.currentPage - 1) * parseInt(data.perPage / 2)) : 0)
      .limit(parseInt(data.perPage / 2))
      .sort(sortByOpt);

    countLearning = await Learning.find(Obj).countDocuments();

  } else if (data.adventure === "workshop" || data.adventure === "online") {

    learnings = await Learning.find(Obj)
      .skip(data.currentPage > 0 ? ((data.currentPage - 1) * data.perPage) : 0)
      .limit(data.perPage)
      .sort(sortByOpt);

    countLearning = await Learning.find(Obj).countDocuments();

  }


  const learningData = await Promise.all(learnings.map(async (l) => ({
    id: l._id,
    country: l.country,
    title: l.title,
    activity: l.activity,
    duration: l.duration,
    durationType: l.durationType,
    price: await convertCurrency(l.priceCurrency, preferredCurrency, l.price),
    priceCurrency: preferredCurrency,
    type: l.workshopType,
    medium: l.workshopMedium,
    cover: getSignedUrl(l.cover),
    skill: l.skill,
    likes: await LearningsLikes.find({ learningId: l._id }),
    active: l.active,
    dateType: l.dateType,
    dateTime: l.dateTime,
    address: l.address,
    suitable: l.suitable,
    pageType: 'workshop',
    description: l.description,
    location: l.location,
  })));

  let allData = [...learningData, ...tripData];

  if (typeof data.sortBy !== "undefined") {

    allData.sort((a, b) => {
      let fa = typeof a.title !== "undefined" && a.title !== "" ? a.title.toLowerCase() : "";
      let fb = typeof b.title !== "undefined" && b.title !== "" ? b.title.toLowerCase() : "";
      if (fa < fb) {
        return -1;
      }
      if (fa > fb) {
        return 1;
      }
      return 0;
    });

    if (data.sortBy === "desc") {
      allData.reverse();
    }
  }

  return { data: allData, count: parseInt(countTrip + countLearning) }
};


exports.learningLikeCreate = async (data) => {
  const learningLike = {
    ...data,
  };
  const like = await LearningsLikes.find(learningLike);
  let res;
  if (like && like[0]) {
    res = await LearningsLikes.findOneAndDelete(learningLike);
    return { ans: "dislike" };
  }
  res = new LearningsLikes(learningLike);

  const savedTripLikes = await res.save();
  return { ans: "like" };
};

exports.updateCurrency = async () => {

  const allLearning = await Learning.find();
  const allTrips = await Trip.find();

  if (allLearning.length > 0) {
    allLearning.map(async (item, index) => {
      let price_usd = await convertCurrency(item.priceCurrency, "USD", item.price);
      const result = await Learning.findOneAndUpdate({ _id: item._id }, { priceUSD: price_usd }, function (err, result) {
        if (err) {
          console.log(err)
        }
        else {
          return result;
        }
      });
    });
  }

  if (allTrips.length > 0) {
    allTrips.map(async (item, index) => {
      let price_usd = await convertCurrency(item.priceCurrency, "USD", item.price);
      const result = await Trip.findOneAndUpdate({ _id: item._id }, { priceUSD: price_usd }, function (err, result) {
        if (err) {
          console.log(err)
        }
        else {
          return result;
        }
      });
    });
  }

};
