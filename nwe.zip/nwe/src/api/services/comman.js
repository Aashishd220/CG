const Lists = require('../models/comman');
const Messages = require('../models/messages');
const Bookings = require('../models/booking');

exports.create = async (data) => {
  const list = new Lists(data);
  const sd = await list.save();
  return sd.transform();
};

exports.list = async (type) => {
  const lists = await Lists.find({ type });
  return lists.map((l) => l.transform());
};

exports.UpdateMessage = async (id, data) => {
	const msg = await Messages.findOneAndUpdate({_id: id}, data);
  return msg;
}

exports.DeleteMessage = async (tripId, learning, type, senderId, receiverId) => {
  const condition = type === 'trip' ? { trip: tripId} : { learning: learning };  
	const messages = await Messages.deleteMany({
    $or: [
      {
        $and: [
          { sender_userid: senderId },
          { receiver_userid: receiverId },
        ],
      },
      {
        $and: [
          { sender_userid: receiverId },
          { receiver_userid: senderId },
        ],
      },
    ],
    $and: [condition],
  });
  return messages;
};

exports.DeleteSingleMessage = async (id) => {
  const message = await Messages.findByIdAndDelete(id);
  return message;
};

exports.FindMessageUpdate = async (id, data) => {
  const message = await Messages.findOneAndUpdate({ _id: id }, data);
  return message;
};

exports.UpdateMessages = async (tripId, learning, type, senderId, receiverId, data) => {
  const condition = type === 'trip' ? { trip: tripId} : { learning: learning };
	const messages = await Messages.updateMany({
    $or: [
      {
        $and: [
          { sender_userid: senderId },
          { receiver_userid: receiverId },
        ],
      },
      {
        $and: [
          { sender_userid: receiverId },
          { receiver_userid: senderId },
        ],
      },
    ],
    $and: [condition],
  },data);
  
  return messages;
};

exports.UpdateSidebarMessages = async (tripId, senderId, receiverId) => {
  const messages = await Messages.find({
    $and: [
      { sender_userid: receiverId },
      { receiver_userid: senderId },
    ],
    $and: [{ trip: tripId }],
  }).sort({ createdAt: 1 });
   
  if(messages) {
    await Messages.findOneAndUpdate({ _id: messages[0].id}, {status: false});
  } 

  return messages;
};

exports.UpdatesBookings = async (id, data) => {
  const booking = await Bookings.findOneAndUpdate({ _id: id}, update);
  return booking;
};