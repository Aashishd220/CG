const Album = require('../models/album');
const AlbumLikes = require('../models/albumLikes');

const { getSignedUrl } = require('../../utils/helper');

exports.create = async (data) => {
  const album = {
    ...data,
    isDelete: false,
    location: {
      type: 'Point',
      coordinates: data.coordinates ? JSON.parse(data.coordinates) : [-86.158068, 39.768403],
    },
  };
  const res = new Album(album);
  const sa = await res.save();
  return sa;
};

exports.update = async (data) => {
  const objUpdate = {
    ...data,
    location: {
      type: 'Point',
      coordinates: JSON.parse(data.coordinates),
    },
  };
  const savedData = await Album.findByIdAndUpdate(data.id, { $set: objUpdate });
  return savedData
};

exports.getAll = async (query) => {
  const {
    page, sortOrder,
  } = query;

  const sort = sortOrder || -1;
  const skip = page || 1;

  // const albums = await Album.find({ isActive: true }).skip((skip - 1) * 25)
  //   .limit(25).sort({ firstName: sort, lastName: sort });
  //   const count = await Album.find({ isActive: true }).countDocuments();
  const albums = await Album.find({ isActive: true })
  return Promise.all(albums.map(async (l) =>
    ({
      id: l._id,
      name: l.name,
      description: l.description,
      date: l.date,
      images: l.images.map((image) => getSignedUrl(image)),
      likes: await AlbumLikes.find({ albumId: l._id }),
      country: l.country,
      isActive: l.isActive,
      isDelete: l.isDelete,
      address: l.address,
      location: l.location,
      isVideo: l.isVideo,
    })));
};

exports.getMyAlbums = async (id) => {
  const albums = await Album.find({ user: id });
  return Promise.all(albums.map(async (l) => ({
    id: l._id,
    name: l.name,
    description: l.description,
    date: l.date,
    images: l.images.map((image) => getSignedUrl(image)),
    likes: await AlbumLikes.find({ albumId: l._id }),
    country: l.country,
    isActive: l.isActive,
    isDelete: l.isDelete,
    address: l.address,
    location: l.location,
    isVideo: l.isVideo,
  })));
};

exports.getExpertAllAlbums = async (id) => {
  const albums = await Album.find({ expert: id });
  return Promise.all(albums.map(async (l) => ({
    id: l._id,
    name: l.name,
    description: l.description,
    date: l.date,
    images: l.images.map((image) => getSignedUrl(image)),
    likes: await AlbumLikes.find({ albumId: l._id }),
    country: l.country,
    isActive: l.isActive,
    isDelete: l.isDelete,
    address: l.address,
    location: l.location,
    isVideo: l.isVideo,
  })));
};

exports.getAlbum = async (id) => {
  const album = await Album.findOne({ _id: id, isActive: true });
  return album;
};

exports.inActive = async (id) => {
  const savedData = await Album.findByIdAndUpdate(id, { $set: { isActive: false } });
  return savedData
};

exports.active = async (id) => {
  const savedData = await Album.findByIdAndUpdate(id, { $set: { isActive: true } });
  return savedData
};

exports.deleteAlbumData = async (id) => {
  const album = await Album.findByIdAndUpdate({ _id: id }, { $set: { isDelete: true } });
  return album;
};


exports.albumLikeCreate = async (data) => {
  const albumLike = {
    ...data,
  };
  const like = await AlbumLikes.find(albumLike);
  let res;
  if (like && like[0]) {
    res = await AlbumLikes.findOneAndDelete(albumLike);
    return { ans: "dislike" };
  }
  res = new AlbumLikes(albumLike);

  const savedAlbumLikes = await res.save();
  return { ans: "like" };
};