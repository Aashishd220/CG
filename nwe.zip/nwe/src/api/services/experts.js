/* eslint-disable no-param-reassign */
const _ = require('lodash');
const Expert = require('../models/expert');
const Messages = require('../models/messages');
const Enthusiast = require('../models/enthusiast');
const User = require('../models/user');
const Trip = require('../models/trips');
const Currency = require('../models/currency');
const Learning = require('../models/learning');
const LoginDeatils = require('../models/loginDetails');

const APIError = require('../../utils/APIError');
const { NOT_FOUND, NO_RECORD_FOUND } = require('../../utils/constants');
const { ADMIN_PROFILE_EXPORTS_URL } = require('../../config/env-vars');
const { getSignedUrl } = require('../../utils/helper');
const { ApprovalEmail, ReplyEmail, AdminNewProfileEmail } = require('../../utils/email');
const logger = require('../../config/logger');

exports.create = async (data) => {
	try {
		const expert = await Expert.saveExpert(data);
		const countryCurrency = await Currency.find({ name: data.country });

		let user = await User.findByIdAndUpdate(data.user, {
			$set: {
				role: "expert",
				isCompleted: true,
				preferredCurrency: countryCurrency.length ? countryCurrency[0].currencyCode : "USD",
			},
		});
		await AdminNewProfileEmail(ADMIN_PROFILE_EXPORTS_URL, expert.firstName, user.email);
		return {
			...expert,
			preferredCurrency: countryCurrency.length ? countryCurrency[0].currencyCode : "USD",
		};
	} catch (err) {
		throw Expert.checkDuplication(err);
	}
};

exports.get = async (id) => {
	const data = await Expert.get(id);
	return data;
};

exports.getForEdit = async (id) => {
	const data = await Expert.findOne({ user: id });
	return data.transform();
};

exports.update = async (id, data) => {
	const us = await Expert.findOne({ user: id });
	if (!us) throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });

	const {
		companyname, address,
		phone, website, businessEmail, booksAndPublications
	} = data;

	const company = {};
	let ubooksAndPublications;
	if (companyname) company.name = companyname;

	if (phone) company.phone = phone;

	if (website) company.website = website;

	if (address) company.address = address;

	if (businessEmail) company.businessEmail = businessEmail;

	if (booksAndPublications.length > 0) {
		const currentBooks = us.booksAndPublications.toObject();

		ubooksAndPublications = booksAndPublications
			.map((booksAndPublication, index) => {
				if (currentBooks[index]) {
					return {
						...currentBooks[index],
						...booksAndPublication,
					};
				}
				return {
					...booksAndPublication,
				};
			});
	}

	const updated = Object.assign(us.company, company);
	data.booksAndPublications = ubooksAndPublications;

	const upE = Object.assign(us, { ...data, updated });

	const se = await upE.save();
	return se.transform();
};

exports.updateProfileApproval = async (id, approved) => {
	const ex = await Expert.findOneAndUpdate({ _id: id }, { $set: { approved } }, { new: true }).populate('user');
	if (approved) {
		await ApprovalEmail(ex.firstName, ex.user.email);
	}
	if (!ex) throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
	return ex.transform();
};

exports.getAll = async (query) => {
	let {
		cnty, activity, skills, page, langauge, sortOrder, perPage, currentPage,cover
	} = query;


	currentPage = parseInt(currentPage);
	perPage = parseInt(perPage)
	const sort = sortOrder || -1;

	const Obj = {};

	if (cnty) {
		Obj.country = { '$regex': cnty, $options: 'i' };
	}

	if (langauge) {
		langauge = JSON.parse(langauge);
		langauge.forEach(function (opt) {
			langauge.push(new RegExp(opt, "i"));
		});

		Obj.speaks = { $in: langauge };
	}

	if (activity) {
		activity = JSON.parse(activity);
		activity.forEach(function (opt) {
			activity.push(new RegExp(opt, "i"));
		});

		Obj.experties = { $in: activity };
	}

	if (skills) {
		skills = JSON.parse(skills);
		skills.forEach(function (opt) {
			skills.push(new RegExp(opt, "i"));
		});

		Obj.skills = { $in: skills };
	}

	Obj.approved = { $eq: true }

	const experts = await Expert.find(Obj)
		.skip(currentPage > 0 ? ((currentPage - 1) * perPage) : 0)
		.limit(perPage)
		.sort({ firstName: sort });

	experts.sort((a, b) => {
		let fa = typeof a.firstName !== "undefined" && a.firstName !== "" ? a.firstName.toLowerCase() : "";
		let fb = typeof b.firstName !== "undefined" && b.firstName !== "" ? b.firstName.toLowerCase() : "";
		if (fa < fb) {
			return -1;
		}
		if (fa > fb) {
			return 1;
		}
		return 0;
	});
	
	if (sort === "-1") {
		experts.reverse();
	}

	const count = await Expert.find(Obj).countDocuments();
	return {
		count,
		experts: experts.map(({
			_id, firstName, lastName, profile,originalProfile, experties, country, speaks, city, approved, location,cover
		}) => ({
			id: _id,
			firstName,
			lastName,
			experties,
			speaks,
			city,
			profile: getSignedUrl(profile),
			originalProfile:getSignedUrl(originalProfile),
			country,
			approved,
			location,
			cover
		})),
	};
};

exports.GetExpertsList = async () => {
	const experts = await Expert.find({}).populate('user', 'email loginType').sort({ createdAt: -1 });
	const count = await Expert.countDocuments();
	return {
		count,
		experts: experts.map(({
			user, _id, firstName, lastName, profile,originalProfile, createdAt, approved, country,
		}) => ({
			id: _id,
			email: user && user.email,
			loginType: user && user.loginType,
			firstName,
			lastName,
			createdAt,
			approved,
			country,
			profile: getSignedUrl(profile),
			originalProfile:getSignedUrl(originalProfile),
		})),
	};
};

exports.getAllMessages = async (id) => {
	const expert = await Expert.findOne({ user: id });
	const msg = await Messages.find({ expert: expert._id });
	const allMsgs = await Promise.all(msg.map(async (m) => {
		const enth = await Enthusiast.findOne({ user: m.user });
		return {
			id: m._id,
			message: m.message,
			user: {
				name: enth.firstName,
				profile: enth.profile ? getSignedUrl(enth.profile) : null,
			},
			reply: m.reply,
			createdAt: m.createdAt,
		};
	}));
	return allMsgs;
};

exports.getEnthMessages = async (id) => {
	const expert = await Expert.findOne({ _id: id });
	const msg = await Messages.find({ expert: id }).sort({ createdAt: -1 });
	const allMsgs = await Promise.all(msg.map(async (m) => {
		const enth = await Enthusiast.findOne({ user: m.user });
		const trip = await Trip.find({ _id: m.trip });
		return {
			id: m._id,
			message: m.message,
			trip: trip[0],
			user: {
				name: enth ? enth.firstName : expert.firstName,
				profile: enth ? enth.profile ? getSignedUrl(enth.profile) : null : getSignedUrl(expert.cover),
			},
			reply: m.reply,
			createdAt: m.createdAt,
		};
	}));
	return allMsgs;
};

exports.getEnthTripMessages = async (id, tripId) => {
	const expert = await Expert.findOne({ _id: id });
	const msg = await Messages.find({ expert: id, trip: tripId }).sort({ createdAt: -1 });
	const allMsgs = await Promise.all(msg.map(async (m) => {
		const enth = await Enthusiast.findOne({ user: m.user });
		const trip = await Trip.find({ _id: m.trip });
		return {
			id: m._id,
			message: m.message,
			trip: trip[0],
			user: {
				name: enth ? enth.firstName : expert.firstName,
				profile: enth ? enth.profile ? getSignedUrl(enth.profile) : null : getSignedUrl(expert.cover),
			},
			reply: m.reply,
			createdAt: m.createdAt,
		};
	}));
	return allMsgs;
};

exports.replyToMessage = async (id, reply) => {
	const data = await Messages.findByIdAndUpdate(id, { $set: { reply } }, { new: true }).populate('expert user');
	const name = `${data.expert.firstName} ${data.expert.lastName}`;
	await ReplyEmail(name, data.user.email, data.message, data.reply);
	return data;
};

exports.UploadCover = async (id, cover,check) => {

  if(check==='upload'){
    const data = await Expert.findOneAndUpdate({ user: id }, { $set: { cover:cover,originalCover:cover } }, { new: true });
    return getSignedUrl(data.cover);
  }
 else if(check==='delete'){
	 const data = await Expert.findOneAndUpdate({ user: id }, { $set: { cover:'',originalCover:'' } }, { new: true });
	 return '';
 } 
  else{
    const data = await Expert.findOneAndUpdate({ user: id }, { $set: { cover:cover } }, { new: true });
    return getSignedUrl(data.cover);
  }
};

exports.getAllChatSession = async (id, name, status) => {
	let flag = false;
	if (status === 'hidden') {
		flag = true;
	}
	const query = {
		$or: [{ sender_userid: id }, { receiver_userid: id }], expert_hide: flag, expert_delete: false,
	};

	if (status === 'fav') {
		query.expert_bookmark = true;
	}

	const msg = await Messages.find(query).populate('trip').populate('learning').sort({ createdAt: -1 });
	const allMsgs = await Promise.all(
		msg.map(async (m) => {
			const enth = await Enthusiast.findOne({ user: m.user });
			// const status = await LoginDeatils.findOne({user: enth.user.toString()});

			return {
				id: m._id,
				message: m.message,
				user: {
					name: `${enth.firstName}`,
					profile: enth.profile ? getSignedUrl(enth.profile) : null,
					id: enth.user,
					country: enth.country,
				},
				trip: m.trip,
				learning: m.learning,
				reply: m.reply,
				// status,
				createdAt: m.createdAt,
				sender_userid: m.sender_userid,
				receiver_userid: m.receiver_userid,
				bookmark: m.expert_bookmark,
				type: m.type,
			};
		}),
	);

	const finalMsg = [];

	allMsgs.forEach((msgA) => {
		let index;
		if (msgA.type === 'trip') {
			index = finalMsg.findIndex((f) => ((f.trip && f.trip.id === msgA.trip.id) && _.isEqual(f.user.id, msgA.user.id)));
		}
		if (msgA.type === 'learning') {
			index = finalMsg.findIndex((f) => ((f.learning && f.learning.id === msgA.learning.id) && _.isEqual(f.user.id, msgA.user.id)));
		}

		if (index < 0) {
			finalMsg.push(msgA);
		}
	});

	let messages = [];
	for (let i = 0; i < finalMsg.length; i++) {
		const msg = finalMsg[i];
		const condition = msg.type === 'learning' ? { learning: msg.learning._id } : { trip: msg.trip._id };

		const rows = await Messages.find({
			$and: [
				{ sender_userid: msg.user.id },
				{ receiver_userid: id },
				condition,
				{ status: false },
			],
		});
		msg.unread = rows.length;
		messages.push(msg);
	}
	if (name && name.trim().length > 0) {
		messages = messages.filter((msg) => {
			const string = msg.type === 'trip' ? msg.trip.title : msg.learning.title;
			return msg.user.name.includes(name.trim()) || string.includes(name.trim());
		});
	}
	return messages.sort((a, b) => b.unread - a.unread);
};

exports.getChatMessages = async (enthuId, expertId, tripId, type, learning, status) => {
	let flag = false;
	if (status === 'hidden') {
		flag = true;
	}
	const condition = type === 'trip' ? { trip: tripId } : { learning };
	const msg = await Messages.find({
		$or: [
			{
				$and: [
					{ sender_userid: enthuId },
					{ receiver_userid: expertId },
				],
			},
			{
				$and: [
					{ sender_userid: expertId },
					{ receiver_userid: enthuId },
				],
			},
		],
		$and: [condition],
	}).sort({ createdAt: 1 });
	const allMsgs = await Promise.all(
		msg.map(async (m) => {
			let type = '';
			if (m.sender_userid.toString() === expertId.toString()) {
				type = 'send';
			}
			if (m.receiver_userid.toString() === expertId.toString()) {
				type = 'receive';
			}
			const enth = await Expert.findById(m.expert);
			const trip = m.type === 'trip' ? await Trip.findById(m.trip) : null;
			const learning = m.type === 'learning' ? await Learning.findOne({ _id: m.learning }) : null;
			return {
				id: m._id,
				message: m.message,
				user: {
					name: enth ? `${enth.firstName} ${enth.lastName}` : '',
					profile: enth && enth.profile ? getSignedUrl(enth.profile) : null,
				},
				trip,
				reply: m.reply,
				createdAt: m.createdAt,
				type,
				status: m.status,
				media: m.media,
				learning,
			};
		}),
	);
	return allMsgs;
};

exports.getAllChatSessionCount = async (id) => {
	const msg = await Messages.find({
		receiver_userid: id, expert_hide: false, status: false,
	}).sort({ createdAt: 1 });
	return msg.length;
};


exports.UploadBookCover = async (id, bookid, cover) => {

	const data = await Expert.findOneAndUpdate({ user: id, "booksAndPublications._id": bookid },
		{ $set: { "booksAndPublications.$.cover": cover } }, { new: true });
	return true;
};


exports.UpdateExpertLocation = async (objExpert) => {
	const data = await Expert.findOneAndUpdate({ _id: objExpert.id }, { location: { type: 'Point', coordinates: [objExpert.location.coordinates.lng, objExpert.location.coordinates.lat] } }, function (err, result) {
		if (err) {
			console.log(err)
		}
		else {
			return result;
		}
	});

};


exports.updateExpertOriginalCover = async (expert) => {
	if(expert.cover){
		const data = await Expert.findOneAndUpdate({ _id: expert.id },{originalCover:expert.cover}  , function (err, result) {
			if (err) {
				console.log(err)
			}
			else {
				return result;
			}
		});
	}
};