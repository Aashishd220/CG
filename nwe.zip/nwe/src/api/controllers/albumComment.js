const {
  create,
  update,
  getAllComment,
} = require('../services/albumComment');
const {
  CREATED,
  OK,
} = require('../../utils/constants');

exports.createAlbumComment = async (req, res, next) => {
  try {
    const ex = await create(req.body);
    res.status(CREATED).json({ data: ex, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateAlbumComment = async (req, res, next) => {
  try {

    const rez = await update(req.body);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getAlbumComment = async (req, res, next) => {
  try {
    const albums = await getAllComment(req.params);
    res.status(OK).json({ data: albums, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};
