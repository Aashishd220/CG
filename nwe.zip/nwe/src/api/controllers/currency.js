const { getAllCurrency } = require('../services/currency');
const {
  OK,
} = require('../../utils/constants');

exports.getAllCurrency = async (req, res, next) => {
  try {
    const currencies = await getAllCurrency();
    res.status(OK).json({ currencies, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};
