const {
  Login, Logout, Register, oAuth,
  ForgotPassword, CheckTokenExpiration,
  ResetPassword, ChangePassword, AdminLogin,
  VerifyProfile, Status, removeLoginDeatils, ConfirmEmail,
  ConfirmPassword,
  updatePreferredCurrency,
  updateRole
} = require('../services/auth');
const { OK, CREATED } = require('../../utils/constants');

exports.Oauth = async (req, res, next) => {
  try {
    const data = await oAuth(req.body);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.login = async (req, res, next) => {
  try {
    const data = await Login(req.body);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.register = async (req, res, next) => {
  try {
    const origin = `${req.headers.origin}`;
    const us = { ...req.body, loginType: 'email' };
    const data = await Register(us, origin);
    res.status(CREATED).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.forgotPassword = async (req, res, next) => {
  // console.log(req.baseUrl);
  // console.log(req.get("origin"));
  // console.log(req.headers);
  // console.log(req);

  try {
    const origin = `${req.headers.origin}`;
    const data = await ForgotPassword(req.body.email, origin);
    res.status(OK).json({ data, success: "SUCCESS" });
  } catch (err) {
    next(err);
  }
};

exports.CheckToken = async (req, res, next) => {
  try {
    await CheckTokenExpiration(req.params.token);
    res.status(OK).json({ success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.resetPassword = async (req, res, next) => {
  try {
    await ResetPassword(req.params.token, req.body.password);
    res.status(OK).json({ success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.verifyProfile = async (req, res, next) => {
  try {
    await VerifyProfile(req.params.token);
    res.status(OK).json({ success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.changePassword = async (req, res, next) => {
  try {
    const origin = `${req.headers.origin}`;
    const data = await ChangePassword(req.user.id, req.body, origin);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.confirmEmail = async (req, res, next) => {
  try {
    const data = await ConfirmEmail(req.user.id, req.body);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updatePreferredCurrency = async (req, res, next) => {
  try {
    const data = await updatePreferredCurrency(req.user.id, req.params.currency);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.confirmPassword = async (req, res, next) => {
  try {
    const origin = `${req.headers.origin}`;
    const data = await ConfirmPassword(req.user.id, req.body, origin);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.changeEmail = async (req, res, next) => {
  try {
    const data = await ChangeEmail(req.user.id, req.body);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.adminLogin = async (req, res, next) => {
  try {
    const data = await AdminLogin(req.body);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.logout = async (req, res, next) => {
  try {
    const data = await Logout(req.body.id);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateLogin = async (req, res, next) => {
  try {
    const data = await removeLoginDeatils(req.user.id);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
}

exports.updateRole = async (req, res, next) => {
  try {
    const data = await updateRole(req.user.id, req.body);
    res.status(OK).json({ data, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};
