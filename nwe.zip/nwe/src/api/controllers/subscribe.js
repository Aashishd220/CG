const { checkEmailExistOrSave } = require('../services/subscribe');
const {
  OK,
} = require('../../utils/constants');

exports.subscribe = async (req, res, next) => {
  try {
    let response = { msg: "", status: 'SUCCESS' };
    const isEmailExist = await checkEmailExistOrSave(req.body);
    if (isEmailExist === "exists") {
      response = { msg: "you have already subscribed for our newsletters", status: 'FAIL' };
    } else {
      response = { msg: isEmailExist, status: 'SUCCESS' };
    }
    res.status(OK).json(response);
  } catch (err) {
    next(err);
  }
};
