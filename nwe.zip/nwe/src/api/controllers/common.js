const { create, list } = require('../services/comman');
const { CREATED, OK } = require('../../utils/constants');

exports.createLists = async (req, res, next) => {
  try {
    const data = await create(req.body);
    res.status(CREATED).json({ message: 'SUCCESS', data });
  } catch (err) {
    next(err);
  }
};

exports.getLists = async (req, res, next) => {
  try {
    const data = await list(req.query.q);
    res.status(OK).json({ message: 'SUCCESS', data });
  } catch (err) {
    next(err);
  }
};
