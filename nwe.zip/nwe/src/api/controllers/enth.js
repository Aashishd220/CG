const Trip = require('../models/trips');
const Bookings = require('../models/booking');
const Enthusiast = require('../models/enthusiast');
const Learning = require('../models/learning');

const {
  create, update, get, UploadCover, getAllMessagesEnthu, getAllChatSession,
  getChatMessages, getAllChatSessionCount
} = require('../services/enth');
const {
  UpdateMessage, DeleteMessage, HideMessage, UpdateMessages,
  UpdateSidebarMessages, FindMessageUpdate, DeleteSingleMessage
} = require('../services/comman');
const { SendMessage } = require('../services/trips');
const { CREATED, OK } = require('../../utils/constants');
const APIError = require('../../utils/APIError');
const { UploadFile, getSignedUrl } = require('../../utils/helper');

exports.createEnth = async (req, res, next) => {
  try {
    let originalProfile;
    if (req.files && (req.files.picture !== 'undefined')) {
      req.body.profile = await UploadFile('profile', req.files.picture);
    }
    if (req.files && (req.files.originalPicture !== 'undefined')) {
      req.body.originalProfile = await UploadFile('profile', req.files.originalPicture);
    }
    const data = {
      ...req.body,
      user: req.user.id,
    };
    const ex = await create(data);
    res.status(CREATED).json({ data: ex, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getEnt = async (req, res, next) => {
  try {
    const data = await get(req.user.id);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateEnth = async (req, res, next) => {
  try {
    if (req.files && (req.files.picture !== 'undefined')) {
      req.body.profile = await UploadFile('profile', req.files.picture);
    }
    if (req.files && (req.files.originalPicture !== 'undefined')) {
      req.body.originalProfile = await UploadFile('profile', req.files.originalPicture);
    }
    const ex = await update(req.user.id, req.body);
    res.status(OK).json({ data: ex, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getEnthuPublicProfile = async (req, res, next) => {
  try {
    const data = await get(req.params.id);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.uploadCover = async (req, res, next) => {
  try {
    let check;
    let data;
    if(req.query && req.query.check){
      check=req.query.check;
    }
    if (check!=='delete' && (!req.files || (req.files.cover === 'undefined'))) {
      throw new APIError({ message: 'Picture is required field', status: 400 });
    }
    if(check!=='delete'){
      const profile = await UploadFile('cover', req.files.cover);
       data = await UploadCover(req.user.id, profile,check);
    }
    else{
      data = await UploadCover(req.user.id, '',check);
   }
   console.log("111111111111111111111111daaataaa"+ data)
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getMyAllMessages = async (req, res, next) => {
  try {
    const messages = await getAllMessagesEnthu(req.user.id);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getMyAllMessagesSession = async (req, res, next) => {
  try {
    const { name, status } = req.query;
    const messages = await getAllChatSession(req.user.id, name, status);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getSessionMessages = async (req, res, next) => {
  try {
    const messages = await getChatMessages(req.user.id, req.body.expert, req.body.trip, req.body.type, req.body.learning);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.sendMessage = async (req, res, next) => {
  try {
    const Obj = {
      user: req.user.id,
      message: req.body.message,
      sender_userid: req.user.id,
      receiver_userid: req.body.expertId,
      media: req.body.media,
    };

    if(req.body.type === 'trip') {
      const trip = await Trip.findById(req.body.tripId);  
      Obj.trip =  trip.id;
      Obj.type = 'trip';
      Obj.expert = trip.expert;
    }
    if(req.body.type === 'learning') {
      const learning = await Learning.findOne({ _id: req.body.learning });  
      Obj.learning =  learning._id;
      Obj.type = 'learning';
      Obj.expert = learning.expert;
    }
    if(req.body.status === 'hidden') {
      Obj.hide = true;
    }

    const msg = await SendMessage(Obj);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.readMessage = async (req, res, next) => {
  try {
    const { action } = req.body;
    const data = action && action === 'unread' ? {status: false} : {status: true};
    const msg =  await UpdateMessage(req.body.id, data);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.deleteMessages = async (req, res, next) => {
  try {
    const msg =  await UpdateMessages(req.body.trip_id, req.body.learning, req.body.type, req.user.id, req.body.receiver_id, { enthusiast_delete: true });
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.hideMessages = async (req, res, next) => {
  try {
    const msg =  await UpdateMessages(req.body.trip_id, req.body.learning, req.body.type, req.user.id, req.body.receiver_id, {enthusiast_hide: true});
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.starMessages = async (req, res, next) => {
  try {
    const msg =  await UpdateMessages(req.body.trip_id, req.body.learning, req.body.type, req.user.id, req.body.receiver_id, {enthusiast_bookmark: req.body.star});
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.unReadMessage = async (req, res, next) => {
  try {
    const msg =  await UpdateSidebarMessages(req.body.trip_id, req.user.id, req.body.receiver_id);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.uploadMessage = async (req, res, next) => {
  try {
    const f = await UploadFile('message', req.files.file);
    const data = {
      name: req.files.file.name,  
      url: getSignedUrl(f),
      status: 'done'
    };
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
}

exports.editMessage = async (req, res, next) => {
  try {
    const {id, ...data} = req.body;
    const message =  await FindMessageUpdate(id, data);
    res.status(OK).json({ message, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.deleteMessage = async (req, res, next) => {
  try {
    const {id} = req.body;
    const message =  await DeleteSingleMessage(id);
    res.status(OK).json({ message, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.confirmBooking = async (req, res, next) => {
  try {
    let booking;

    const {tripId, user, type, learning } = req.body;

    if(req.body.type === 'trip') {
      const trip = await Trip.findOne({ _id: req.body.tripId });  
      booking = await Bookings.find({trip: trip._id, expert: trip.expert._id, user: req.user.id}).sort({ createdAt: -1 });
    }

    if(req.body.type === 'learning') {
      const learn = await Learning.findOne({ _id: learning });  
      booking = await Bookings.find({learning: learn._id, expert: learn.expert._id, user: req.user.id}).sort({ createdAt: -1 });
    }    
    
    if (!booking) {
      throw new APIError({ message: 'Booking reacord not find.', status: 400 });
    }
    
    const book = await Bookings.findOneAndUpdate({_id: booking[0]._id}, { payment: true, paymentDate: new Date() });

    res.status(OK).json({ book, succes: 'SUCCESS' });
    
  } catch (err) {
    next(err);
  }
};

exports.getUnreadCount = async (req, res, next) => {
  try {
    const messages = await getAllChatSessionCount(req.user.id);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
}