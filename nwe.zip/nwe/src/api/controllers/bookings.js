const Trip = require('../models/trips');
const Learning = require('../models/learning');
const Booking = require('../models/booking');
const Enthusiast = require('../models/enthusiast');
const APIError = require('../../utils/APIError');

const {
  getEnthBooking, SendMessage, getSlotsData,
} = require('../services/bookings');
const {
  OK, NO_RECORD_FOUND, NOT_FOUND
} = require('../../utils/constants');

exports.sendMessage = async (req, res, next) => {
  try {
    const Obj = {
      user: req.user.id,
      date: req.body.Date,
      people: req.body.People,
      phone: req.body.Phone,
      slot: req.body.slot,
    };
    const trip = await Trip.findOne({ _id: req.params.tripId });
    if(trip) {
      Obj.trip = trip._id;
      Obj.expert = trip.expert;
    }
    const learning = await Learning.findOne({ _id: req.params.tripId });
    if(learning) {
      Obj.learning = learning._id;
      Obj.expert = learning.expert;
    }

    const msg = await SendMessage(Obj);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getAllBooking = async (req, res, next) => {
  try {
    const bookings = await getEnthBooking(req.params.id, req.query.name, req.query.status);
    res.status(OK).json({ data: bookings, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getBookingForTrip = async (req, res, next) => {
   try {
      const { id } = req.params;      
      const bookings = await getSlotsData(id);
      res.status(OK).json({ data: bookings, succes: 'SUCCESS' });
   } catch (err) {
    next(err);
   }
};


exports.starBookings = async (req, res, next) => {
  try {
     const { id, status} = req.body;
     if(!id) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND});
     }
     const bookings = await Booking.updateMany({
      $or: [ {trip: id}, {learning: id}]
     }, {bookmark: status});
     res.status(OK).json({ data: bookings, succes: 'SUCCESS' });
  } catch (err) {
     next(err);
  }
}

exports.deleteBookings = async (req, res, next) => {
  try {
    const {id} = req.body;
    if(!id) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND});
    }
    const bookings = await Booking.deleteMany({
      $or: [ {trip: id}, {learning: id}]
    });
    res.status(OK).json({ data: bookings, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
}

exports.hideBookings = async (req, res, next) => {
  try {
     const { id, status} = req.body;
     if(!id) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND});
     }
     const bookings = await Booking.updateMany({
      $or: [ {trip: id}, {learning: id}]
     }, { hide: true });
     res.status(OK).json({ data: bookings, succes: 'SUCCESS' });
  } catch (err) {
     next(err);
  }
}