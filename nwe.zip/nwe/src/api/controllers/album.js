const {
  create,
  update,
  getAll,
  getMyAlbums,
  getAlbum,
  deleteAlbumData,
  getExpertAllAlbums,
  inActive,
  active,
  albumLikeCreate
} = require('../services/album');
const {
  CREATED,
  NOT_FOUND,
  NO_RECORD_FOUND,
  OK,
} = require('../../utils/constants');
const { UploadFile, getSignedUrl } = require('../../utils/helper');
const APIError = require('../../utils/APIError');
const Expert = require('../models/expert');
const Album = require('../models/album');

exports.createAlbum = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user._id });
    if (!req.files.pictures || req.files.pictures === 'undefined') {
      throw new APIError({ message: 'Picture is required field', status: 400 });
    }

    const images = [];
    if (Array.isArray(req.files.pictures)) {
      /* eslint-disable */
      for (let index = 0; index < req.files.pictures.length; index++) {
        const pic = req.files.pictures[index];
        /* eslint-disable */
        const picture = await UploadFile('albums', pic);
        images.push(picture);
      }
    } else {
      const picture = await UploadFile('albums', req.files.pictures);
      images.push(picture);
    }

    const data = {
      ...req.body,
      images,
      user: req.user.id,
      isActive: true,
      expert: expert._id
    };
    const ex = await create(data);
    res.status(CREATED).json({ data: ex, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateAlbums = async (req, res, next) => {
  try {
    const images = [];
    const albumData = await Album.findOne({ _id: req.body.id });
    if (req.files && req.files.picture !== 'undefined') {
      if (Array.isArray(req.files.pictures)) {
        /* eslint-disable */
        for (let index = 0; index < req.files.pictures.length; index++) {
          const pic = req.files.pictures[index];
          /* eslint-disable */
          const picture = await UploadFile('albums', pic);
          images.push(picture);
        }
      } else {
        const picture = await UploadFile('albums', req.files.pictures);
        images.push(picture);
      }
      let photoList = JSON.parse(req.body.photoList);
      photoList.map(async (img, index) => {
        if (albumData.images.indexOf(img) > -1) {
          images.push(img);
        }
        if (photoList.length === index + 1) {
          const data = {
            ...req.body,
            images
          };
          const rez = await update(data);
          res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
        }
      })
    } else {
      let photoList = JSON.parse(req.body.photoList);
      photoList.map(async (img, index) => {
        if (albumData.images.indexOf(img) > -1) {
          images.push(img);
        }
        if (photoList.length === index + 1) {
          const data = {
            ...req.body,
            images
          };
          const rez = await update(data);
          res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
        }
      })
    }

  } catch (err) {
    next(err);
  }
};

exports.getAlbums = async (req, res, next) => {
  try {
    const albums = await getAll(req.query);
    res.status(OK).json({ data: albums, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getExpertAlbums = async (req, res, next) => {
  try {
    const albums = await getExpertAllAlbums(req.params.id);
    res.status(OK).json({ data: albums, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.GetMyAlbums = async (req, res, next) => {
  try {
    const data = await getMyAlbums(req.user.id);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getDetails = async (req, res, next) => {
  try {
    const album = await getAlbum(req.params.albumId);
    if (!album) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    }
    album.images = album.images.map((image) => getSignedUrl(image));
    res.status(OK).json({ data: album, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};


exports.InActiveAlbum = async (req, res, next) => {
  try {
    const rez = await inActive(req.params.id);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.ActiveAlbum = async (req, res, next) => {
  try {
    const rez = await active(req.params.id);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.deleteAlbum = async (req, res, next) => {
  try {
    const album = await deleteAlbumData(req.params.albumId);
    if (!album) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    }
    res.status(OK).json({ data: album, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.addLikeOnAlbum = async (req, res, next) => {
  try {
    const data = {
      userId: req.user.id,
      albumId: req.body.id
    };
    const rez = await albumLikeCreate(data);
    res.status(CREATED).json({ data: rez, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};