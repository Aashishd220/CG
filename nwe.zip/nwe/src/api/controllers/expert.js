const axios = require('axios');
const Cookie = require('universal-cookie');
const Bookings = require('../models/booking');
const Expert = require('../models/expert');
const Learning = require('../models/learning');
const {
  create, update, get, getAll,
  updateProfileApproval, GetExpertsList,
  getAllMessages, replyToMessage, getForEdit,
  UploadCover, getEnthMessages, getEnthTripMessages,
  getAllChatSession, getChatMessages, getAllChatSessionCount, UploadBookCover,UpdateExpertLocation,updateExpertOriginalCover
} = require('../services/experts');
const {
  UpdateMessage, DeleteMessage, HideMessage, UpdateMessages,
  UpdateSidebarMessages, FindMessageUpdate, DeleteSingleMessage,
} = require('../services/comman');
const { SendMessage, SendMessageEnthus } = require('../services/trips');
const Trip = require('../models/trips');
const { CREATED, OK } = require('../../utils/constants');
const { UploadFile, getSignedUrl,uploadFileOnAWS } = require('../../utils/helper');
const APIError = require('../../utils/APIError');
const logger = require('../../config/logger');

exports.createExpert = async (req, res, next) => {
  try {
    if (!req.files || (req.files.picture === undefined)) {
      throw new APIError({ message: 'Picture is required field', status: 400 });
    }
    // const profile =  generateCoverName('profile', req.files.picture);
    const originalProfile = generateCoverName('profile', req.files.originalPicture);
    const profile = await UploadFile('profile', req.files.picture);

    // let booksAndPublications = [];
    // if (req.body.booksAndPublications && Array.isArray(req.body.booksAndPublications)) {
    //   booksAndPublications = await Promise.all(
    //     req.body.booksAndPublications.map(async (book, index) => {
    //       if (req.files && (req.files[`booksAndPublications-${index}`] !== undefined)) {
    //         const bookCover = await UploadFile(
    //           'bookCover',
    //           req.files[`booksAndPublications-${index}`],
    //         );
    //         return {
    //           name: book.name,
    //           url: book.url,
    //           cover: bookCover,
    //         };
    //       }
    //       return {
    //         name: book.name,
    //         url: book.url,
    //       };
    //     }),
    //   );
    // }
    const data = {
      ...req.body,
      profile,
      originalProfile,
      // booksAndPublications,
      user: req.user.id,
    };
    const ex = await create(data);
    res.status(CREATED).json({ data: ex, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

const getExtension = (filename) => {
  const i = filename.lastIndexOf('.');
  return (i < 0) ? '' : filename.substr(i);
};

const generateCoverName= (key,files,fileName)=>{
  try{
    console.log("herreeeeeee")
    const name = `${fileName}${getExtension(files.name)}`;
    console.log("naamemmeeee "+name)
    const params = {
      Bucket: `expeditions-connect-bucket/${key}`,
      Key: name,
      ContentType: files.mimetype,
      Body: files.data,
    };
    uploadFileOnAWS(params);
    return `${key}/`+name;
  }
  catch(err){
    
  }
}



exports.getExpert = async (req, res, next) => {
  try {
    const data = await get(req.params.id);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getExpertForEdit = async (req, res, next) => {
  try {
    const data = await getForEdit(req.user.id);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateExpert = async (req, res, next) => {
  try {

    if (req.files && (req.files.originalPicture !== undefined)) {
      const nameCoveFile = ((new Date().getTime())+1).toString();
      req.body.originalProfile = generateCoverName('profile', req.files.originalPicture, nameCoveFile );
    }
    if (req.files && (req.files.picture !== undefined)) {
      const nameFile = new Date().getTime().toString();
      req.body.profile = await UploadFile('profile', req.files.picture);
     
      // req.body.profile = generateCoverName('profile', req.files.picture, nameFile);
    }
 
  
    // let booksAndPublications = [];
    // if (req.body.booksAndPublications && Array.isArray(req.body.booksAndPublications)) {
    //   booksAndPublications = await Promise.all(
    //     req.body.booksAndPublications.map(async (book, index) => {
    //       if (req.files && (req.files[`booksAndPublications-${index}`] !== undefined)) {
    //         const bookCover = await UploadFile(
    //           'bookCover',
    //           req.files[`booksAndPublications-${index}`],
    //         );
    //         return {
    //           name: book.name,
    //           url: book.url,
    //           cover: bookCover,
    //         };
    //       }
    //       return {
    //         name: book.name,
    //         url: book.url,
    //       };
    //     }),
    //   );
    // }

    // req.body.booksAndPublications = booksAndPublications;

    const ex = await update(req.user.id, req.body);
    res.status(OK).json({ data: ex, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getExperts = async (req, res, next) => {
  try {
    if (req.user) {
      const { interest } = req.query;
      req.query.interest = interest || req.user.interest;
    }
    const { count, experts } = await getAll(req.query);
    res.status(OK).json({ data: experts, succes: 'SUCCESS', count });
  } catch (err) {
    next(err);
  }
};

exports.approveExpertProfile = async (req, res, next) => {
  try {
    const data = await updateProfileApproval(req.params.id, req.body.approve);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getListOfExperts = async (req, res, next) => {
  try {
    const { count, experts } = await GetExpertsList();
    res.status(OK).json({ data: experts, succes: 'SUCCESS', count });
  } catch (err) {
    next(err);
  }
};

exports.getMyAllMessages = async (req, res, next) => {
  try {
    const messages = await getAllMessages(req.user.id);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getAllMessages = async (req, res, next) => {
  try {
    const messages = await getEnthMessages(req.params.id);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getAllTripMessages = async (req, res, next) => {
  try {
    const messages = await getEnthTripMessages(req.params.id, req.params.trip_id);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.replyToMyMessage = async (req, res, next) => {
  try {
    const messages = await replyToMessage(req.body.id, req.body.reply);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.uploadCover = async (req, res, next) => {
  try {
     let check;
     let data;
     if(req.query && req.query.check){
       check=req.query.check;
     }
     console.log("fileeeeeeeeeeeeeeeeeeeeeeee"+JSON.stringify(req.files.cover))
    if (check!=='delete' && (!req.files || (req.files.cover === 'undefined'))) {
      throw new APIError({ message: 'Picture is required field', status: 400 });
    }
    const nameFile = new Date().getTime().toString();
    
    if(check!=='delete'){
      const profile = generateCoverName('cover', req.files.cover,nameFile);
       data = await UploadCover(req.user.id, profile,check);
    }
    else{
       data = await UploadCover(req.user.id, '',check);
    }
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.editCover = async (req, res, next) => {
  try {
    if (!req.files || (req.files.cover === 'undefined')) {
      throw new APIError({ message: 'Picture is required field', status: 400 });
    }
    const profile = generateCoverName('cover', req.files.cover);
    const data = await UploadCover(req.user.id, profile);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};


exports.getMyAllMessagesSession = async (req, res, next) => {
  try {
    const { name, status } = req.query;
    const messages = await getAllChatSession(req.user.id, name, status);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};


exports.getSessionMessages = async (req, res, next) => {
  try {
    const messages = await getChatMessages(req.body.enthuId, req.user.id, req.body.trip, req.body.type, req.body.learning, req.body.status);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.sendMessage = async (req, res, next) => {
  try {
    const Obj = {
      user: req.body.expertId,
      message: req.body.message,
      sender_userid: req.user.id,
      receiver_userid: req.body.expertId,
      media: req.body.media,
    };

    if (req.body.type === 'trip') {
      const trip = await Trip.findById(req.body.tripId);
      Obj.trip = trip.id;
      Obj.type = 'trip';
      Obj.expert = trip.expert;
    }
    if (req.body.type === 'learning') {
      const learning = await Learning.findOne({ _id: req.body.learning });
      Obj.learning = learning._id;
      Obj.type = 'learning';
      Obj.expert = learning.expert;
    }
    if (req.body.status === 'hidden') {
      Obj.hide = true;
    }
    const msg = await SendMessageEnthus(Obj);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.readMessage = async (req, res, next) => {
  try {
    const { action } = req.body;
    const data = action && action === 'unread' ? { status: false } : { status: true };
    const msg = await UpdateMessage(req.body.id, data);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.deleteMessages = async (req, res, next) => {
  try {
    const msg = await UpdateMessages(req.body.trip_id, req.body.learning, req.body.type, req.user.id, req.body.receiver_id, { expert_delete: true });
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.hideMessages = async (req, res, next) => {
  try {
    const msg = await UpdateMessages(req.body.trip_id, req.body.learning, req.body.type, req.user.id, req.body.receiver_id, { expert_hide: true });
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.starMessages = async (req, res, next) => {
  try {
    const msg = await UpdateMessages(req.body.trip_id, req.body.learning, req.body.type, req.user.id, req.body.receiver_id, { expert_bookmark: req.body.star });
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.unReadMessage = async (req, res, next) => {
  try {
    const msg = await UpdateSidebarMessages(req.body.trip_id, req.user.id, req.body.receiver_id);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.uploadMessage = async (req, res, next) => {
  try {
    const f = await UploadFile('message', req.files.file);
    const data = {
      name: req.files.file.name,
      url: getSignedUrl(f),
      status: 'done',
    };
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.editMessage = async (req, res, next) => {
  try {
    const { id, ...data } = req.body;
    const message = await FindMessageUpdate(id, data);
    res.status(OK).json({ message, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.deleteMessage = async (req, res, next) => {
  try {
    const { id } = req.body;
    const message = await DeleteSingleMessage(id);
    res.status(OK).json({ message, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.confirmBooking = async (req, res, next) => {
  try {
    let booking;

    const {
      tripId, user, type, learning,
    } = req.body;

    const expert = await Expert.findOne({ user: req.user.id });

    if (req.body.type === 'trip') {
      booking = await Bookings.find({ trip: tripId, expert: expert._id, user }).sort({ createdAt: -1 });
    }

    if (req.body.type === 'learning') {
      booking = await Bookings.find({ learning, expert: expert._id, user }).sort({ createdAt: -1 });
    }

    if (!booking) {
      throw new APIError({ message: 'Booking reacord not find.', status: 400 });
    }

    if (!booking[0].payment) {
      throw new APIError({ message: 'Booking payment is still in awaiting.', status: 400 });
    }

    const book = await Bookings.findOneAndUpdate({ _id: booking[0].id }, { confirm: true, confirmDate: new Date() });

    res.status(OK).json({ book, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getUnreadCount = async (req, res, next) => {
  try {
    const messages = await getAllChatSessionCount(req.user.id);
    res.status(OK).json({ data: messages, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};



exports.uploadBookCover = async (req, res, next) => {
  try {
    if (!req.files || (req.files.cover === 'undefined')) {
      throw new APIError({ message: 'Picture is required field', status: 400 });
    }
    const book = await UploadFile('cover', req.files.cover);
    const data = await UploadBookCover(req.user.id, req.body.bookid, book);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateExpertOriginalCover = async (req, res, next) => {
 try{
  const {  experts } = await getAll(req.query);
  if(experts && experts.length>0){
    experts.map((expert)=>{
     updateExpertOriginalCover(expert);
    })
  }
  res.status(OK).json({ data: experts, succes: 'SUCCESS' });
 } catch (err) {
  next(err);
}
};



exports.updateExpertLocation = async (req, res, next) => {
  try {
    logger.info("Calleddd")
    const { count, experts } = await getAll(req.query);
    if(experts && experts.length>0){
      experts.map((expert)=>{
        getLatLong(expert)
      })
    }
    
    res.status(OK).json({ data: experts, succes: 'SUCCESS', count });
  } catch (err) {
    next(err);
  }
};

getLatLong= async (expert)=>{
  try{
    if(expert.city){
      let res=await axios.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${expert.city}&key=AIzaSyDRbkCf-zFbUjLsY62KXua-1p-cVmrj6v0`)
     let data={...expert,
       location: {
         type: 'Point',
         coordinates:res.data.results[0].geometry.location}
       }
     UpdateExpertLocation(data)
   }
   else{
    let res=await axios.get(`https://maps.googleapis.com/maps/api/geocode/json?address=Chandigarh&key=AIzaSyDRbkCf-zFbUjLsY62KXua-1p-cVmrj6v0`)
    let data={...expert,
      location: {
        type: 'Point',
        coordinates:res.data.results[0].geometry.location}
      }
    UpdateExpertLocation(data)
   }
 
  }catch(err){
    console.log(err)
  }
  
 }