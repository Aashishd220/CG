const APIError = require('../../utils/APIError');
const Expert = require('../models/expert');
const Learning = require('../models/learning');
const LearningsLikes = require('../models/learningsLikes');

const { UploadFile, getSignedUrl,uploadFileOnAWS } = require('../../utils/helper');
const {
  create,
  getLearnings,
  getMyLearnings,
  UpcomingLearnings,
  getSimilarLearnings,
  update,
  SendMessage,
  inActive,
  active,
  UploadAccomodationPhotos,
  getLearningPlusTrip,
  learningLikeCreate,
  updateCurrency,
  updateExpertLearningOriginalCover
} = require('../services/learning');
const { ErrorHandler } = require('../../middleware/error');
const {
  CREATED,
  NOT_FOUND,
  NO_RECORD_FOUND,
  OK,
  FORBIDDEN_ACCESS,
  UNAUTHORIZED,
} = require('../../utils/constants');
const { convertCurrency, getPreferredCurrency } = require('../../utils/currency');

exports.loadLearning = async (req, res, next, id) => {
  try {
    const learning = await Learning.findById(id).populate(
      'expert',
      'firstName lastName profile country experties user speaks city',
    );
    if (!learning) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    }
    req.locals = { learning };
    return next();
  } catch (error) {
    return ErrorHandler(error, req, res, next);
  }
};

exports.createLearning = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user.id });
    if (!expert.approved) {
      throw new APIError({
        message:
          'Your profile needs be to approved by admins in order to add a trip or workshop',
        status: 401,
      });
    }
    if (req.files) {
      const originalCover =  generateCoverName('cover', req.files.originalCover);
      const cover = await UploadFile('cover', req.files.cover);
      // const cover = awa generateCoverName('cover', req.files.cover);
      const data = { ...req.body, cover,originalCover, expert: expert._id };
      const rez = await create(data);
      res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    } else {
      const data = { ...req.body, expert: expert._id };
      const rez = await create(data);
      res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    }
  } catch (err) {
    next(err);
  }
};

const getExtension = (filename) => {
  const i = filename.lastIndexOf('.');
  return (i < 0) ? '' : filename.substr(i);
};

const generateCoverName= (key,files)=>{
  try{
    console.log("herreeeeeee")
    const name = `${new Date().getTime().toString()}${getExtension(files.name)}`;
    console.log("naamemmeeee "+name)
    const params = {
      Bucket: `expeditions-connect-bucket/${key}`,
      Key: name,
      ContentType: files.mimetype,
      Body: files.data,
    };
    uploadFileOnAWS(params);
    return "cover/"+name;
  }
  catch(err){
    
  }
}

 

// exports.createLearning = async (req, res, next) => {
//   try {
//     const expert = await Expert.findOne({ user: req.user.id });
//     if (!expert.approved) {
//       throw new APIError({
//         message:
//           'You need to get your profile approved before creating learning',
//         status: 401,
//       });
//     }
//     if (!req.files || req.files.cover === 'undefined') {
//       throw new APIError({
//         message: 'Cover Picture is required field',
//         status: 400,
//       });
//     }
//     const cover = await UploadFile('cover', req.files.cover);
//     const data = { ...req.body, cover, expert: expert._id };
//     const rez = await create(data);
//     res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
//   } catch (err) {
//     next(err);
//   }
// };

exports.getDetails = async (req, res, next) => {
  try {
    const { learning } = req.locals;
    const preferredCurrency = getPreferredCurrency(req);
    if(learning.cover){
      learning.cover = getSignedUrl(learning.cover);
    }
    else{
      learning.cover=null;
    }
    if(learning.originalCover){
      learning.originalCover = getSignedUrl(learning.originalCover);
    }
    else{
      learning.originalCover=null;
    }
    learning.expert.profile = getSignedUrl(learning.expert.profile);
    learning.accomodationPhotos = typeof learning.accomodationPhotos !== "undefined" && learning.accomodationPhotos !== null ? learning.accomodationPhotos.map((image) => getSignedUrl(image)) : [];
    learning.price = await convertCurrency(
      learning.priceCurrency,
      preferredCurrency,
      learning.price,
    );
    learning.likes = await LearningsLikes.find({ learningId: learning._id });
    learning.pageType = "workshop";
    learning.priceCurrency = preferredCurrency;
    learning.dateTime = await Promise.all(
      learning.dateTime.map(async (dateTime) => ({
        ...dateTime._doc,
        priceCurrency: preferredCurrency,
        price: await convertCurrency(
          dateTime.priceCurrency,
          preferredCurrency,
          dateTime.price,
        ),
      })),
    );
    res.status(OK).json({ data: learning, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.GetLearnings = async (req, res, next) => {
  try {
    const preferredCurrency = getPreferredCurrency(req);
    const data = await getLearnings(req.query, preferredCurrency);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.GetMyLearnings = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user.id });
    const preferredCurrency = getPreferredCurrency(req);
    const data = await getMyLearnings(expert._id, preferredCurrency);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getUpcomingExpertLearnings = async (req, res, next) => {
  try {
    const preferredCurrency = getPreferredCurrency(req);
    const trips = await UpcomingLearnings(req.params.id, preferredCurrency);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateLearnings = async (req, res, next) => {
  try {
    const { learning } = req.locals;
    if (learning.expert.user.toString() !== req.user.id.toString()) {
      throw new APIError({ message: FORBIDDEN_ACCESS, status: UNAUTHORIZED });
    }
    // if (req.files && req.files.picture !== 'undefined') {
    //   req.body.cover = await UploadFile('cover', req.files.cover);
    //   req.body.originalCover = await UploadFile('cover', req.files.originalCover);

    // }
    
    if (req.files && req.files.picture !== 'undefined') {
      req.body.originalCover =  generateCoverName('cover', req.files.originalCover);
      req.body.cover = await UploadFile('cover', req.files.cover);
    }
    const rez = await update(learning, req.body);
    res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateExpertLearningOriginalCover = async (req, res, next) => {
  try{
    const preferredCurrency = getPreferredCurrency(req);
    const learnings = await getLearnings(req.query,preferredCurrency);

    if(learnings.data && learnings.data.length>0){
      learnings.data.map((learning)=>{
        updateExpertLearningOriginalCover(learning)
      })
    }
  res.status(OK).json({ data: learnings, succes: 'SUCCESS' });
  }
   catch (err) {
    next(err);
  }
};

exports.InActiveLearning = async (req, res, next) => {
  try {
    const rez = await inActive(req.params.id);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.ActiveLearning = async (req, res, next) => {
  try {
    const rez = await active(req.params.id);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.GetSimilarLearning = async (req, res, next) => {
  try {
    const { activity } = req.query;
    const preferredCurrency = getPreferredCurrency(req);
    const trips = await getSimilarLearnings(activity, preferredCurrency);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.sendMessage = async (req, res, next) => {
  try {
    const { learning } = req.locals;
    const Obj = {
      user: req.user.id,
      expert: learning.expert,
      message: req.body.message,
      learning: learning.id,
      type: 'learning',
      sender_userid: req.user.id,
      receiver_userid: learning.expert.user
    };
    const origin = `${req.headers.origin}`;
    const msg = await SendMessage(Obj, origin);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.UploadLearningsAccomodationPhotos = async (req, res, next) => {
  try {
    const { id } = req.params;
    const trips = await UploadAccomodationPhotos(id, req.files.photos);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.copyLearning = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user.id });
    if (!expert.approved) {
      throw new APIError({
        message:
          'Your profile needs be to approved by admins in order to add a trip or workshop',
        status: 401,
      });
    }
    const learning = await Learning.findById(req.body.id);
    if (!learning) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    }
    const preferredCurrency = getPreferredCurrency(req);
    delete learning._id;
    const data = {
      title: `Copy of ${learning.title}`,
      active: false,
      expert: expert._id,
      cover: learning.cover,
      dateType: learning.dateType,
      cancellantion: learning.cancellantion,
      extras: learning.extras,
      exclusion: learning.exclusion,
      inclusion: learning.inclusion,
      itenary: JSON.stringify(learning.itenary),
      accomodation: learning.accomodation,
      attend: learning.attend,
      whatLearn: learning.whatLearn,
      description: learning.description,
      meetingPoint: learning.meetingPoint,
      country: learning.country,
      workshopMedium: learning.workshopMedium,
      workshopType: learning.workshopType,
      dateTime: JSON.stringify(learning.dateTime),
      skill: learning.skill,
      price: await convertCurrency(learning.priceCurrency, preferredCurrency, learning.price),
      priceCurrency: preferredCurrency,
      duration: learning.duration,
      durationType: typeof learning.durationType !== "undefined" ? learning.durationType : "days",
      langauge: JSON.stringify(learning.langauges),
      activity: JSON.stringify(learning.activity),
      coordinates: JSON.stringify(learning.location.coordinates),
      participants: learning.participants,
      address: learning.address,
    };
    const newDoc = await create(data);
    res.status(CREATED).json({ data: newDoc, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};


exports.GetLearningPlusTrip = async (req, res, next) => {
  try {
    const preferredCurrency = getPreferredCurrency(req);
    const data = await getLearningPlusTrip(req.query, preferredCurrency);
    res.status(OK).json({ data, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};


exports.addLikeOnLearnings = async (req, res, next) => {
  try {
    const data = {
      userId: req.user.id,
      learningId: req.body.id
    };
    const rez = await learningLikeCreate(data);
    res.status(CREATED).json({ data: rez, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateCurrency = async (req, res) => {
  try {
    const rez = await updateCurrency();
    res.status(CREATED).json({ data: rez, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};
