const _ = require('lodash');
const APIError = require('../../utils/APIError');
const Trip = require('../models/trips');
const TripLikes = require('../models/tripsLikes');
const Expert = require('../models/expert');
const { ErrorHandler } = require('../../middleware/error');
const { UploadFile, getSignedUrl,uploadFileOnAWS } = require('../../utils/helper');
const { convertCurrency, getPreferredCurrency } = require('../../utils/currency');
const {
  create, tripLikeCreate, update,
  getMyTrips, getTripsAll,
  SendMessage, UpcomingTrips, inActive, active,
  GetTravelMaps, getSimilarTrips, getRecentTrips,
  UploadAccomodationPhotos,
  UploadAccommoPhotos, updateAccommoImage, updatePhotosAndVideo,updateTripsOriginalCover
} = require('../services/trips');
const {
  CREATED, NOT_FOUND, NO_RECORD_FOUND,
  UNAUTHORIZED, FORBIDDEN_ACCESS, OK,
} = require('../../utils/constants');
const logger = require('../../config/logger');

exports.loadTrips = async (req, res, next, id) => {
  try {
    const trip = await Trip.findById(id).populate('expert', 'firstName lastName profile country experties user speaks city');
    if (!trip) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    }
    req.locals = { trip };
    return next();
  } catch (error) {
    return ErrorHandler(error, req, res, next);
  }
};

exports.updateTripsOriginalCover = async (req, res, next) => {
  try{
    const preferredCurrency = getPreferredCurrency(req);
    const { trips, count } = await getTripsAll(req.query, preferredCurrency);
   
    if(trips && trips.length>0){
      trips.map((trip)=>{
        updateTripsOriginalCover(trip)
      })
    }
  res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  }
   catch (err) {
    next(err);
  }
};

exports.createTrips = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user.id });
    if (!expert.approved) {
      throw new APIError({ message: 'You need to get your profile approved before creating trip', status: 401 });
    }
    if (req.files) {
      const accomodationImages = [];
      if (req.files.accomodationPhotos) {
        if (Array.isArray(req.files.accomodationPhotos)) {
          /* eslint-disable */
          for (let index = 0; index < req.files.accomodationPhotos.length; index++) {
            const pic = req.files.accomodationPhotos[index];
            /* eslint-disable */
            const picture = await UploadFile('photos', pic);
            accomodationImages.push(picture);
          }
        } else {
          const picture = await UploadFile('photos', req.files.accomodationPhotos);
          accomodationImages.push(picture);
        }
      }

      // const cover =  generateCoverName('cover', req.files.cover);
      const originalCover =  generateCoverName('cover', req.files.originalCover);
      const cover = await UploadFile('cover', req.files.cover);

      const data = { ...req.body, cover,originalCover, accomodationPhotos: accomodationImages, expert: expert._id };
      const rez = await create(data);
      res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    } else {
      const data = { ...req.body, expert: expert._id };
      const rez = await create(data);
      res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    }
  } catch (err) {
    next(err);
  }
};


const getExtension = (filename) => {
  const i = filename.lastIndexOf('.');
  return (i < 0) ? '' : filename.substr(i);
};

const generateCoverName= (key,files)=>{
  try{
    console.log("herreeeeeee")
    const name = `${new Date().getTime().toString()}${getExtension(files.name)}`;
    console.log("naamemmeeee "+name)
    const params = {
      Bucket: `expeditions-connect-bucket/${key}`,
      Key: name,
      ContentType: files.mimetype,
      Body: files.data,
    };
    uploadFileOnAWS(params);
    return "cover/"+name;
  }
  catch(err){
    
  }
}


// exports.createTrips = async (req, res, next) => {
//   try {
//     const expert = await Expert.findOne({ user: req.user.id });
//     if (!expert.approved) {
//       throw new APIError(
//           { message: 'You need to get your profile approved before creating trip'
//             , status: 401 });
//     }
//     if (!req.files || (req.files.cover === 'undefined')) {
//       throw new APIError({ message: 'Cover Picture is required field', status: 400 });
//     }
//     const cover = await UploadFile('cover', req.files.cover);
//     const data = { ...req.body, cover, expert: expert._id };
//     const rez = await create(data);
//     res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
//   } catch (err) {
//     next(err);
//   }
// };

exports.addLikeOnTrips = async (req, res, next) => {
  try {
    const data = {
      userId: req.user.id,
      tripId: req.body.id
    };
    const rez = await tripLikeCreate(data);
    res.status(CREATED).json({ data: rez, success: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.updateTrips = async (req, res, next) => {
  try {
    const { trip } = req.locals;
    if (trip.expert.user.toString() !== req.user.id.toString()) {
      throw new APIError({ message: FORBIDDEN_ACCESS, status: UNAUTHORIZED });
    }


    if (req.files && req.files.cover) {
      // req.body.cover = generateCoverName('cover', req.files.cover);
      req.body.originalCover =generateCoverName('cover', req.files.originalCover);
      req.body.cover = await UploadFile('cover', req.files.cover);
    
    }

    const accomodationImages = [];

    /* disable accomodation images code */
    /* if (req.files && req.files.accomodationPhotos !== undefined) {



    /*const accomodationImages = [];

    if (req.files && req.files.accomodationPhotos !== undefined) {

      if (Array.isArray(req.files.accomodationPhotos)) {
        /* eslint-disable
        for (let index = 0; index < req.files.accomodationPhotos.length; index++) {
          const pic = req.files.accomodationPhotos[index];
          /* eslint-disable
          const picture = await UploadFile('photos', pic);
          accomodationImages.push(picture);
        }
      } else {
        const picture = await UploadFile('photos', req.files.accomodationPhotos);
        accomodationImages.push(picture);
      }

      let photoList = JSON.parse(req.body.accomodationPhotoList);
      photoList.map(async (img, index) => {
        if (trip.accomodationPhotos.indexOf(img) > -1) {
          accomodationImages.push(img);
        }
        if (photoList.length === index + 1) {
          const data = {
            ...req.body,
            accomodationPhotos: accomodationImages
          };
          const rez = await update(trip, data);
          res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
        }
      })
    } else {
      let photoList = JSON.parse(req.body.accomodationPhotoList);
      photoList.map(async (img, index) => {
        if (trip.accomodationPhotos.indexOf(img) > -1) {
          accomodationImages.push(img);
        }
        if (photoList.length === index + 1) {
          const data = {
            ...req.body,
            accomodationPhotos: accomodationImages
          };
          const rez = await update(trip, data);
          res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
        }
      })
    }*/


    // const images = [];
    // const albumData = trip;
    // if (req.files && req.files.picture !== 'undefined') {
    //   if (Array.isArray(req.files.pictures)) {
    //     /* eslint-disable */
    //     for (let index = 0; index < req.files.pictures.length; index++) {
    //       const pic = req.files.pictures[index];
    //       /* eslint-disable */
    //       const picture = await UploadFile('albums', pic);
    //       images.push(picture);
    //     }
    //   } else {
    //     const picture = await UploadFile('albums', req.files.pictures);
    //     images.push(picture);
    //   }
    //   let photoList = JSON.parse(req.body.photoList);
    //   photoList.map(async (img, index) => {
    //     if (albumData.images.indexOf(img) > -1) {
    //       images.push(img);
    //     }
    //     if (photoList.length === index + 1) {
    //       const data = {
    //         ...req.body,
    //         images
    //       };
    //       const rez = await update(trip, data);
    //       res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    //     }
    //   })
    // } else {
    //   let photoList = JSON.parse(req.body.photoList);
    //   photoList.map(async (img, index) => {
    //     if (albumData.images.indexOf(img) > -1) {
    //       images.push(img);
    //     }
    //     if (photoList.length === index + 1) {
    //       const data = {
    //         ...req.body,
    //         images
    //       };
    //       // const rez = await update(data);
    //       const rez = await update(trip, data);
    //       res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    //     }
    //   })
    // }
    /******/

    const rez = await update(trip, req.body);
    res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.InActiveTrip = async (req, res, next) => {
  try {
    const rez = await inActive(req.params.id);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};


exports.ActiveTrip = async (req, res, next) => {
  try {
    const rez = await active(req.params.id);
    res.status(OK).json({ data: rez, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getTrips = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user.id });
    if (!expert.approved) {
      throw new APIError({ message: 'You need to get your profile approved before creating trip', status: 401 });
    }
    const preferredCurrency = getPreferredCurrency(req);
    const trips = await getMyTrips(expert._id, preferredCurrency);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getAllTrips = async (req, res, next) => {
  try {
    const preferredCurrency = getPreferredCurrency(req);
    const { trips, count } = await getTripsAll(req.query, preferredCurrency);
    res.status(OK).json({ data: trips, count, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.GetRecentTrips = async (req, res, next) => {
  try {
    const preferredCurrency = getPreferredCurrency(req);
    const { trips } = await getRecentTrips(preferredCurrency);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getDetails = async (req, res, next) => {
  try {
    const { trip } = req.locals;
    const preferredCurrency = getPreferredCurrency(req);

    trip.expert.profile = getSignedUrl(trip.expert.profile);
    if(trip.cover){
      trip.cover = getSignedUrl(trip.cover);
    }
    else{
      trip.cover=null;
    }
    if(trip.originalCover){
      trip.originalCover = getSignedUrl(trip.originalCover);
    }
    else{
      trip.originalCover=null;
    }
    trip.accomodationPhotos = trip.accomodationPhotos.map((image) => getSignedUrl(image));
    trip.price = await convertCurrency(trip.priceCurrency, preferredCurrency, trip.price);
    trip.priceCurrency = preferredCurrency;
    trip.likes = await TripLikes.find({ tripId: trip._id });
    trip.dateTime = await Promise.all(trip.dateTime.map(async (d) => {
      return {
        ...d._doc,
        price: await convertCurrency(d.priceCurrency, preferredCurrency, d.price),
        priceCurrency: preferredCurrency
      }
    }));
    res.status(OK).json({ data: trip, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.sendMessage = async (req, res, next) => {
  try {
    const { trip } = req.locals;
    const Obj = {
      user: req.user.id,
      expert: trip.expert,
      message: req.body.message,
      trip: trip._id,
      type: 'trip',
      sender_userid: req.user.id,
      receiver_userid: trip.expert.user
    };
    const msg = await SendMessage(Obj);
    res.status(OK).json({ data: msg, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getUpcomingExpertTrips = async (req, res, next) => {
  try {
    const preferredCurrency = getPreferredCurrency(req);
    const trips = await UpcomingTrips(req.params.id, preferredCurrency);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.getTravelMap = async (req, res, next) => {
  try {
    const trips = await GetTravelMaps(req.params.id);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.GetSimilarTrips = async (req, res, next) => {
  try {
    const { activity, type } = req.query;
    const preferredCurrency = getPreferredCurrency(req);
    const trips = await getSimilarTrips(activity, type, preferredCurrency);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.UploadTripsAccomodationPhotos = async (req, res, next) => {
  logger.info('UploadTripsAccomodationPhotos');

  try {
    const { id } = req.params;
    const trips = await UploadAccomodationPhotos(id, req.files.photos);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.UploadTripsAccomodationPhotosUpload = async (req, res, next) => {
  logger.info('UploadTripsAccomodationPhotosUpload');
  try {

    const { id } = req.params;
    const trips = await UploadAccommoPhotos(id, req.files.pictures, req.body.type);
    res.status(OK).json({ data: trips, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};

exports.copyTrip = async (req, res, next) => {
  try {
    const expert = await Expert.findOne({ user: req.user.id });
    if (!expert.approved) {
      throw new APIError({
        message:
          'Your profile needs be to approved by admins in order to add a trip or workshop',
        status: 401,
      });
    }
    const trip = await Trip.findById(req.body.id);
    if (!trip) {
      throw new APIError({ message: NO_RECORD_FOUND, status: NOT_FOUND });
    }
    const preferredCurrency = getPreferredCurrency(req);
    delete trip._id;

    const data = {
      title: `Copy of ${trip.title}`,
      active: false,
      accomodation: trip.accomodation,
      accomodationPhotos: trip.accomodationPhotos,
      activity: JSON.stringify(trip.activity),
      attend: trip.attend,
      cancellations: trip.cancellations,
      country: trip.country,
      cover: trip.cover,
      dateTime: JSON.stringify(trip.dateTime),
      dateType: trip.dateType,
      description: trip.description,
      difficulty: trip.difficulty,
      duration: trip.duration,
      durationType: typeof trip.durationType !== "undefined" ? trip.durationType : "days",
      exclusion: trip.exclusion,
      expert: trip.expert,
      extras: trip.extras,
      inclusion: trip.inclusion,
      itenary: JSON.stringify(trip.itenary),
      language: trip.language,
      coordinates: JSON.stringify(trip.location.coordinates),
      meetingPoint: trip.meetingPoint,
      participants: trip.participants,
      price: await convertCurrency(trip.priceCurrency, preferredCurrency, trip.price),
      priceCurrency: preferredCurrency,
      skill: trip.skill,
      suitable: trip.suitable,
      type: JSON.stringify(trip.type),
      whatLearn: trip.whatLearn,
      address: trip.address,
    };
    const newTrip = await create(data);
    res.status(CREATED).json({ data: newTrip, succes: 'SUCCESS' });
  } catch (err) {
    next(err);
  }
};



exports.updateAccommo = async (req, res, next) => {
  try {
    const images = [];
    let tmpPhotoList = typeof req.body.photoList !== "undefined" ? req.body.photoList : [];

    if (req.files && req.files.picture !== 'undefined') {
      if (Array.isArray(req.files.pictures)) {
        /* eslint-disable */

        for (let index = 0; index < req.files.pictures.length; index++) {
          const pic = req.files.pictures[index];
          /* eslint-disable */
          const picture = await UploadFile('photos', pic);
          images.push(picture);
        }
      } else {

        const picture = await UploadFile('photos', req.files.pictures);
        images.push(picture);
      }

      let photoList = tmpPhotoList.length > 0 ? JSON.parse(tmpPhotoList) : [];
      const rez = await updateAccommoImage(req.body, images.concat(photoList));
      res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    } else {
      let photoList = tmpPhotoList.length > 0 ? JSON.parse(tmpPhotoList) : [];
      const rez = await updateAccommoImage(req.body, photoList);
      res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });
    }

  } catch (err) {
    next(err);
  }
};

exports.updatePhotosAndVideo = async (req, res, next) => {
  try {

    const rez = await updatePhotosAndVideo(req.body);

    res.status(CREATED).json({ data: rez, succes: 'SUCCESS' });

  } catch (err) {
    next(err);
  }
};
