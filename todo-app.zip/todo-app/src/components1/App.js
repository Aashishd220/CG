import React, { useReducer ,useEffect} from "react";
import {MessageContext} from '../context1/MessageContext'
import reducers from '../context1/reducers'
import MessageForm from "./MessageForm";
import Messages from "./Messages";

const App=()=> {
  const[messages,dispatch]=useReducer(reducers,[],()=>{
    const localData=localStorage.getItem('messages');
   return  localData?JSON.parse(localData):[]
})
  

useEffect(() => {
  localStorage.setItem('messages',JSON.stringify(messages))
}, [messages])



  return (
    <div style={{background:"linear-gradient(-135deg, #c850c0, #4158d0)", height:"100vh"}}>
    <div className="container" >
    <MessageContext.Provider value={{messages,dispatch}}>
    <h1 style={{textAlign:"center",color:"white" ,padding:"20px 20px",margin:"10px 0px 50px 0px" ,fontSize:"60px",fontFamily:"500px" }}><i>TODO App</i></h1>
    <MessageForm/>
    <Messages/>
    </MessageContext.Provider>
    </div>
    </div>
  )
}

export default App;
