import React, { useState, useContext } from "react";
import { MessageContext } from "../context1/MessageContext";
import { ADD_MESSAGE } from "../context1/action.types";
import {v4} from 'uuid'

const MessageForm = () => {
  const [messageString, setMessageString] = useState("");
  const { dispatch } = useContext(MessageContext);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (messageString === "") {
      alert("You can't send a blank message");
      return;
    }
    const message = {
      messageString,
      id:v4()
    };
    dispatch({
        type:ADD_MESSAGE,
        payload:message
    })
    setMessageString("");
  };
  return (
    <div>
      <form className="form-inline"  onSubmit={handleSubmit}>
      <div className="form-group  mb-2">
        <input
        className="form-control "
          type="text"
          placeholder="Enter a task"
          value={messageString}
          onChange={(e) => setMessageString(e.target.value)}
        />
        
        </div>
        <button className="btn btn-primary mx-sm-3 mb-2">Set</button>
      </form>
    </div>
  );
};

export default MessageForm;
