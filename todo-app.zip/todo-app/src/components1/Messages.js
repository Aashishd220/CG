import React, { useContext } from 'react'
import {MessageContext} from '../context1/MessageContext'
import MessageDetail from './MessageDetail';

const Messages=()=> {
    const{messages}=useContext(MessageContext);
    if(messages.length==0){
        return(
            <div className="container" style={{marginTop:"50px"}}>
                <h1>No Task!!</h1>
            </div>
        )
    }
    const renderedList=messages.map((message)=>{
        return(
            <ul className="list-group" key={message.id}>
                <MessageDetail message={message}/>
            </ul>
        )
    })

    return(
        <div>
            {renderedList}
        </div>
    )
}


export default Messages
