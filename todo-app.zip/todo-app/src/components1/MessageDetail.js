import React, { useContext } from 'react'
import { MessageContext } from '../context1/MessageContext'
import { REMOVE_MESSAGE } from '../context1/action.types';


const MessageDetail=({message})=> {
    const{dispatch}=useContext(MessageContext);
    return (
        <div style={{display:"flex", marginTop:"10px" ,alignItems:"baseline"}}>
        <li className="list-group-item container   ">
            {message.messageString}
        </li>
            <button style={{marginLeft:"8px"}} className="btn btn-primary mb-2 " onClick={()=>{dispatch({type:REMOVE_MESSAGE,payload:message.id})}}>Completed</button>
            </div>
    )
}

export default MessageDetail


























