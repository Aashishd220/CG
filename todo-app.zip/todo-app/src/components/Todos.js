import React, { useContext } from 'react'
import { REMOVE_TODO } from '../context/action.types'
import { TodoContext } from '../context/TodoContext'


const Todos=()=> {
    const {todos,dispatch}=useContext(TodoContext);
    return (
        <ul>
            {todos.map((todo)=>{
                return(
                    <li key={todo.id}>
                       {todo.todoString}
                        <button onClick={()=>{dispatch({type:REMOVE_TODO,payload:todo.id})}}>Done</button>
                    </li>
                )
            })}
        </ul>
    )
}

export default Todos
