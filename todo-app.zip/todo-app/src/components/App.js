import React, {useReducer} from 'react'
import { TodoContext } from '../context/TodoContext'
import reducer from '../context/reducer'
import TodoForm from './TodoForm'
import Todos from './Todos'

const App=()=> {
    const [todos,dispatch]=useReducer(reducer,[])
    return(
        <TodoContext.Provider value={{todos,dispatch}}>
            <h1>Todo App with Context API</h1>
            <Todos/>
            <TodoForm/>
        </TodoContext.Provider>
    )
   
}

export default App
