import React from "react";
import ReactDOM from "react-dom";
import App from "./components1/App";


ReactDOM.render(<App />, document.querySelector("#root"));
