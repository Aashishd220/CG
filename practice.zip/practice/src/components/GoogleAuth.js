import React from 'react'

class GoogleAuth extends React.Component{
    render(){
        return(
            <div>
                Auth
            </div>
        )
    }
}

export default GoogleAuth