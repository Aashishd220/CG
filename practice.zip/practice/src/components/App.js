import React from 'react'
import PostList from './PostList'
import {BrowserRouter,Route,Link} from 'react-router-dom'
import Check from './check'
import GoogleAuth from './GoogleAuth'

const App=()=>{
    return (
        <div>
            <GoogleAuth/>
            <BrowserRouter>
                <Route path="/check" exact component={Check}/>
            </BrowserRouter>
            
        </div>
    )
}

export default App