var req = require('request');

var request =
    (function () {
        var that = {
            basic : req.defaults({
                headers: { 'Authorization': Buffer.from(process.env.cms_user + ':' + process.env.cms_token).toString('base64') }
            })
        };
        return {
            basic : that.basic
        };
    } ());


module.exports = {
    basic: request.basic
};

