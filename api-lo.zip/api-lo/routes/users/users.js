var CryptoJS = require("crypto-js");
var db = require("../../utilities/users/users");
let nodemailer = require('nodemailer');
let ejs = require('ejs')
var generator = require('generate-password');
transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'testload676@gmail.com',
        pass: 'devdash123#'
    }
});



const exp = 60;
module.exports = function (express, app, connection, middleware, jwt) {
    var router = express.Router();
    router.use(middleware.basic);
    router.get('/', async function (req, res) {
        try {
            res.status(200).send({
                status: true,
                message: "Health good"
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.post('/sign-up', async function (req, res) {
        try {
            if ((!req.body.hasOwnProperty('first_name') || req.body.first_name == "") ||
                (!req.body.hasOwnProperty('last_name') || req.body.last_name == "") ||
                (!req.body.hasOwnProperty('email') || req.body.email == "") ||
                (!req.body.hasOwnProperty('password') || req.body.password == "") ||
                (!req.body.hasOwnProperty('user_role'))) {
                res.status(400).send({ status: false, error: "Required field are missing" });
                return
            }
            let { first_name, last_name, email, password, user_role } = req.body;
            var encrypPassword = CryptoJS.AES.encrypt(password, 'loadCryptedPass').toString();
            let checkIfuserExit = await db.getUserByEmail(email)
            if (checkIfuserExit && checkIfuserExit.length > 0) {
                res.status(400).send({ status: false, message: "Email already exists!" });
            } else {
                let saveUser = await db.saveUser({ first_name, last_name, email, encrypPassword, user_role })
                if (saveUser) {
                    var path = `/media/frantic/projects/load/load-api/public/logo.png`
                    var fileContent = await ejs.renderFile(__dirname + '/../../public/sendEmail.ejs', { name: first_name, path: path })

                    if (!fileContent) {
                        console.log("Error in sending email")
                    }
                    var mailOptions = {
                        from: 'aashish.d.220@gmail.com',
                        to: email,
                        subject: 'Welcome to Lodash',
                        html: fileContent

                    };
                    await transporter.sendMail(mailOptions, function (error, info) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log('Email sent: ' + info.response);
                        }
                    });
                    let user = await db.getUserByEmail(email)
                    if (user && user.length > 0) {
                        user = user[0]
                        var token = jwt.sign({ user: { _id: user.id, email: user.email } }, app.get('superSecret'), {
                            expiresIn: `${exp}d`
                        });
                        user.token = token
                        res.status(200).send({ status: true, user: user });
                    } else {
                        res.status(400).send({ status: false, message: "Error while signup" });
                    }

                }

            }

        } catch (err) {
            res.status(400).send({ status: false, error: err });
        }
    });

    router.post('/sign-in', async function (req, res) {
        try {
           
            let { email, password } = req.body;
            let user = await db.signIn(email);
            if(user && user.length>0 && user[0].active!==1){
               return res.status(400).send({ status: false, message: "Admin has deactivated your account" });

            }
            if (user && user.length > 0) {
                user = user[0]
                var bytes = CryptoJS.AES.decrypt(user.password, 'loadCryptedPass');
                var decryptedPassword = bytes.toString(CryptoJS.enc.Utf8);
                if (decryptedPassword != password) {
                    res.status(400).send({ status: false, message: "Invalid credentials" });
                } else {
                    var token = jwt.sign({ user: { _id: user.id, email: user.email } }, app.get('superSecret'), {
                        expiresIn: `${exp}d`
                    });
                    user.token = token
                    user.password = null
                    res.status(200).send({ status: true, user: user });
                }
            } else {
                res.status(400).send({ status: false, message: "User Not found" });
            }
        } catch (err) {
            res.status(400).send({ status: false, error: err });
        }
    });

    router.get('/get-all-roles', async function (req, res) {
        try {
            let roles = await db.getRoles();
            if (roles && roles.length > 0) {
                res.status(200).send({
                    status: true,
                    roles: roles
                });
            } else {
                res.status(400).send({ status: false, message: "Error while fetching roles" });
            }

        } catch (err) {
            res.status(400).send({ status: false, error: err });
        }
    });

    router.post('/forgot-password', async function (req, res) {
        try {
            var {email}=req.body
            let user=await db.getUserByEmail(email);
            if(user.length==0){
                res.status(400).send({status:false, message:'No user found with this email.'})
            }else{
                var newPass = generator.generate({
                    length: 10,
                    numbers: true
                });
            var password = CryptoJS.AES.encrypt(newPass, 'loadCryptedPass').toString();
                const updatePassword =  await db.resetPassword(email,password)
                if(updatePassword){
                    var mailOptions = {
                        from: 'testload676@gmail.com',
                        to: email,
                        subject: 'Password Reset',
                        html: `Your new Password is ${newPass}. Click on the below link to reset your password. https://devdash.load-bundle.com/reset-password?email=${email}`
    
                    };
                    await transporter.sendMail(mailOptions, function (error, info) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log('Email sent: ' + info.response);
                        }
                    });
                }          
                res.status(200).send({status:true, message:'An email has been sent to your email id ' +email+".",user:user})
            }

        } catch (err) {
            res.status(400).send({ status: false, message: err });
        }
    });

    router.post('/reset-password', async function (req, res) {
     try{
        const {oldPassword,newPassword,email}=req.body
        let user = await db.signIn(email);
        if (user && user.length > 0) {
            user = user[0]
            var bytes = CryptoJS.AES.decrypt(user.password, 'loadCryptedPass');
            var decryptedPassword = bytes.toString(CryptoJS.enc.Utf8);
            if (decryptedPassword != oldPassword) {
                res.status(400).send({ status: false, message: "Please use the old password as we have sent you on the email." });
            }
            else{
            var newEncryPass = CryptoJS.AES.encrypt(newPassword, 'loadCryptedPass').toString();
                const updatePassword =  await db.resetPassword(email,newEncryPass)
                res.status(200).send({status:true, message:'You have successfully changed your password',user:user})
            }
        }  
     }
     catch(err){
        res.status(400).send({ status: false, error: err });
     }
    });

    router.post('/update-user-status', async function(req,res){
        try{
            const{id,active}=req.body
            let users;
            if(active===1){
                 users=await db.updateUserStatus(id,0)
            }
            else{
                users=await db.updateUserStatus(id,1)
            }
            allUsers=await db.getAllUsers()
            if (users && allUsers) {
                res.status(200).send({
                    status: true,
                    users:allUsers
                });
            } else {
                res.status(400).send({ status: false, message: "Error while changing user status" });
            }
        }
        catch(err){
            res.status(400).send({ status: false, error: err });
        }
    })

    router.post("/jumia-creds",async function(req,res){
       try{
        const {jumiaId,apiKey}=req.body
         const userId=req.userData.user._id
        const users=await db.updateUserKongaIdAndEmail(jumiaId,apiKey,userId)
        if (users) {
            res.status(200).send({
                status: true,
                message:'Jumia credentials has been updated successfully'
            });
        } else {
            res.status(400).send({ status: false, message: "Error while updating jumia credentials" });
        }
       }
       catch(err){
           res.status(400).send({status:false, message:"Error while updating jumia credentials"})
       }

    })

    app.use("/users", router);
};