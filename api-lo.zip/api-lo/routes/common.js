var CryptoJS = require("crypto-js");
var db = require("../utilities/commom");
// var axios = require("axios");
// const { request } = require("http");
// const https = require('https');
let nodemailer = require('nodemailer');

const exp = 60;
module.exports = function (express, app, connection, middleware, jwt) {
    var router = express.Router();
    router.use(middleware.userRequired);
    router.get('/', async function (req, res) {
        try {
            var userData = req.userData.user;
            if (userData && userData.email) {
                const email = userData.email
                let user = await db.getUserByEmail(email)
                if (user && user.length > 0) {
                    let roles = await db.getAllRoles();
                    const userFavoriteProducts = await db.getFavoriteProducts(user[0].id)
                    const userUnseenNotifications = await db.getNotifications(user[0].id)
                    var requests;
                    if (user[0].user_role === 0) {
                        requests = await db.getSuperAdminRequests();
                    }
                    user = user[0]
                    var token = jwt.sign({ user: { _id: user.id, email: user.email } }, app.get('superSecret'), {
                        expiresIn: `${exp}d`
                    });
                    user.token = token;
                    user.roles = roles;
                    user.favProducts = userFavoriteProducts;
                    user.unseenNotifications = userUnseenNotifications
                    user.superAdminRequests = requests

                    res.status(200).send({ status: true, user: user });
                } else {
                    res.status(400).send({ status: false, message: "Error getting user" });
                }
            } else {
                res.status(200).send({
                    status: false,
                    message: "User not found"
                });
            }

        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-all-users', async function (req, res) {
        try {
            var userData = req.userData.user;
            if (userData && userData.email) {
                const email = userData.email
                let user = await db.getUserByEmail(email)
                if (user && user.length > 0) {
                    if (user[0].user_role == 0) {
                        const users = await db.getAllUsers();
                        res.status(200).send({ status: true, users: users });
                    } else {
                        res.status(400).send({ status: false, message: "Error getting user" });
                    }
                } else {
                    res.status(400).send({ status: false, message: "Error getting user" });
                }
            } else {
                res.status(200).send({
                    status: false,
                    message: "User not found"
                });
            }

        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/update-notification', async function (req, res) {
        try {
            var userId = req.userData.user._id;
            const { ID } = req.query
            const updatedNotifications = await db.updateNotification(userId, ID);
            if (updatedNotifications) {
                res.status(200).send({
                    updatedNotifications: 'successfully updated'
                })
            }

        } catch (err) {
            res.status(400).send({ status: false, error: 'failed to update the notification' });
        }
    });

    router.get('/get-notification', async function (req, res) {
        try {
            const { ID } = req.query
            const notification = await db.getNotification(ID);
            if (notification) {
                res.status(200).send({
                    notification: notification
                })
            }
        }
        catch (err) {
            res.status(400).send({ status: false, error: err })
        }
    })


    router.get('/clear-all-notifications', async function (req, res) {
        try {
            const { userId } = req.query
            const notification = await db.clearAllNotification(userId);
            if (notification) {
                res.status(200).send({
                    notification: notification
                })
            }
        }
        catch (err) {
            res.status(400).send({ status: false, error: 'failed to update the notification' })
        }
    })

    router.post('/update-role-request', async function (req, res) {
        try {
            const {firstName,lastName, email, currentRole, requestedRole } = req.body
            var userId = req.userData.user._id;
            const requests = await db.getSingleUserRequests(userId);
            if (requests.length > 0) {
                return res.status(200).send({
                    status: true,
                    updatedRole: 'One request is already pending with admin.'
                })
            }
            const updatedRole = await db.updateRoleRequest(firstName,lastName,email, currentRole, requestedRole,userId);
            if (updatedRole) {
                res.status(200).send({
                    status: true,
                    updatedRole: 'Request sent to super admin.'
                })
            }
        }
        catch (err) {
            res.status(400).send({ status: false, error: 'Failed to send the request to super admin' })
        }
    })

    router.post('/update-role', async function (req, res) {
        try {
            const { id, email, role, isAccept } = req.body
            var userId = req.userData.user._id;
            let isAccepted=isAccept?'accepted':'rejected';
            let userRole=role===1?'Staff Account':role===2?'User Account':'User Admin Account'
            let updatedRole;
            let updateRequestTable;
            if (isAccept) {
                updatedRole = await db.updateRoleUserTable(email, role, id);
                updateRequestTable = await db.updateRoleRequestTable(id, 1)

            } else {
                updateRequestTable = await db.updateRoleRequestTable(id, 0)
            }
            const requestData=await db.getSuperAdminRequests();

            if(updateRequestTable){
                var mailOptions = {
                    from: 'testload676@gmail.com',
                    to: email,
                    subject: 'Change account type request',
                    html: `Your request has been ${isAccepted} for the applied role ${userRole}`

                };
                await transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                    }
                });
            }   
            if (updatedRole || updateRequestTable) {
                res.status(200).send({
                    status: true,
                    data:requestData
                })
            }
        }
        catch (err) {
            res.status(400).send({ status: false, error: 'Failed to send the request to super admin' })
        }

    })


    

    app.use("/user", router);
};

