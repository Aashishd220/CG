
const https = require('https');
var CryptoJS = require("crypto-js");
var crypto = require('crypto');
var db = require("../../utilities/users/users");
const { concat } = require('lodash');
const axios = require('axios');
const { readdirSync } = require('fs');

module.exports = function (express, app, connection, middleware) {
    var router = express.Router();
    router.use(middleware.basic);

    router.get("/get-metrics-data-from-api", async function (req, res) {
        try {
            let { action } = req.query
            let userId = req.userData.user._id;
            let jumiaCreds = await db.getUserJumiaCreds(userId);

            if (!jumiaCreds[0].jumia_id || !jumiaCreds[0].jumia_api_key) {
                return res.status(400).send({ status: false, ErrorResponse: { Head: { ErrorMessage: "Please provide Jumia Credentials" } } })
            }
            let key = jumiaCreds[0].jumia_api_key
            let name = jumiaCreds[0].jumia_id
            let date = new Date();
            let currDate = date.toISOString().slice(0, 19)
            let encodedUserId = encodeURIComponent(name)
            let encodeURI = encodeURIComponent(currDate.concat('+01'))
            encodeURI = encodeURI.concat('%3A00')
            let url = `Action=${action}&Format=JSON&Timestamp=${encodeURI}&UserID=${encodedUserId}&Version=1.0`
            var hash = crypto.createHmac('sha256', key).update(url).digest('hex');
            url += `&Signature=${hash}`
            https.get(`https://sellercenter-api.jumia.com.ng/?${url}`, (resp) => {
                let data = '';

                // A chunk of data has been received.
                resp.on('data', (chunk) => {
                    data += chunk;
                });

                // The whole response has been received. Print out the result.
                resp.on('end', () => {
                    res.status(200).send(JSON.parse(data))
                });

            }).on("error", (err) => {
                console.log("Error: " + err.message);
            });

        }
        catch (err) {
            res.status(400).send({ status: false, error: err.message })
        }
    })

    router.get("/get-orders-data-from-api", async function (req, res) {
        try {
            let { action } = req.query
            let userId = req.userData.user._id;
            let jumiaCreds = await db.getUserJumiaCreds(userId);

            if (!jumiaCreds[0].jumia_id || !jumiaCreds[0].jumia_api_key) {
                return res.status(400).send({ status: false, ErrorResponse: { Head: { ErrorMessage: "Please provide Jumia Credentials" } } })
            }

            let key = jumiaCreds[0].jumia_api_key
            let name = jumiaCreds[0].jumia_id
            let encodedUserId = encodeURIComponent(name)

            let date = new Date();
            let currDate = date.toISOString().slice(0, 19)
            let encodeURI = encodeURIComponent(currDate.concat('+01'))
            encodeURI = encodeURI.concat('%3A00')




            var fromDate = new Date();
            fromDate.setMonth(fromDate.getMonth() - 6);
            fromDate = fromDate.toISOString().slice(0, 19)
            let encodeURIfromDate = encodeURIComponent(fromDate.concat('+01'))
            encodeURIfromDate = encodeURIfromDate.concat('%3A00')

            let timeStamp = new Date();
            timeStamp = timeStamp.toISOString().slice(0, 19)
            var encodeURITimeStamp = encodeURIComponent(timeStamp.concat('+01'))
            encodeURITimeStamp = encodeURITimeStamp.concat('%3A00')

            let url = `Action=${action}&CreatedAfter=${encodeURIfromDate}&Format=JSON&Timestamp=${encodeURITimeStamp}&UserID=${encodedUserId}&Version=1.0`
            var hash = crypto.createHmac('sha256', key).update(url).digest('hex');
            url += `&Signature=${hash}`
            https.get(`https://sellercenter-api.jumia.com.ng/?${url}`, (resp) => {
                let data = '';

                // A chunk of data has been received.
                resp.on('data', (chunk) => {
                    data += chunk;
                });

                // The whole response has been received. Print out the result.
                resp.on('end', () => {
                    res.status(200).send(JSON.parse(data))
                });

            }).on("error", (err) => {
                console.log("Error: " + err.message);
            });

        }
        catch (err) {
            res.status(400).send({ status: false, error: err.message })
        }
    })





    router.get("/get-products-data-from-api", async function (req, res) {
        try {
            let { action } = req.query
            let userId = req.userData.user._id;
            let jumiaCreds = await db.getUserJumiaCreds(userId);
            if (!jumiaCreds[0].jumia_id || !jumiaCreds[0].jumia_api_key) {
                return res.status(400).send({ status: false, ErrorResponse: { Head: { ErrorMessage: "Please provide Jumia Credentials" } } })
            }
            let key = jumiaCreds[0].jumia_api_key
            let name = jumiaCreds[0].jumia_id
            let date = new Date();
            let currDate = date.toISOString().slice(0, 19)
            let encodedUserId = encodeURIComponent(name)
            let encodeURI = encodeURIComponent(currDate.concat('+01'))
            encodeURI = encodeURI.concat('%3A00')
            let url = `Action=${action}&Format=JSON&Timestamp=${encodeURI}&UserID=${encodedUserId}&Version=1.0`
            var hash = crypto.createHmac('sha256', key).update(url).digest('hex');
            url += `&Signature=${hash}`
            https.get(`https://sellercenter-api.jumia.com.ng/?${url}`, (resp) => {
                let data = '';

                // A chunk of data has been received.
                resp.on('data', (chunk) => {
                    data += chunk;
                });

                // The whole response has been received. Print out the result.
                resp.on('end', () => {
                    res.status(200).send(JSON.parse(data))
                });

            }).on("error", (err) => {
                console.log("Error: " + err.message);
            });

        }
        catch (err) {
            res.status(400).send({ status: false, error: err.message })
        }
    })



    router.get("/get-statistics-data-from-api", async function (req, res) {
        try {
            let { action } = req.query
            let userId = req.userData.user._id;
            let jumiaCreds = await db.getUserJumiaCreds(userId);
            if (!jumiaCreds[0].jumia_id || !jumiaCreds[0].jumia_api_key) {
                return res.status(400).send({ status: false, ErrorResponse: { Head: { ErrorMessage: "Please provide Jumia Credentials" } } })
            }
            let key = jumiaCreds[0].jumia_api_key
            let name = jumiaCreds[0].jumia_id
            let date = new Date();
            let currDate = date.toISOString().slice(0, 19)
            let encodedUserId = encodeURIComponent(name)
            let encodeURI = encodeURIComponent(currDate.concat('+01'))
            encodeURI = encodeURI.concat('%3A00')
            let url = `Action=${action}&Format=JSON&Timestamp=${encodeURI}&UserID=${encodedUserId}&Version=1.0`
            var hash = crypto.createHmac('sha256', key).update(url).digest('hex');
            url += `&Signature=${hash}`
            https.get(`https://sellercenter-api.jumia.com.ng/?${url}`, (resp) => {
                let data = '';

                // A chunk of data has been received.
                resp.on('data', (chunk) => {
                    data += chunk;
                });

                // The whole response has been received. Print out the result.
                resp.on('end', () => {
                    res.status(200).send(JSON.parse(data))
                });

            }).on("error", (err) => {
                console.log("Error: " + err.message);
            });

        }
        catch (err) {
            res.status(400).send({ status: false, error: err.message })
        }
    })

    router.get("/get-payout-data-from-api", async function (req, res) {
        try {
            let { action } = req.query
            let userId = req.userData.user._id;
            let jumiaCreds = await db.getUserJumiaCreds(userId);
            if (!jumiaCreds[0].jumia_id || !jumiaCreds[0].jumia_api_key) {
                return res.status(400).send({ status: false, ErrorResponse: { Head: { ErrorMessage: "Please provide Jumia Credentials" } } })
            }
            let key = jumiaCreds[0].jumia_api_key
            let name = jumiaCreds[0].jumia_id
            let date = new Date();
            let currDate = date.toISOString().slice(0, 19)
            let encodedUserId = encodeURIComponent(name)
            let encodeURI = encodeURIComponent(currDate.concat('+01'))
            encodeURI = encodeURI.concat('%3A00')
            let url = `Action=${action}&Format=JSON&Timestamp=${encodeURI}&UserID=${encodedUserId}&Version=1.0`
            var hash = crypto.createHmac('sha256', key).update(url).digest('hex');
            url += `&Signature=${hash}`
            https.get(`https://sellercenter-api.jumia.com.ng/?${url}`, (resp) => {
                let data = '';

                // A chunk of data has been received.
                resp.on('data', (chunk) => {
                    data += chunk;
                });

                // The whole response has been received. Print out the result.
                resp.on('end', () => {
                    res.status(200).send(JSON.parse(data))
                });

            }).on("error", (err) => {
                console.log("Error: " + err.message);
            });

        }
        catch (err) {
            res.status(400).send({ status: false, error: err.message })
        }
    })


    router.get("/get-best-worst-product-from-api", async function (req, res) {

        try {
            let { action, endDate, startDate } = req.query

            console.log(req.query)
            if (startDate && endDate) {
                var date1 = new Date(startDate)
                mnth = ("0" + (date1.getMonth() + 1)).slice(-2),
                    day = ("0" + date1.getDate()).slice(-2);
                var newStartDate = [date1.getFullYear(), mnth, day].join("-")
                newStartDate = newStartDate.concat('T').concat(startDate.substring(16, 24))

                var date = new Date(endDate)
                mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                    day = ("0" + date.getDate()).slice(-2);
                var newEndDate = [date.getFullYear(), mnth, day].join("-")
                newEndDate = newEndDate.concat('T').concat(endDate.substring(16, 24))

            }


            let userId = req.userData.user._id;
            console.log(userId)
            let jumiaCreds = await db.getUserJumiaCreds(userId);

            if (!jumiaCreds[0].jumia_id || !jumiaCreds[0].jumia_api_key) {
                return res.status(400).send({ status: false, ErrorResponse: { Head: { ErrorMessage: "Please provide Jumia Credentials" } } })
            }

            let key = jumiaCreds[0].jumia_api_key
            let name = jumiaCreds[0].jumia_id
            let encodedUserId = encodeURIComponent(name)

            var fromDate = new Date();
            fromDate.setMonth(fromDate.getMonth() - 3);
            fromDate = fromDate.toISOString().slice(0, 19)
            if (newStartDate) {
                fromDate = newStartDate
            }
            let encodeURIfromDate = encodeURIComponent(fromDate.concat('+01'))
            encodeURIfromDate = encodeURIfromDate.concat('%3A00')

            let toDate = new Date();
            toDate = toDate.toISOString().slice(0, 19)
            if (newEndDate) {
                toDate = newEndDate
            }
            var encodeURItoDate = encodeURIComponent(toDate.concat('+01'))
            encodeURItoDate = encodeURItoDate.concat('%3A00')


            let timeStamp = new Date();
            timeStamp = timeStamp.toISOString().slice(0, 19)
            var encodeURITimeStamp = encodeURIComponent(timeStamp.concat('+01'))
            encodeURITimeStamp = encodeURITimeStamp.concat('%3A00')


            let url = `Action=${action}&CreatedAfter=${encodeURIfromDate}&CreatedBefore=${encodeURItoDate}&Format=JSON&Timestamp=${encodeURITimeStamp}&UserID=${encodedUserId}&Version=1.0`
            let hash = crypto.createHmac('sha256', key).update(url).digest('hex');
            url += `&Signature=${hash}`
            var counter = {};

            axios.get(`https://sellercenter-api.jumia.com.ng/?${url}`)
                .then((response) => {
                    //    console.log(response.data.SuccessResponse.Body.Orders.Order.length)
                    // var data2 = JSON.parse(data.data)
                    if(response.data.SuccessResponse.Body.Orders.Order.length>200){
                      return  res.status(400).send({ err: 'Please shift the date range' })
                    }
                    var orders = response.data.SuccessResponse.Body.Orders.Order
                    var orderId = orders.map((order) => order.OrderId)
                    var x = {}
                    var i = 0;
                    const promiseArray = [];
                    orderId.forEach(id => {
                        i++;
                        let url = `Action=GetOrderItems&Format=JSON&OrderId=${id}&Timestamp=${encodeURITimeStamp}&UserID=info%40chamuze.com&Version=1.0`
                        let hash = crypto.createHmac('sha256', key).update(url).digest('hex');
                        url += `&Signature=${hash}`
                        promiseArray.push(axios.get(`https://sellercenter-api.jumia.com.ng/?${url}`))

                    })
                    // console.log("promises"+promiseArray.length)
                    Promise.all(promiseArray)
                        .then((responseArray) => {
                            responseArray.forEach((response) => {
                                const orderItems = response.data.SuccessResponse.Body.OrderItems.OrderItem

                                if (Array.isArray(orderItems)) {
                                    var key = orderItems[0].Name
                                    counter[key] = (counter[key] || 0) + orderItems.length
                                }
                                else {
                                    var key = orderItems.Name.trim();
                                    counter[key] = (counter[key] || 0) + 1
                                }
                            })
                            //  console.log(counter)
                            return res.status(200).send({ data: counter })

                        })
                        .catch((err) => {
                            return res.status(400).send({ err: `Failed to find the item` })
                        })


                }).catch((err) => {
                    // return res.status(400).send({ err: 'Failed to find the products data' })
                    return res.status(400).send({ err: `Failed to find the item`})
                })

        }
        catch (err) {
            res.status(400).send({ status: false, error: err.message })
        }
    })


    // router.get("/get-metrics-data-from-api", async function (req, res) {
    //     try {
    //         console.log("check")
    //         const data = {
    //             Product: {
    //                 SellerSku: "PTC280A",
    //                 Price: "19001"
    //              }
    //         };
          
       
    
    //                 const res = await axios.post('https://sellercenter-api.jumia.com.ng/?Action=ProductUpdate&Format=JSON&Timestamp=2021-03-01T06%3A20%3A34%2B01%3A00&UserID=info%40chamuze.com&Version=1.0&Signature=c4ea512dd0b134dcb9a6af40b883518233f77daf22a10d6d15e536005dd14eea', data);
    //                 console.log(`Status: ${res.status}`);
    //                 console.log('Body: ', res.data);
    //     }
    //     catch (err) {
    //         res.status(400).send({ status: false, error: err.message })
    //     }
    // })





    app.use("/external-api", router);

}


