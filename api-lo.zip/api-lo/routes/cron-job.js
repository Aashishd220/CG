
let nodemailer = require('nodemailer');
var db = require("../utilities/products/products");
var dbNotification = require("../utilities/commom");
const { saveEcomComboProducts } = require('../utilities/ecommerce/ecommerce-products');

let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'testload676@gmail.com',
        pass: 'devdash123#'
    }
});


module.exports = async function () {
    try {
        var dateObj = new Date();
        var currDate = dateObj.toISOString().slice(0, 11).replace('T', ' ').concat(' 23:59:59')
        dateObj.setDate(dateObj.getDate() - 1);
        prevDate = dateObj.toISOString().slice(0, 11).replace('T', ' ')

        const userIds = await db.getUniqueUserIds();
        for (var i = 0; i < userIds.length; i++) {
            const q = `SELECT fav_products.user_id, load_products.users.email, load_products.users.first_name,load_products.product_data.name,product_pricing.insert_date, product_pricing.product_code, product_pricing.product_code,product_pricing.price from load_products.product_pricing as product_pricing INNER JOIN load_products.favorite_products as fav_products ON fav_products.product_code = product_pricing.product_code INNER JOIN load_products.product_data on load_products.product_data.product_code=product_pricing.product_code INNER JOIN load_products.users as users ON fav_products.user_id=users.id WHERE fav_products.user_id=${userIds[i].user_id} and product_pricing.insert_date<='${currDate}' and product_pricing.insert_date>='${prevDate}' order by product_pricing.product_code, product_pricing.insert_date DESC`
            const res = await db.getProductPricingEvery24Hours(q);
            var flag = false;
            // let text=`Hi ${res[i].first_name},`;
            let text = ''
            for (var j = 1; j < res.length; j++) {
                if (res[j].product_code === res[j - 1].product_code && res[j].insert_date !== res[j - 1].insert_date && res[j].price !== res[j - 1].price) {
                    flag = true;
                    let notification = ` Price of the product ${res[j].name} has been changed from "${res[j].price}" to "${res[j - 1].price}". `
                    text += ` Price of the product ${res[j].name} has been changed from "${res[j].price}" to "${res[j - 1].price}". `
                    let saveNotification = await dbNotification.saveNotification(res[i].user_id, notification, res[j].product_code, res[j - 1].price);
                }
            }
            if (flag) {
                var mailOptions = {
                    from: 'aashish.d.220@gmail.com',
                    to: `${res[i].email}`,
                    subject: 'Lodash: Change in price of your favorite product',
                    text: text
                };
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                    }
                });
            }
        }
    }
    catch (error) {
        res.status(400).send({ status: false, error: err });
    }
}

