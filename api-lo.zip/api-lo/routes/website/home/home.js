
module.exports = function(express, app, connection, _CMS, jwt, middleware, request) {
    var router = express.Router();
    router.use(middleware.basic);
    router.get('/', async function(req, res) {
		try{
            res.status(200).send({
                status:true,
                message:"Health good"
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-latest-news', async function(req, res) {
		try{
            request(_CMS + '/get-latest-news', (error, response, body) => {
                if (!error) {
                    let { news } = JSON.parse(body);
                    res.status(200).send({ news: news });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-pricing', async function(req, res) {
		try{
            request(_CMS + '/get-pricing', (error, response, body) => {
                if (!error) {
                    let { pricing } = JSON.parse(body);
                    res.status(200).send({ pricing: pricing });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });


    router.get('/get-partners', async function(req, res) {
		try{
            request(_CMS + '/get-partners', (error, response, body) => {
                if (!error) {
                    let { partners } = JSON.parse(body);
                    res.status(200).send({ partners: partners });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });


    router.get('/get-home-benner-content', async function(req, res) {
		try{
            request(_CMS + '/get-home-benner-content', (error, response, body) => {
                if (!error) {
                    let { home } = JSON.parse(body);
                    res.status(200).send({ home: home });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });


    router.get('/get-faq', async function(req, res) {
		try{
            request(_CMS + '/get-faq', (error, response, body) => {
                if (!error) {
                    let { faq } = JSON.parse(body);
                    res.status(200).send({ faq: faq });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-about-us', async function(req, res) {
		try{
            request(_CMS + '/get-about-us', (error, response, body) => {
                if (!error) {
                    let { aboutus } = JSON.parse(body);
                    res.status(200).send({ aboutus: aboutus });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });


    router.get('/get-home-content', async function(req, res) {
		try{
            request(_CMS + '/get-home-content', (error, response, body) => {
                if (!error) {
                    let {home} = JSON.parse(body);
                    res.status(200).send({ home: home });
                } else {
                    res.status(400).send();
                }
            });
        }catch(err){
            res.status(400).send({ error: err });
        }
    });

    app.use("/website", router);
};