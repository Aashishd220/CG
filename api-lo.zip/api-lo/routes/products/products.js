
var db = require("../../utilities/products/products");
module.exports = function (express, app, connection, middleware) {
    var router = express.Router();
    router.use(middleware.userRequired);
    router.get('/', async function (req, res) {
        try {
            let products = await db.getProducts();
            res.status(200).send({
                status: true,
                products: products
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/website-products', async function (req, res) {
        try {
            const { page, website, category, brands, term } = req.query;
            let brandsString = ""
            if (brands.length !== 0) {
                let tempArray = brands.split(",")
                tempArray.map((brand, index) => (
                    brandsString = brandsString === "" ? '"' + brand + '"' : brandsString + "," + '"' + brand + '"'
                ))
            }
            // const webUrl = website == "konga" ? "konga.com" : website == "jumia-co-ke" ? "jumia.co.ke" : website == "jumia-ng" ? "jumia.com.ng" : website == "jumia-gh" ? "jumia.com.gh" : "konga.com"
            const webUrl = website == "jumia-co-ke" ? "jumia.co.ke" : website == "jumia-ng" ? "jumia.com.ng" : website == "jumia-gh" ? "jumia.com.gh" : "konga.com"

            const limit = 50
            const offset = (page - 1) * limit;
            let productCount;
            productCount = await db.getProductsCountWithCategory({ webUrl, category })
            if (brands) {
                productCount = await db.getProductCountWithCategoryAndBrands({ webUrl, category, brands })
            }
            let products;
            if (term) {
                let q = `SELECT * FROM load_products.product_data WHERE dealer ='${webUrl}' AND category ='${category}' `

                if (brands) {
                    q += ` AND `
                    let check = false;
                    let tempArray = brands.split(",")
                    if (tempArray.length === 1) {
                        q += `brand="${brands}"`
                    }
                    else {
                        tempArray.forEach(value => {
                            q += `brand="${value}" or `
                        })
                        check = true;
                    }
                    if (check) {
                        q = q.substring(0, q.length - 3)
                    }
                }
                if (term) {
                    const allBrands = await db.getBrands(webUrl);
                    var br;
                    let tempArray = term.split(" ")
                    for (var i = 0; i < allBrands.length; i++) {
                        if (tempArray.length === 1) {
                            if (allBrands[i].brand !== '' && allBrands[i].brand !== undefined && allBrands[i].brand !== null && allBrands[i].brand.length > 2 && term.toLowerCase() == allBrands[i].brand.toLowerCase()) {
                                br = allBrands[i].brand;
                            }
                        }
                        else {
                            tempArray.forEach(value => {
                                if (allBrands[i].brand !== '' && allBrands[i].brand !== undefined && allBrands[i].brand !== null && allBrands[i].brand.length > 2 && value.toLowerCase() == allBrands[i].brand.toLowerCase()) {
                                    br = allBrands[i].brand;
                                }
                            })
                        }

                    }

                    if (!brands && br !== '' && br !== null && br !== undefined) {
                        q += ` AND brand='${br}'`
                    }

                    q += ` AND (`
                    let check = false;

                    if (tempArray.length === 1) {
                        q += `name like '%${term}%'`
                    }
                    else {
                        tempArray.forEach(value => {
                            if (value.toLowerCase() !== br.toLowerCase()) {
                                q += `name like '%${value}%' or `
                            }
                        })
                        check = true;
                    }
                    if (check) {
                        q = q.substring(0, q.length - 3)
                    }
                    q += `) limit ${limit} offset ${offset}`
                }
                products = await db.getProductsWithTermBrandCategory(q)
                productCount[0].rowCount = products.length
            }
            else {
                products = brandsString === "" ? await db.getProducts({ webUrl, limit, offset, category }) : await db.getProductsWithBrand({ webUrl, limit, offset, category, brandsString })
            }
            var jsonResult = {
                'products_page_count': products.length,
                'page_number': page,
                'products': products,
                "total_pages": productCount[0].rowCount / limit
            }
            res.status(200).send({
                status: true,
                products: jsonResult
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-product-count', async function (req, res) {
        try {
            const kongaCount = await db.getProductsCount("konga.com");
            const jumiaCount = await db.getProductsCount("jumia.co.ke");
            const jumiaGhCount = await db.getProductsCount("jumia.com.gh");
            const jumiangCount = await db.getProductsCount("jumia.com.ng");
            res.status(200).send({
                status: true,
                count: {
                    "jumia": jumiaCount[0].rowCount,
                    "konga": kongaCount[0].rowCount,
                    "jumiaGh": jumiaGhCount[0].rowCount,
                    "jumiaNg": jumiangCount[0].rowCount
                }
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-categories', async function (req, res) {
        try {
            const { website } = req.query
            const webUrl = website == "konga" ? "konga.com" : website == "jumia-co-ke" ? "jumia.co.ke" : website == "jumia-ng" ? "jumia.com.ng" : website == "jumia-gh" ? "jumia.com.gh" : "konga.com"
            const categories = await db.getCategories(webUrl);
            const brands = await db.getBrands(webUrl);
            res.status(200).send({
                categories: categories,
                brands: brands
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-product-data', async function (req, res) {
        try {
            const { code } = req.query;
            const product = await db.getProductData(code);
            const productCode = product[0].product_code
            const productPricing = await db.getProductPricingData(productCode);

            res.status(200).send({
                product: product,
                productPricing: productPricing
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.post('/add-fav-product', async function (req, res) {
        try {
            const { id, isFavorite, productCode, price, dealer, name, images } = req.body;
            var userId = req.userData.user._id;
            let saveFavoriteProducts;
            if (isFavorite === true) {
                saveFavoriteProducts = await db.unFavoriteProduct(id, userId)
            }
            else {
                saveFavoriteProducts = await db.saveFavoriteProducts(id, userId, productCode, price, dealer, name, images)
            }
            if (saveFavoriteProducts) {
                res.status(201).send({ status: true });
            }
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-fav-products-details', async function (req, res) {
        try {
            const { category, brands, term, page } = req.query;

            const limit = 50
            let offset;
            if (page) {
                offset = (page - 1) * limit
            }
            else {
                offset = 0;
            }
            var user_id = req.userData.user._id;
            let favProductDetails;
            let q = `SELECT * from load_products.product_data as product_data INNER JOIN load_products.favorite_products as fav_products ON fav_products.product_id = product_data.ID WHERE fav_products.user_id=${user_id} `
            if (category) {
                q += `AND category="${category}"`
            }
            if (brands) {
                q += ` AND `
                let check = false;
                let tempArray = brands.split(",")
                if (tempArray.length === 1) {
                    q += `brand="${brands}"`
                }
                else {
                    tempArray.forEach(value => {
                        q += `brand="${value}" or `
                    })
                    check = true;
                }
                if (check) {
                    q = q.substring(0, q.length - 3)
                }
            }
            if (term) {
                q += ` AND (`
                let check = false;
                let tempArray = term.split(" ")
                if (tempArray.length === 1) {
                    q += `fav_products.name like '%${term}%'`
                }
                else {
                    tempArray.forEach(value => {
                        q += `fav_products.name like '%${value}%' or `
                    })
                    check = true;
                }
                if (check) {
                    q = q.substring(0, q.length - 3)
                }
                q += `)`
            }
            const favProducts = await db.getFavoriteProductsDetail(q);
            const numberOfFavProducts = favProducts.length;
            q += ` limit ${limit} offset ${offset}`
            favProductDetails = await db.getFavoriteProductsDetail(q);
            var jsonData = {
                'products_page_count': favProductDetails.length,
                'page_number': page,
                'favProducts': favProducts,
                "total_pages": numberOfFavProducts / limit
            }
            res.status(200).send({ favProducts: favProductDetails, pagenationDetails: jsonData });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-searched-products', async function (req, res) {
        try {
            const { term, website } = req.query
            let q = `select DISTINCT(dealer),name,price from load_products.product_data where `
            if (website) {
                q += `dealer='${website}' AND `
            }
            q += ` (`
            let check = false;
            let tempArray = term.split(" ")
            if (tempArray.length === 1) {
                q += `name like '%${term}%'`
            }
            else {
                tempArray.forEach(value => {
                    q += `name like '%${value}%' or `
                })
                check = true;
            }
            if (check) {
                q = q.substring(0, q.length - 3)
            }
            q += `) limit 1000 `

            const allProducts = await db.searchedProducts(q)
            res.status(200).send({
                searchedProducts: allProducts
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });

    router.get('/get-searched-single-product', async function (req, res) {
        try {
            let { term, website } = req.query
            let bufferObj = Buffer.from(term, "base64");
            let decodedString = bufferObj.toString("utf8");
            term = decodedString
            const singleProduct = await db.searchedExactProduct(term, website);
            res.status(200).send({
                singleProduct: singleProduct
            });
        } catch (err) {
            res.status(400).send({ error: err });
        }
    });
    app.use("/products", router);
};