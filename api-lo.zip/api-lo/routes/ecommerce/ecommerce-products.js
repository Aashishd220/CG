var db = require("../../utilities/ecommerce/ecommerce-products");
var fs = require('fs')
var multer = require('multer')
var XLSX = require('xlsx')
var xlsx = require('node-xlsx').default;
var json2xls = require('json2xls');
module.exports = function (express, app, connection, middleware, upload) {
    var router = express.Router();
    router.use(middleware.basic);

    //***************************** */
    //  CODE FOR OLD SPREADSHEET
    //***************************** */


    // router.get('/get-uniq-ecomm-products', async function (req, res) {
    //     try {
    //         let { product_sku } = req.query;
    //         if (product_sku) {
    //             let getEcomProductDetails = await db.getEcomProductDetails(req.userData.user._id, product_sku)
    //             if (getEcomProductDetails) {
    //                 res.status(200).send({ data: getEcomProductDetails });
    //             }
    //             return;
    //         }
    //         let getEcomProducts = await db.getEcomProducts(req.userData.user._id);
    //         let uniqEcomProducts = [];
    //         const map = new Map();
    //         for (const item of getEcomProducts) {
    //             if (!map.has(item.product_sku)) {
    //                 map.set(item.product_sku, true);
    //                 uniqEcomProducts.push(item)
    //             }
    //         }
    //         if (getEcomProducts) {
    //             res.status(200).send({ data: uniqEcomProducts });
    //         }
    //     }
    //     catch (err) {
    //         res.status(400).send({ error: err });
    //     }
    // })


    // router.get('/get-uniq-ecomm-combo-products', async function (req, res) {
    //     try {
    //         let { product_sku } = req.query;
    //         var userId = req.userData.user._id;
    //         if (product_sku) {
    //             let q = `SELECT * FROM load_products.combo_products where user_id=${userId} and products_sku like '%${product_sku}%'`
    //             let getEcomComboProductDetails = await db.getEcomComboProductDetails(q)
    //             if (getEcomComboProductDetails) {
    //                 res.status(200).send({ data: getEcomComboProductDetails });
    //             }
    //         }
    //     }
    //     catch (err) {
    //         res.status(400).send({ error: err });
    //     }
    // })

    // router.get('/get-uniq-ecomm-seller', async function (req, res) {
    //     try {
    //         let { shop } = req.query;
    //         if (shop) {
    //             let { product_sku } = req.query;
    //             if (product_sku) {
    //                 let getEcomSellerProductsDetails = await db.getEcomSellerProductsDetails(req.userData.user._id, shop, product_sku)

    //                 if (getEcomSellerProductsDetails) {
    //                     res.status(200).send({ data: getEcomSellerProductsDetails });
    //                 }
    //                 return;
    //             }
    //             let getEcomSellerDetails = await db.getEcomSellerDetails(req.userData.user._id, shop)

    //             if (getEcomSellerDetails) {
    //                 res.status(200).send({ data: getEcomSellerDetails });
    //             }
    //             return;
    //         }
    //         let getEcomSellers = await db.getEcomSellers(req.userData.user._id);
    //         let uniqEcomSellers = [];
    //         const map = new Map();
    //         for (const item of getEcomSellers) {
    //             if (!map.has(item.shop_id)) {
    //                 map.set(item.shop_id, true);
    //                 uniqEcomSellers.push(item)
    //             }
    //         }
    //         if (getEcomSellers) {
    //             res.status(200).send({ data: uniqEcomSellers });
    //         }
    //     }
    //     catch (err) {
    //         res.status(400).send({ error: err });
    //     }
    // })
    // router.post('/save-products', upload, async function (req, res) {
    //     try {
    //         const data = xlsx.parse(req.file.path, { cellDates: true });
    //         var dataValues = data[0].data
    //         var userId = req.userData.user._id;
    //         var dateObj = new Date();
    //         var currDate = dateObj.toISOString().slice(0, 19).replace('T', ' ')
    //         //let q = `INSERT INTO load_products.ecommerce_single_products (product_name, quantity,pack_size,quantity_per_carton,selling_price,purchase_price,platform,sku_code,order_created_date,user_id) Values `
    //         let q = `INSERT INTO load_products.ecommerce_tracking (order_created_date, shop_id,shop_name,order_number,sub_total,order_delivery_date,order_delivery_status,fulfilment_by,shipping_fee_charge,kos_charge,item_name,product_sku,quantity,sales_price,commission_rate,commission_fee,expected_payment_date,payout_amount,payout_status,user_id) Values `
    //         for (let i = 0; i < dataValues.length; i++) {
    //             if (i == 0) {
    //                 continue;
    //             }
    //              if (dataValues[i][16] == '-' || dataValues[i][16] == '') {
    //                  newValues = null
    //              } else {
    //                  newValues = "'" + dataValues[i][16].toISOString().slice(0, 19).replace('T', ' ') + "'"
    //              }
    //              let rowvalues = `(` + "'" + dataValues[i][0].toISOString().slice(0, 19).replace('T', ' ') + "'" + ',' + "'" + dataValues[i][1] + "'" + ',' + "'" + dataValues[i][2] + "'" + ',' + "'" + dataValues[i][3] + "'" + ',' + "'" + dataValues[i][4] + "'" + ',' + "'" + dataValues[i][5].toISOString().slice(0, 19).replace('T', ' ') + "'" + ',' + "'" + dataValues[i][6] + "'" + ',' + "'" + dataValues[i][7] + "'" + ',' + "'" + dataValues[i][8] + "'" + ',' + "'" + dataValues[i][9] + "'" + ',' + "'" + dataValues[i][10] + "'" + ',' + "'" + dataValues[i][11] + "'" + ',' + "'" + dataValues[i][12] + "'" + ',' + "'" + dataValues[i][13] + "'" + ',' + "'" + dataValues[i][14] + "'" + ',' + "'" + dataValues[i][15] + "'" + ',' + newValues + ',' + "'" + dataValues[i][17] + "'" + ',' + "'" + dataValues[i][18] + "'" + ',' + req.userData.user._id + ' )'
    //             //let rowvalues = `("${dataValues[i][0]}" , "${dataValues[i][1]}" , '${dataValues[i][2]}' , '${dataValues[i][3]}' , '${dataValues[i][4]}' , '${dataValues[i][5]}' , '${dataValues[i][6]}' , '${dataValues[i][7]}' , '${currDate}' , ${userId} )`
    //             if (i == 1) {
    //                 q += rowvalues;
    //             }
    //             else {
    //                 q = q + ',' + rowvalues;
    //             }
    //         }
    //         var ecomProducts = await db.saveEcomProducts(q)
    //         if (ecomProducts) {
    //             res.status(201).send({ status: true });
    //         }
    //     } catch (err) {
    //         res.status(400).send({ error: err });
    //     }
    // });

    // router.post('/save-combo-products', upload, async function (req, res) {
    //     try {
    //         var userId = req.userData.user._id;
    //         const data = xlsx.parse(req.file.path, { cellDates: true });
    //         var dataValues = data[0].data
    //         let q = `INSERT INTO load_products.combo_products (combo_names, combo_items, quantity, selling_price, purchase_price, platform, products_sku, insert_date,user_id) Values `
    //         for (let i = 0; i < dataValues.length; i++) {
    //             if (i == 0) {
    //                 continue;
    //             }
    //             let rowvalues = `("${dataValues[i][0]}" , "${dataValues[i][1]}" , '${dataValues[i][2]}' , '${dataValues[i][3]}' , '${dataValues[i][4]}' , '${dataValues[i][5]}' , '${dataValues[i][6]}' , '${dataValues[i][7].toISOString().slice(0, 19).replace('T', ' ')}', ${userId} )`
    //             if (i == 1) {
    //                 q += rowvalues;
    //             }
    //             else {
    //                 q = q + ',' + rowvalues;
    //             }
    //         }
    //         var ecomComboProducts = await db.saveEcomComboProducts(q)
    //         if (ecomComboProducts) {
    //             res.status(201).send({ status: true });
    //         }
    //     } catch (err) {
    //         res.status(400).send({ error: err });
    //     }
    // });


    //***************************** */
    //  CODE FOR NEW SPREADSHEET
    //***************************** */

    router.get('/get-uniq-ecomm-products', async function (req, res) {
        try {
            let { product_sku } = req.query;
            if (product_sku) {
                let getEcomProductDetails = await db.getEcomProductDetails(req.userData.user._id, product_sku)
                if (getEcomProductDetails) {
                    res.status(200).send({ data: getEcomProductDetails });
                }
                return;
            }
            let getEcomProducts = await db.getEcomProducts(req.userData.user._id);
            let uniqEcomProducts = [];
            const map = new Map();
            for (const item of getEcomProducts) {
                if (!map.has(item.product_sku)) {
                    map.set(item.product_sku, true);
                    uniqEcomProducts.push(item)
                }
            }
            if (getEcomProducts) {
                res.status(200).send({ data: uniqEcomProducts });
            }

        }
        catch (err) {
            res.status(400).send({ error: err });
        }
    })


    router.get('/get-single-ecomm-combo-products', async function (req, res) {
        try {
            let { product_sku } = req.query;
            var userId = req.userData.user._id;
            if (product_sku) {
                let q = `SELECT * FROM load_products.combo_products where user_id=${userId} and products_sku like '%${product_sku}%'`
                let getEcomComboProductDetails = await db.getEcomComboProductDetails(q)
                if (getEcomComboProductDetails) {
                    res.status(200).send({ data: getEcomComboProductDetails });
                }
            }
        }
        catch (err) {
            res.status(400).send({ error: err });
        }
    })

    router.get('/get-unique-ecomm-combo-products', async function (req, res) {
        try {
            var userId = req.userData.user._id;
            let getEcomProducts = await db.getEcomComboProducts(userId);
            if (getEcomProducts) {
                let uniqEcomProductsSqu = [];
                let skuArray = [];
                let nameArray = [];
                let products = []
                getEcomProducts.map((product) => {
                    skuArray = product.products_sku.split(',')
                    nameArray = product.combo_items.split(',')
                    for (var i = 0; i < skuArray.length; i++) {
                        if (!uniqEcomProductsSqu.includes(skuArray[i].trim())) {
                            uniqEcomProductsSqu = [...uniqEcomProductsSqu, skuArray[i].trim()]
                            var obj = {};
                            obj['sku'] = skuArray[i].trim();
                            obj['name'] = nameArray[i];
                            products.push(obj);
                        }
                    }
                })
                if (getEcomProducts) {
                    res.status(200).send({ data: products });
                }
            }

        }
        catch (err) {
            res.status(400).send({ error: err });
        }
    })

    router.post('/save-products', upload, async function (req, res) {
        try {
            const data = xlsx.parse(req.file.path, { cellDates: true });
            var dataValues = data[0].data;
            var userId = req.userData.user._id;
            var dateObj = new Date();
            var currDate = dateObj.toISOString().slice(0, 19).replace('T', ' ')
            let q = `INSERT INTO load_products.ecommerce_single_products (item_name, quantity,pack_size,quantity_per_carton,selling_price,purchase_price,platform,product_sku,order_created_date,user_id) Values `

            for (let i = 0; i < dataValues.length; i++) {


                if (i == 0) {
                    continue;
                }
                if (!dataValues[i][0] || typeof dataValues[i][0] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][1]) {
                    throw `Error in row ${i + 1} column ${dataValues[0][1]}. Value should be a number. It cannot be empty.`
                }
                if (dataValues[i][1] && typeof dataValues[i][1] !== 'number') {
                    let check = dataValues[i][1].substring(1).replace(',', '')
                    if (!check) {
                        throw `Error in row ${i + 1} column ${dataValues[0][1]}. Value should be a number. `
                    }
                }
                if (!dataValues[i][2] || typeof dataValues[i][2] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][2]}. Value should be a string. `
                }
                if (!dataValues[i][3]) {
                    throw `Error in row ${i + 1} column ${dataValues[0][3]}. Value should be a number.  It cannot be empty.`
                }
                if (dataValues[i][3] && typeof dataValues[i][3] !== 'number') {
                    let check = parseInt(dataValues[i][3].replace(',', ''))
                    if (!check) {
                        throw `Error in row ${i + 1} column ${dataValues[0][3]}. Value should be a number. `
                    }
                }
                if (!dataValues[i][4]) {
                    throw `Error in row ${i + 1} column ${dataValues[0][4]}. Value should be a number.  It cannot be empty.`
                }
                if (dataValues[i][4] && typeof dataValues[i][4] !== 'number') {
                    let check = parseInt(dataValues[i][4].replace(',', ''))
                    if (!check) {
                        throw `Error in row ${i + 1} column ${dataValues[0][4]}. Value should be a number. `
                    }
                }
                if (!dataValues[i][5]) {
                    throw `Error in row ${i + 1} column ${dataValues[0][5]}. Value should be a number.  It cannot be empty.`
                }
                if (dataValues[i][5] && typeof dataValues[i][5] !== 'number') {
                    let check = parseInt(dataValues[i][5].replace(',', ''))
                    if (!check) {
                        throw `Error in row ${i + 1} column ${dataValues[0][5]}. Value should be a number. `
                    }
                }

                if (!dataValues[i][6] || typeof dataValues[i][6] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][6]}. Value should be a string. `
                }
                if (!dataValues[i][7]) {
                    throw `Error in row ${i + 1} column ${dataValues[0][7]}. Value should be a number.  It cannot be empty.`
                }
                if (dataValues[i][7] && typeof dataValues[i][7] !== 'number') {
                    let check = parseInt(dataValues[i][7].replace(',', ''))
                    if (!check) {
                        throw `Error in row ${i + 1} column ${dataValues[0][7]}. Value should be a number. `
                    }
                }

                let rowvalues = `("${dataValues[i][0]}" , "${dataValues[i][1]}" , '${dataValues[i][2]}' , '${dataValues[i][3]}' , '${dataValues[i][4]}' , '${dataValues[i][5]}' , '${dataValues[i][6]}' , '${dataValues[i][7]}' , '${currDate}' , ${userId} )`
                if (i == 1) {
                    q += rowvalues;
                }
                else {
                    q = q + ',' + rowvalues;
                }
            }
            var ecomProducts = await db.saveEcomProducts(q)
            if (ecomProducts) {
                res.status(201).send({ status: true, message: 'Succesfully added ecommerce data!!' });
            }
        } catch (err) {

            res.status(400).send({ error: err });
        }
    });

    router.post('/save-combo-products', upload, async function (req, res) {
        try {
            var userId = req.userData.user._id;
            var dateObj = new Date();
            var currDate = dateObj.toISOString().slice(0, 19).replace('T', ' ')
            const data = xlsx.parse(req.file.path, { cellDates: true });

            var dataValues = data[0].data

            let q = `INSERT INTO load_products.combo_products (combo_names, combo_items, quantity, selling_price, purchase_price, platform, products_sku, insert_date,user_id) Values `
            for (let i = 0; i < dataValues.length; i++) {
                if (i == 0) {
                    continue;
                }

                if (!dataValues[i][0] || typeof dataValues[i][0] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][0] || typeof dataValues[i][1] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][0] || typeof dataValues[i][2] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][0] || typeof dataValues[i][3] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][0] || typeof dataValues[i][4] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][0] || typeof dataValues[i][5] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }
                if (!dataValues[i][0] || typeof dataValues[i][6] !== 'string') {
                    throw `Error in row ${i + 1} column ${dataValues[0][0]}. Value should be a string. `
                }


                let rowvalues = `("${dataValues[i][0]}" , "${dataValues[i][1]}" , '${dataValues[i][2]}' , '${dataValues[i][3]}' , '${dataValues[i][4]}' , '${dataValues[i][5]}' , '${dataValues[i][6]}' , '${currDate}', ${userId} )`
                if (i == 1) {
                    q += rowvalues;
                }
                else {
                    q = q + ',' + rowvalues;
                }
            }

            var ecomComboProducts = await db.saveEcomComboProducts(q)
            if (ecomComboProducts) {
                res.status(201).send({ status: true, message: 'Succesfully added ecommerce combo data!!' });
            }

        } catch (err) {
            res.status(400).send({ error: err });
        }
    });



    // router.get('/get-uniq-ecomm-combo-products', async function (req, res) {
    //     try {
    //         let { product_sku } = req.query;
    //         var userId = req.userData.user._id;
    //         if (product_sku) {
    //             let q = `SELECT * FROM load_products.combo_products where user_id=${userId} and products_sku like '%${product_sku}%'`
    //             let getEcomComboProductDetails = await db.getEcomComboProductDetails(q)
    //             if (getEcomComboProductDetails) {
    //                 res.status(200).send({ data: getEcomComboProductDetails });
    //             }
    //         }
    //     }
    //     catch (err) {
    //         res.status(400).send({ error: err });
    //     }
    // })



    router.get('/get-ecom-products', async function (req, res) {
        try {
            let userId = req.userData.user._id;
            let ecomProducts = await db.getEcomProducts(userId)
            if (ecomProducts) {
                res.status(200).send({ data: ecomProducts })
            }
        }
        catch (err) {
            res.status(400).send({ error: err })
        }
    })

    router.get('/get-ecom-combo-products', async function (req, res) {
        try {
            let userId = req.userData.user._id;
            let ecomComboProducts = await db.getEcomComboProducts(userId)
            if (ecomComboProducts) {
                res.status(200).send({ data: ecomComboProducts })
            }
        }
        catch (err) {
            res.status(400).send({ error: err })
        }
    })


    router.get('/delete-ecom-single-product', async function (req, res) {

        try {
            let userId = req.userData.user._id;
            const { productId } = req.query;
            let deletedProduct = await db.deleteEcomSingleProduct(userId, productId)
            if (deletedProduct) {
                res.status(200).send({ data: productId })
            }
        }
        catch (err) {
            res.status(400).send({ error: err })
        }

    })

    router.get('/delete-ecom-combo-product', async function (req, res) {
        try {
            let userId = req.userData.user._id;
            const { productId } = req.query;
            let deletedProduct = await db.deleteEcomComboProduct(userId, productId)
            if (deletedProduct) {
                res.status(200).send({ data: productId })
            }
        }
        catch (err) {
            res.status(400).send({ error: err })
        }
    })

    router.get('/update-ecom-single-product', async function (req, res) {
        try {
            let userId = req.userData.user._id;
            const { order_created_date, product_sku, item_name, quantity, quantity_per_carton, selling_price, platform, purchase_price, ID } = req.query
            let updatedProduct = await db.updateEcomSingleProduct(order_created_date, product_sku, item_name, quantity, quantity_per_carton, selling_price, platform, purchase_price, userId, ID)
            if (updatedProduct) {
                res.status(200).send({ data: ID })
            }
        }
        catch (err) {
            res.status(400).send({ error: err })
        }

    })

    router.get('/update-ecom-combo-product', async function (req, res) {
        try {
            let userId = req.userData.user._id;
            const { insert_date, products_sku, combo_names, combo_items, quantity, selling_price, platform, purchase_price, ID } = req.query
            let updatedProduct = await db.updateEcomComboProduct(insert_date, products_sku, combo_names, combo_items, quantity, selling_price, platform, purchase_price, userId, ID)
            if (updatedProduct) {
                res.status(200).send({ data: ID })
            }
        }
        catch (err) {
            res.status(400).send({ error: err })
        }

    })

    router.post('/create-report', async function (req, res) {
        try {
            const data = req.body.data;
            var xls = json2xls(data);
            fs.writeFileSync('./public/data.xlsx', xls, 'binary');
            res.status(200).send({ data: 'file created' })
        }
        catch (err) {
            res.status(400).send({ error: 'unable to create a report' })
        }
    })
    
    router.get('/get-report', async function (req, res) {
       try{
        res.download('./public/data.xlsx', 'data.xlsx')     
       }
       catch(err){
        res.status(400).send({ error:err })
       }
    })
    app.use("/ecom", router)
}



