module.exports = function (express, app, jwt) {
    var ware = {};

    ware.basic = function (req, res, next) {
        let token = req.cookies.token || req.body.token || req.query.token || req.headers['authorization'];
        if (token) {
            jwt.verify(token.replace('Bearer ', ''), app.get('superSecret'), function (err, decoded) {
                if (!err && decoded) {
                    req.userData = decoded;
                }
                next();
            });
        } else
            next();

    };
    ware.userRequired = function (req, res, next) {
        let token = req.cookies.token || req.body.token || req.query.token || req.headers['authorization'];
        if (token) {
            jwt.verify(token.replace('Bearer ', ''), app.get('superSecret'), function (err, decoded) {
                if (err) {
                    return res.status(402).send({ error: 'Failed to authenticate token.' });
                } else {
                    req.userData = decoded;
                    next();
                }
            });
        } else
            return res.status(403).send({ error: 'No token provided.' });
    };
    return ware;
};