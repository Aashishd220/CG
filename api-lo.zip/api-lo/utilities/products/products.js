
const { load } = require('dotenv');
var mysql = require('../connection');

module.exports.getProducts = async ({ webUrl, limit, offset, category }) => {

	return await mysql.query('SELECT * FROM load_products.product_data WHERE dealer = ? AND category = ? LIMIT ? OFFSET ?', [webUrl, category, limit, offset]);
};

module.exports.getProductsWithBrand = async ({ webUrl, limit, offset, category, brandsString }) => {
	brandsString = brandsString.split(",")
	let q = 'SELECT * FROM load_products.product_data WHERE dealer = ? AND category = ? AND '
	brandsString.forEach(brand => {
		q += `brand=${brand} or `
	});

	q = q.substring(0, q.length - 3)
	q += ` limit ${limit} offset ${offset}`
	return await mysql.query(q, [webUrl, category]);
};

module.exports.getProductsWithTermBrandCategory = async (q) => {
	return await mysql.query(q)
};

module.exports.getProductsCountWithCategory = async ({ webUrl, category }) => {
	return await mysql.query('SELECT COUNT(*) as rowCount FROM load_products.product_data where dealer=? AND category = ?', [webUrl, category]);
};

module.exports.getProductCountWithCategoryAndBrands=async ({webUrl,category,brands})=>{
	let q=`SELECT COUNT(*) as rowCount FROM load_products.product_data where dealer='${webUrl}' AND category = '${category}'  AND `
	let check = false;
	let tempArray = brands.split(",")
                    if (tempArray.length === 1) {
                        q += `brand="${brands}"`
                    }
                    else {
                        tempArray.forEach(value => {
                            q += `brand="${value}" or `
                        })
                        check = true;
                    }
                    if (check) {
                        q = q.substring(0, q.length - 3)
					}
			return await mysql.query(q);
                
}

module.exports.getProductsCount = async (website) => {
	return await mysql.query('SELECT COUNT(*) as rowCount FROM load_products.product_data where dealer=?', [website]);
};

module.exports.getCategories = async (website) => {
	return await mysql.query('SELECT DISTINCT(category) FROM load_products.product_data where dealer=?', [website]);
};

module.exports.getBrands = async (website) => {
	return await mysql.query('SELECT DISTINCT(brand), category FROM load_products.product_data where dealer=?', [website]);
};

module.exports.saveFavoriteProducts = async (id, userId, productCode,price,dealer,name,images) => {
	return await mysql.query('INSERT INTO load_products.favorite_products (product_id, product_code, user_id,created_at,price,name,dealer,images) Values (?,?,?,now(),?,?,?,?)', [id, productCode, userId,price,name,dealer,images]);
}

module.exports.unFavoriteProduct = async (id, userId) => {
	return await mysql.query('DELETE FROM load_products.favorite_products WHERE product_id=? AND user_id=?', [id, userId]);
}

module.exports.getFavoriteProductsDetail = async (q) => {
	//return await mysql.query('SELECT * from load_products.product_data as product_data INNER JOIN load_products.favorite_products as fav_products ON fav_products.product_id = product_data.ID WHERE fav_products.user_id=?',[user_id])
	return await mysql.query(q)
};

module.exports.getProductData = async (code) => {
	return await mysql.query('SELECT * FROM load_products.product_data where id=?', [code]);
};

module.exports.getProductPricingData = async (productCode) => {
	return await mysql.query('SELECT * FROM load_products.product_pricing where product_code = ?', [productCode]);
};

module.exports.getProductPricingEvery24Hours = async (q) => {
	return await mysql.query(q);
};

module.exports.getUniqueUserIds = async () => {
	return await mysql.query('SELECT DISTINCT user_id FROM load_products.favorite_products')
}

module.exports.searchedProducts = async (q) => {

	return await mysql.query(q)
};

module.exports.searchedExactProduct = async (term,website) => {
	let q=`select DISTINCT(dealer),ID,name,price,images from load_products.product_data where `;
	if(website){
		q+=`dealer='${website}' AND `
	}
	if (term.includes('"')) {
		q += `name='${term}'`
	}
	else {
		q += `name="${term}"`
	}
	
	return await mysql.query(q)
};

