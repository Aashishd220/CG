var mysql = require('promise-mysql');

var pool = mysql.createPool({
    host: process.env.mysql_host,
    user: process.env.mysql_user,
    password: process.env.mysql_password
});

module.exports.getConnection = () => {
    return new Promise((resolve, reject) => {
        pool.getConnection((err, connection) => {
            if (err)
                reject(err);
            else
                resolve(connection);
        });
    });
}

module.exports.query = (queryStr, values) => {
   
    return pool.query(queryStr, values);
}