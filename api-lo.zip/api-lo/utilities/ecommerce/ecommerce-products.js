var mysql = require('../connection');



//***************************** */
//  CODE FOR OLD SPREADSHEET
//***************************** */


// module.exports.saveEcomProducts = async (q) => {
// 	return await mysql.query(q)
// };

// module.exports.saveEcomComboProducts = async (q) => {
// 	return await mysql.query(q)
// };
// module.exports.getEcomProducts = async (user_id) => {
// 	return await mysql.query(`select product_sku,item_name from load_products.ecommerce_tracking where user_id=?`,user_id)
// };

// module.exports.getEcomProductDetails = async (user_id,product_sku) => {
// 	return await mysql.query(`select * from load_products.ecommerce_tracking where user_id=? and product_sku=?`,[user_id,product_sku])
// };

// module.exports.getEcomComboProductDetails = async (q) => {
// 	return await mysql.query(q)
// };



// module.exports.getEcomSellers = async (user_id) => {
// 	return await mysql.query(`select shop_id,shop_name from load_products.ecommerce_tracking where user_id=?`,user_id)
// };

// module.exports.getEcomSellerDetails = async (user_id,shop_id) => {
// 	return await mysql.query(`select * from load_products.ecommerce_tracking where user_id=? and shop_id=?`,[user_id,shop_id])
// };

// module.exports.getEcomSellerProductsDetails = async(user_id,shop_id,product_sku) =>{
//     return await mysql.query(`select * from load_products.ecommerce_tracking where user_id=? and shop_id=? and product_sku=?`,[user_id,shop_id,product_sku])	
// }




// ***************************** */
//      CODE FOR NEW SPREADSHEET
// 	***************************** */


module.exports.saveEcomProducts = async (q) => {
	return await mysql.query(q)
};

module.exports.saveEcomComboProducts = async (q) => {
	return await mysql.query(q)
};
module.exports.getEcomProducts = async (user_id) => {
	return await mysql.query(`select * from load_products.ecommerce_single_products where user_id=?`, user_id)
};

module.exports.getEcomComboProducts = async (user_id) => {
	return await mysql.query(`select * from load_products.combo_products where user_id=?`, user_id)
};

module.exports.getEcomProductDetails = async (user_id, product_sku) => {
	return await mysql.query(`select * from load_products.ecommerce_single_products where user_id=? and product_sku=?`, [user_id, product_sku])
};

module.exports.getEcomComboProductDetails = async (q) => {
	return await mysql.query(q)
};

module.exports.deleteEcomSingleProduct = async (userId, productId) => {
	return await mysql.query('DELETE from load_products.ecommerce_single_products where user_id=? and ID=?', [userId, productId])
};

module.exports.deleteEcomComboProduct = async (userId, productId) => {
	return await mysql.query('DELETE from load_products.combo_products where user_id=? and ID=?', [userId, productId])
};

module.exports.updateEcomSingleProduct = async (createdDate, productSku, itemName, quantity, quantityPerCarton, sellingPrice, platform, purchasePrice, userId, ID) => {
	q = `UPDATE load_products.ecommerce_single_products SET order_created_date='${createdDate}',  product_sku='${productSku}', item_name="${itemName}",quantity='${quantity}',quantity_per_carton='${quantityPerCarton}',selling_price='${sellingPrice}',platform='${platform}',purchase_price='${purchasePrice}' WHERE user_id = ${userId} AND ID=${ID}`
	return await mysql.query(q)
};

module.exports.updateEcomComboProduct = async (createdDate, products_sku, combo_names, combo_items, quantity, selling_price, platform, purchase_price, userId, ID) => {
	q = `UPDATE load_products.combo_products SET insert_date='${createdDate}',  products_sku='${products_sku}', combo_names="${combo_names}",combo_items="${combo_items}",quantity='${quantity}',selling_price='${selling_price}',platform='${platform}',purchase_price='${purchase_price}' WHERE user_id = ${userId} AND ID=${ID}`
	return await mysql.query(q)
};


