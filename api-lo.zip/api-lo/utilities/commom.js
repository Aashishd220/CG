var mysql = require('./connection');
module.exports.getUserByEmail = async (email) => {
	return await mysql.query('SELECT id,first_name,last_name,email,user_role FROM load_products.users WHERE email = ?', [email]);
};

module.exports.getAllRoles = async () => {
	return await mysql.query('SELECT * FROM load_products.roles');
};

module.exports.getAllUsers = async () => {
	return await mysql.query('SELECT * FROM load_products.users WHERE user_role <> 0');
};

module.exports.getFavoriteProducts = async (userId) => {
	return await mysql.query('SELECT * from load_products.favorite_products WHERE user_id=?', [userId])
}

module.exports.getNotifications = async (userId) => {
	return await mysql.query('SELECT * FROM load_products.notification WHERE user_id=? and is_seen=0', [userId])
}

module.exports.saveNotification = async (userId, msg, productCode, price) => {
	return await mysql.query(`INSERT INTO load_products.notification (user_id,notification_message,is_seen,product_code,price) values (?,?,0,?,?)`, [userId, msg, productCode, price])
};

module.exports.updateNotification = async (userId, ID) => {
	return await mysql.query(`UPDATE load_products.notification SET is_seen=1 where ID=?`, [ID])
};

module.exports.clearAllNotification = async (userId) => {
	return await mysql.query(`UPDATE load_products.notification SET is_seen=1 where user_id=?`, [userId])
};

module.exports.getNotification = async (ID) => {
	return await mysql.query('SELECT DISTINCT(product_data.product_code),product_data.ID,notification.user_id,product_data.images,product_data.name,notification.price, notification.notification_message,notification.created_date from load_products.product_data as product_data INNER JOIN load_products.notification as notification ON notification.product_code = product_data.product_code where notification.ID=?', [ID])
}

module.exports.updateRoleRequest = async (firstName,lastName,email,currentRole,requestedRole,userId) => {
	return await mysql.query('INSERT INTO load_products.user_requests (user_id,first_name,last_name,email,current_role,requested_role) VALUES(?,?,?,?,?,?)',[userId,firstName,lastName,email,currentRole,requestedRole])
}

module.exports.getSuperAdminRequests=async()=>{
	return await mysql.query('SELECT * FROM load_products.user_requests')
}
module.exports.getSingleUserRequests=async(userId)=>{
	return await mysql.query('SELECT * FROM load_products.user_requests where user_id=? and action_taken=0',[userId])
}
module.exports.updateRoleUserTable = async (email,role,id) => {
	return await mysql.query('UPDATE load_products.users set user_role=? where ID=?',[role,id])
}
module.exports.updateRoleRequestTable = async (id,isAccepted) => {
	return await mysql.query('UPDATE load_products.user_requests set is_accepted=?,action_taken=1 where ID=?',[isAccepted,id])
}

module.exports.deleteRequest = async (id) => {
	return await mysql.query('DELETE from load_products.user_requests where ID=?',[id])
}