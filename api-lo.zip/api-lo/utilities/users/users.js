
var mysql = require('../connection');

module.exports.saveUser = async ({first_name, last_name, email, encrypPassword, user_role}) => {
	return await mysql.query('INSERT INTO load_products.users (first_name, last_name, email, password, user_role, created_at, updated_at) Values (?,?,?,?,?, now(), now())',[first_name, last_name, email, encrypPassword, user_role]);
};

module.exports.getUserByEmail = async (email) => {
	return await mysql.query('SELECT id,first_name,last_name,email,user_role FROM load_products.users WHERE email = ?',[email]);
};

module.exports.signIn = async (email) => {
	return await mysql.query('SELECT id,first_name,last_name,email,user_role,password,active FROM load_products.users WHERE email = ?',[email]);
};

module.exports.getRoles = async () => {
	return await mysql.query('SELECT * FROM load_products.roles WHERE id <> 0');
};

module.exports.resetPassword = async (email,password) => {
	return await mysql.query('UPDATE load_products.users set password=? WHERE email=?',[password,email]);
};

module.exports.updateUserStatus = async (id,active) => {
	return await mysql.query('UPDATE load_products.users set active=? WHERE id=?',[active,id]);
};

module.exports.getAllUsers=async ()=>{
	return await mysql.query('SELECT * FROM load_products.users')
}
module.exports.updateUserKongaIdAndEmail=async (jumiaId,apiKey,userId)=>{
	return await mysql.query('UPDATE load_products.users set jumia_id=?,jumia_api_key=? where id=?',[jumiaId,apiKey,userId])
}

module.exports.getUserJumiaCreds=async(userId)=>{
	return await mysql.query('SELECT jumia_id,jumia_api_key FROM load_products.users WHERE id=?',[userId])
}