import Axios from '../../shared/services/axios-service';

const seenNotification = (ID,token) => {
	return Axios.get("/user/update-notification?ID="+ID, undefined, token);
};

const clearNotifications=(userId,token)=>{
	return Axios.get("/user/clear-all-notifications?userId="+userId, undefined, token);

}

export default {
	seenNotification,
	clearNotifications
};