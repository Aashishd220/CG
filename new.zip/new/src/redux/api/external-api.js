import Axios from '../../shared/services/axios-service';


const getMetricsDatafromExternalApi = (action,token) => {
	return Axios.get(`/external-api/get-metrics-data-from-api?action=${action}`,undefined, token);
};

const getOrdersDatafromExternalApi = (action,token) => {
	return Axios.get(`/external-api/get-orders-data-from-api?action=${action}`,undefined, token);
};

const getProductsDatafromExternalApi = (action,token) => {
	return Axios.get(`/external-api/get-products-data-from-api?action=${action}`,undefined, token);
};

const getStatisticsDatafromExternalApi = (action,token) => {
	return Axios.get(`/external-api/get-statistics-data-from-api?action=${action}`,undefined, token);
};

const getPayoutStatusDataFromExternalApi = (action,token) => {
	return Axios.get(`/external-api/get-payout-data-from-api?action=${action}`,undefined, token);
};


const getBestWorstSellingProducts = (action,startDate,endDate,token) => {
	return Axios.get(`/external-api/get-best-worst-product-from-api?action=${action}&startDate=${startDate}&endDate=${endDate}`,undefined, token);
};
export default {
    getMetricsDatafromExternalApi,
    getOrdersDatafromExternalApi,
    getProductsDatafromExternalApi,
    getStatisticsDatafromExternalApi,
    getPayoutStatusDataFromExternalApi,
    getBestWorstSellingProducts
}