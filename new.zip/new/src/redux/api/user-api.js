import Axios from '../../shared/services/axios-service';

const signIn = (user) => {
	
	return Axios.post("/users/sign-in", user, undefined);
};

const signUp = (user) => {
	return Axios.post("/users/sign-up", user, undefined);
};

const forgotPassword = (email) => {
	return Axios.post("/users/forgot-password", {email}, undefined);
};

const resetPassword = (oldPassword,newPassword,email) => {
	return Axios.post("/users/reset-password", {oldPassword,newPassword,email}, undefined);
};
const updateRoleRequest = (firstName,lastName,email,currentRole,requestedRole,token) => {
	return Axios.post("/user/update-role-request", {firstName,lastName,email,currentRole,requestedRole}, token);
};

const updateUserRole = (id,email,role,isAccept,token) => {
	return Axios.post("/user/update-role", {id,email,role,isAccept},token);
};

const updateUserStatus = (id,active,token) => {
	return Axios.post("/users/update-user-status", {id,active},token);
};
const addJumiaCreds = (jumiaId,apiKey,token) => {
	return Axios.post("/users/jumia-creds", {jumiaId,apiKey},token);
};
export default {
	signIn,
	signUp,
	forgotPassword,
	resetPassword,
	updateRoleRequest,
	updateUserRole,
	updateUserStatus,
	addJumiaCreds
};
