import Axios from '../../shared/services/axios-service';

const saveEcommerceProductsData = (data, token) => {
	return Axios.post("/ecom/save-products", data, token);
};

const saveEcommerceComboProductsData = (data, token) => {
	return Axios.post("/ecom/save-combo-products", data, token);
};

const deleteEcommerceSingleProduct = (id, token) => {
	return Axios.get("/ecom/delete-ecom-single-product?productId="+id,undefined, token);
};

const deleteEcommerceComboProduct = (id, token) => {
	return Axios.get("/ecom/delete-ecom-combo-product?productId="+id,undefined, token);
};

const updateEcommerceSingleProduct = (values, token) => {
	return Axios.get("/ecom/update-ecom-single-product",values, token);
};

const updateEcommerceComboProduct = (values, token) => {
	return Axios.get("/ecom/update-ecom-combo-product",values, token);
};

const saveReport = (data, token) => {
	return Axios.post("/ecom/create-report", {data}, token);
};


export default {
	saveEcommerceProductsData,
	saveEcommerceComboProductsData,
	deleteEcommerceSingleProduct,
	deleteEcommerceComboProduct,
	updateEcommerceSingleProduct,
	updateEcommerceComboProduct,
	saveReport,
};

