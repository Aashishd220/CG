import Axios from '../../shared/services/axios-service';

const getWebsiteProducts = (website,defaultCategory, page,token,brand,term) => {
	defaultCategory = encodeURIComponent(defaultCategory);
	return Axios.get("/products/website-products?page="+page+"&website="+website+"&category="+defaultCategory+"&brands="+brand+"&term="+term, undefined, token);
};

const saveFavoriteProduct=(id,isFavorite,token,productCode,name,price,dealer,images)=>{
	let value={name,id,isFavorite,token,productCode,name,price,dealer,images}
	return Axios.post("/products/add-fav-product",value,token)
}

const getFavProducts=(category,brands,term,token,page)=>{	
	category=category.replace('&','%26')
	return Axios.get("/products/get-fav-products-details?category="+category+"&brands="+brands+"&term="+term+"&page="+page,undefined,token)
}

const getSearchedProducts=(term,token,website)=>{	
	return Axios.get("/products/get-searched-products?term="+term+"&website="+website,undefined,token)
}
const getUniqueProduct=(term,token,website)=>{		
	// term=btoa(term)
	term=btoa(unescape(encodeURIComponent(term)))
	return Axios.get("/products/get-searched-single-product?term="+term+"&website="+website,undefined,token)
}
export default {
	getWebsiteProducts,
	saveFavoriteProduct,
	getFavProducts,
	getSearchedProducts,
	getUniqueProduct
};