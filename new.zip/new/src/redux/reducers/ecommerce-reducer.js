import { Types } from "../constants/ecommerce-types";

const initialState = {
    saveEcommerceProductsResponse: {},
    saveEcommerceComboProductsResponse: {},
    deleteEcommerceSingleProductResponse: {},
    deleteEcommerceComboProductResponse: {},
    updateEcommerceSingleProductResponse: {},
    updateEcommerceComboProductResponse: {}
};

export default function ecommerceReducer(state = initialState, action) {

    switch (action.type) {
        case Types.SAVE_ECOMMERCE_PRODUCTS_DATA_FAIL:
            return {
                ...state, saveEcommerceProductsResponse: {
                    status: 'fail',
                    message: `Failed to add e-commerce data. ${action.payload} Check the file format from above.`
                }
            };
        case Types.SAVE_ECOMMERCE_PRODUCTS_DATA_SUCCESS:
            return {
                ...state, saveEcommerceProductsResponse: {
                    status: 'success',
                    message: 'Succesfully added ecommerce data'
                }
            };

        case Types.SAVE_ECOMMERCE_COMBO_PRODUCTS_DATA_FAIL:
            return {
                ...state, saveEcommerceComboProductsResponse: {
                    status: 'fail',
                    message: `Failed to add e-commerce data. ${action.payload} Check the file format from above.`
                }
            };
        case Types.SAVE_ECOMMERCE_COMBO_PRODUCTS_DATA_SUCCESS:
            return {
                ...state, saveEcommerceComboProductsResponse: {
                    status: 'success',
                    message: 'Succesfully added ecommerce combo products data.'
                }
            };
        case Types.DELETE_ECOMMERCE_SINGLE_PRODUCT_SUCCESS:
            return {
                ...state, deleteEcommerceSingleProductResponse: {
                    status: 'success',
                    id: action.payload,
                    message: 'Succesfully deleted ecommerce single product.'
                }
            };
        case Types.DELETE_ECOMMERCE_SINGLE_PRODUCT_FAIL:
            return {
                ...state, deleteEcommerceSingleProductResponse: {
                    status: 'fail',
                    message: 'fail to delete ecommerce single product.'
                }
            };
        case Types.DELETE_ECOMMERCE_COMBO_PRODUCT_SUCCESS:
            return {
                ...state, deleteEcommerceComboProductResponse: {
                    status: 'success',
                    id: action.payload,
                    message: 'Succesfully deleted ecommerce combo product.'
                }
            };
        case Types.DELETE_ECOMMERCE_COMBO_PRODUCT_FAIL:
            return {
                ...state, deleteEcommerceComboProductResponse: {
                    status: 'fail',
                    message: 'fail to delete ecommerce combo product.'
                }
            };
        case Types.UPDATE_ECOMMERCE_SINGLE_PRODUCT_SUCCESS:
            return {
                ...state, updateEcommerceSingleProductResponse: {
                    status: 'success',
                    message: 'Succesfully updated ecommerce single product.',
                    id: action.payload,
                }
            };
        case Types.UPDATE_ECOMMERCE_SINGLE_PRODUCT_FAIL:
            return {
                ...state, updateEcommerceSingleProductResponse: {
                    status: 'fail',
                    message: 'fail to updated ecommerce single product.'
                }
            };

        case Types.UPDATE_ECOMMERCE_SINGLE_PRODUCT_SUCCESS:
            return {
                ...state, updateEcommerceComboProductResponse: {
                    status: 'success',
                    message: 'Succesfully updated ecommerce combo product.',
                    id: action.payload,
                }
            };
        case Types.UPDATE_ECOMMERCE_SINGLE_PRODUCT_FAIL:
            return {
                ...state, updateEcommerceComboProductResponse: {
                    status: 'fail',
                    message: 'fail to updated ecommerce combo product.'
                }
            };

        default:
            return state;
    }
}