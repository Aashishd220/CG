import { Types } from "../constants/user-types";
import User from '../../shared/services/user-service';
const initialState = {
  isLoggedIn: User.isLoggedIn(),
  token: User.getToken(),
  user: {},
  errorMessage: "",
  successMessage:'',
  isSuccess: true,
  roleChangedRequestSuccess: '',
  roleChangedRequestFailure: '',
  requesActionSuccessData: '',
  requesActionFailure: '',
  data: [],
  allUsers: [],
  jumiaCreds: ''
};

export default function userReducer(state = initialState, action) {
  switch (action.type) {
    case Types.LOG_IN:
      User.logIn(action.payload.token, 60);
      return { ...state, isLoggedIn: true, user: action.payload, isSuccess: true };
    case Types.LOG_OUT:
      User.logOut();
      return { ...state, isLoggedIn: false, user: initialState.user };
    case Types.SAVE_USER:
      return { ...state, user: action.payload };
    case Types.SAVE_FAILURE:
      return { ...state, errorMessage: action.payload, isSuccess: false };
    case Types.FORGOT_PASSWORD_SUCCESS:
      return { ...state, user: action.payload };
    case Types.FORGOT_PASSWORD_FAILURE:
      return { ...state, errorMessage: action.payload, isSuccess: false };
    case Types.RESET_PASSWORD_SUCCESS:
      return { ...state, user: action.payload };
    case Types.RESET_PASSWORD_FAILURE:
      return { ...state, errorMessage: action.payload, isSuccess: false };
    case Types.UPDATE_ROLE_SUCCESS:
      return { ...state, roleChangedRequestSuccess: action.payload }
    case Types.UPDATE_ROLE_FAILURE:
      return { ...state, roleChangedRequestFailure: action.payload }
    case Types.REQUEST_ACTION_SUCCESS:
      return { ...state, requesActionSuccessData: action.payload.data }
    case Types.REQUEST_ACTION_FAILURE:
      return { ...state, requesActionFailure: action.payload }
    case Types.UPDATE_USER_STATUS_SUCCESS:
      return { ...state, allUsers: action.payload.users }
    case Types.UPDATE_USER_STATUS_FAILURE:
      return { ...state, allUsers: action.payload.message }
    case Types.UPDATE_JUMIA_CREDS_SUCCESS:
      return { ...state, successMessage: action.payload }
    case Types.UPDATE_JUMIA_CREDS_FAILURE:
      return { ...state, errorMessage: action.payload }
    default:
      return state;
  }
}
