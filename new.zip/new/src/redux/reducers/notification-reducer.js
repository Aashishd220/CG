import { Types } from "../constants/notification-types";
const initialState = {

    seenSingleNotification: {},
    seenAllNotifications: {},
};

export default function notificationReducer(state = initialState, action) {
    switch (action.type) {
        case Types.CLEAR_ALL_NOTIFICATIONS_SUCCESS:
            return {
                ...state, seenAllNotifications: {
                    status: 'success',
                    message: 'Succesfully clear all notifications'
                }
            };
        case Types.CLEAR_ALL_NOTIFICATIONS_FAILURE:
            return {
                ...state, seenAllNotifications: {
                    status: 'fail',
                    message: `Failed to clear all notifications`
                }
            };
        case Types.SEEN_NOTIFICATION_SUCCESS:
            return {
                ...state, seenSingleNotification: {
                    status: 'success',
                    message: 'Succesfully clear the notification'
                }
            };
        case Types.SEEN_NOTIFICATION_FAILURE:
            return {
                ...state, seenSingleNotification: {
                    status: 'fail',
                    message: `Failed to clear a notification`
                }
            }
        default:
            return state;
    }
}
