import { Types } from "../constants/product-types";

const initialState = {
  websiteProducts: [],
  totalPages: 0,
  favTotalPages: 0,
  isFavorite: false,
  favProductsList: [],
  allFavProductsList: [],
  saveFavoriteProductsResponse: {},
  searchedProducts: {},
  uniqueSearchedProduct: {}
};

export default function productReducer(state = initialState, action) {

  switch (action.type) {
    case Types.SAVE_WEBSITE_PRODCUTS:
      return { ...state, websiteProducts: action.payload };
    case Types.SAVE_TOTAL_PAGES:
      return { ...state, totalPages: action.payload };
    case Types.FAVORITE_SAVE_TOTAL_PAGES:
      return { ...state, favTotalPages: action.payload };
    case Types.GET_FAVORITE_PRODUCTS:
      return { ...state, favProductsList: action.payload }
    case Types.GET_ALLFAVORITE_PRODUCTS:
      return { ...state, allFavProductsList: action.payload }
    case Types.SAVE_FAVORITE_PRODUCTS:
      return { ...state, isFavorite: action.payload };
    case Types.SAVE_FAVORITE_PRODUCTS_SUCCESS:
      return {
        ...state, saveFavoriteProductsResponse: {
          status: 'success',
          message: 'Added favorite product.'
        }
      }
    case Types.SAVE_FAVORITE_PRODUCTS_FAIL:
      return {
        ...state, saveFavoriteProductsResponse: {
          status: 'fail',
          message: 'Failed to add favorite product.'
        }
      }
    case Types.SEARCHED_PRODUCTS:
      return {
        ...state, searchedProducts: action.payload
      }
    case Types.GET_UNIQUE_PRODUCT:
      return {
        ...state, uniqueSearchedProduct: action.payload
      }
    default:
      return state;
  }
}


