import { Types } from "../constants/external-api-types";
const initialState = {
    metricsData: {},
    ordersData: {},
    productsData: {},
    statsData: {},
    payoutData: {},
    bestWorstProductsData: {}
};

export default function externalApiReducer(state = initialState, action) {
    switch (action.type) {
        case Types.GET_METRICS_DATA_SUCCESS:
            return { ...state, metricsData: action.payload };
        case Types.GET_METRICS_DATA_FAILURE:
            return { ...state, metricsData: action.payload };
        case Types.GET_ORDERS_DATA_SUCCESS:
            return { ...state, ordersData: action.payload };
        case Types.GET_ORDERS_DATA_FAILURE:
            return { ...state, ordersData: action.payload };
        case Types.GET_PRODUCTS_DATA_SUCCESS:
            return { ...state, productsData: action.payload };
        case Types.GET_PRODUCTS_DATA_FAILURE:
            return { ...state, productsData: action.payload };
        case Types.GET_STATISTICS_DATA_SUCCESS:
            return { ...state, statsData: action.payload };
        case Types.GET_STATISTICS_DATA_FAILURE:
            return { ...state, statsData: action.payload };
        case Types.GET_PAYOUT_DATA_SUCCESS:
            return { ...state, payoutData: action.payload };
        case Types.GET_PAYOUT_DATA_FAILURE:
            return { ...state, payoutData: action.payload };
        case Types.GET_BEST_WORST_PRODUCTS_DATA_SUCCESS:
            return { ...state, bestWorstProductsData: action.payload };
        case Types.GET_BEST_WORST_PRODUCTS_DATA_FAILURE:
            return { ...state, bestWorstProductsData: action.payload };
        default:
            return state;
    }
}
