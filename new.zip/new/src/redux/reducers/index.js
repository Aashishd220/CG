import { combineReducers } from "redux";
import productReducer from "./product-reducer";
import userReducer from "./user-reducer";
import ecommerceReducer from './ecommerce-reducer'
import notificationReducer from "./notification-reducer";
import externalApiReducer from './external-api-reducer'
export default combineReducers({
     product: productReducer,
     user: userReducer,
     ecommerce: ecommerceReducer,
     notification: notificationReducer,
     apiData:externalApiReducer
});
