import { Types } from "../constants/user-types";
import API from "../api/user-api"
import User from "../../shared/services/user-service"

export function signIn(user) {
  
  return async function(dispatch, getState) {
    const userData = await  API.signIn(user);
    if(userData && userData.status){
      const user = userData.user;
      dispatch({ type: Types.LOG_IN, payload:user });
    }else{
        dispatch({ type: Types.SAVE_FAILURE, payload:userData.message });
    }
  };
}

export function signUp(user) {
  
  return async function(dispatch, getState) {
    const userData = await  API.signUp(user);
    if(userData && userData.status){
      const user = userData.user;
      dispatch({ type: Types.LOG_IN, payload:user });
    }else{
        dispatch({ type: Types.SAVE_FAILURE, payload:userData.message });
    }
  };
}

export function logOut() {
  return async function(dispatch, getState) {
      dispatch({ type: Types.LOG_OUT, payload:{} });
  };
}

export function forgotPassword(email) {
  return async function(dispatch, getState) {

    const password = await  API.forgotPassword(email);
    if(password && password.status){
     
      return dispatch({ type: Types.FORGOT_PASSWORD_SUCCESS, payload:password });
    }else{
        return dispatch({ type: Types.FORGOT_PASSWORD_FAILURE, payload:password });
    }
  };
}


export function resetPassword(oldPassword,newPassword,email) {
  return async function(dispatch, getState) {
    
    const password = await  API.resetPassword(oldPassword,newPassword,email);
    if(password && password.status){
     
      return dispatch({ type: Types.RESET_PASSWORD_SUCCESS, payload:password });
    }else{
        return dispatch({ type: Types.RESET_PASSWORD_FAILURE, payload:password });
    }
  };
}

export function updateRoleRequest(firstName,lastName,email,currentRole,requestedRole){
  return async function(dispatch,getState){
    const token = User.getToken()
    const role=await API.updateRoleRequest(firstName,lastName,email,currentRole,requestedRole,token)
    if(role && role.status){ 
      return dispatch({ type: Types.UPDATE_ROLE_SUCCESS, payload:role.updatedRole });
    }else{ 
        return dispatch({ type: Types.UPDATE_ROLE_FAILURE, payload:role.error });
    }
  }
}

export function updateUserRole(id,email,role,isAccept){
  return async function(dispatch,getState){
    const token=User.getToken()
    const updatedUser=await API.updateUserRole(id,email,role,isAccept,token);
    if(updatedUser && updatedUser.status){ 
      return dispatch({ type: Types.REQUEST_ACTION_SUCCESS, payload:updatedUser });
    }else{ 
        return dispatch({ type: Types.REQUEST_ACTION_FAILURE, payload:updatedUser.error });
    }
  }
}


export function updateUserStatus(id,active){
  return async function(dispatch,getState){
    const token=User.getToken()
    const allUsers=await API.updateUserStatus(id,active,token);
    if(allUsers && allUsers.status){ 
      return dispatch({ type: Types.UPDATE_USER_STATUS_SUCCESS, payload:allUsers });
    }else{ 
        return dispatch({ type: Types.UPDATE_USER_STATUS_FAILURE, payload:allUsers });
    }
  }
}

export function addJumiaCreds(jumiaId,apiKey){
  return async function(dispatch,getState){
    const token=User.getToken()
    const users=await API.addJumiaCreds(jumiaId,apiKey,token);
    if(users && users.status){
      return dispatch({type:Types.UPDATE_JUMIA_CREDS_SUCCESS,payload:users.message})
    }
    else{
      return dispatch({type:Types.UPDATE_JUMIA_CREDS_FAILURE,payload:users.message})
    }
  }
}