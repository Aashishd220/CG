import { Types } from "../constants/product-types";
import API from "../api/product-api"
import User from "../../shared/services/user-service"


export function getWebsiteProducts(website, defaultCategory, pageNumber, brand, term) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const responseProducts = await API.getWebsiteProducts(website, defaultCategory, pageNumber, token, brand, term);
    if (responseProducts && responseProducts.status) {
      const products = responseProducts.products.products
      const pages = responseProducts.products.total_pages

      dispatch({ type: Types.SAVE_WEBSITE_PRODCUTS, payload: products });
      dispatch({ type: Types.SAVE_TOTAL_PAGES, payload: pages });
    }
  };
}
export function saveProductFavorite(id, isFavorite, productCode,name,price,dealer,images) {
  return async function (dispatch, getState) {

    const state = getState();
    const token = User.getToken()
    const savedFavoriteProduct = await API.saveFavoriteProduct(id, isFavorite, token, productCode,name,price,dealer,images);

    if (savedFavoriteProduct.error) {
      return dispatch({ type: Types.SAVE_FAVORITE_PRODUCTS_FAIL, payload: savedFavoriteProduct.error });
    }
    else {
      return dispatch({ type: Types.SAVE_FAVORITE_PRODUCTS_SUCCESS, payload: savedFavoriteProduct });
    }

  };
}

export function getFavProducts(category, brands, term, pageNumber) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const listFavProducts = await API.getFavProducts(category, brands, term, token, pageNumber);

    if (listFavProducts) {
      const favProducts = listFavProducts.favProducts
      const pages = listFavProducts.pagenationDetails.total_pages
      const allFavProducts = listFavProducts.pagenationDetails.favProducts

      dispatch({ type: Types.GET_ALLFAVORITE_PRODUCTS, payload: allFavProducts });
      dispatch({ type: Types.GET_FAVORITE_PRODUCTS, payload: favProducts });
      dispatch({ type: Types.FAVORITE_SAVE_TOTAL_PAGES, payload: pages });
    }
  };
}


export function getSearchedProducts(term,website) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const searchedProducts = await API.getSearchedProducts(term, token,website);
    if (searchedProducts) {
      return dispatch({ type: Types.SEARCHED_PRODUCTS, payload: searchedProducts.searchedProducts });
    }
  };
}

export function getUniqueSearchedProduct(term,website) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const searchedProduct = await API.getUniqueProduct(term, token,website);
    if (searchedProduct) {
      return dispatch({ type: Types.GET_UNIQUE_PRODUCT, payload: searchedProduct.singleProduct });
    }
  };
}

