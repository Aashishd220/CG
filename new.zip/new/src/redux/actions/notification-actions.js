import { Types } from "../constants/notification-types"
import API from "../api/notification-api"
import User from "../../shared/services/user-service"


export function seenNotification(ID) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const notifications = await API.seenNotification(ID, token);
    if (notifications.error) {
      return dispatch({ type: Types.SEEN_NOTIFICATION_FAILURE, payload: notifications.error });
    }
    else {
      return dispatch({ type: Types.SEEN_NOTIFICATION_SUCCESS, payload: notifications });
    }
  };
}

export function seenAllNotifications(userId) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const notifications = await API.clearNotifications(userId, token);
    if (notifications.error) {
      return dispatch({ type: Types.CLEAR_ALL_NOTIFICATIONS_FAILURE, payload: notifications.error });
    }
    else {
      return dispatch({ type: Types.CLEAR_ALL_NOTIFICATIONS_SUCCESS, payload: notifications });
    }
  };
}
