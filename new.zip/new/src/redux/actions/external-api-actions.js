import User from "../../shared/services/user-service"
import API from "../api/external-api"
import { Types } from "../constants/external-api-types";


export function getMetricsDatafromExternalApi(action){
    return async function(dispatch,getState){
      const token=User.getToken()
      const data=await API.getMetricsDatafromExternalApi(action,token);
      if(data.SuccessResponse){
        return dispatch({type:Types.GET_METRICS_DATA_SUCCESS,payload:data})
      }
      else{
        return dispatch({type:Types.GET_METRICS_DATA_FAILURE,payload:data})
      }
    }
  }

  export function getOrdersDatafromExternalApi(action){
    return async function(dispatch,getState){
      const token=User.getToken()
      const data=await API.getOrdersDatafromExternalApi(action,token);
      if(data.SuccessResponse){
        return dispatch({type:Types.GET_ORDERS_DATA_SUCCESS,payload:data})
      }
      else{
        return dispatch({type:Types.GET_ORDERS_DATA_FAILURE,payload:data})
      }
    }
  }


  export function getProductsDatafromExternalApi(action){
    return async function(dispatch,getState){
      const token=User.getToken()
      const data=await API.getProductsDatafromExternalApi(action,token);
      if(data.SuccessResponse){
        return dispatch({type:Types.GET_PRODUCTS_DATA_SUCCESS,payload:data})
      }
      else{
        return dispatch({type:Types.GET_PRODUCTS_DATA_FAILURE,payload:data})
      }
    }
  }


  export function getStatisticsDatafromExternalApi(action){
    return async function(dispatch,getState){
      const token=User.getToken()
      const data=await API.getStatisticsDatafromExternalApi(action,token);
      if(data.SuccessResponse){
        return dispatch({type:Types.GET_STATISTICS_DATA_SUCCESS,payload:data})
      }
      else{
        return dispatch({type:Types.GET_STATISTICS_DATA_FAILURE,payload:data})
      }
    }
  }

  export function getPayoutStatusDataFromExternalApi(action){
    return async function(dispatch,getState){
      const token=User.getToken()
      const data=await API.getPayoutStatusDataFromExternalApi(action,token);
      if(data.SuccessResponse){
        return dispatch({type:Types.GET_PAYOUT_DATA_SUCCESS,payload:data})
      }
      else{
        return dispatch({type:Types.GET_PAYOUT_DATA_FAILURE,payload:data})
      }
    }
  }
  

  export function getBestWorstSellingProducts(action,fromDate,endDate){
    
    return async function(dispatch,getState){
      const token=User.getToken()
      const data=await API.getBestWorstSellingProducts(action,fromDate,endDate,token);
      if(data.data){
        return dispatch({type:Types.GET_BEST_WORST_PRODUCTS_DATA_SUCCESS,payload:data})
      }
      else{
        return dispatch({type:Types.GET_BEST_WORST_PRODUCTS_DATA_FAILURE,payload:data})
      }
    }
  }

 
 
 

  