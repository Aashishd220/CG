import { Types } from "../constants/ecommerce-types";
import API from "../api/ecommerce-api"
import User from "../../shared/services/user-service"

export function saveEcommerceProductsData(data) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const responseProducts = await API.saveEcommerceProductsData(data, token);

    if (responseProducts.error) {

      return dispatch({ type: Types.SAVE_ECOMMERCE_PRODUCTS_DATA_FAIL, payload: responseProducts.error });
    }
    else {
      return dispatch({ type: Types.SAVE_ECOMMERCE_PRODUCTS_DATA_SUCCESS, payload: responseProducts });
    }
  };
}


export function saveEcommerceComboProductsData(data) {
  return async function (dispatch, getState) {
    const state = getState();
    const token = User.getToken()
    const responseProducts = await API.saveEcommerceComboProductsData(data, token);

    if (responseProducts.error) {
      return dispatch({ type: Types.SAVE_ECOMMERCE_COMBO_PRODUCTS_DATA_FAIL, payload: responseProducts.error });
    }
    else {
      return dispatch({ type: Types.SAVE_ECOMMERCE_COMBO_PRODUCTS_DATA_SUCCESS, payload: responseProducts });
    }
  };
}

export function deleteEcommerceSingleProduct(id) {
  return async function (dispatch, getState) {
    const token = User.getToken();
    const deletedProduct = await API.deleteEcommerceSingleProduct(id, token);

    if (deletedProduct.error) {
      return dispatch({ type: Types.DELETE_ECOMMERCE_SINGLE_PRODUCT_FAIL, payload: deletedProduct.error });
    }
    else {
      return dispatch({ type: Types.DELETE_ECOMMERCE_SINGLE_PRODUCT_SUCCESS, payload: deletedProduct.data });
    }
  }
}


export function deleteEcommerceComboProduct(id) {
  return async function (dispatch, getState) {
    const token = User.getToken();
    const deletedProduct = await API.deleteEcommerceComboProduct(id, token);

    if (deletedProduct.error) {
      return dispatch({ type: Types.DELETE_ECOMMERCE_COMBO_PRODUCT_FAIL, payload: deletedProduct.error });
    }
    else {
      return dispatch({ type: Types.DELETE_ECOMMERCE_COMBO_PRODUCT_SUCCESS, payload: deletedProduct.data });
    }
  }
}


export function updateEcommerceSingleProduct(values) {
  return async function (dispatch, getState) {
    const token = User.getToken();
    const updatedProduct = await API.updateEcommerceSingleProduct(values, token);

    if (updatedProduct.error) {
      return dispatch({ type: Types.UPDATE_ECOMMERCE_SINGLE_PRODUCT_FAIL, payload: updatedProduct.error });
    }
    else {
      return dispatch({ type: Types.UPDATE_ECOMMERCE_SINGLE_PRODUCT_SUCCESS, payload: updatedProduct.data });
    }
  }
}

export function updateEcommerceComboProduct(values) {
  return async function (dispatch, getState) {
    const token = User.getToken();
    const updatedProduct = await API.updateEcommerceComboProduct(values, token);

    if (updatedProduct.error) {
      return dispatch({ type: Types.UPDATE_ECOMMERCE_COMBO_PRODUCT_FAIL, payload: updatedProduct.error });
    }
    else {
      return dispatch({ type: Types.UPDATE_ECOMMERCE_COMBO_PRODUCT_SUCCESS, payload: updatedProduct.data });
    }
  }
}


export function saveReport(values) {
  return async function (dispatch, getState) {
    const token = User.getToken();
    const reportMessage = await API.saveReport(values, token);
    if(reportMessage.error){
      return dispatch({type:Types.FILE_CREATED_FAILURE,payload:reportMessage.error})
    }
    else{
      return dispatch({type:Types.FILE_CREATED_SUCCESS,payload:reportMessage.data})
    }
  }
}


