import React from 'react'
import { getUserData,getDatafromExternalApi,getProductsDatafromExternalApi,getStatisticsfromExternalApi,getBestWorstProductsfromExternalApi } from "../../shared/services/fetch-urls"
import PageHead from '../../components/page-head/page-head';
import Router from 'next/router'
import axios from 'axios';
import ExternalAPIData from '../../components/external-api/externalApi';
import Link from 'next/link'

const ExternalApi = ({data,products,stats,bestWorstProducts}) => {    
  return (
    <>
      <PageHead title="File-Upload" />     
      {(data && data.ErrorResponse)||(products && products.ErrorResponse)||(stats && stats.ErrorResponse) ? <div className="jumia-acc"><h1>You haven't setup your Jumia account.  </h1><p><Link href="/jumia-creds">Setup Jumia Account</Link>  </p>  </div>: <ExternalAPIData bestWorstProductTab={bestWorstProducts.data} metricsTab={data} productsTab={products} statsTab={stats}/>}
       
    </>
  );
};

export const getServerSideProps = async (ctx) => {
  const { req, res, query } = ctx
  try {
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {
        const apiData = await fetch(getDatafromExternalApi(), { headers: headers });
        const data = await apiData.json();
        const userData = response.data.user

        // const ordersData = await fetch(getOrdersDatafromExternalApi(), { headers: headers });
        // const orders=await ordersData.json();

        const productsData = await fetch(getProductsDatafromExternalApi(), { headers: headers });  
        const products=await productsData.json();

        const statsData = await fetch(getStatisticsfromExternalApi(), { headers: headers });  
        const stats=await statsData.json();

        const bestWorstProductData = await fetch(getBestWorstProductsfromExternalApi(), { headers: headers });  
        const bestWorstProducts=await bestWorstProductData.json();
        return {
          props: {
            userData: userData,
            data:data,
            // orders:orders,
            products:products,
            stats:stats,
            bestWorstProducts:bestWorstProducts
            
          },

        }
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    }

  } catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        products: {}
      },
    }
  }

}

export default ExternalApi;
