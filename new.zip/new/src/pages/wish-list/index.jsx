import React from 'react'
import { GetFavoriteProducts, getUserData } from "../../shared/services/fetch-urls"
import Router from 'next/router'
import axios from 'axios';
import PageHead from '../../components/page-head/page-head';
import WishListProducts from '../../components/wish-list/index.jsx';
const fetch = require("node-fetch");

const WishList = ({ favProducts }) => {

    return (
        <>
            <PageHead title="Wishlist" />
            <WishListProducts favProducts={favProducts} />
        </>
    )
}

export const getServerSideProps = async (ctx) => {
    const { req, res, query } = ctx
    try {
        let headers = {};
        let token = ""
        if (ctx.req) {
            let name = 'token=';
            let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
            let ca = decodedCookie.split(';');
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    if (c.substring(name.length, c.length) !== "") {
                        token = c.substring(name.length, c.length);
                    } else {
                        token = "";
                    }

                }
            }
            headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
            const response = await axios({
                method: 'get',
                url: getUserData(),
                headers: headers
            })
            if (response && response.status === 200) {
                const favProducts = await fetch(GetFavoriteProducts(), { headers: headers });
                const data = await favProducts.json();
                const userData = response.data.user
                return {
                    props: {
                        favProducts: data,
                        userData: userData
                    }
                }
            } else {
                if (res) {
                    res.writeHead(302, {
                        Location: '/login'
                    });

                    res.end();
                } else {
                    Router.push('/login');
                }
            }
        }

    } catch (err) {
        if (res) {
            res.writeHead(302, {
                Location: '/login'
            });

            res.end();
        } else {
            Router.push('/login');
        }
        return {
            props: {
                products: {}
            },
        }
    }

}
export default WishList
