import PageHead from "../../components/page-head/page-head.jsx";
import PasswordReset from "../../components/password-reset/index.jsx";

const ResetPassword = ({ email }) => {
    return (
        <>
            <PageHead title="Forgot Password" />
            <PasswordReset email={email} />
        </>
    );
};

export const getServerSideProps = async (ctx) => {
    const { req, res, query } = ctx
    return {
        props: {
            email: ctx.query.email
        }
    }
}

export default ResetPassword;
