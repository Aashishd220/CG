import { wrapper } from "../redux/store";
import Layout from "../components/layout/layout.jsx";
import Router, { useRouter } from "next/router";
import { useState } from "react";
import "../index.scss"
const WrappedApp = ({ Component, pageProps }) => {
  const router = useRouter();
  const [loader, setLoader] = useState(false)
  Router.events.on('routeChangeStart', () => setLoader(true));
  Router.events.on('routeChangeComplete', () => setLoader(false));
  Router.events.on('routeChangeError', () => setLoader(false));

  return (
    <Layout router={router} loader={loader}>
      <Component {...pageProps} />
    </Layout>
  );
};

export default wrapper.withRedux(WrappedApp);
