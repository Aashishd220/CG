import PageHead from "../../components/page-head/page-head.jsx";
import { getUniqueEcomProductsData, getUniqueEcomComboProductsData, GetEcomComboProducts, GetEcomProducts, getUserData } from "../../shared/services/fetch-urls"
import Router from 'next/router'
import axios from 'axios';
import ReportsComparison from "../../components/reports-compare/index.jsx";

const fetch = require("node-fetch");
const Reports = ({ ecomProducts, ecomComboProduct, uniqueSingleProducts, uniqueComboProducts }) => {
  return (
    <>
      <PageHead title="Reports" />
      <ReportsComparison uniqueSingleProducts={uniqueSingleProducts} uniqueComboProducts={uniqueComboProducts} ecomComboProduct={ecomComboProduct} ecomProducts={ecomProducts} />
    </>
  );
};

export const getServerSideProps = async (ctx) => {
  const { req, res, query } = ctx
  try {
    const website = query.website;
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {

        let uniqueSingleProducts = await fetch(getUniqueEcomProductsData(), { headers: headers });
        let uniqueProductsDataJson = await uniqueSingleProducts.json();

        let uniqueComboProducts = await fetch(getUniqueEcomComboProductsData(), { headers: headers });
        let uniqueComboProductsDataJson = await uniqueComboProducts.json();

        const ecomComboProducts = await fetch(GetEcomComboProducts(), { headers: headers });
        const comboData = await ecomComboProducts.json();

        const ecomProducts = await fetch(GetEcomProducts(), { headers: headers });
        const data = await ecomProducts.json();
        const userData = response.data.user
        return {
          props: {
            ecomProducts: data.data,
            ecomComboProduct: comboData.data,
            userData: userData,
            uniqueSingleProducts: uniqueProductsDataJson,
            uniqueComboProducts: uniqueComboProductsDataJson,
          },

        }
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    }

  } catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        products: {}
      },
    }
  }

}

export default Reports;
