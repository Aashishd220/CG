import React from 'react'
import { getUserData, GetEcomProducts, GetEcomComboProducts } from "../../shared/services/fetch-urls"
import PageHead from '../../components/page-head/page-head';
import Router from 'next/router'
import axios from 'axios';
import EcomProductUpload from '../../components/ecom-products-upload';

const EcomProducts = ({ ecomProducts }) => {
  return (
    <>
      <PageHead title="Ecom Products-Upload" />
      <EcomProductUpload ecomProducts={ecomProducts} />
    </>
  );
};

export const getServerSideProps = async (ctx) => {
  const { req, res, query } = ctx
  try {
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {
        const userData = response.data.user;
        const ecomProducts = await fetch(GetEcomProducts(), { headers: headers });
        const data = await ecomProducts.json();
        return {
          props: {
            userData: userData,
            ecomProducts: data.data,
          },

        }
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    }

  } catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        products: {}
      },
    }
  }

}

export default EcomProducts;
