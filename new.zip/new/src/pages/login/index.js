import LoginPage from "../../components/login/login";
import PageHead from "../../components/page-head/page-head.jsx";
const Login = ({ }) => {
  return (
    <>
      <PageHead title="Login" />
      <LoginPage />
    </>
  );
};

export default Login;
