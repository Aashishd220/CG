import HomePage from "../components/home/home.jsx";
import PageHead from "../components/page-head/page-head.jsx";
import { GetAllProductCount, getUserData } from "../shared/services/fetch-urls"
const fetch = require("node-fetch");
import Router from 'next/router'
import axios from 'axios';
const Home = ({ products }) => {
  return (
    <>
      <PageHead title="Home" />
      <HomePage products={products} />
    </>
  );
};
export const getServerSideProps = async (ctx) => {
  const { req, res } = ctx
  try {
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {
        const resProduct = await fetch(GetAllProductCount(), { headers: headers });
        const data = await resProduct.json()
        const userData = response.data.user
        return {
          props: {
            products: data,
            userData: userData
          },

        }
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    } else {
      return {
        props: {
          products: {}
        },
      }
    }
  }
  catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        products: {}
      },
    }
  }

}
export default Home;

