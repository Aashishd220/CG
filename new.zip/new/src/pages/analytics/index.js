import React, { useState } from 'react'
import { getUniqueEcomProductsData, getUniqueEcomComboProductsData, getUniqueEcomSellerData, getUserData } from "../../shared/services/fetch-urls"
import PageHead from '../../components/page-head/page-head';
const fetch = require("node-fetch");
import Router from 'next/router'
import axios from 'axios';
import AnalyticsComponent from '../../components/analytics/analytics';

const Analytics = (props) => {
  return (
    <>
      <PageHead title="Analytics" />
      <AnalyticsComponent {...props} />
    </>
  );
};

export const getServerSideProps = async (ctx) => {
  const { req, res, query } = ctx
  try {
    // const website = query.website;
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {
        let userProductsData = await fetch(getUniqueEcomProductsData(), { headers: headers });
        let userProductsDataJson = await userProductsData.json();

        let comboProductsData = await fetch(getUniqueEcomComboProductsData(), { headers: headers });
        let comboProductsDataJson = await comboProductsData.json();
        // let userSellersData = await fetch(getUniqueEcomSellerData(), { headers: headers });
        // let userSellersDataJson = await userSellersData.json();

        const userData = response.data.user;

        return {
          props: {
            userProductsData: userProductsDataJson,
            comboProductsData: comboProductsDataJson,
            userData: userData
          },

        }
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    }

  } catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        products: {}
      },
    }
  }

}

export default Analytics;
