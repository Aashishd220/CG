import SignUpPage from "../../components/sign-up/sign-up";
import PageHead from "../../components/page-head/page-head.jsx";
import { getAllRoles } from "../../shared/services/fetch-urls";
const fetch = require("node-fetch");
const SignUp = ({ roles }) => {
  return (
    <>
      <PageHead title="Sign Up" />
      <SignUpPage roles={roles} />
    </>
  );
};

export const getServerSideProps = async (ctx) => {
  const roles = await fetch(getAllRoles());
  let data = await roles.json();
  if (data) {
    data = data.roles
  }
  return {
    props: {
      roles: data
    },
  }
}

export default SignUp;
