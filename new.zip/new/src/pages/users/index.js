import UsersPage from "../../components/users/users.jsx";
import PageHead from "../../components/page-head/page-head.jsx";
import { GetAllUsers, getUserData } from "../../shared/services/fetch-urls"
import Router from 'next/router'
import axios from 'axios';
const fetch = require("node-fetch");
const Users = ({ users }) => {
  return (
    <>
      <PageHead title="Users" />
      <UsersPage users={users} />
    </>
  );
};
export const getServerSideProps = async (ctx) => {
  const { req, res } = ctx
  try {
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {
        const resProduct = await fetch(GetAllUsers(), { headers: headers });
        const data = await resProduct.json()
        const userData = response.data.user
        return {
          props: {
            users: data,
            userData: userData
          },

        }
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    } else {
      return {
        props: {
          users: {}
        },
      }
    }
  }
  catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        users: {}
      },
    }
  }

}
export default Users;
