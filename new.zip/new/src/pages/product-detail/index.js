import ProductDetails from "../../components/product-details";
import PageHead from "../../components/page-head/page-head.jsx";
import { getProductDetail, getUserData } from "../../shared/services/fetch-urls"
import Router from 'next/router'
import axios from 'axios';
const fetch = require("node-fetch");
const ProductInfo = ({ productData }) => {

  return (
    <>
      <PageHead title="Product " />
      <ProductDetails product={productData} />
    </>
  );
};

export const getServerSideProps = async (ctx) => {
  const { req, res, query } = ctx
  try {
    const productCode = query.code;
    let headers = {};
    let token = ""
    if (ctx.req) {
      let name = 'token=';
      let decodedCookie = decodeURIComponent(ctx.req.headers.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          if (c.substring(name.length, c.length) !== "") {
            token = c.substring(name.length, c.length);
          } else {
            token = "";
          }

        }
      }
      headers['authorization'] = token !== "" ? 'Bearer ' + token : undefined;
      const response = await axios({
        method: 'get',
        url: getUserData(),
        headers: headers
      })
      if (response && response.status === 200) {
        const resProductDetail = await fetch(getProductDetail(productCode), { headers: headers });
        const data = await resProductDetail.json();
        const userData = response.data.user
        return {
          props: {
            productData: data,
            userData: userData
          },
        };
      } else {
        if (res) {
          res.writeHead(302, {
            Location: '/login'
          });

          res.end();
        } else {
          Router.push('/login');
        }
      }
    }

  } catch (err) {
    if (res) {
      res.writeHead(302, {
        Location: '/login'
      });

      res.end();
    } else {
      Router.push('/login');
    }
    return {
      props: {
        products: {}
      },
    }
  }

}

export default ProductInfo;
