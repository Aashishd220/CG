import PasswordForgot from "../../components/forgot-password";
import PageHead from "../../components/page-head/page-head.jsx";

const ForgotPassword = ({ }) => {
  return (
    <>
      <PageHead title="Forgot Password" />
      <PasswordForgot />
    </>
  );
};

export default ForgotPassword;
