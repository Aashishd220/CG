import React , {Component} from 'react';

export default class Footer extends Component {
    render() {
        return (
            <div>
                <h2>Footer</h2>
            </div>
        );
    }
}

