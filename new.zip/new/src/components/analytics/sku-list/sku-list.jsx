import React from "react";
import { Row } from "react-bootstrap";
import Link from "next/link";

const skuList = (props) => {

    return (
        <>
                <Row className="sku-list-page">
                    {props.userProductsData.map((product, index) => {
                        return (

                            <div className="col-xl-3 col-sm-6 col-md-6 mt-4">
                                <div className="card">
                                        <Link href={"/ecom-product?sku=" + product.product_sku + "&combo=" + false}>
                                            <div className="product-box">
                                                <div style={{ paddingTop: "20px" }}>
                                                    <h2>{product.product_sku}</h2>
                                                    {product.item_name && (
                                                        <p>{product.item_name}</p>
                                                    )}
                                                </div>
                                            </div>
                                        </ Link>
                                </div>
                            </div>

                        )
                    })}
                </Row>

        </>
    )
}


export default skuList;