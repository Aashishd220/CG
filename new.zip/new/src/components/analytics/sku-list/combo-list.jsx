import React from "react";
import { Row } from "react-bootstrap";
import Link from "next/link";

const ComboList = (props) => {
    return (
        <>
                <Row className="sku-list-page">
                    {props.comboProductsData.map((product, index) => {
                        return (

                            <div className="col-xl-3 col-sm-6 col-md-6 mt-4">
                                <div className="card">
                                        <Link href={`/ecom-product?sku=${product.sku}&combo=true`}>
                                            <div className="product-box">
                                                <div style={{ paddingTop: "20px" }}>
                                                    <h2>{product.sku}</h2>
                                                    {product.name && (
                                                        <p>{product.name}</p>
                                                    )}
                                                </div>
                                            </div>
                                        </ Link>
                                </div>
                            </div>

                        )
                    })}
                </Row>
        </>
    )
}


export default ComboList;