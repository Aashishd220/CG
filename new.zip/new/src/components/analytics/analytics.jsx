import React from "react";
import ComboList from "./sku-list/combo-list";
import ProductBySkuList from "./sku-list/sku-list";

const AnalyticsComponent = (props) => {

    return (
      <>
        <div className="analytics-page">
          <div className="page-body">
            <div className="container-fluid">
              <ul className="nav nav-tabs analytics-tab" role="tablist">
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    data-toggle="tab"
                    href="#tabs-1"
                    role="tab"
                  >
                    Single Products
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="tab"
                    href="#tabs-2"
                    role="tab"
                  >
                    Combo Products
                  </a>
                </li>
              </ul>
              <div className="tab-content">
                <div className="tab-pane active" id="tabs-1" role="tabpanel">
                  <ProductBySkuList
                    userProductsData={props.userProductsData.data}
                  />
                </div>
                <div className="tab-pane" id="tabs-2" role="tabpanel">
                  <ComboList comboProductsData={props.comboProductsData.data} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
}


export default AnalyticsComponent;
