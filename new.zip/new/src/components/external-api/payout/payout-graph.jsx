import React from 'react'
import dynamic from 'next/dynamic'
import { 
  Col, 
  Row,
  Card,
  CardBody
} from 'reactstrap';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })
class PayOutGraph extends React.Component{
    constructor(props) {
        super(props);
        this.state = {}
      }
    
      static getDerivedStateFromProps(props, state) {
        return {
        series: [{
          name: 'Item Revenue',
          type: 'bar',
          data: props.itemRevenue,
        //   product:props.product,
        //   platform:props.platform
        }, {
          name: 'Payout',
          type: 'bar',
          data: props.payOut,
        //   product:props.product,
        //   platform:props.platform
        }],
        options: {   
          chart: {
            height: 350,
            type: 'bar',
            zoom: {
              enabled: false
            }
          },
          plotOptions: {
            bar: {
              horizontal: false,
              startingShape: 'flat',
              endingShape: 'flat',
              columnWidth: props.itemRevenue.length>5?'60%':props.itemRevenue.length<=2?'20%':'60%',
    
              barHeight: '70%',
              distributed: false,
              rangeBarOverlap: true,
              rangeBarGroupRows: false,
              dataLabels: {
                position: 'center',  
                orientation:'vertical'          
              },
            
            }
          },
          dataLabels: {
            enabled: false
          },
          
          title: {
            text: '',
            align: 'center'
          },
          grid: {
            row: {
              colors: ['#f3f3f3', 'transparent'], 
              opacity: 0.5
            },
          },
          xaxis: {
            categories: props.date,
          },
          yaxis: [
            {
              title: {
                text: 'Item Revenue',
              },
            },
            {
              opposite: true,
              title: {
                text: 'Payout',
              },
            },
          ],
          fill: {
            type: 'gradient',
            colors: ['#6a82fb', '#00E38E'],
            gradient: {
              shade: 'dark',
              type: "horizontal",
              shadeIntensity: 0.5,
              gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
              inverseColors: true,
              opacityFrom: 1,
              opacityTo: 1,
              stops: [0, 50, 100],
              colorStops: []
            }
          },
          dataLabels: {
            style: {
              colors: ['#fff', '#fff']
            }
          },
          tooltip: {
            enabled: true, 
                     
            // y: {
            //   formatter: function(value, opts) {
            //     return (
                 
            //       'Name:  ' +
            //       opts.w.config.series[opts.seriesIndex].product[opts.dataPointIndex]+
            //       ', Platform:  ' +
            //       opts.w.config.series[opts.seriesIndex].platform[opts.dataPointIndex]+ 
            //       ', Selling Price: '+
            //       opts.series[opts.seriesIndex][opts.dataPointIndex] 
                  
            //     )
            //   }
            // }
            
          }
        }
        }
      }
      render() {
        return (
          <Row className="pt-3">
          <Col xl={12} lg={12} md={12} sm={12} xs={12} className="mb-3 ">
          <Card className="flex-row ">
         <CardBody>
        <div className="graph-maindiv" >
              <h1>Transaction Graph</h1>
            { this.state && <ReactApexChart options={this.state.options} series={this.state.series} type="bar" width={700} height={350} />}
          </div>
          </CardBody>
          </Card>
        </Col>
         
        </Row>
         
        )
      }
    }
export default PayOutGraph