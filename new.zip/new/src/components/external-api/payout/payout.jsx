import React from 'react'
import Dropdown from '../../../shared/component/Dropdown';
import PayOutGraph from './payout-graph';

class PayoutData extends React.Component{
    constructor(props){     
        super(props);
        this.state = {
             date: [],
            payOut:[],
            itemRevenue:[],
            invalidDateMsg:'',
        }
     }

     componentDidMount(){
         
        let d = new Date();
        let month = d.getMonth();
        month += 1;
        if (month < 10) {
          month = '0' + month
        }
        let year = d.getFullYear();
        let strDate = year.toString().concat("-").concat(month)

        this.setPriceAndDate(strDate);  
    }

  
    setPriceAndDate = (strDate) => {
        
        let revenueArray = [];
        let payOutArray = [];
        let dateArray = [];
        if(this.props.payOut.length>0){
            for(var i=0;i<this.props.payOut.length;i++){
                if(this.props.payOutDate[i].includes(strDate)){
                  dateArray=[...dateArray,this.props.payOutDate[i]]
                  revenueArray=[...revenueArray,this.props.itemRevenue[i]]
                  payOutArray=[...payOutArray,this.props.payOut[i]]
                }
           this.setState({ payOut: payOutArray,date: dateArray,itemRevenue:revenueArray })
        }
        }
      }

    getMonthAndYear = (month, year) => {
        let d = new Date();
        let currentMonth = d.getMonth();
        currentMonth += 1;
        let currentYear = d.getFullYear();
        if(month>currentMonth && year==currentYear){
          this.setState({invalidDateMsg:'*Selected Date cannot be greater than than the current date.'})
        }
        else{
          this.setState({invalidDateMsg:''})
        }
        let strdate = year.toString().concat("-").concat(month);
        this.setPriceAndDate(strdate);

      }


    render(){
        return (
            <>
             <Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />
             {this.state.invalidDateMsg &&  <div className="error-msg"><h3>{this.state.invalidDateMsg}</h3></div>}
            { this.state.payOut.length>0  ? <PayOutGraph itemRevenue={this.state.itemRevenue}  payOut={this.state.payOut} date={this.state.date}  /> :!this.state.invalidDateMsg &&  <h1>No data for the selected month and year.</h1>}       
            </>
        )
    }
    
    
}

export default PayoutData