import React from 'react'
import dynamic from 'next/dynamic'
const DataTable = dynamic(() => import('react-data-table-component'), { ssr: false })
const DataTableExtensions = dynamic(() => import('react-data-table-component-extensions'), { ssr: false })

const Orders = (props) => {
    
    const data = props.data
    const columns = [
        {
            name: 'Order Number',
            selector: 'OrderNumber',
            sortable: true,
        },
        {
            name: 'Items Count',
            selector: 'ItemsCount',
            sortable: true,
        },
        {
            name: 'CreatedAt',
            cell: row => <div data-tag="allowRowEvents">{row.CreatedAt.substring(0,10)}</div>,
            sortable: true,

        },
        {
            name: 'UpdatedAt',
            cell: row => <div data-tag="allowRowEvents">{row.UpdatedAt.substring(0,10)}</div>,

            sortable: true,

        },
        {
            name: 'Payment Method',
            selector: 'PaymentMethod',
        },
        {
            name: 'Price',
            selector: 'Price',
            sortable: true,
        },

        {
            name: 'Delivery Status',
            selector: 'Statuses.Status',
        },
    ];
    const tableData = {
        columns,
        data,
    };
    
    return (
        <div className="user-table">
            <h1>Orders Report</h1>

            <DataTableExtensions
                {...tableData}
            >
                <DataTable
                    columns={columns}
                    data={data}
                    defaultSortField="id"
                    pagination
                />
            </DataTableExtensions>
        </div>
    )



}

export default Orders