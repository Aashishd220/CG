import React from 'react'
import Dropdown from '../../../shared/component/Dropdown';
import OrdersGraph from './ordersGraph';

class GraphData extends React.Component {

  constructor(props) {
    
    super(props)
    this.state = { count: [], date: [], invalidDateMsg: '', monthCount: [] }
  }
  componentDidMount() {
    let d = new Date();
    let month = d.getMonth();
    month += 1;
    if (month < 10) {
      month = '0' + month
    }
    let year = d.getFullYear();
    let strDate = year.toString().concat("-").concat(month)
    this.setPriceAndDate(strDate);
  }

  setPriceAndDate = (strDate) => {
    let countArray = [];
    let dateArray = [];
    for (var i = 0; i < this.props.count.length; i++) {
      if (this.props.date[i].includes(strDate)) {
        dateArray = [...dateArray, this.props.date[i]]
        countArray = [...countArray, this.props.count[i]]
      }
    }
    this.setState({ count: countArray })
    this.setState({ date: dateArray })
  }


getMonthAndYear = (month, year) => {
  let d = new Date();
  let currentMonth = d.getMonth();
  currentMonth += 1;
  let currentYear = d.getFullYear();
  if (month > currentMonth && year == currentYear) {
    this.setState({ invalidDateMsg: '*Selected Date cannot be greater than than the current date.' })
  }
  else {
    this.setState({ invalidDateMsg: '' })
  }
  let strdate = year.toString().concat("-").concat(month);
  this.setPriceAndDate(strdate);
}



render() {

  return (
    <>
    
      {!this.props.dashboard &&<Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />}
      {this.state.invalidDateMsg && <div className="error-msg"><h3>{this.state.invalidDateMsg}</h3></div>}

      {!this.props.dashboard && (this.state.count.length > 0 ? <OrdersGraph count={this.state.count} date={this.state.date} /> : !this.state.invalidDateMsg && <h1>No data for the selected month and year.</h1>)}

      {/* {this.props.dashboard && <PieChart status={Object.keys(this.props.orderStatus)} values={Object.values(this.props.orderStatus)} />} */}
    </>
  )
}
}

export default GraphData

