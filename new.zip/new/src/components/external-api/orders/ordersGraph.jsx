


import React from 'react'
import dynamic from 'next/dynamic'
import { 
  Col, 
  Row,
  Card,
  CardBody
} from 'reactstrap';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class OrdersGraph extends React.Component {
  
  static getDerivedStateFromProps(props, state) {
    return {
      series: [{
        name: 'Count',
        data: props.count ? props.count:[]
      }],
      options: {
        chart: {
          height: 350,
          type: 'bar',
        },
        plotOptions: {
          bar: {
            horizontal: false,
            startingShape: 'flat',
            endingShape: 'flat',
            columnWidth: props.count.length>5?'70%':props.count.length<=2?'10%':'40%',
            barHeight: '70%',
            distributed: false,
            rangeBarOverlap: true,
            rangeBarGroupRows: false,
            dataLabels: {
              position: 'top',
            },
          }
        },
        dataLabels: {
          enabled: true,
          formatter: function (val) {
            return val;
          },
          offsetY: -20,
          style: {
            fontSize: '12px',
            colors: ["#304758"]
          }
        },
        xaxis: {
          categories:   props.date ?props.date:[],
          position: 'bottom',
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          },
          crosshairs: {
            fill: {
              type: 'gradient',
              gradient: {
                colorFrom: '#D8E3F0',
                colorTo: '#BED1E6',
                stops: [0, 100],
                opacityFrom: 0.4,
                opacityTo: 0.5,
              }
            }
          },
          tooltip: {
            enabled: true,
          }
        },
        yaxis: {
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false,
          },
          labels: {
            show: false,
            formatter: function (val) {
              return val;
            }
          }
        },
        grid: {
          row: {
            colors: ['#f3f3f3', 'transparent'], 
            opacity: 0.5
          },
        },
        yaxis: [
          {
            title: {
              text: 'Count',
            },
          },
         
        ],
        fill: {
          type: 'gradient',
          colors: ['#6a82fb', '#6a82fb', '#6a82fb'],
          gradient: {
            shade: 'dark',
            type: "horizontal",
            shadeIntensity: 0.5,
            gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
            inverseColors: true,
            opacityFrom: 1,
            opacityTo: 1,
            stops: [0, 50, 100],
            colorStops: []
          }
        },
       dataLabels: {
        style: {
          colors: ['#fff', '#E91E63', '#9C27B0']
        }
      },
        title: {
          text: 'Total Order Count ' ,
          floating: true,
          align: 'center',
          style: {
            color: '#444',
          }
        }
      },
    }
  }

  render() {
    return (

    <Row className="pt-3">
      <Col xl={12} lg={12} md={12} sm={12} xs={12} className="mb-3 ">
      <Card className="flex-row ">
     <CardBody>
    <h1>Products Status</h1> 
    <div className="graph-maindiv">
          {this.state && <ReactApexChart className="ml-4" options={this.state.options} series={this.state.series} type="bar"  height={350} width={this.props.date.length>5?700:300} />}

      </div>
       </CardBody>
      </Card>
    </Col>
     
    </Row>

    )
  }
}
export default OrdersGraph

