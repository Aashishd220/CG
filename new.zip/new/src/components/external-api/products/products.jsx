import React from 'react'
import dynamic from 'next/dynamic'

const DataTable = dynamic(() => import('react-data-table-component'), { ssr: false })
const DataTableExtensions = dynamic(() => import('react-data-table-component-extensions'), { ssr: false })
import Loader from '../../loader'
const Products=({data,loading})=>{
    
    const ExpandableComponent = ({ data }) => <img src={data.Images.Image} />;

    const columns = [
        // {
        //     name:'Product',
        //     // selector:'SaleStartDate',
        //     cell: row => <div style={{height:'80px', width:'80px',objectFit:'contain'}}><img src={row.Images.Image} /></div>,
  
        // },
      
        {
            name: 'Name',
            selector: 'Name',
            // sortable: true,
        },
        {
            name: 'Shop Sku',
            selector: 'ShopSku',
          
        },
       
       
        {
            name: 'Price',
            selector: 'Price',
            // sortable: true,
              
        },
        {
            name: 'Sale Price',
            selector: 'SalePrice',
            // sortable: true,
            
        },
       
        {
            name: 'Available',
            selector: 'Available',
            // sortable: true,
        },
    ];
    const tableData = {
        columns,
        data,
    };

  
    
    return  (
        <div className="user-table">
            <h1>Products Report</h1>

            <DataTableExtensions 
  {...tableData}
>
                <DataTable 
                    className="hello helo"
                    columns={columns}
                    data={data}
                    defaultSortField="id"
                    pagination
                    expandableRows
                    expandableRowsComponent={<ExpandableComponent />}
                />
            </DataTableExtensions>
        </div>
    )
}

export default Products