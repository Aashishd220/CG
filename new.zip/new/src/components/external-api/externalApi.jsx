import React from 'react'
import Metrics from './metrics-data/metrics'
import Orders from './orders/orders'
import Products from './products/products'
import Statistics from './statistics/statistics'
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";
import * as extenalApiActions from "../../redux/actions/external-api-actions";

import Loader from '../loader'
import {
    Col,
    Row,
    Card,
    CardBody,
} from 'reactstrap';
import OrdersGraph from './orders/ordersGraph'
import GraphData from './orders/graph-data'
import PayoutData from './payout/payout'
import StatsData from './statistics/stats-data'
import Link from 'next/link'
import BestWorstProductsData from './best-worst-products/products-data'

class ExternalAPIData extends React.Component {

    constructor(props){
        super(props)
        

        this.state = {
            metricsData: [],
            metricsDataFailure: '',
            ordersData: [],
            ordersDataFailure: '',
            bestProdFailureMsg:this.props.productsTab && this.props.productsTab.err,
            statsData: props.statsTab.SuccessResponse ? props.statsTab.SuccessResponse.Body:'',
            statsDataFailure: '',
            productsData: [],
            productsDataFailure: '',
            payoutData: [],
            payoutDataFailure: '',
            loader: false,
            loading: false,
            dateArray: [],
            countArray: [],
            payOut: [],
            itemRevenue: [],
            payOutDate: [],
            counter: {},
            orderStatus: {},
            totalSale:props.metricsTab && props.metricsTab.SuccessResponse && parseInt(props.metricsTab.SuccessResponse.Body.Metrics.MetricsType[0].SalesTotal),
            totalOrders:props.statsTab && props.statsTab.SuccessResponse && props.statsTab.SuccessResponse.Body.Orders.Total,
            productsLength:props.productsTab && props.productsTab.SuccessResponse && props.productsTab.SuccessResponse.Body.Products.Product.length,
            allProductsLength:props.statsTab && props.statsTab.SuccessResponse && props.statsTab.SuccessResponse.Body.Products.Total
        }
       
        
    }

    

    hanldeMetrics = async () => {
        this.setState({ loading: true, metricsDataFailure: '', ordersDataFailure: '', productsDataFailure: '', statsDataFailure: '', message: '' })
        await this.props.getMetricsDatafromExternalApi('GetMetrics');
        { this.props.metricsData && this.props.metricsData.ErrorResponse && this.setState({ loading: false, metricsDataFailure: this.props.metricsData.ErrorResponse.Head.ErrorMessage }) }
        { this.props.metricsData && this.props.metricsData.SuccessResponse && this.setState({ loading: false, metricsData: this.props.metricsData.SuccessResponse.Body.Metrics.MetricsType }) }

    }

    handleOrders = async () => {
        this.setState({ loading: true, metricsDataFailure: '', ordersDataFailure: '', productsDataFailure: '', statsDataFailure: '', message: '' })
        await this.props.getOrdersDatafromExternalApi('GetOrders');
        { this.props.ordersData && this.props.ordersData.ErrorResponse && this.setState({ loading: false, ordersDataFailure: this.props.ordersData.ErrorResponse.Head.ErrorMessage }) }
        { this.props.ordersData && this.props.ordersData.SuccessResponse && this.setState({ loading: false, ordersData: this.props.ordersData.SuccessResponse.Body.Orders.Order }) }
    }

    handleProducts = async () => {
        this.setState({ loading: true, metricsDataFailure: '', ordersDataFailure: '', productsDataFailure: '', statsDataFailure: '', message: '' })
        await this.props.getProductsDatafromExternalApi('GetProducts');
        { this.props.productsData && this.props.productsData.ErrorResponse && this.setState({ loading: false, productsDataFailure: this.props.productsData.ErrorResponse.Head.ErrorMessage }) }
        { this.props.productsData && this.props.productsData.SuccessResponse && this.setState({ loading: false, productsData: this.props.productsData.SuccessResponse.Body.Products.Product }) }
    }

    handleStatistics = async () => {
        this.setState({ loading: true, metricsDataFailure: '', ordersDataFailure: '', productsDataFailure: '', statsDataFailure: '', message: '' })
        await this.props.getStatisticsDatafromExternalApi('GetStatistics');
        { this.props.statsData && this.props.statsData.ErrorResponse && this.setState({ loading: false, statsDataFailure: this.props.statsData.ErrorResponse.Head.ErrorMessage }) }
        { this.props.statsData && this.props.statsData.SuccessResponse && this.setState({ loading: false, statsData: this.props.statsData.SuccessResponse.Body }) }
        
    }

    handleGraphsData = async () => {
        this.setState({ loading: true, metricsDataFailure: '', ordersDataFailure: '', productsDataFailure: '', statsDataFailure: '', message: '' })
        await this.props.getOrdersDatafromExternalApi('GetOrders');
        var orderStatus = {}
        var counter = {}
        var yearCounter={}
        {
            this.props.ordersData && this.props.ordersData.SuccessResponse && this.props.ordersData.SuccessResponse.Body.Orders.Order.forEach(function (obj) {
                var key = JSON.stringify(obj.CreatedAt)
                var key1 = JSON.stringify(obj.Statuses.Status)
                var yearKey = JSON.stringify(obj.CreatedAt)

                key = key.substring(1, 11)
                key1=key1.substring(1,key1.length-1).toUpperCase()
                 yearKey=yearKey.substring(1,8);
                
                yearCounter[yearKey]=(yearCounter[yearKey] ||0)+1
                counter[key] = (counter[key] || 0) + 1
                orderStatus[key1] = (orderStatus[key1] || 0) + 1
            })
        }
        { this.props.ordersData && this.props.ordersData.ErrorResponse && this.setState({ loading: false, ordersDataFailure: this.props.ordersData.ErrorResponse.Head.ErrorMessage }) }
        { this.props.ordersData && this.props.ordersData.SuccessResponse && this.setState({ loading: false, ordersData: this.props.ordersData.SuccessResponse.Body.Orders.Order, dateArray: Object.keys(counter), countArray: Object.values(counter), counter: yearCounter, orderStatus: orderStatus }) }
    }

    handleTransactionOverview = async () => {
        this.setState({ loading: true, metricsDataFailure: '', ordersDataFailure: '', productsDataFailure: '', statsDataFailure: '', message: '' })
        await this.props.getPayoutStatusDataFromExternalApi('GetPayoutStatus');

        var result = [];
        var payOutResult = [];

        this.props.payoutData && this.props.payoutData.SuccessResponse && this.props.payoutData.SuccessResponse.Body.PayoutStatus.Statement.forEach(function (a) {
            if (!this[a.CreatedAt]) {
                this[a.CreatedAt] = { CreatedAt: a.CreatedAt.substring(0, 10), ItemRevenue: 0.0 };
                result.push(this[a.CreatedAt]);
            }
            this[a.CreatedAt].ItemRevenue += parseInt(a.ItemRevenue);
        }, Object.create(null));

        this.props.payoutData && this.props.payoutData.SuccessResponse && this.props.payoutData.SuccessResponse.Body.PayoutStatus.Statement.forEach(function (a) {
            if (!this[a.CreatedAt]) {
                this[a.CreatedAt] = { CreatedAt: a.CreatedAt.substring(0, 10), Payout: 0 };
                payOutResult.push(this[a.CreatedAt]);
            }
            this[a.CreatedAt].Payout += parseInt(a.Payout.substring(0, a.Payout.length - 3));
        }, Object.create(null));

        { this.props.payoutData && this.props.payoutData.ErrorResponse && this.setState({ loading: false, payoutDataFailure: this.props.payoutData.ErrorResponse.Head.ErrorMessage }) }
        { this.props.payoutData && this.props.payoutData.SuccessResponse && this.setState({ loading: false, payoutData: this.props.payoutData.SuccessResponse.Body.PayoutStatus.Statement, payOutDate: result.map(a => a.CreatedAt), payOut: payOutResult.map(a => a.Payout), itemRevenue: result.map(a => a.ItemRevenue) }) }

    }

    render() {
 
        return (
            <>
                <div className="analytics-page api-page">
                    <div className="page-body">
                        <div className="container-fluid">
                            {/* <h1><Link href="/jumia-creds">Setup Jumia Account</Link>  if you haven't setup yet.  </h1> */}
                            
                            <ul className="nav nav-tabs analytics-tab" role="tablist">
                            <li className="nav-item tb1"
                                    onClick={this.handleStatistics}>
                                    <a
                                        className="nav-link active"
                                        data-toggle="tab"
                                        href="#tabs-7"
                                        role="tab"
                                    >
                                        Dashboard
                                    </a>
                                </li>
                                <li className="nav-item tb2"
                                    onClick={this.hanldeMetrics}>
                                    <a
                                        className="nav-link "
                                        data-toggle="tab"
                                        href="#tabs-1"
                                        role="tab"
                                    >
                                    <div className="ap-img">
                                        <img src="images/r1.png" />
                                    </div>
                                    <div className="ap-data">
                                        <p className="api-heading">
                                        Metrics Data 
                                        </p>
                                       
                                        <p>
                                        Total Sales:                                       
                                        {this.state.totalSale}
                                        </p>
                                        </div>
                                </a>
                                </li>
                                <li className="nav-item tb3"
                                    onClick={this.handleOrders}>
                                    <a
                                        className="nav-link"
                                        data-toggle="tab"
                                        href="#tabs-2"
                                        role="tab"
                                    >
                                        <div className="ap-img">
                                        <img src="images/r2.png" />
                                    </div>
                                    <div className="ap-data">
                                        <p className="api-heading">
                                         Orders
                                         </p>
                                         <p>
                                        Total Orders:
                                      
                                        {this.state.totalOrders}
                                        </p>
                                        </div>
                                </a>
                                </li>
                                <li className="nav-item tb4"
                                    onClick={this.handleProducts}>
                                    <a
                                        className="nav-link"
                                        data-toggle="tab"
                                        href="#tabs-3"
                                        role="tab"
                                    >
                                         <div className="ap-img">
                                        <img src="images/r3.png" />
                                    </div>
                                    <div className="ap-data">
                                        <p className="api-heading">
                                        Products
                                        </p>
                                        <p>
                                        Total Products:
                                       
                                        {this.state.productsLength}
                                        </p>
                                        </div>
                                 </a>
                                </li>
                                <li className="nav-item tb5"

                                    onClick={this.handleStatistics}>
                                    <a
                                        className="nav-link"
                                        data-toggle="tab"
                                        href="#tabs-4"
                                        role="tab"
                                    >
                                          <div className="ap-img">
                                        <img src="images/r4.png" />
                                    </div>
                                    <div className="ap-data">
                                        <p className="api-heading">
                                        Statistics
                                        </p>
                                        <p>
                                        All Products:
                                        
                                        {this.state.allProductsLength}
                                        </p>
                                        
                                        </div>
                                 </a>
                                </li>

                                <li className="nav-item tb6"

                                    onClick={this.handleGraphsData}>
                                    <a
                                        className="nav-link"
                                        data-toggle="tab"
                                        href="#tabs-5"
                                        role="tab"
                                    >
                                        Orders Count
                                    </a>
                                </li>
                                <li className="nav-item tb7"

                                    onClick={this.handleTransactionOverview}>
                                    <a
                                        className="nav-link"
                                        data-toggle="tab"
                                        href="#tabs-6"
                                        role="tab"
                                    >
                                        Transaction Overview
                                    </a>
                                </li>

                                  <li className="nav-item tb7"

                                    >
                                    <a
                                        className="nav-link"
                                        data-toggle="tab"
                                        href="#tabs-8"
                                        role="tab"
                                    >
                                        Products Performance
                                    </a>
                                </li>
                               

                            </ul>
                            <div className="tab-content">
                                <div className="tab-pane " id="tabs-1" role="tabpanel">
                                    {(this.state.loading && !this.props.metricsData.SuccessResponse) && <Loader />}
                                    {this.props.metricsData && this.props.metricsData.SuccessResponse ? <Metrics loading={this.state.loading} data={this.state.metricsData} /> : <p>{this.state.metricsDataFailure}</p>}
                                </div>
                                <div className="tab-pane" id="tabs-3" role="tabpanel">
                                    {this.state.loading && !this.props.productsData.SuccessResponse && <Loader />}
                                    {this.props.productsData && this.props.productsData.SuccessResponse ? <Products loading={this.state.loading} data={this.state.productsData} /> : <p>{this.state.productsDataFailure}</p>}
                                </div>
                                <div className="tab-pane" id="tabs-2" role="tabpanel">
                                    {this.state.loading && !this.props.ordersData.SuccessResponse && <Loader />}
                                    {this.props.ordersData && this.props.ordersData.SuccessResponse ? <Orders count={this.state.countArray} date={this.state.dateArray} loading={this.state.loading} data={this.state.ordersData} /> : <p>{this.state.ordersDataFailure}</p>}
                                </div>
                                <div className="tab-pane" id="tabs-4" role="tabpanel">
                                    {this.state.loading && !this.props.statsData.SuccessResponse && <Loader />}
                                    {this.props.statsData && this.props.statsData.SuccessResponse ? <Statistics loading={this.state.loading} Orders={this.state.statsData.Orders} Products={this.state.statsData.Products} data={this.state.statsData} /> : <p>{this.state.statsDataFailure}</p>}
                                </div>
                                <div className="tab-pane" id="tabs-5" role="tabpanel">
                                    {this.state.loading&& !this.state.countArray.length>0 && <Loader />}
                                    {this.props.ordersData && this.props.ordersData.SuccessResponse && this.state.countArray.length>0  ? <GraphData orderStatus={this.state.orderStatus} counter={this.state.counter} loading={this.state.loading} count={this.state.countArray} date={this.state.dateArray} /> : <p>{this.state.ordersDataFailure}</p>}
                                </div>
                                <div className="tab-pane" id="tabs-6" role="tabpanel">
                                    {this.state.loading && !this.props.payoutData.SuccessResponse && <Loader />}
                                    {this.props.payoutData && this.props.payoutData.SuccessResponse && this.state.payOut.length>0? <PayoutData loading={this.state.loading} payOutDate={this.state.payOutDate} payOut={this.state.payOut} itemRevenue={this.state.itemRevenue} data={this.state.payoutData} /> : <p>{this.state.payoutDataFailure}</p>}
                                </div>
                                <div className="tab-pane active" id="tabs-7" role="tabpanel">
                                    {this.state.loading && !this.props.statsData.SuccessResponse && <Loader />}
                                    {this.props.statsTab && this.props.statsTab.SuccessResponse  && this.props.bestWorstProductTab  ? <StatsData bestWorstProductsValues={Object.values(this.props.bestWorstProductTab)}  bestWorstProductsStatus={Object.keys(this.props.bestWorstProductTab)} loading={this.state.loading} statsData={this.props.statsTab.SuccessResponse.Body} /> : <p>{this.state.statsDataFailure}</p>}
                                </div>

                                <div className="tab-pane " id="tabs-8" role="tabpanel">
                                    { this.props.bestWorstProductTab && !this.props.bestWorstProductTab.err ? <BestWorstProductsData   bestWorstProdData={this.props.bestWorstProductTab} /> : <p>Failed to find the products data</p>}
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

function mapStateToProps(state) {
    return {
        ...state.user, ...state.apiData
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...userActions, ...extenalApiActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(ExternalAPIData);
