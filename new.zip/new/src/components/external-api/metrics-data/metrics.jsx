import React from 'react'
import dynamic from 'next/dynamic'
const DataTable = dynamic(() => import('react-data-table-component'), { ssr: false })
const DataTableExtensions = dynamic(() => import('react-data-table-component-extensions'), { ssr: false })

const Metrics = (props) => {
    const data = props.data
    const columns = [
        {
            name: 'Statistics Type',
            cell: row => <div data-tag="allowRowEvents">{row.StatisticsType!=='alltime'?`Current ${row.StatisticsType}`:row.StatisticsType}</div>,
            sortable: true,
        },
        {
            name: 'Total Sku',
            selector: 'SkuNumber',
            sortable: true,
        },
        {
            name: 'Sku Active',
            selector: 'SkuActive',
            sortable: true,
        },
        {
            name: 'Sales Total',
            selector: 'SalesTotal',
            sortable: true,

        },
        {
            name: 'Orders',
            selector: 'Orders',
            sortable: true,

        },
        {
            name: 'Commissions',
            selector: 'Commissions',
        },
       
    ];
    const tableData = {
        columns,
        data,
    };
    
    return (
        <div className="user-table">
            <h1>Orders Report</h1>

            <DataTableExtensions
                {...tableData}
            >
                <DataTable
                    columns={columns}
                    data={data}
                    defaultSortField="id"
                    pagination                   
                />
            </DataTableExtensions>
        </div>
    )



}

export default Metrics