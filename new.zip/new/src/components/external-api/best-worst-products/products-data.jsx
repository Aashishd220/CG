import React, { useState } from "react";
import DatePicker from "react-datepicker";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as extenalApiActions from "../../../redux/actions/external-api-actions";
import ProductChartGraph from "./product-sale-chart";
import Loader from "../../loader";
import PieChart from "../statistics/pie-chart";


class BestWorstProductsData extends React.Component{
    constructor(props){
        super(props)
        let oldDate=new Date();
        oldDate.setMonth(oldDate.getMonth() - 3);
        this.state={
            loading:false,
            fromDate:oldDate,
            endDate:new Date(),
            products:Object.keys(this.props.bestWorstProdData),
            productsCount:Object.values(this.props.bestWorstProdData),
            message:''
        }
    }

    handleSubmit=async()=>{
       
        
        this.setState({loading:true})
       
        await this.props.getBestWorstSellingProducts('GetOrders',this.state.fromDate,this.state.endDate)
        
        {(this.props.bestWorstProductsData && this.props.bestWorstProductsData.data) ? this.setState({message:'',loading:false,products:Object.keys(this.props.bestWorstProductsData.data),productsCount:Object.values(this.props.bestWorstProductsData.data)}):this.setState({loading:false,message:this.props.bestWorstProductsData.err})}
    }
    render(){
       
        return this.state.loading?<Loader/>:(
            <div>
            <div className="prt-s-datepickr pb-3">
                <div className="main-p-datepickr ">
              <DatePicker selected={this.state.fromDate} onChange={date => this.setState({fromDate:date})}/>
              <DatePicker selected={this.state.endDate} onChange={date => this.setState({endDate:date})}/>
                 <button onClick={this.handleSubmit} className="btn-primary">Submit</button>
             </div>
             </div>
             
        {this.state.message?<p className="error-msg">{this.state.message}</p>:<ProductChartGraph type="pie"  status={this.state.products}  values={this.state.productsCount}/>} 
             {/* <PieChart type="pie" status={this.state.products}  values={this.state.productsCount}/> */}
           
             {/* <PieChart type="pie" status={Object.keys(this.props.bestWorstProdData)}  values={Object.values(this.props.bestWorstProdData)}/> */}

            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        ...state.user, ...state.apiData
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({  ...extenalApiActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(BestWorstProductsData);

