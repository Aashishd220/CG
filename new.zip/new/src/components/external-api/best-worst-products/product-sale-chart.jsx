import React, { useState } from 'react'
import dynamic from 'next/dynamic'
import { 
  Col, 
  Row,
  Card,
  CardBody
} from 'reactstrap';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class PieChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {}
  }

  static getDerivedStateFromProps(props, state) {
    return {
        series: props.values,
        chartOptions: {
          labels: props.status,

        },
      options: {
        // colors: ['#ffb822', '#249EFA', '#1dc9b7', '#fd397a', '#5578eb','#5578eb','#5578eb','#5578eb'], 
        fill: {
          type: 'gradient',
      },
        chart: {
            width: 440,         
          },
        
          series: props.values,
          labels: props.status
        
    }  
    }
  }

  render() {
      
    return (
      
        <Row >
          <Col xl={12} lg={12} md={12} sm={12} xs={12} className="mb-3 ">
          <Card className="flex-row ">
         <CardBody>
         <h1>Products Performance</h1>

        <div className="graph-maindiv" >
              {this.state && <ReactApexChart className="ml-4" options={this.state.options} series={this.state.series} type={this.props.type}  height={300} />}
        
          </div>
           </CardBody>
          </Card>
        </Col>
         
        </Row>
    )
  }
}
export default PieChart

