import React from 'react'
import dynamic from 'next/dynamic'
import Loader from '../../loader'
const DataTable = dynamic(() => import('react-data-table-component'), { ssr: false })
const DataTableExtensions = dynamic(() => import('react-data-table-component-extensions'), { ssr: false })

const Statistics = ({Orders,Products}) => {
    
    const data1=[{Total:Orders.Total,Delivered:Orders.Status.Delivered,Canceled:Orders.Status.Canceled,Failed:Orders.Status.Failed,Pending:Orders.Status.Pending,Returned:Orders.Status.Returned}]

    const data=[{Total:Products.Total,Active:Products.Status.Active,All:Products.Status.All,Deleted:Products.Status.Deleted,Live:Products.Status.Live,SoldOut:Products.Status.SoldOut}]

const columns1 = [
    {
        name: 'Total',
        selector: 'Total',
        sortable: true,
    },
    {
        name: 'Delivered',
        selector: 'Delivered',
        sortable: true,
    },
    {
        name: 'Canceled',
        selector: 'Canceled',
        sortable: true,

    },
    {
        name: 'Failed',
        selector: 'Failed',
        sortable: true,

    },
    {
        name: 'Pending',
        selector: 'Pending',
    },
    {
        name: 'Returned',
        selector: 'Returned',
    },
   
];

    const columns = [
        {
            name: 'Total',
            selector: 'Total',
            sortable: true,
        },
        {
            name: 'Active',
            selector: 'Active',
            sortable: true,
        },
        {
            name: 'All',
            selector: 'All',
            sortable: true,

        },
        {
            name: 'Deleted',
            selector: 'Deleted',
            sortable: true,

        },
        {
            name: 'Live',
            selector: 'Live',
        },
        {
            name: 'Sold Out',
            selector: 'SoldOut',
        },
       
    ];
    const tableData = {
        columns,
        data,
    };
    
    const tableData1 = {
        columns:columns1,
        data:data1,
    };
    return (
        <div className="user-table">
            <h1>Products Report</h1>

            <DataTableExtensions
                {...tableData}
            >
                <DataTable
                    columns={columns}
                    data={data}
                    defaultSortField="id"
                    pagination
                    

                />
            </DataTableExtensions>

            <h1>Orders Report</h1>

            <DataTableExtensions
                {...tableData1}
            >
                <DataTable
                     columns={columns}
                     data={data}
                    defaultSortField="id"
                    pagination
                    

                />
            </DataTableExtensions>
        </div>
    )



}

export default Statistics