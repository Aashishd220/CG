import React from 'react'
import dynamic from 'next/dynamic'
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class PieChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {}
  }

  static getDerivedStateFromProps(props, state) {
    return {
        series: props.values,
        chartOptions: {
          labels: props.status,

        },
       
      options: {
        fill: {
          type: 'gradient',
      },
        chart: {
            width: 440,
          },
          series: props.values,
          labels: props.status
        
    }  
    }
  }

  render() {
      
    return (
      <div className="graph-maindiv">
        {this.state && <ReactApexChart className="ml-4" options={this.state.options} series={this.state.series} type={this.props.type}  height={300} />}
      </div>
    )
  }
}
export default PieChart

