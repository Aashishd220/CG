import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import PieChart from './pie-chart'
import { 
    CardGroup,
    Col, 
    Row,
    Card,
    CardBody,
    CardImg, 
    CardText,
    CardTitle, 
    CardHeader
  
  } from 'reactstrap';
const StatsData=({statsData,bestWorstProductsStatus,bestWorstProductsValues})=>{
    
    const { Orders, Products, OrdersItemsPending } = statsData
    const[orderStatus,setOrderStatus]=useState(['Active','All','Deleted','Live','Sold Out'])
    const[productValues,setProductValues]=useState([parseInt(Products.Status.Active),parseInt(Products.Status.All),parseInt(Products.Status.Deleted),parseInt(Products.Status.Live),parseInt(Products.Status.SoldOut)])

    const[status,setStatus]=useState(['Canceled','Delivered','Failed','Pending','Returned'])
    const[values,setValues]=useState([parseInt(Orders.Status.Canceled),parseInt(Orders.Status.Delivered),parseInt(Orders.Status.Failed),parseInt(Orders.Status.Pending),parseInt(Orders.Status.Returned)])

 

    return (
        <div className="page-body">
            <Row>
        <Col xl={6} lg={6} md={6} sm={12} xs={12} className="mb-3 ">
        <Card className="flex-row ">
        <CardBody>
         <h1>Order status</h1>
          <PieChart type="pie" status={status}  values={values}/>
          </CardBody>
         </Card>
         </Col>
        
         <Col xl={6} lg={6} md={6} sm={12} xs={12} className="mb-3 ">
         <Card className="flex-row ">
        <CardBody>
       <h1>Products Status</h1> 
          <PieChart type="pie" status={orderStatus} values={productValues}/>
          </CardBody>
         </Card>
       </Col>

       
         <Col xl={12} lg={12} md={6} sm={12} xs={12} className="mb-3 ">
         <Card className="flex-row ">
        <CardBody>
      <div className="d-flex align-items-center justify-content-between">
      <h1>Products Performance </h1> 
       <p>*Last 3 months</p>
      </div>
          <PieChart type="pie" status={bestWorstProductsStatus} values={bestWorstProductsValues}/>
          </CardBody>
         </Card>
       </Col>
      
       </Row>
         
        </div>
    )
}

export default StatsData