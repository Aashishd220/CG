import React, { Component } from "react";
import UserList from "./list-users/list-users.jsx";
import { connect } from 'react-redux'
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";

const Users = ({ users,updateUserStatus,allUsers }) => {
    if(allUsers){
        allUsers=allUsers.filter((user)=>user.user_role!==0)
    }
   const handleUpdateUser= async(id,active)=>{
      await  updateUserStatus(id,active)
    }
    
    return (
        <div className="page-body">
            <UserList updateUser={(id,active)=>{handleUpdateUser(id,active)}} users={allUsers.length>0?allUsers:users.users}/>
        </div>
    );

}

function mapStateToProps(state) {
    return {
        ...state.user,
    };
}
function mapDispatchToProps(dispatch) {
    {
        return bindActionCreators({ ...userActions }, dispatch);
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Users)
