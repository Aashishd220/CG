import React, { Component } from "react";
import { 
    Button, 
} from 'reactstrap';
class UserList extends Component {
    constructor(props) {
        super(props)
    }

    _bindUsers = (users) => {
        
        return users.map((user, index) => (
            <tr>
                <td>{user.first_name}</td>
                <td>{user.last_name}</td>
                <td>{user.email}</td>
                <td>{user.user_role === 1 ? "Staff Account" : user.user_role === 2 ? "User Account" : user.user_role === 3 ? "User Admin Account":"Admin"}</td>
                <td>{user.active === 1?<Button onClick={()=>{this.props.updateUser(user.id,user.active)}} color="success" className="accepted-btn">Active</Button>:user.active === 0?<Button onClick={()=>{this.props.updateUser(user.id,user.active)}} color="danger" className="rejected-btn">Inactive</Button>:''}</td>
               
                {/* <td><button type="button" class="btn btn-outline-primary">Edit</button></td> */}
                {/* <td><button type="button" class="btn btn-outline-danger">Delete</button></td> */}
            </tr>
        ))
    }
    render() {
        return (
            <div className="user-table">
                <div className="container-fluid">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Role</th>
                        <th scope="col">Active</th>
                        {/* <th scope="col">Delete</th> */}
                    </tr>
                </thead>
                <tbody>
                   {this._bindUsers(this.props.users)}
                </tbody>
            </table>
            </div>
            </div>
        );

    }
}


export default UserList;
