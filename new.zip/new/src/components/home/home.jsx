import React, { Component } from "react";
import Link from "next/link";
import { 
  CardGroup,
  Col, 
  Row,
  Card,
  CardBody,
  CardImg, 
  CardText,
  CardTitle, 
  CardHeader

} from 'reactstrap';
import { Container } from "next/app";
class Home extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    return (     
      <div className="page-body">
      <div className="dashborad-page">
        <div className="container-fluid">
          <h1>Select your Website</h1>
        <Row>
        <Col xl={4} lg={6} md={6} sm={12} xs={12} className="mb-3 website-img block">
     
        <Link href="/products?website=jumia-co-ke">
          <Card className="flex-row hovicon effect-1 sub-a">
            <CardImg
              className="card-img-left alert-primary"
              src="images/logo1.png"
              style={{ width: 'auto'}}
            />
            <CardBody>
              <CardTitle>https://www.jumia.co.ke</CardTitle>
              <CardText >
              <h1 className="total-product"> {" Product : " + this.props.products.count.jumia}</h1>
              </CardText>
            </CardBody>
          </Card>
         
        </Link>
        </Col>
        <Col  xl={4} lg={6} md={6} sm={12} xs={12}  className="mb-3 website-img block">
        <Link href="/products?website=jumia-ng">

          <Card className="flex-row hovicon effect-1 sub-a">
            <CardImg
              className="card-img-left alert-primary"
              src="/images/logo1.png"
              style={{ width: 'auto'}}
            />
            <CardBody>
              <CardTitle>https://www.jumia.co.ng</CardTitle>
              <CardText>
              <h1 className="total-product">{"Product : " + this.props.products.count.jumiaNg}</h1>
              </CardText>
            </CardBody>
          </Card>
          </Link>
        </Col>
        <Col  xl={4} lg={6} md={6} sm={12} xs={12}  className="mb-3 website-img block">
        <Link href="/products?website=jumia-gh">
         
          <Card className="flex-row hovicon effect-1 sub-a">
            <CardImg
              className="card-img-left alert-primary"
              src="/images/logo1.png"
              style={{ width: 'auto'}}
            />
            <CardBody>
              <CardTitle>https://www.jumia.co.gh</CardTitle>
              <CardText>
              <h1 className="total-product"> {"Product : " + this.props.products.count.jumiaGh}</h1>
              </CardText>
            </CardBody>
          </Card>
          </Link>
        </Col>
        </Row>

        <Row>
        <Col>
          <Card>
            <CardHeader>Welcome</CardHeader>
            <CardBody>
                <p> Welcome to load</p>
                <p> Welcome message or any other info go here</p>
            </CardBody>
          </Card>
        </Col>
    
      </Row>
      </div>
      </div>
      </div>
     
    );
  }
}

export default Home;
