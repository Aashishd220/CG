
import React from 'react';

import NotificationSystem from 'react-notification-system';
import { NOTIFICATION_SYSTEM_STYLE } from '../../shared/utils/constants';
import Content from '../content/Content';
import Header from '../header/header'
import Sidebar from '../side-bar/side-bar'
import Loader from "../loader/index.jsx";
import { ThemeProvider } from 'react-bootstrap';


class MainLayout extends React.Component {

  state = { check: false }
  static isSidebarOpen() {
    return document
      .querySelector('.cr-sidebar')
      .classList.contains('cr-sidebar--open');
  }

  
  componentDidUpdate() {
    this.checkBreakpoint(this.props.breakpoint)
  }


  componentDidMount() {
    this.checkBreakpoint(this.props.breakpoint);
  }

  // close sidebar when
  handleContentClick = event => {
    // close sidebar if sidebar is open and screen size is less than `md`
    if (this.props.router && (this.props.router.pathname !== '/reset-password' && this.props.router.pathname !== '/forgot-password' && this.props.router.pathname !== "/login" && this.props.router.pathname !== "/sign-up")) {

      if (
        MainLayout.isSidebarOpen() &&
        (this.props.breakpoint === 'xs' ||
          this.props.breakpoint === 'sm' ||
          this.props.breakpoint === 'md')
      ) {
        this.openSidebar('close');
      }
    }
  };

  checkBreakpoint(breakpoint) {
    switch (breakpoint) {
      case 'xs':
      case 'sm':
      case 'md':
        return this.openSidebar('close');
      case 'lg':
      case 'xl':
      default:
        return this.openSidebar('open');
    }
  }

  openSidebar(openOrClose) {
    if (this.props.router && (this.props.router.pathname !== '/reset-password' && this.props.router.pathname !== '/forgot-password' && this.props.router.pathname !== "/login" && this.props.router.pathname !== "/sign-up")) {
      if (openOrClose === 'open') {
        return document
          .querySelector('.cr-sidebar')
          .classList.add('cr-sidebar--open');
      }
      document.querySelector('.cr-sidebar').classList.remove('cr-sidebar--open');
    }

  }

  render() {
    const { children, loader, router } = this.props;
    return (
      <div>
        <main className="cr-app bg-light">
          {router && (router.pathname !== '/reset-password' && router.pathname !== '/forgot-password' && router.pathname !== "/login" && router.pathname !== "/sign-up") && (<Sidebar user={children.props.userData?.id ? children.props.userData : {}} router={router} loader={loader} />)}
          <Content fluid onClick={this.handleContentClick}>
            {router && (router.pathname !== '/reset-password' && router.pathname !== '/forgot-password' && router.pathname !== "/login" && router.pathname !== "/sign-up") && (<Header user={children.props.userData?.id ? children.props.userData : {}} router={router} />)}
            {loader && <Loader />}
            {!loader && children}
          </Content>

          <NotificationSystem
            dismissible={false}
            ref={notificationSystem =>
              (this.notificationSystem = notificationSystem)
            }
            style={NOTIFICATION_SYSTEM_STYLE}
          />
        </main>
      </div>
    )
  }
}
export default MainLayout;
