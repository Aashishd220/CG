import React from 'react'
import ComboProudctReports from '.';
import Dropdown from '../../../shared/component/Dropdown';
import WebsitesDropdown from '../../../shared/component/Websites-Dropdown';

class ComboProductsData extends React.Component {

  constructor(props) {
    super(props)
    this.state = { price: [], date: [], currency: '', name: [], quantity: [], sku: [], dataObject: {} }
  }
  componentDidMount() {
    let d = new Date();
    let month = d.getMonth();
    month += 1;
    if (month < 10) {
      month = '0' + month
    }
    let year = d.getFullYear();
    let strDate = year.toString().concat("-").concat(month)
    this.setPriceAndDate(strDate);
  }

  setPriceAndDate = (strDate) => {
    let filteredProducts = this.props.products.filter(product => product.insert_date.includes(strDate))
    let uniqEcomProductsSqu = [];
    let skuArray = [];
    let nameArray = [];
    let products = [];
    let quantityArray = [];
    let sellingPriceArray = [];
    let purchasePriceArray=[];
    filteredProducts.map((product) => {
      skuArray = product.products_sku.split(',')
      nameArray = product.combo_items.split(',')
      quantityArray = product.quantity.split(',')
      sellingPriceArray = product.selling_price.split(',')
      purchasePriceArray = product.purchase_price.split(',')


      var obj;
      for (var i = 0; i < skuArray.length; i++) {
        if (!uniqEcomProductsSqu.includes(skuArray[i].trim())) {
          uniqEcomProductsSqu = [...uniqEcomProductsSqu, skuArray[i].trim()]
          obj = {};
          obj['sku'] = skuArray[i].trim();
          obj['name'] = nameArray[i];
          obj['quantity'] = quantityArray[i];
          obj['selling_price'] = sellingPriceArray[i];
          obj['purchase_price'] = purchasePriceArray[i];
          obj['profit'] = sellingPriceArray[i]-purchasePriceArray[i];
          products.push(obj);
        } else {
          var objIndex = products.findIndex((obj => obj.sku == skuArray[i].trim()));
          products[objIndex].quantity = +quantityArray[i] + +products[objIndex].quantity;
          products[objIndex].selling_price = +sellingPriceArray[i] + +products[objIndex].selling_price;
          products[objIndex].purchase_price = +purchasePriceArray[i] + +products[objIndex].purchase_price;
          products[objIndex].profit = products[objIndex].selling_price-products[objIndex].purchase_price

        }
      }


    })
    this.setState({ dataObject: products })

  }
  getMonthAndYear = (month, year) => {
    let strdate = year.toString().concat("-").concat(month);
    this.setPriceAndDate(strdate);
  }
  handleWebsiteChange = (website) => {
    // this.setState({ selectedWebsite: website })
    {this.state.dataObject && this.state.dataObject.filter((product)=>{product.dealer})}
}
  render() {
    return (
      <>
        <div className="pt-4">
        <div className="analytic-graph-D">
          <Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />
        </div>
         {/* <WebsitesDropdown handleWebsiteChange={(website) => { this.handleWebsiteChange(website) }}/> */}
          {this.state.dataObject.length > 0 ? <ComboProudctReports products={this.state.dataObject} /> : <p className="notes-text">No data for the selected month and year.</p>}
        </div>
      </>
    )
  }
}

export default ComboProductsData

