import React from 'react'
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as eCommerceActions from '../../../redux/actions/ecommerce-actions'
import axios from 'axios'
import fileDownload from 'js-file-download'
import {_API} from '../../../config'
class ComboProudctReports extends React.Component {
    state = {
        message: ''
    }
    handleClick = async () => {
        await this.props.saveReport(this.props.products).then((res) => {
            if (res.type === 'FILE_CREATED_SUCCESS') {
                axios.get(_API+'/ecom/get-report', {
                    responseType: 'blob',
                }).then((res) => {
                    fileDownload(res.data, 'report.xlsx')
                }).catch((err) => {
                    this.setState({ message: 'Not able to get a file' })
                })
            }
            else {
                this.setState({ message: 'Not able to store a file' })
            }
        })
    }
    render() {
        return (
            <>
                <div className="pt-4">
                    <button className="download-button" onClick={this.handleClick}>Quantity sold per product</button>
                    {this.state.message ? <p className="error-msg">{this.state.message}</p> : ''}
                </div>
            </>
        )
    }
}
function mapStateToProps(state) {
    return {
        ...state.ecommerce,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...eCommerceActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(ComboProudctReports)

