import React from 'react'
import ComboProductsData from './combo-proudcts/combo-products-data';
import SingleProudctData from './single-products/single-products-data';

const ReportsComparison = ({ ecomComboProduct, ecomProducts, uniqueSingleProducts, uniqueComboProducts }) => {
    return (
        <>
           <div className="analytics-page">
          <div className="page-body">
            <div className="container-fluid">
              <ul className="nav nav-tabs analytics-tab" role="tablist">
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    data-toggle="tab"
                    href="#tabs-1"
                    role="tab"
                  >
                    Single Products
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="tab"
                    href="#tabs-2"
                    role="tab"
                  >
                    Combo Products
                  </a>
                </li>
              </ul>
                <div className="tab-content">
                    <div className="tab-pane active" id="tabs-1" role="tabpanel">
                        <ul>
                            <li>
                                <SingleProudctData products={ecomProducts} uniqueSingleProducts={uniqueSingleProducts} />
                            </li>
                        </ul>
                    </div>
                    <div className="tab-pane" id="tabs-2" role="tabpanel">
                        <ul>
                            <li>
                                <ComboProductsData products={ecomComboProduct} uniqueSingleProducts={uniqueSingleProducts} />
                            </li>
                        </ul>

                    </div>
                </div>

            </div>
            </div>
            </div>
        </>
    )
}

export default ReportsComparison