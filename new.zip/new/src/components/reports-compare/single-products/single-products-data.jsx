import React from 'react'
import SingleProudctReports from '.';
import Dropdown from '../../../shared/component/Dropdown';
import WebsitesDropdown from '../../../shared/component/Websites-Dropdown';

class SingleProudctData extends React.Component {

    constructor(props) {
        super(props)
        this.state = { price: [], date: [], currency: '', name: [], quantity: [], sku: [], dataObject: {} }
    }
    componentDidMount() {
        let d = new Date();
        let month = d.getMonth();
        month += 1;
        if (month < 10) {
            month = '0' + month
        }
        let year = d.getFullYear();
        let strDate = year.toString().concat("-").concat(month)
        this.setPriceAndDate(strDate);
    }

    setPriceAndDate = (strDate) => {

        let filteredProducts = this.props.products.filter(product => product.order_created_date.includes(strDate))
        let skuArray = [];
        let products = [];
        filteredProducts.map((product) => {
            skuArray.push(product.product_sku)
        })

        var obj;
        let uniqEcomProductsSqu = [];
        for (var i = 0; i < filteredProducts.length; i++) {
            if (!uniqEcomProductsSqu.includes(skuArray[i])) {
                uniqEcomProductsSqu = [...uniqEcomProductsSqu, skuArray[i]]
                obj = {};
                obj['product_sku'] = filteredProducts[i].product_sku;
                obj['item_name'] = filteredProducts[i].item_name;
                obj['quantity'] = filteredProducts[i].quantity;
                obj['selling_price'] = filteredProducts[i].selling_price;
                obj['purchase_price']=filteredProducts[i].purchase_price;
                obj['platform'] = filteredProducts[i].platform;
                obj['profit']= filteredProducts[i].selling_price -filteredProducts[i].purchase_price;
                 products.push(obj);              
            } else {
                var objIndex = products.findIndex((obj => obj.product_sku == skuArray[i]));
                products[objIndex].quantity = +filteredProducts[i].quantity + +products[objIndex].quantity;
                products[objIndex].selling_price = +filteredProducts[i].selling_price + +products[objIndex].selling_price;
                products[objIndex].purchase_price = +filteredProducts[i].purchase_price + +products[objIndex].purchase_price;
                products[objIndex].profit =  products[objIndex].selling_price -products[objIndex].purchase_price;

            }
        }
        this.setState({ dataObject: products })
    }

    getMonthAndYear = (month, year) => {
        let strdate = year.toString().concat("-").concat(month);
        this.setPriceAndDate(strdate);
    }

    handleWebsiteChange = (website) => {
        let platform=''
        if(website=== 'jumia.com.ng'){
            platform='JUMIA NG'
        }
        else if(website==='jumia.co.ke'){
            platform='JUMIA KE'
        }
        else if(website==='jumia.com.gh'){
            platform='JUMIA GH'
        }
        var data=[]
        if(this.state.dataObject){
          data=  this.state.dataObject.filter((product)=>product.platform==platform)
          this.setState({dataObject:data})
        }
        
        // this.setState({ selectedWebsite: website })
    }

    render() {
        return (
            <>
                <div className="pt-4">
                <div className="analytic-graph-D">
                    <Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />
                  </div>
                    {/* <WebsitesDropdown handleWebsiteChange={(website) => { this.handleWebsiteChange(website) }}/> */}

                    {this.state.dataObject.length > 0 ? <SingleProudctReports products={this.state.dataObject} /> : <p className="notes-text">No data for the selected month and year.</p>}
                </div>
            </>
        )
    }
}

export default SingleProudctData

