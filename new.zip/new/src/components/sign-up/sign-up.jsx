import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";
import {Dropdown } from "react-bootstrap";
import Link from "next/link";
import Router from 'next/router'
const validEmailRegex = RegExp(
    /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
);
class SignupPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            first_name: "",
            last_name: "",
            email: "",
            password: "",
            role: props.roles[0].role,
            errors: {
                email: "",
                password: "",
                first_name: "",
                last_name: ""
            },
            errorMessage: ""
        }
        this.handleChange = this.handleChange.bind(this)
    }
    handleChange(evt) {
        const { name, value } = evt.currentTarget;
        let errors = this.state.errors
        errors[name]=""
        this.setState({ [name]: value , errorMessage:"", errors:errors})
    }


    componentDidMount() {
        document.body.classList.add("login-body")
    }
    componentWillUnmount() {
        document.body.classList.remove("login-body")
    }

    onSubmit = async (evt) => {
        evt.preventDefault()
        var errors = this.state.errors;
        if (!validEmailRegex.test(this.state.email)) {
            errors.email = "Please enter a valid email";
            this.setState({ errors: errors })
        } else {
            const roleId = this.props.roles.find(x=>x.role=== this.state.role)
            const user = {
                email: this.state.email,
                password: this.state.password,
                user_role:roleId.id,
                first_name:this.state.first_name,
                last_name:this.state.last_name
            }
            await this.props.signUp(user);
            if (!this.props.isSuccess) {
                const message = this.props.errorMessage !== "" ? this.props.errorMessage : "Error while creating user."
                this.setState({ errorMessage: message })
            } else {
                Router.push('/')
            }
        }
    }

    render() {
        const { email, password, errors, errorMessage, first_name, last_name, role } = this.state
        return (
            <div className="login-form">
                <form onSubmit={this.onSubmit}>
                    <h2 className="text-center">Sign Up</h2>
                    <div className="form-group">
                        <input type="text" name="first_name" className="form-control" placeholder="First Name" value={first_name} required="required" onChange={this.handleChange} />
                        {errors.first_name !== "" && (<span className="error-message">{errors.first_name}</span>)}
                    </div>
                    <div className="form-group">
                        <input type="text" name="last_name" className="form-control" placeholder="Last Name" value={last_name} required="required" onChange={this.handleChange} />
                        {errors.last_name !== "" && (<span className="error-message">{errors.last_name}</span>)}
                    </div>
                    <div className="form-group">
                        <input type="text" name="email" className="form-control" placeholder="E-mail" value={email} required="required" onChange={this.handleChange} />
                        {errors.email !== "" && (<span className="error-message">{errors.email}</span>)}
                    </div>
                    <div className="form-group">
                        <input type="password" name="password" className="form-control" placeholder="Password" value={password} required="required" onChange={this.handleChange} />
                        {errors.password !== "" && (<span className="error-message">{errors.password}</span>)}
                    </div>
                    <div className="form-group sing-up-drp">
                        <Dropdown>
                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                {role}
                            </Dropdown.Toggle>

                            <Dropdown.Menu>
                                {this.props.roles && this.props.roles.length > 0 && (
                                    this.props.roles.map((role,index)=>(
                                        <Dropdown.Item onClick={(evt) => this.setState({role:role.role})}>{role.role}</Dropdown.Item>
                                    ))
                                )}
                            </Dropdown.Menu>
                        </Dropdown>
                    </div>

                    <div className="form-group">
                        <button type="submit" className="btn btn-primary btn-block btn-login">Sign Up</button>
                        {errorMessage !== "" && (<span className="error-message">{errorMessage}</span>)}
                    </div>
                </form>
                <p className="text-center"><Link href="/login">Login</Link></p>
            </div>
        );
    }
}
SignupPage.propTypes = {
    signUp: PropTypes.func,
    errorMessage: PropTypes.string,
    isSuccess: PropTypes.bool
};
function mapStateToProps(state) {
    return {
        ...state.user,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...userActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(SignupPage);
