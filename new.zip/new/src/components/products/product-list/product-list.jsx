import Link from "next/link";
import { useState, useEffect } from "react";
import Loader from "../../loader";
import { Col, Card, CardBody } from "reactstrap";
const _bindProducts = (
  products,
  favProducts,
  saveProductFavorite,
  selectedCategory,
  selectedBrands,
  getProductsOnFavoriteUnfavorite
) => {
  // if(products.length===0){
  //     return (
  //         <div>
  //             <h1>No product found with the current filters. Try another search. </h1>
  //         </div>
  //     )
  // }

  const setFavorite = async (
    id,
    isFavorite,
    productCode,
    name,
    price,
    dealer,
    images
  ) => {
    await saveProductFavorite(
      id,
      isFavorite,
      productCode,
      name,
      price,
      dealer,
      images
    );
    await getProductsOnFavoriteUnfavorite(selectedCategory, selectedBrands);
  };

  const _bindFavOrUnFavorite = (
    id,
    productCode,
    name,
    price,
    dealer,
    images
  ) => {
    const isFavorite =
      favProducts.findIndex((x) => x.product_id == id) > -1 ? true : false;
    return (
      <button
        onClick={() => {
          setFavorite(id, isFavorite, productCode, name, price, dealer, images);
        }}
        className="btn"
        type="button"
      >
        {isFavorite && (
          <i
            data-toggle="tooltip"
            data-placement="left"
            className="fa fa-minus add-to-cart bg-primary text-white"
            aria-hidden="true"
          />
        )}
        {!isFavorite && (
          <i
            data-toggle="tooltip"
            data-placement="left"
            className="fa fa-plus add-to-cart bg-primary text-white"
            aria-hidden="true"
          />
        )}
      </button>
    );
  };

  return products.map((product, index) => (
    <>
      <Col xl={2} lg={4} md={6} sm={6} xs={12} className="mb-3 website-img ">
        <Card className="h-100">
          <img
            className="img-fluid"
            src={
              product.images && product.images !== ""
                ? product.images
                    .trim()
                    .substr(1, product.images.length - 2)
                    .split(", ")
                    .map((e) => e.trim())[0]
                : ""
            }
            alt=""
          />
          <CardBody className="position-relative d-flex flex-column">    
            {_bindFavOrUnFavorite(
              product.ID,
              product.product_code,
              product.name,
              product.price,
              product.dealer,
              product.images
            )}

            <h3 className="text-primary ">
              {product.dealer === "konga.com"
                ? product.price.replace("?", "₦")
                : product.dealer === "jumia.co.gh"
                ? product.price.replace("?", "₵")
                : product.price.replace("?", "₦")}
            </h3>
            <div className="rating text-warning">
              <i className="fa fa-star" aria-hidden="true"></i>
              <i className="fa fa-star" aria-hidden="true"></i>
              <i className="fa fa-star" aria-hidden="true"></i>
              <i className="fa fa-star" aria-hidden="true"></i>
              <i className="fa fa-star-half-o" aria-hidden="true"></i>
            </div>
            <h4>{product.name}</h4>
            <Link href={"/product-detail?code=" + product.ID}>
              <div className="btn btn-primary btn-block mt-auto">
                <i className="fa fa-eye" aria-hidden="true"></i>
                Product Detail
              </div>
            </Link>
          </CardBody>
        </Card>
      </Col>
    </>
  ));
};

const _bindCategory = (categories, selectedCategory) => {
  return categories.map((category, index) =>
    category.category ? (
      <label className="d-block" for="edo-ani9">
        <input
          className="radio_animated"
          type="radio"
          checked={category.category === selectedCategory ? true : false}
          name={category.category}
          value={category.category}
        />
        {category.category}
      </label>
    ) : (
      <></>
    )
  );
};

const _bindBrands = (brands, selectedCategory, selectedBrands) => {
  const refinedbrand = brands.filter((x) => x.category === selectedCategory);
  return refinedbrand.map((brand, index) => (
    <>
      {brand.brand && (
        <label className="d-block" for="chk-ani">
          <input
            checked={selectedBrands.indexOf(brand.brand) > -1 ? true : false}
            className="checkbox_animated"
            value={brand.brand}
            type="checkbox"
            data-original-title=""
            title=""
          />
          {brand.brand}
        </label>
      )}
    </>
  ));
};

const ProductList = ({
  loadingSearch,
  changed,
  loading,
  filteredProductList,
  getProductsOnFavoriteUnfavorite,
  saveProductFavorite,
  categories,
  websiteProducts,
  getProductsOnCategoryChange,
  getProductsBrands,
  favProducts,
  getProductsOnTerm,
}) => {
  const [toggleClass, setToggle] = useState("");
  const [brandUpdate, setBrandUpdate] = useState(false);
  const [selectedCategory, setCategory] = useState(
    categories.categories[0].category
  );
  const [selectedBrands, setBrands] = useState([]);
  const [term, setTerm] = useState("");
  const noScrollBarClass = "checkbox-animated mt-0 pt-2";
  const [check, setCheck] = useState(false);

  useEffect(() => {
    if (brandUpdate) getProductsBrands(selectedCategory, selectedBrands, term);
  }, [selectedBrands]);

  useEffect(() => {
    if (check === true && term !== undefined && term !== null) {
      const timeOutId = setTimeout(
        () => getProductsOnTerm(term, selectedCategory, selectedBrands),
        1000
      );
      return () => clearTimeout(timeOutId);
    }
  }, [term]);

  const handleInputChange = (event) => {
    let value = event.target.value;
    setToggle("");
    if (selectedBrands.includes(value)) {
      setBrands(selectedBrands.filter((brand) => brand != value));
      setBrandUpdate(true);
    } else {
      setBrands([...selectedBrands, value]);
      setBrandUpdate(true);
    }
  };


  return loading ? (
    <Loader />
  ) : (
    <div className="page-body">
      <div className="container-fluid">
        <div className="page-title">
          <div className="row">
            <div className="col-6">
              <h1>Product</h1>
            </div>
          </div>
        </div>
      </div>
      <div className={toggleClass + " container-fluid product-wrapper"}>
        <div className="product-grid">
          <div className="feature-products">
            <div className="row"></div>
            <div className="row">
              <div className="col-lg-3 col-md-12 col-sm-12">
                <div className="product-sidebar">
                  <div className="filter-section">
                    <div className="card">
                      <div
                        className="card-header"
                        onClick={(e) =>
                          setToggle(toggleClass === "" ? "sidebaron" : "")
                        }
                      >
                        <h6 className="mb-0 f-w-600">
                          Filters
                          <span className="pull-right">
                            <i className="fa fa-chevron-down toggle-data"></i>
                          </span>
                        </h6>
                      </div>
                      <div className="left-filter">
                        <div className="card-body filter-cards-view animate-chk">
                          <div className="product-filter pb-4 ">
                            <h6 className="f-w-600">Category</h6>
                            <div
                              className={
                                categories.categories &&
                                categories.categories.length > 15
                                  ? `${noScrollBarClass} scrollbar`
                                  : noScrollBarClass
                              }
                              onChange={(evt) => {
                                setCategory(evt.target.value);
                                getProductsOnCategoryChange(evt.target.value);
                                setBrands([]);
                                setTerm("");
                                setToggle("");
                              }}
                            >
                              {_bindCategory(
                                categories.categories,
                                selectedCategory
                              )}
                            </div>
                          </div>
                          <div className="product-filter">
                            <h6 className="f-w-600">Brand</h6>
                            <div
                              className={
                                categories.brands &&
                                categories.brands.length > 10
                                  ? `${noScrollBarClass} scrollbar`
                                  : noScrollBarClass
                              }
                              onChange={handleInputChange}
                            >
                              {_bindBrands(
                                categories.brands,
                                selectedCategory,
                                selectedBrands
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className=" col-lg-9 col-md-12 col-sm-12">
                <div className="search-frm" >
                  <div className="form-group m-0">
                    <input 
                      onChange={(event) => {
                        setTerm(event.target.value);
                        setCheck(true);
                        setToggle("");
                      }}
                      value={term}
                      className="form-control"
                      type="text"
                      placeholder="Search.."
                    />
                    <i className="fa fa-search"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="product-wrapper-grid">
            <div className="row">
              {!loadingSearch?(filteredProductList
                ? _bindProducts(
                    websiteProducts,
                    filteredProductList,
                    saveProductFavorite,
                    selectedCategory,
                    selectedBrands,
                    getProductsOnFavoriteUnfavorite
                  )
                : _bindProducts(
                    websiteProducts,
                    favProducts,
                    saveProductFavorite,
                    selectedCategory,
                    selectedBrands,
                    getProductsOnFavoriteUnfavorite
                  )):<div className="search-loader"><Loader/></div>}
              {websiteProducts.length === 0 && changed && (
                <h1 className="product-msg">
                  No product found with the current filters. Try another search.{" "}
                </h1>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProductList;
