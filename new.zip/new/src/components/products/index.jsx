import React, { Component } from "react";
import ProductList from "./product-list/product-list";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as productActions from "../../redux/actions/product-actions";
import ReactPaginate from "react-paginate"
class Products extends Component {
  constructor(props) {
    
    super(props);
    this.state = {
      productData: [],
      offset: 0,
      totalPage: 0,
      selectedCategory: this.props.categories.categories[0].category,
      selectedBrand: [],
      selectedTerm: '',
      loading: false,
      changed:false,
      loadingSearch:false
    }
  }

  componentDidMount() {
    const defaultCategory = this.props.categories.categories[0].category
    this.initialize(1, defaultCategory, [], '');
  }

  async initialize(page, defaultCategory, brands, term) {
    await this.props.getWebsiteProducts(this.props.categories.website, defaultCategory, page, brands, term)
    await this.props.getFavProducts('', [], '', 1)
    this.setState({ loading: false,loadingSearch:false })
    this.setState({ totalPage: this.props.totalPages })
  }

  getProductsOnCategoryChange = (category) => {
    this.setState({ loading: true,changed:true })
    this.initialize(1, category, [], '')

  }

  getProductsOnFavoriteUnfavorite = async (category, brands) => {
    await this.props.getFavProducts('', [], '', 1)
  }
  handlePageClick = (data) => {
    this.setState({ loading: true })
    let selected = data.selected;
    this.initialize(selected + 1, this.state.selectedCategory, this.state.selectedBrand, this.state.selectedTerm)
  };

  getProductsBrands = (category, brands, term) => {
    this.setState({ loading: true,changed:true })
    this.initialize(1, category, brands, term)
  }

  saveProductFavorite = async (id, isFavorite, productCode,name,price,dealer,images) => {
    this.setState({ loading: true })
    await this.props.saveProductFavorite(id, isFavorite, productCode,name,price,dealer,images)
    this.setState({ loading: false })
  }

  getProductsOnTerm = (term, category, brands) => {
    this.setState({changed:true,loadingSearch:true })
    this.initialize(1, category, brands, term)

  }

  render() {    
    return (
      <div className="product-page">
        <ProductList loadingSearch={this.state.loadingSearch} changed={this.state.changed} loading={this.state.loading} getProductsOnTerm={(term, category, brands) => { this.getProductsOnTerm(term, category, brands); this.setState({ selectedCategory: category, selectedBrand: brands, selectedTerm: term }) }} filteredProductList={this.props.allFavProductsList} getProductsOnFavoriteUnfavorite={(category, brands) => this.getProductsOnFavoriteUnfavorite(category, brands)} saveProductFavorite={(id, isFavorite, productCode,name,price,dealer,images) => this.saveProductFavorite(id, isFavorite, productCode,name,price,dealer,images)} favProducts={this.props.favProducts} getProductsBrands={(category, brands, term) => { this.getProductsBrands(category, brands, term); this.setState({ selectedCategory: category, selectedBrand: brands, selectedTerm: term }) }} getProductsOnCategoryChange={(category) => { this.getProductsOnCategoryChange(category); this.setState({ selectedCategory: category }) }} categories={this.props.categories} websiteProducts={this.props.websiteProducts} />
        {this.state.totalPage > 1 && this.state.loading===false &&this.state.loadingSearch===false && (<ReactPaginate
          previousLabel={'previous'}
          nextLabel={'next'}
          breakLabel={'...'}
          breakClassName={'break-me'}
          pageCount={this.state.totalPage}
          marginPagesDisplayed={1}
          pageRangeDisplayed={1}
          onPageChange={this.handlePageClick}
          containerClassName={'pagination'}
          subContainerClassName={'pages pagination'}
          activeClassName={'active'}
        />)}
      </div>
    );
  }
}
Products.propTypes = {
  getWebsiteProducts: PropTypes.func,
  websiteProducts: PropTypes.func,
};
function mapStateToProps(state) {
  return {
    ...state.product,
  };
}
function mapDispatchToProps(dispatch) {
  return bindActionCreators({ ...productActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Products);
