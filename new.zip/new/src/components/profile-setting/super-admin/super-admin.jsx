import React from 'react'
import { 
    Button, 
} from 'reactstrap';
class SuperAdmin extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            initialData: this.props.user.superAdminRequests
        }
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.data !== this.state.initialData) {
            this.setState({ initialData: nextProps.data })
        }
    }

    renderRequests = () => {
        return this.state.initialData.map((request) => {
            return (
                <tr>
                    <td>{request.first_name}</td>
                    <td>{request.last_name}</td>
                    <td>{request.email}</td>
                    <td>{request.current_role === 1 ? 'Staff Account' : request.current_role === 2 ? 'User Account' : 'User Admin Account'}</td>
                    <td>{request.requested_role === 1 ? 'Staff Account' : request.requested_role === 2 ? 'User Account' : 'User Admin Account'}</td>
                    <td>{request.is_accepted === 1?<Button color="success" className="accepted-btn">Accepted</Button>:request.is_accepted === 0?<Button color="danger" className="rejected-btn">Rejected</Button>:''}</td>
                    <td>{ request.action_taken == 0 && (<div>
                        <Button  color="success" onClick={() => { this.props.handleRoleChangeRequest(request.ID, request.email, request.requested_role, true) }} className=" accept-btn" aria-hidden="true">
                       <i class="fa fa-check" aria-hidden="true"></i>
                        </Button>
                        <Button  color="primary" onClick={() => { this.props.handleRoleChangeRequest(request.ID, request.email, request.requested_role, false) }} className=" reject-btn" aria-hidden="true"> 
                        <i class="fa fa-trash" aria-hidden="true"></i>
                                                </Button>
                    </div>
                    )}</td>
                </tr>                
                )
        })
    }

    render() {
        return (
            <div className="user-table">
                <div className="container-fluid">
                <h1> Users Requests</h1>
                {this.state.initialData.length===0 && <h2>No user requests</h2>}
                <table class="table table-hover">
                        <thead>
                        <tr>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Current Role</th>
                        <th scope="col">Requested Role</th>
                        <th scope="col">Status</th>
                        <th scope="col">Decision</th>                
                    </tr>
                        </thead>
                        <tbody>
                        <this.renderRequests />
                        </tbody>
                   </table>
              </div>
            </div>
        )
    }
}
export default SuperAdmin
