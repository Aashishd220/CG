import React from 'react'

class Users extends React.Component {
    constructor(props) {
        super(props)
        let userRoles = this.props.user.roles
        userRoles = userRoles.filter((role) => role.id !== 0)
        this.state = {
            roles: userRoles,
            selectedRole: this.props.user.user_role
        }
    }
    handleChange = (event) => {
        this.setState({ selectedRole: event.target.value })
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.props.roleChangeRequest(this.state.selectedRole)
    }

    render() {
        return (
            <div className="container-fluid">
                <div className="select-role">
                <h1>Select a Role</h1>
              
                <form onSubmit={this.handleSubmit}>
                    <select value={this.state.selectedRole} onChange={this.handleChange}>
                        {this.state.roles.map((role) => (
                            <option disabled={role.id == this.props.user.user_role} key={role.role} value={role.id}>{role.role}</option>
                        ))}
                    </select>
                    <input type="submit" value="Submit" />
                </form>
               
            </div>
            </div>
        )
    }
}
export default Users
