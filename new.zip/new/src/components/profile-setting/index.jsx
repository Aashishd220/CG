import React from 'react'
import SuperAdmin from './super-admin/super-admin'
import Users from './users/users'
import { connect } from 'react-redux'
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";
import * as userActions from "../../redux/actions/user-actions";

class ProfileSetting extends React.Component {

    state = {
        updateMessage: '',
    }

    roleChangeRequest = async (requestedRole) => {
        await this.props.updateRoleRequest(this.props.userInfo.first_name,this.props.userInfo.last_name,this.props.userInfo.email, this.props.userInfo.user_role, requestedRole)
        { this.props.roleChangedRequestSuccess && this.setState({ updateMessage: this.props.roleChangedRequestSuccess }) }
        { this.props.roleChangedRequestFailure && this.setState({ updateMessage: this.props.roleChangedRequestFailure }) }
    }

    handleRoleChangeRequest = async (id, email, role, isAccept) => {
        await this.props.updateUserRole(id, email, role, isAccept)
    }

    render() {
        return (
            <div>
                {(this.props.userInfo && this.props.userInfo.user_role === 0) && (<SuperAdmin data={this.props.requesActionSuccessData} handleRoleChangeRequest={(id, email, role, isAccept) => { this.handleRoleChangeRequest(id, email, role, isAccept) }} user={this.props.userInfo} />)}
                {this.props.userInfo && this.props.userInfo.user_role !== 0 && (<Users roleChangeRequest={(requestedRole) => { this.roleChangeRequest(requestedRole) }} user={this.props.userInfo} />)}
                {this.state.updateMessage && <p className="submit-msg">{this.state.updateMessage}</p>}
            </div>
        )
    }

}
ProfileSetting.propTypes = {
    signIn: PropTypes.func,
    errorMessage: PropTypes.string,
    isSuccess: PropTypes.bool
};
function mapStateToProps(state) {
    return {
        ...state.user,
    };
}
function mapDispatchToProps(dispatch) {
    {
        return bindActionCreators({ ...userActions }, dispatch);
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(ProfileSetting)
