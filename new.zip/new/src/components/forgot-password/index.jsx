import React from 'react'
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";

const validEmailRegex = RegExp(
    /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
  );
class PasswordForgot extends React.Component{

    state={email:'', message:'', errors:""}
    handleSubmit=async(e)=>{
        e.preventDefault();
        if (!validEmailRegex.test(this.state.email)) {
            this.setState({errors:"Please enter a valid email"})
        }
        else{
            const res=await this.props.forgotPassword(this.state.email)
            if(res.type==='FORGOT_PASSWORD_SUCCESS'){
                this.setState({message:res.payload.message,email:''})
            }
            else{
                this.setState({message:res.payload.message})
            }
        }
      
    }
    
    render(){
        return (
          <div className="login-form frgt-form">
            <div className="pwd-rest-main">
              <div className="pwd-rest">
                <div className="frt-img">
                  <img src="images/forget.png" />
                </div>
                <div className="frt-text">
                  <h2 className="text-center">Trouble Logging In?</h2>
                  <p>
                    Enter your email and we'll send you a link to get back into
                    your account.
                  </p>
                </div>
                <div className="form-group">
                  <input
                    type="email"
                    className="form-control"
                    required
                    value={this.state.email}
                    onChange={(e) => {
                      this.setState({
                        email: e.target.value,
                        message: "",
                        errors: "",
                      });
                    }}
                    placeholder="Email"
                  />
                </div>
                <div className="form-group subtn">
                  <input
                    type="submit"
                    onClick={this.handleSubmit}
                    className="form-control"
                  />
                  {this.state.errors && (
                    <p className="error-message">{this.state.errors}</p>
                  )}

                  {this.state.message && <p className="submit-msg">{this.state.message}</p>}
                </div>

                <div className="forget-f">
                  <p className="for-text">
                    <span>Or</span>
                  </p>
                  <p className="cre-new">
                   
                      Create New Account
                   
                  </p>
                </div>
              </div>
            </div>
          </div>
        );
    }
    
}

PasswordForgot.propTypes = {
    signIn: PropTypes.func,
    errorMessage: PropTypes.string,
    isSuccess:PropTypes.bool
};
function mapStateToProps(state) {
    return {
        ...state.user,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...userActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(PasswordForgot);
