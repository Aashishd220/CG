import React, { useState } from 'react'
import dynamic from 'next/dynamic'
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class ProductGraph extends React.Component {
  constructor(props) {
    super(props);
    this.state = {}
  }

  static getDerivedStateFromProps(props, state) {
    return {
      series: [{
        name: 'price',
        data: props.price
      }],
      options: {
        chart: {
          height: 350,
          type: 'bar',
        },
        plotOptions: {
          bar: {
            horizontal: false,
            startingShape: 'flat',
            endingShape: 'flat',
            columnWidth: props.price.length>5?'70%':props.price.length<=2?'10%':'30%',
            barHeight: '70%',
            distributed: false,
            rangeBarOverlap: true,
            rangeBarGroupRows: false,
            dataLabels: {
              position: 'top',
            },
          }
        },
        dataLabels: {
          enabled: true,
          formatter: function (val) {
            return val;
          },
          offsetY: -20,
          style: {
            fontSize: '12px',
            colors: ["#304758"]
          }
        },
        xaxis: {
          categories: props.date,
          position: 'bottom',
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          },
          crosshairs: {
            fill: {
              type: 'gradient',
              gradient: {
                colorFrom: '#D8E3F0',
                colorTo: '#BED1E6',
                stops: [0, 100],
                opacityFrom: 0.4,
                opacityTo: 0.5,
              }
            }
          },
          tooltip: {
            enabled: true,
          }
        },
        yaxis: {
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false,
          },
          labels: {
            show: false,
            formatter: function (val) {
              return val;
            }
          }
        },
        grid: {
          row: {
            colors: ['#f3f3f3', 'transparent'], 
            opacity: 0.5
          },
        },
        yaxis: [
          {
            title: {
              text: 'Price',
            },
          },
         
        ],
        fill: {
          type: 'gradient',
          colors: ['#6a82fb', '#6a82fb', '#6a82fb'],
          gradient: {
            shade: 'dark',
            type: "horizontal",
            shadeIntensity: 0.5,
            gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
            inverseColors: true,
            opacityFrom: 1,
            opacityTo: 1,
            stops: [0, 50, 100],
            colorStops: []
          }
        },
       dataLabels: {
        style: {
          colors: ['#fff', '#E91E63', '#9C27B0']
        }
      },
        title: {
          text: 'Price in ' + props.currency,
          floating: true,
          align: 'center',
          style: {
            color: '#444',
          }
        }
      },
    }
  }

  render() {
    return (
      <div className="graph-maindiv">
        {this.state && <ReactApexChart className="ml-4" options={this.state.options} series={this.state.series} type="bar"  height={350} />}
      </div>
    )
  }
}
export default ProductGraph

