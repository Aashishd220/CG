import React from "react";
import { Carousel } from 'react-responsive-carousel';
const bindImages = (images) => {
    return images.map((image, index) => (
        <div>
            <img src={image} />

        </div>
    ))

}
const ProductImages = ({ product }) => {
    const productImages = product.images && product.images !== "" ? (product.images.trim().substr(1, product.images.length - 2).split(', ').map(e => e.trim())) : []
    return (
        <div className="col-xl-4 pr-info ">
            <div className="card product-detail-img h-100">
                <div className="card-body">
                    <div className="product-slider" id="sync1">
                        <div className="product-item">
                            <Carousel>
                                {productImages && productImages.length > 0 && (bindImages(productImages))}
                            </Carousel>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProductImages;
