import React from "react";

const ProductInfo = ({ product }) => {
    return (
        <div className="col-xl-3 pr-info ">
            <div className="card h-100">
                <div className="card-body">
                    <div className="product-page-details">
                        <h3>{product.name}</h3>
                    </div>
                    <div className="product-price ">{product.dealer === "konga.com" ? product.price.replace("?", "₦"): product.dealer === "jumia.co.gh" ? product.price.replace("?", "₵") : product.price.replace("?", "₦")}
                        {/* <del>{product.price} </del> */}
                    </div>
                    
                    
                    <hr />
                    <div>
                        <table className="product-page-width">
                            <tbody>
                                <tr>
                                    <td className="pr-cat"> <b>Brand </b></td>
                                    <td>{product.brand}</td>
                                </tr>
                                <tr>
                                    <td className="pr-cat"> <b>Category</b></td>
                                    <td>{product.category}</td>
                                </tr>
                                <tr>
                                    <td className="pr-cat"> <b>Rating </b></td>
                                    <td>{product.customer_rating ? product.customer_rating : 0}</td>
                                </tr>
                                <tr>
                                    <td className="pr-cat"> <b>Rating Count</b></td>
                                    <td>{product.rating_count ? product.rating_count : 0}</td>
                                </tr>
                                <tr>
                                    <td className="pr-cat"> <b>Seller</b></td>
                                    <td>{product.seller_information}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProductInfo;
