import React from 'react'
import ProductGraph from './product-graph';
import Dropdown from '../../../shared/component/Dropdown';

class GraphData extends React.Component {

  constructor(props) {
    super(props)
    this.state = { price: [], date: [], currency: '',invalidDateMsg:'' }
  }
  componentDidMount() {
    let d = new Date();
    let month = d.getMonth();
    month += 1;
    if (month < 10) {
      month = '0' + month
    }
    let year = d.getFullYear();
    let strDate = year.toString().concat("-").concat(month)

    if (this.props.dealerInfo === 'konga.com' || this.props.dealerInfo === 'jumia.com.ng') {
      this.setState({ currency: '₦' })
    }
    else if (this.props.dealerInfo === 'jumia.co.ke') {
      this.setState({ currency: 'KSh' })
    }
    else if (this.props.dealerInfo === 'jumia.com.gh') {
      this.setState({ currency: 'GH₦' })
    }

    this.setPriceAndDate(strDate);
  }

  setPriceAndDate = (strDate) => {
    let priceArray = [];
    let dateArray = [];
    let filteredProducts = this.props.products.filter(product => product.insert_date.includes(strDate))

    filteredProducts.map((product) => {
      if (product.price.includes('GH')) {
        priceArray = [...priceArray, product.price.replace('GH?', '').replace(',', '')]
      }
      else if (product.price.includes('KSh')) {
        priceArray = [...priceArray, product.price.substring(4, 10).replace(',', '')]
      }
      else if (product.price.includes('?')) {
        priceArray = [...priceArray, product.price.replace('?', '').replace(',', '')]
      }

      dateArray = [...dateArray, product.insert_date.substring(0, 10)]
    })
    this.setState({ price: priceArray })
    this.setState({ date: dateArray })
  }

  getMonthAndYear = (month, year) => {
    let d = new Date();
    let currentMonth = d.getMonth();
    currentMonth += 1;
    let currentYear = d.getFullYear();
    if(month>currentMonth && year==currentYear){
      this.setState({invalidDateMsg:'*Selected Date cannot be greater than than the current date.'})
    }
    else{
      this.setState({invalidDateMsg:''})
    }
    let strdate = year.toString().concat("-").concat(month);
    this.setPriceAndDate(strdate);
  }

  render() {
    return (
      <>
        <Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />
        {this.state.invalidDateMsg &&  <div className="error-msg"><h3>{this.state.invalidDateMsg}</h3></div>}
        { this.state.price.length  ? <ProductGraph currency={this.state.currency} price={this.state.price} date={this.state.date} dealerInfo={this.props.dealerInfo} /> :!this.state.invalidDateMsg &&  <h1>No data for the selected month and year.</h1>}
      </>
    )
  }
}

export default GraphData

