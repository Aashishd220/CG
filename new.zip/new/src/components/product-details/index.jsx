import React from "react";
import ProductImages from "./sections/product-image";
import ProductInfo from "./sections/product-info"
import ProductGraph from "./sections/product-graph"
import GraphData from "./sections/product-graph-data";

const ProductView = ({ product }) => {
  return (
    <>
      <div className="page-body">
        <div className="container-fluid">
          <div className="page-title">
            <div className="row">
              <div className="col-6">
                <h1>Product Details</h1>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid">
          <div>
            <div className="row product-page-main">
              <ProductImages product={product.product[0]} />
              <ProductInfo product={product.product[0]} />
              <div className="col-xl-5 pr-info " >
                 <div className="card h-100 ">
                  <div className="card-body">
                 <div className="grp-div">
                <GraphData products={product.productPricing} dealerInfo={product.product[0].dealer}/>
              </div>
              </div>
              </div>
              </div>
              <div className="pr-des">
              
                    <div className="container-fluid">
                        <div className="card ">
                  <div className="card-body">
                    <div className="col-12">
                      <h3>Product Description</h3>
                      <div className="prd-describ"
                        dangerouslySetInnerHTML={{ __html: product.product[0].description }}
                      ></div>
                    </div>
                    </div>
                  </div>
                </div>
              </div>

             

            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ProductView
