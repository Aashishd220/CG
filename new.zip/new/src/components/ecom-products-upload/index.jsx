import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as eCommerceActions from '../../redux/actions/ecommerce-actions'
import Table from '../../shared/component/Table'
import Loader from "../loader";

const columnsSingle = [
    {
        title: 'Sku',
        dataIndex: 'product_sku',
        key: 'product_sku',
        width: '10%',
        isSearch: true
    },
    {
        title: 'Name',
        dataIndex: 'item_name',
        key: 'item_name',
        width: '20%',
        isSearch: true
    },
    {
        title: 'Quantity',
        dataIndex: 'quantity',
        key: 'quantity',
    },
    {
        title: 'Quantity(caton)',
        dataIndex: 'quantity_per_carton',
        key: 'quantity_per_carton',
    },
    {
        title: 'Selling Price',
        dataIndex: 'selling_price',
        key: 'selling_price',
    }
    ,
    {
        title: 'Platform',
        dataIndex: 'platform',
        key: 'platform',
    }
    ,
    {
        title: 'Purchase price',
        dataIndex: 'purchase_price',
        key: 'purchase_price',
    },
    {
        title: 'Date',
        dataIndex: 'order_created_date',
        key: 'order_created_date',
        isDate: true
    }
];

const EcomProducts = ({ ecomProducts, deleteEcommerceSingleProduct, updateEcommerceSingleProduct }) => {
    const [updatedProducts, setProducts] = useState(ecomProducts)
    const [loading,setLoading]=useState(false)

    useEffect(() => {
        setProducts(ecomProducts)
    }, [])

    const deleteSingleProduct = async (id) => {
        setLoading(true);
        await deleteEcommerceSingleProduct(id).then((res) => {
            const newList = updatedProducts.filter((product) => product.ID != res.payload);
            setProducts(newList)
             setLoading(false)    
        })
    }


    const handleDataChange = async (dataObject) => {
        setLoading(true);
        await updateEcommerceSingleProduct(dataObject).then((res) => {
            var products = updatedProducts.map(product => {
                if (product.ID == dataObject.ID) return { ...dataObject }
                else { return product }
            });
            setProducts(products)
        })
        setLoading(false)  
    }

    return (loading)?(<Loader/>):(
        <div className="page-body">
            <div className="product-table">
            <div className="container-fluid">
                <h1>Single Products</h1>
                <Table isDelete={true} handleDataChange={(dataObject) => handleDataChange(dataObject)} handleDeleteClick={(productId) => deleteSingleProduct(productId)} columns={columnsSingle} data={updatedProducts} />
            </div>
            </div>
           
        </div>
    );
}

function mapStateToProps(state) {
    return {
        ...state.ecommerce
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...eCommerceActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(EcomProducts)
