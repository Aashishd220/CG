import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";
import Link from "next/link";
import Router from 'next/router'
const validEmailRegex = RegExp(
    /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
  );
class LoginPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: "",
            password: "",
            errors: {
                email: "",
                password: ""
            },
            errorMessage:""
        }
        this.handleChange = this.handleChange.bind(this)
    }
    handleChange(evt) {
        const { name, value } = evt.currentTarget
        this.setState({ [name]: value })
    }

    componentDidMount() {
        document.body.classList.add("login-body")
    }
    componentWillUnmount() {
        document.body.classList.remove("login-body")
    }

    onSubmit = async (evt) => {
        evt.preventDefault()
        var errors = this.state.errors;
        if (!validEmailRegex.test(this.state.email)) {
            errors.email = "Please enter a valid email";
            this.setState({errors:errors})
        }else{
            const user ={
                email:this.state.email,
                password:this.state.password
            }
            await this.props.signIn(user);
            if(!this.props.isSuccess){
                const message = this.props.errorMessage !== "" ? this.props.errorMessage : "Error while creating user."
                this.setState({ errorMessage: message })
            }else{
                Router.push('/')
            }
        }
    }

    render() {
        const { email, password, errors,errorMessage } = this.state
        return (
          <div className="login-form">
            <form onSubmit={this.onSubmit}>
              <div className="frt-img">
                <img src="images/user.png" />
              </div>
              <div className="frt-text">
                <h2 className="text-center">Log in</h2>
              </div>
              <div className="form-group">
                <input
                  type="text"
                  name="email"
                  className="form-control"
                  placeholder="Username"
                  value={email}
                  required="required"
                  onChange={this.handleChange}
                />
                {errors.email !== "" && (
                  <span className="error-message">{errors.email}</span>
                )}
              </div>
              <div className="form-group">
                <input
                  type="password"
                  name="password"
                  className="form-control"
                  placeholder="Password"
                  value={password}
                  required="required"
                  onChange={this.handleChange}
                />
                {errors.password !== "" && (
                  <span className="error-message">{errors.password}</span>
                )}
              </div>
              <div className="forget-div">
                <label className="float-left form-check-label">
                  <input type="checkbox" />
                  <span>Remember me</span>{" "}
                </label>
                <span>
                  <Link href="/forgot-password" className="float-right">
                    <span className="btn-forget">Forgot Password?</span>
                  </Link>
                </span>
              </div>
              <div className="form-group">
                <button
                  type="submit"
                  className="btn btn-primary btn-block btn-login"
                >
                  Log in
                </button>
                {errorMessage !== "" && (
                  <span className="error-message">{errorMessage}</span>
                )}
              </div>
            </form>
            <span className="text-center sign-u">
              Don’t have an account? <Link href="/sign-up">Sign up</Link>
            </span>
          </div>
        );
    }
}
LoginPage.propTypes = {
    signIn: PropTypes.func,
    errorMessage: PropTypes.string,
    isSuccess:PropTypes.bool
};
function mapStateToProps(state) {
    return {
        ...state.user,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...userActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginPage);
