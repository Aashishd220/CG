import React from 'react'
import Autosuggest from 'react-autosuggest'
import { connect } from "react-redux";
import Link from "next/link";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as productActions from "../../redux/actions/product-actions";
import '../../styles/autosuggest.scss'
import { debounce } from 'throttle-debounce'
import Loader from "../loader";
import WishListProducts from './wishlist-products';
import WebsitesDropdown from '../../shared/component/Websites-Dropdown';
import {
    Col,
    Card,
    CardBody,
  } from 'reactstrap';
class ComparePrice extends React.Component {
    state = {
        value: '',
        suggestions: [],
        uniqueProducts: [],
        selectedProducts: [],
        singleProduct: '',
        limitSearch: false,
        loading: false,
        toggle: false,
        selectedWebsite: 'jumia.com.ng'
    }

    componentWillMount() {
        this.onSuggestionsFetchRequested = debounce(
            500,
            this.onSuggestionsFetchRequested
        )
    }

    renderSuggestion = suggestion => {
        return (
            <div className="result">
                <div>{suggestion}</div>
            </div>
        )
    }

    onChange = (event, { newValue }) => {
        this.setState({ value: newValue })
    }

    onSuggestionsFetchRequested = async ({ value }) => {
        await this.props.getSearchedProducts(value, this.state.selectedWebsite)
        if (this.props.searchedProducts) {
            const products = this.props.searchedProducts.map((product) => product.name)
            this.setState({ suggestions: products })
        }
    }

    onSuggestionsClearRequested = () => {
        this.setState({ suggestions: [] })
    }

    onSuggestionSelected = async (event, { suggestion, suggestionValue, suggestionIndex, sectionIndex, method }) => {
        let check = this.state.toggle ? this.state.selectedProducts.length > 0 : this.state.selectedProducts.length > 3
        if (check) {
            this.setState({ limitSearch: true, value: '' })
            return;
        }
        this.setState({ loading: true, selectedProducts: [...this.state.selectedProducts, suggestion] })
        await this.props.getUniqueSearchedProduct(suggestion, this.state.selectedWebsite)
        this.setState({ loading: false })
        if (this.props.uniqueSearchedProduct) {
            let arr = [...arr, this.props.uniqueSearchedProduct]
            this.setState({ uniqueProducts: [...this.state.uniqueProducts, ...this.props.uniqueSearchedProduct], value: '' })
        }
    }

    changeList = (prod) => {
        if (this.state.selectedProducts) {
            var newList = this.state.selectedProducts.filter(product => product !== prod)
            var newProducts = this.state.uniqueProducts.filter(product => product.name !== prod)
        }
        this.setState({ selectedProducts: newList, uniqueProducts: newProducts, limitSearch: false })
    }

    tags = () => {
        return this.state.selectedProducts.map((product) => {
            return (
                <div className="product-comp">
                    <h4>{product.substring(0, 20).concat("...")}<i onClick={() => this.changeList(product)} class="fa fa-times" aria-hidden="true"></i></h4>
                </div>
            )
        })
    }

    showList = ({check}) => {
        return this.state.uniqueProducts.map((product) => {
            return (

               <>
                <Col lg={check? '4':'2'} md={6} sm={6} xs={12} className="mb-3 website-img">
                  <Card className="h-100">
                    <img className="img-fluid" src={product.images && product.images !== "" ? (product.images.trim().substr(1, product.images.length - 2).split(', ').map(e => e.trim()))[0] : ""} alt="" />
                    <CardBody className="position-relative d-flex flex-column">
                      
                     
                      <h3 className="text-primary ">{product.dealer === "konga.com" ? product.price.replace("?", "₦") : product.dealer === "jumia.co.gh" ? product.price.replace("?", "₵") : product.price.replace("?", "₦")}</h3>
                      <div className="rating text-warning">
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star-half-o" aria-hidden="true"></i>
                      </div>
                      <h4>{product.name}</h4>
                      <Link href={"/product-detail?code=" + product.ID}>
                      <div className="btn btn-primary btn-block mt-auto">
                        <i className="fa fa-eye" aria-hidden="true"></i>
                        Product Detail
                      </div>
                      </Link>
                    </CardBody>
                  </Card>
                </Col>
                </>
            )

        })
    }

    handleCheckBoxChange = () => {
        this.setState({ toggle: !this.state.toggle, selectedProducts: [], uniqueProducts: [], limitSearch: false })
    }

    handleWebsiteChange = (website) => {
        this.setState({ selectedWebsite: website })
    }

    render() {
        const { value, suggestions } = this.state
        const inputProps = {
            placeholder: 'Search Product',
            value,
            onChange: this.onChange
        }

        return (
            <div className="container-fluid product-page">
                   <h1>Compare Products</h1>
            <div className="App page-body">             
                <div className="d-flex  justify-content-end ">
                    <label className="com-wish">
                        <input
                            name="isGoing"
                            type="checkbox"
                            checked={this.state.toggle}
                            onChange={this.handleCheckBoxChange}
                        /> Compare from wishlist
                          </label>
                </div>
                <div className="row">
                    <div className={this.state.toggle ? `col-xl-6 col-md-12` : `col-xl-12 col-md-12`}>
                        <h2  className="com-heading">All Products</h2>
                       
                        <div className="d-flex justify-content-center compare-search">
                            <Autosuggest
                                suggestions={suggestions}
                                onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                                onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                                getSuggestionValue={suggestion => suggestion}
                                renderSuggestion={this.renderSuggestion}
                                inputProps={inputProps}
                                onSuggestionSelected={this.onSuggestionSelected}
                            />
                            <WebsitesDropdown handleWebsiteChange={(website) => { this.handleWebsiteChange(website) }} />
                        </div>
                         {this.state.selectedProducts.length > 0 && <div><this.tags /></div>}
                        {this.state.limitSearch && <div className="error-msg"><h3>Compare products from wishlist </h3></div>}
                        {(!this.state.loading && this.state.uniqueProducts.length > 0) && <div className="row pt-4"><this.showList  check={this.state.toggle}/></div>}
                    </div>
                    <div className="col-xl-6 col-md-12 ">
                        
                        {this.state.toggle &&
                            <WishListProducts prods={this.props.favProducts} />}
                    </div>
                </div>
                </div>
            </div>)

    }
}
ComparePrice.propTypes = {
    getSearchedProducts: PropTypes.func,
    getUniqueSearchedProduct: PropTypes.func,
};

function mapStateToProps(state) {
    return {
        ...state.product,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...productActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(ComparePrice);
