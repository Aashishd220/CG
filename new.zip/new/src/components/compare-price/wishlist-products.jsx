import React from 'react'
import Autosuggest from 'react-autosuggest'
import { debounce } from 'throttle-debounce'
import Link from "next/link";
import {
    Col,
    Card,
    CardBody,
  } from 'reactstrap';
class WishListProducts extends React.Component {

    state = {
        value: '',
        suggestions: [],
        uniqueProducts: [],
        selectedProducts: [],
        singleProduct: '',
        limitSearch: false,
        loading: false,
        toggle: false
    }

    componentWillMount() {
        this.onSuggestionsFetchRequested = debounce(
            500,
            this.onSuggestionsFetchRequested
        )
    }

    renderSuggestion = suggestion => {
        return (
            <div className="result">
                <div>{suggestion}</div>
            </div>
        )
    }

    onChange = (event, { newValue }) => {
        this.setState({ value: newValue })
        if (newValue.length === 0) {
            this.setState({ selectedProducts: [], uniqueProducts: [] })
        }
    }



    onSuggestionsFetchRequested = async ({ value }) => {

        let suggestedProducts = [];
        this.props.prods.map(prod => {
            if (prod.name.toLowerCase().includes(value.toLowerCase())) {
                suggestedProducts = [...suggestedProducts, prod.name]
            }
        })
        this.setState({ suggestions: suggestedProducts })

    }

    onSuggestionsClearRequested = () => {
        this.setState({ suggestions: [] })
    }


    onSuggestionSelected = async (event, { suggestion, suggestionValue, suggestionIndex, sectionIndex, method }) => {

        if (this.state.selectedProducts.length > 0) {
            this.setState({ limitSearch: true, value: '' })
            return;
        }
        this.setState({ selectedProducts: [...this.state.selectedProducts, suggestion] })

        this.props.prods.map((prod) => {
            if (prod.name === suggestion) {
                this.setState({ uniqueProducts: [...this.state.uniqueProducts, prod] })
            }
        })
    }

    changeList = (prod) => {
        if (this.state.selectedProducts) {
            var newList = this.state.selectedProducts.filter(product => product !== prod)
            var newProducts = this.state.uniqueProducts.filter(product => product.name !== prod)
        }
        this.setState({ selectedProducts: newList, uniqueProducts: newProducts, limitSearch: false, value: '' })
    }

    tags = () => {
        return this.state.selectedProducts.map((product) => {
            return (
                <div className="product-comp">
                    <h4>{product.substring(0, 20).concat("...")}<i onClick={() => this.changeList(product)} class="fa fa-times" aria-hidden="true"></i></h4>
                </div>
            )
        })
    }
    showList = () => {

        return this.state.uniqueProducts.map((product) => {
            return (
                <>
                <Col lg={4} md={6} sm={6} xs={12} className="mb-3 website-img">
                  <Card className="h-100">
                    <img className="img-fluid" src={product.images && product.images !== "" ? (product.images.trim().substr(1, product.images.length - 2).split(', ').map(e => e.trim()))[0] : ""} alt="" />
                    <CardBody className="position-relative d-flex flex-column">
                      
                     
                      <h3 className="text-primary ">{product.dealer === "konga.com" ? product.price.replace("?", "₦") : product.dealer === "jumia.co.gh" ? product.price.replace("?", "₵") : product.price.replace("?", "₦")}</h3>
                      <div className="rating text-warning">
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star" aria-hidden="true"></i>
                        <i className="fa fa-star-half-o" aria-hidden="true"></i>
                      </div>
                      <h4>{product.name}</h4>
                      <Link href={"/product-detail?code=" + product.ID}>
                      <div className="btn btn-primary btn-block mt-auto">
                        <i className="fa fa-eye" aria-hidden="true"></i>
                        Product Detail
                      </div>
                      </Link>
                    </CardBody>
                  </Card>
                </Col>
                </>
            )

        })
    }

    render() {
        const { value, suggestions } = this.state
        const inputProps = {
            placeholder: 'Search Product',
            value,
            onChange: this.onChange
        }

        return (this.state.loading) ? (<Loader />) : (
            <div className="wish-compare">
                <h2 className="com-heading">Wishlist Products</h2>
               
                <div className="wishC-search">
                <Autosuggest
                    suggestions={suggestions}
                    onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                    onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                    getSuggestionValue={suggestion => suggestion}
                    renderSuggestion={this.renderSuggestion}
                    inputProps={inputProps}
                    onSuggestionSelected={this.onSuggestionSelected}
                /> </div>{this.state.selectedProducts.length > 0 && <div><this.tags /></div>}
                {this.props.prods.length===0 && <div className="error-msg"><h3>No Products in wishlist.</h3></div>}
                {this.state.uniqueProducts.length > 0 && <div className="row pt-4"><this.showList /></div>}

            </div>
           
        )
    }
}
export default WishListProducts
