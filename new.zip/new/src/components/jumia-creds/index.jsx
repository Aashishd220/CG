import React from 'react'
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";
import * as extenalApiActions from "../../redux/actions/external-api-actions";

import Loader from '../loader'
import {
    Col,
    Row,
    Card,
    CardBody,
} from 'reactstrap';
import Link from 'next/link';


class JumiaForm extends React.Component {
    state = {
        userId: '',
        apiKey: '',
        message: '',
        loading: false
    }
    handleSubmit = async (event) => {
        event.preventDefault();
        { (!this.state.userId || !this.state.apiKey) && this.setState({ message: 'Please provide credentials' }) }
        this.setState({ loader: true })
        { this.state.userId && this.state.apiKey && await this.props.addJumiaCreds(this.state.userId, this.state.apiKey) }
        { this.props.errorMessage && this.setState({ message: this.props.errorMessage, loader: false }) }
        { this.props.successMessage && this.setState({ loader: false, message: this.props.successMessage, apiKey: '', userId: '' }) }
    }

    render() {
        return (
            <>
                <form className="form-group extrnl-api" onSubmit={this.handleSubmit}>
                    <Row>
                        <div className="apikeymain">
                            <h2>Setup Jumia Account</h2>
                            <div className="apiuserid1">
                                <input type="text" placeholder="UserId" value={this.state.userId} onChange={(event) => { this.setState({ userId: event.target.value }) }} />
                            </div>
                            <div className="apikey">
                                <input type="text" placeholder="API Key" value={this.state.apiKey} onChange={(event) => { this.setState({ apiKey: event.target.value }) }} />
                            </div>
                            <div>
                                <input type="submit" />
                            </div>
                {this.state.message && <p>{this.state.message}</p>}

                        <Link  href="/external-api">Jumia Dashboard</Link>

                        </div>
                    </Row>

                </form>

            </>
        )
    }
}


function mapStateToProps(state) {
    return {
        ...state.user, ...state.apiData
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...userActions, ...extenalApiActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(JumiaForm);
