import React from 'react'
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as userActions from "../../redux/actions/user-actions";
import Router from 'next/router'

class PasswordReset extends React.Component {
    state = { oldPassword: '', newPassword: '', message: '' }

    submitPassword = async (e) => {
        e.preventDefault();
        if (this.state.oldPassword.length === 0 || this.state.newPassword.length === 0) {
            this.setState({ message: "Password cannot be empty" })
            return;
        }

        const res = await this.props.resetPassword(this.state.oldPassword, this.state.newPassword, this.props.email);
        if (res.type === 'RESET_PASSWORD_SUCCESS') {
            const user = {
                email: this.props.email,
                password: this.state.newPassword
            }
            await this.props.signIn(user);
            if (!this.props.isSuccess) {
                const message = this.props.errorMessage !== "" ? this.props.errorMessage : "Error while signin the  user."
                this.setState({ message: message })
            } else {
                Router.push('/')
            }
        }
        else {
            this.setState({ message: res.payload.message })
        }
    }
    render() {
        return (
              <div className="login-form frgt-form">
            <div className="pwd-rest-main">
                <div className="pwd-rest">
                     <div className="frt-img">
                  <img src="images/forget.png" />
                </div>
                 <div className="frt-text">
                  <h2 className="text-center">Reset Password</h2>
               
                </div>
                    <div className="form-group">
                    <input type="password"
                        required="required"
                         className="form-control"
                        placeholder="Old Password"
                        value={this.state.oldPassword}
                        onChange={(e) => this.setState({ oldPassword: e.target.value, message: '' })}
                    />
                    </div>
                     <div className="form-group">
                    <input type="password"
                        placeholder="New Password"
                        required="required"
                         className="form-control"
                        value={this.state.newPassword}
                        onChange={(e) => this.setState({ newPassword: e.target.value, message: '' })}
                    />
                    </div>
                     <div className="form-group subtn">
                    <input type="submit"  className="form-control" onClick={this.submitPassword} />
                    {this.state.message && <p>{this.state.message}</p>}
                </div>
                </div>
            </div>
            </div>
        )
    }
}


PasswordReset.propTypes = {
    signIn: PropTypes.func,
    errorMessage: PropTypes.string,
    isSuccess: PropTypes.bool
};
function mapStateToProps(state) {
    return {
        ...state.user,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...userActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(PasswordReset);
