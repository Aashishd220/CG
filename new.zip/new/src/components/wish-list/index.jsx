import React, { Component } from "react";
import WishListProducts from "./list-fav-product/wish-list.jsx";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import * as productActions from "../../redux/actions/product-actions";
import ReactPaginate from "react-paginate"
import { GetFavoriteProducts } from "../../shared/services/fetch-urls.js";

class Products extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productData: [],
            offset: 0,
            totalPage: 0,
            brands: [],
            categories: [],
            term: '',
            favProducts: props.favProducts,
            brandCategory: [],
            selectedCategory: '',
            selectedBrand: [],
            selectedTerm: '',
            loading: false,
            favoritesChanged: false
        }
    }

    async initialize(page, defaultCategory, brands, term) {
        this.setState({ loading: false })
        await this.props.getFavProducts(defaultCategory, brands, term, page)
        this.setState({ totalPage: this.props.favTotalPages })
    }
    getProductsOnUnfavorite = async () => {
        this.setState({ loading: true })
        await this.props.getFavProducts('', [], '', 1)
        this.setState({ loading: false, favoritesChanged: true })
        this.bindBrandsAndCategories()
    }

    bindBrandsAndCategories = () => {
        let brandArray = []
        let categoryArray = []
        let brandCategoryArray = []
        const brandMap = new Map();
        const categoryMap = new Map();

        let prods = this.state.favoritesChanged ? this.props.favProductsList : this.props.favProducts.favProducts
        for (const item of prods) {
            brandCategoryArray.push({
                brand: item.brand,
                category: item.category
            })

            if (!brandMap.has(item.brand)) {
                brandMap.set(item.brand, true);
                brandArray.push({
                    brand: item.brand,
                    name: item.brand,
                    category: item.category
                });
            }
            if (!categoryMap.has(item.category)) {
                categoryMap.set(item.category, true);
                categoryArray.push({
                    category: item.category,
                    name: item.category
                });
            }
        }
        this.setState({ brands: brandArray, categories: categoryArray, brandCategory: brandCategoryArray })
    }

    componentDidMount() {
        this.bindBrandsAndCategories()
        this.setState({ totalPage: this.props.favTotalPages })
    }


    getProductsOnTerm = (term, category, brands) => {
        this.setState({ loading: true })
        this.initialize(1, category, brands, term)
    }

    getProductsOnCategoryChange = (category, term) => {
        this.setState({ loading: true })
        this.initialize(1, category, [], '')
    }

    getProductsBrands = (category, brands, term) => {
        this.setState({ loading: true })
        this.initialize(1, category, brands, term)

    }

    handlePageClick = (data) => {
        this.setState({ loading: true })
        let selected = data.selected;
        this.initialize(selected + 1, this.state.selectedCategory, this.state.selectedBrand, this.state.selectedTerm)
    };

    saveProductFavorite = async (id, isFavorite) => {
        await this.props.saveProductFavorite(id, isFavorite)
    }
    
    render() {
        return (
              <div className="product-page">
                <WishListProducts loading={this.state.loading} getProductsOnUnfavorite={() => this.getProductsOnUnfavorite()} saveProductFavorite={(id, isFavorite) => this.saveProductFavorite(id, isFavorite)} filteredProductList={this.props.favProductsList} favProducts={this.state.favProducts} getProductsBrands={(category, brands, term) => this.getProductsBrands(category, brands, term)} getProductsOnCategoryChange={(category, term) => this.getProductsOnCategoryChange(category, term)} getProductsOnTerm={(term, category, brands) => this.getProductsOnTerm(term, category, brands)} brands={this.state.brands} categories={this.state.categories} brandCategory={this.state.brandCategory} />
                {this.state.totalPage!==0 && this.state.totalPage > 1 && this.state.loading===false&&(<ReactPaginate
                    previousLabel={'previous'}
                    nextLabel={'next'}
                    breakLabel={'...'}
                    breakClassName={'break-me'}
                    pageCount={this.state.totalPage}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={this.handlePageClick}
                    containerClassName={'pagination'}
                    subContainerClassName={'pages pagination'}
                    activeClassName={'active'}
                />)}
            </div>
        );
    }
}
Products.propTypes = {
    getWebsiteProducts: PropTypes.func,
    websiteProducts: PropTypes.func,
};
function mapStateToProps(state) {
    return {
        ...state.product,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...productActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Products);
