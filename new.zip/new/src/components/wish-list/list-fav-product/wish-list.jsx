import Link from "next/link";
import React, { useEffect, useState } from "react";
import Loader from "../../loader";
import {
    Col,
    Card,
    CardBody,
  } from 'reactstrap';
const _bindProducts = (favProducts, saveProductFavorite, getProductsOnUnfavorite, setNewListTrue, setCategory, setBrands) => {

    const setFavorite = async (id, isFavorite, setNewListTrue) => {
        setNewListTrue(true)
        await saveProductFavorite(id, isFavorite);
        await getProductsOnUnfavorite();
        setCategory('')
        setBrands([])
    }
    return favProducts.map((product, index) => (

        <>
        <Col lg={2} md={6} sm={6} xs={12} className="mb-3 website-img">
          <Card className="h-100">
            {/* <div className="labels">
              <div className="label-new  btn-info text-white text-center py-1">Favorite Products</div>
            </div> */}
            <img className="img-fluid" src={product.images && product.images !== "" ? (product.images.trim().substr(1, product.images.length - 2).split(', ').map(e => e.trim()))[0] : ""} alt="" />
            <CardBody className="position-relative d-flex flex-column">
              
              <button onClick={() => { setFavorite(product.product_id, true, setNewListTrue, setCategory, setBrands); }} className="btn" type="button">
                                        <i data-toggle="tooltip" data-placement="left" className="fa fa-minus add-to-cart bg-primary text-white" aria-hidden="true"/>
                                    </button>
              <h3 className="text-primary ">{product.dealer === "konga.com" ? product.price.replace("?", "₦") : product.dealer === "jumia.co.gh" ? product.price.replace("?", "₵") : product.price.replace("?", "₦")}</h3>
              <div className="rating text-warning">
                <i className="fa fa-star" aria-hidden="true"></i>
                <i className="fa fa-star" aria-hidden="true"></i>
                <i className="fa fa-star" aria-hidden="true"></i>
                <i className="fa fa-star" aria-hidden="true"></i>
                <i className="fa fa-star-half-o" aria-hidden="true"></i>
              </div>
              <h4>{product.name}</h4>
              <Link href={"/product-detail?code=" + product.product_id}>
              <div className="btn btn-primary btn-block mt-auto">
                <i className="fa fa-eye" aria-hidden="true"></i>
                Product Detail
              </div>
              </Link>
            </CardBody>
          </Card>
        </Col>


        </>
    ))
}
const _bindCategory = (categories, selectedCategory) => {
    return categories.map((category, index) => (
        <>
            <label className="d-block" for="edo-ani9">
                <input className="radio_animated" type="radio" checked={category.category === selectedCategory ? true : false} name={category.category} value={category.category} />{category.category}</label>
        </>
    ))
}

const _bindBrands = (brandCategory, selectedCategory, selectedBrands) => {

    if (selectedCategory) {
        brandCategory = brandCategory.filter(x => x.category === selectedCategory)
    }
    const uniqueBrands = [...new Set(brandCategory.map(item => item.brand))]
    return uniqueBrands.map((brand, index) => (
        <>
            {brand && (
                <label className="d-block" for="chk-ani">
                    <input checked={selectedBrands.indexOf(brand) > -1 ? true : false} className="checkbox_animated" value={brand} type="checkbox" data-original-title="" title="" />{brand}</label>
            )}
        </>
    ))
}


const WishListProducts = ({ loading, filteredProductList, getProductsOnUnfavorite, favProducts, brandCategory, brands, categories, saveProductFavorite, getProductsOnCategoryChange, getProductsBrands, getProductsOnTerm }) => {

    const [term, setTerm] = useState('')
    const [toggleClass, setToggle] = useState("");
    const [selectedCategory, setCategory] = useState('');
    const [brandUpdate, setBrandUpdate] = useState(false)
    const [selectedBrands, setBrands] = useState([]);
    const [check, setCheck] = useState(false);
    const [newListTrue, setNewListTrue] = useState(false);

    const noScrollBarClass = "checkbox-animated mt-0 pt-2"


    useEffect(() => {
        if (brandUpdate)
            getProductsBrands(selectedCategory, selectedBrands, term)
    }, [selectedBrands])


    useEffect(() => {
        if (check === true && term !== undefined && term !== null) {
            const timeOutId = setTimeout(() => getProductsOnTerm(term, selectedCategory, selectedBrands), 1000);
            return () => clearTimeout(timeOutId);
        }
    }, [term]);


    const handleInputChange = (event) => {
        let value = event.target.value
        if (selectedBrands.includes(value)) {
            setBrands(selectedBrands.filter(brand => brand != value))
            setBrandUpdate(true)
        }
        else {
            setBrands([...selectedBrands, value])
            setBrandUpdate(true)
        }
    };
    return (loading) ? (<Loader />) : (
        <div className="page-body">
            <div className="container-fluid">
                <div className="page-title">
                    <div className="row">
                        <div className="col-6">
                            <h1>Favorite Products</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div className={toggleClass + " container-fluid product-wrapper"}>
                <div className="product-grid">
                    <div className="feature-products">
                        <div className="row">
                        </div>
                        <div className="row">
                        <div className="col-lg-3 col-md-12 col-sm-12">
                                <div className="product-sidebar">
                                    <div className="filter-section">
                                        <div className="card">
                                            <div className="card-header" onClick={(e) => setToggle(toggleClass === "" ? "sidebaron" : "")}>
                                                <h6 className="mb-0 f-w-600">Filters<span className="pull-right"><i className="fa fa-chevron-down toggle-data"></i></span></h6>
                                            </div>
                                            <div className="left-filter">
                                                <div className="card-body filter-cards-view animate-chk">
                                                    <div className="product-filter">
                                                        <h6 className="f-w-600">Category</h6>

                                                        <div className={categories && categories.length > 15 ? `${noScrollBarClass} scrollbar` : noScrollBarClass} onChange={(evt) => { setCategory(evt.target.value); getProductsOnCategoryChange(evt.target.value, setTerm('')); setBrands([]); }}>
                                                            {categories.length > 0 && _bindCategory(categories, selectedCategory)}
                                                        </div>
                                                    </div>
                                                    <div className="product-filter">
                                                        <h6 className="f-w-600">Brand</h6>
                                                        <div className={brands && brands.length > 15 ? `${noScrollBarClass} scrollbar` : noScrollBarClass} onChange={handleInputChange}>
                                                            {brands.length > 0 && _bindBrands(brandCategory, selectedCategory, selectedBrands)}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className=" col-lg-9 col-md-12 col-sm-12">
                                    <div className="form-group m-0">
                                        <input onChange={(event) => { setTerm(event.target.value); setCheck(true) }} value={term} className="form-control" type="text" placeholder="Search.." data-original-title="" title="" /><i className="fa fa-search"></i>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div className="product-wrapper-grid">
                        <div className="row">
                            {filteredProductList.length > 0 ? _bindProducts(filteredProductList, saveProductFavorite, getProductsOnUnfavorite, setNewListTrue, setCategory, setBrands) : (!newListTrue && _bindProducts(favProducts.favProducts, saveProductFavorite, getProductsOnUnfavorite, setNewListTrue, setCategory, setBrands))}
                        </div>
                        {(favProducts.favProducts.length === 0 || (filteredProductList.length === 0 && newListTrue)) && <h1>No Favorite products!!</h1>}
                    </div>
                </div>
            </div>
        </div>
    );

}

export default WishListProducts
