import React from 'react';
import PropTypes from '../../../shared/utils/propTypes';
import { Media } from 'reactstrap';
import Avatar from './Avatar';
import Router from 'next/router';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as notificationActions from "../../../redux/actions/notification-actions";
import Link from 'next/link'
import { render } from 'nprogress';
import onClickOutside from "react-onclickoutside";

class Notifications extends React.Component {
   handleNotification= async (ID)=>{
      await this.props.seenNotification(ID).then((res) => {
        if (res.payload.error) {
          return <h1>{res.payload.error}</h1>
        }
      }); <Link href="/notification" />
    }
    handleClickOutside = evt => {
      this.props.handleClick()
    };
  render(){
    const notificationsData=this.props.notificationsData
    return(
      notificationsData &&
    notificationsData.length ?
    (notificationsData.map(({ ID, avatar, notification_message, created_date }) => (
      <Link href={`/notification?ID=${ID}`}>
        <Media key={ID} className="pb-fade " onClick={()=>this.handleNotification(ID)} >
        <Media left className="align-self-center pr-3">
          <Avatar tag={Media} object src={avatar} alt="Avatar" />
        </Media>
        <Media body middle className="align-self-center">
          {notification_message.substring(0, 100).concat("...")}
        </Media>
        <Media right className="align-self-center">
          <small className="text-muted">{created_date.substring(0, 10)}</small>
        </Media>
      </Media>
      </Link>
      
    ))
    ):(<li>No notifications</li>)
  
    )
  }
 
}

function mapStateToProps(state) {
  return {
    ...state.notification,
  };
}
function mapDispatchToProps(dispatch) {
  return bindActionCreators({ ...notificationActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(onClickOutside(Notifications));
