

import React , {Component} from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import User from "../../shared/services/user-service"
import Router from 'next/router';
import * as notificationActions from "../../redux/actions/notification-actions";
import onClickOutside from "react-onclickoutside";
import Link from 'next/link';
import Avatar from './header-components/Avatar';
import  UserCard  from './header-components/UserCard';
import Notifications from './header-components/Notifications';
import { notificationsData } from './header-components/header';
import withBadge from './header-components/withBadge';

import {
  MdClearAll,
  MdExitToApp,
  MdHelp,
  MdInsertChart,
  MdMessage,
  MdNotificationsActive,
  MdNotificationsNone,
  MdPersonPin,
  MdSettingsApplications,
} from 'react-icons/md';
import {
  Button,
  ListGroup,
  ListGroupItem,
  // NavbarToggler,
  Nav,
  Navbar,
  NavItem,
  NavLink,
  Popover,
  PopoverBody,
} from 'reactstrap';
import bn from '../../shared/utils/bemnames';

const bem = bn.create('header');

const MdNotificationsActiveWithBadge = (MdNotificationsActive);

class Header extends React.Component {
  
  constructor(props){
    super(props)
   this.state = {
     notificationsLength:this.props.user && this.props.user.unseenNotifications?props.user.unseenNotifications.length:0,
     unseenNotifications:this.props.user && this.props.user.unseenNotifications
   }
  }

  state = {
    isOpenNotificationPopover: false,
    isNotificationConfirmed: false,
    isOpenUserCardPopover: false,
    checkClear:false
  };

  toggleNotificationPopover = () => {
    this.setState({
      isOpenNotificationPopover: !this.state.isOpenNotificationPopover,
      isOpenUserCardPopover:this.state.isOpenUserCardPopover?false:''
    });

    if (!this.state.isNotificationConfirmed) {
      this.setState({ isNotificationConfirmed: true });
    }
  };

  toggleUserCardPopover = () => {
    this.setState({
      isOpenUserCardPopover: !this.state.isOpenUserCardPopover,
      isOpenNotificationPopover:this.state.isOpenNotificationPopover?false:''
    });
  };
  handleClickOutside = evt => {
  this.setState({isOpenNotificationPopover:false,isOpenUserCardPopover:false})
  };
  
  handleSidebarControlButton = event => {
    event.preventDefault();
    event.stopPropagation();

    document.querySelector('.cr-sidebar').classList.toggle('cr-sidebar--open');
  };

 
  render() {

    const user = this.props.user
    
    const { isNotificationConfirmed } = this.state;

    return (
      <Navbar light expand className={bem.b('bg-white')}>
        <Nav navbar className="mr-2">
          <Button outline onClick={this.handleSidebarControlButton}>
            <MdClearAll size={25} />
          </Button>
        </Nav>
      

        <Nav navbar className={bem.e('nav-right')}>
          <NavItem className="d-inline-flex">
            <NavLink id="Popover1" className="position-relative">
              {isNotificationConfirmed ? (
                <MdNotificationsNone
                  size={25}
                  className="text-secondary can-click"
                  onClick={this.toggleNotificationPopover}
                />
              ) : (
                  <MdNotificationsActiveWithBadge
                  size={25}
                  className="text-secondary can-click animated swing infinite"
                  onClick={this.toggleNotificationPopover}
                />         
              )}
                <p>{this.state.checkClear?0:this.props.user.unseenNotifications && this.props.user.unseenNotifications.length}</p>

            </NavLink>
            
            <Popover
              placement="bottom"
              isOpen={this.state.isOpenNotificationPopover}
              toggle={this.toggleNotificationPopover}
              target="Popover1"
            >
              <PopoverBody>
             
                <Notifications handleClick={this.handleClickOutside} notificationsData={this.state.checkClear?[]:this.props.user.unseenNotifications} />
                {(!this.state.checkClear && this.props.user.unseenNotifications && this.props.user.unseenNotifications.length !== 0) &&  <li onClick={() => {
                            this.props.seenAllNotifications(user.id).then((res) => {
                        
                              if (res.payload.error) {
                                return <h1>{res.payload.error}</h1>
                              }
                              this.setState({checkClear:true})
                            });
                          }}>Clear all notifications</li>}
              </PopoverBody>
            </Popover>
          </NavItem>
          <NavItem>
            <NavLink id="Popover2">
              <Avatar
                onClick={this.toggleUserCardPopover}
                user={this.props.user}
                className="can-click"
              />
            </NavLink>
            <Popover
              placement="bottom-end"
              isOpen={this.state.isOpenUserCardPopover}
              toggle={this.toggleUserCardPopover}
              target="Popover2"
              className="p-0 border-0"
              style={{ minWidth: 250 }}
            >
              <PopoverBody className="p-0 border-light">
                <UserCard handleClick={this.handleClickOutside}
                 subtitle={this.props.user.first_name+" " +this.props.user.last_name}
text={this.props.user.email}
                  className="border-light"
                >
                  <ListGroup flush>
                    <ListGroupItem tag="button" action className="border-light">
                      <MdPersonPin /> Profile
                    </ListGroupItem>
                    <ListGroupItem tag="button" action className="border-light">
                      <MdInsertChart /> Stats
                    </ListGroupItem>
                    <ListGroupItem tag="button" action className="border-light">
                      <MdMessage /> <Link href="/jumia-creds">Setup Jumia API</Link>
                    </ListGroupItem>
                    <ListGroupItem tag="button" action className="border-light">
                      <MdSettingsApplications /> {this.props.user.user_role!==0?<Link href="/settings">Settings</Link>:'Settings'}
                    </ListGroupItem>
                    <ListGroupItem tag="button" action className="border-light">
                      <MdHelp /> Help
                    </ListGroupItem>
                    <ListGroupItem tag="button" action className="border-light"
                     onClick={(evt) => { evt.preventDefault(); User.logOut(); Router.push('/login') }}>
                      <MdExitToApp /> Signout
                    </ListGroupItem>
                  </ListGroup>
                </UserCard>
              </PopoverBody>
            </Popover>
          </NavItem>
        </Nav>
      </Navbar>
    );
  }
}

Header.propTypes = {
    location: PropTypes.object,
    history: PropTypes.object
};
function mapStateToProps(state) {
  return {
    ...state.notification,
  };
}
function mapDispatchToProps(dispatch) {
  return bindActionCreators({ ...notificationActions }, dispatch);
}


export default connect(mapStateToProps, mapDispatchToProps)(onClickOutside(Header));
