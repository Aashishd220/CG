import React, { Component } from "react";
import Link from 'next/link';
class Logo extends Component {
  render() {
    return (
      <div className="logo col-sm-3 col-6">
        <Link href="/">
        	<img src="/svg/blackYellow.svg" alt="logo"></img>
        </Link>
      </div>
    );
  }
}

export default Logo;
