import SourceLink from "./side-bar-components/SourceLink";
import React from "react";
import { FaGithub } from "react-icons/fa";
import {
  MdAccountCircle,
  MdArrowDropDownCircle,
  MdBorderAll,
  MdBrush,
  MdChromeReaderMode,
  MdDashboard,
  MdExtension,
  MdGroupWork,
  MdInsertChart,
  MdKeyboardArrowDown,
  MdNotificationsActive,
  MdPages,
  MdRadioButtonChecked,
  MdSend,
  MdStar,
  MdTextFields,
  MdViewCarousel,
  MdViewDay,
  MdViewList,
  MdWeb,
  MdWidgets,
} from "react-icons/md";
import Link from "next/link";
import {
  Collapse,
  Nav,
  Navbar,
  NavItem,
  NavLink as BSNavLink,
} from "reactstrap";
import bn from "../../shared/utils/bemnames";

const sidebarBackground = {
  backgroundImage: `url("")`,
  backgroundSize: "cover",
  backgroundRepeat: "no-repeat",
};

const analyticsComponents = [
  {
    to: "/file-upload",
    name: "Upload File",
    exact: false,
    Icon: MdRadioButtonChecked,
  },
  {
    to: "/ecom-products",
    name: "Single Products",
    exact: false,
    Icon: MdGroupWork,
  },
  {
    to: "/ecom-combo-products",
    name: "Combo Products",
    exact: false,
    Icon: MdChromeReaderMode,
  },
  { to: "/analytics", name: "Analytics", exact: false, Icon: MdViewList },
  { to: "/external-api", name: "External Api", exact: false, Icon: MdViewList },

];

const reportsComponents = [
  { to: "/reports", name: "Reports", exact: false, Icon: MdViewList },
];

const userComponents = [
  { to: "/users", name: "Users", exact: false, Icon: MdViewList },
  { to: "/settings", name: "User Requests", exact: false, Icon: MdViewList },
];

const dashboardComponents = [
  { to: "/", name: "websites", exact: true, Icon: MdDashboard },
  { to: "/wish-list", name: "Wishlist", exact: false, Icon: MdWeb },
  {
    to: "/compare-price",
    name: "Compare Products",
    exact: false,
    Icon: MdWidgets,
  },
];

const bem = bn.create("sidebar");

class Sidebar extends React.Component {
  state = {
    isOpenDashboard: false,
    isOpenEcommerce: false,
    isOpenReports: false,
    isOpenUser: false,
  };

  componentDidMount() {
    if(!this.props.loader){
      const router = this.props.router;
      if (
        router.pathname === "/" ||
        router.pathname === "/wish-list" ||
        router.pathname.indexOf("/product-detail") >= 0 ||
        router.pathname.indexOf("/products") >= 0 ||
        router.pathname.indexOf("/compare-price") >= 0
      )
        this.setState({ isOpenDashboard: true });
      else if (
        router.pathname === "/file-upload" ||
        router.pathname === "/analytics" ||
        router.pathname.indexOf("/ecom-seller") >= 0 ||
        router.pathname.indexOf("/ecom-product") >= 0 ||
        router.pathname.indexOf("/ecom-combo-products") >= 0
      )
        this.setState({ isOpenEcommerce: true });
      else if (router.pathname === "/reports")
        this.setState({ isOpenReports: true });
      else if (router.pathname === "/users" || router.pathname === "/settings")
        this.setState({ isOpenUser: true });
    }
  }

  handleClick = (name) => () => {
    this.setState((prevState) => {
      const isOpen = prevState[`isOpen${name}`];
      if (name === "Dashboard")
        this.setState({
          isOpenEcommerce: false,
          isOpenReports: false,
          isOpenUser: false,
        });
      if (name === "Ecommerce")
        this.setState({
          isOpenDashboard: false,
          isOpenReports: false,
          isOpenUser: false,
        });
      if (name === "Reports")
        this.setState({
          isOpenDashboard: false,
          isOpenEcommerce: false,
          isOpenUser: false,
        });
      if (name === "User")
        this.setState({
          isOpenDashboard: false,
          isOpenEcommerce: false,
          isOpenReports: false,
        });
      return {
        [`isOpen${name}`]: !isOpen,
      };
    });
  };

  render() {
    return (
      <aside className={bem.b()} data-image={""}>
        <div className={bem.e("background")} style={sidebarBackground} />
        <div className={bem.e("content")}>
          <Navbar>
            <SourceLink className="navbar-brand d-flex">
              <img
                src="/images/logo_200.png"
                width="40"
                height="30"
                className="pr-2"
                alt=""
              />
              <Link href="/">
                <span className="text-white">Load</span>
              </Link>
            </SourceLink>
          </Navbar>
          <Nav vertical>
            <NavItem
              className={bem.e("nav-item")}
              onClick={this.handleClick("Dashboard")}
              className={this.state.isOpenDashboard ? "active" : ""}
            >
              <BSNavLink className={bem.e("nav-item-collapse")}>
                <div className="d-flex">
                  <MdExtension className={bem.e("nav-item-icon")} />
                  <span className=" align-self-start">Dashboard</span>
                </div>
                <MdKeyboardArrowDown
                  className={bem.e("nav-item-icon")}
                  style={{
                    padding: 0,
                    transform: this.state.isOpenDashboard
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                    transitionDuration: "0.3s",
                    transitionProperty: "transform",
                  }}
                />
              </BSNavLink>
            </NavItem>
            <Collapse isOpen={this.state.isOpenDashboard}>
              {dashboardComponents.map(({ to, name, exact, Icon }, index) => (
                <Link href={to}>
                  <NavItem key={index} className={bem.e("nav-item")}>
                    <BSNavLink
                      id={`navItem-${name}-${index}`}
                      className="text-uppercase"
                      to={to}
                      activeClassName="active"
                      exact={exact}
                    >
                      <Icon className={bem.e("nav-item-icon")} />
                      <span className={this.state.isOpenDashboard ? "" : ""}>
                        {name}
                      </span>
                    </BSNavLink>
                  </NavItem>
                </Link>
              ))}
            </Collapse>

            <NavItem
              className={bem.e("nav-item")}
              onClick={this.handleClick("Ecommerce")}
              className={this.state.isOpenEcommerce ? "active" : ""}
            >
              <BSNavLink className={bem.e("nav-item-collapse")}>
                <div className="d-flex">
                  <MdExtension className={bem.e("nav-item-icon")} />
                  <span>Ecommerce</span>
                </div>
                <MdKeyboardArrowDown
                  className={bem.e("nav-item-icon")}
                  style={{
                    padding: 0,
                    transform: this.state.isOpenEcommerce
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                    transitionDuration: "0.3s",
                    transitionProperty: "transform",
                  }}
                />
              </BSNavLink>
            </NavItem>
            <Collapse isOpen={this.state.isOpenEcommerce}>
              {analyticsComponents.map(({ to, name, exact, Icon }, index) => (
                <Link href={to}>
                  <NavItem key={index} className={bem.e("nav-item")}>
                    <BSNavLink
                      id={`navItem-${name}-${index}`}
                      className="text-uppercase"
                      to={to}
                      activeClassName="active"
                      exact={exact}
                    >
                      <Icon className={bem.e("nav-item-icon")} />
                      <span className="">{name}</span>
                    </BSNavLink>
                  </NavItem>
                </Link>
              ))}
            </Collapse>

            <NavItem
              className={bem.e("nav-item")}
              onClick={this.handleClick("Reports")}
              className={this.state.isOpenReports ? "active" : ""}
            >
              <BSNavLink className={bem.e("nav-item-collapse")}>
                <div className="d-flex">
                  <MdPages className={bem.e("nav-item-icon")} />
                  <span>Reports</span>
                </div>
                <MdKeyboardArrowDown
                  className={bem.e("nav-item-icon")}
                  style={{
                    padding: 0,
                    transform: this.state.isOpenReports
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                    transitionDuration: "0.3s",
                    transitionProperty: "transform",
                  }}
                />
              </BSNavLink>
            </NavItem>
            <Collapse isOpen={this.state.isOpenReports}>
              {reportsComponents.map(({ to, name, exact, Icon }, index) => (
                <Link href={to}>
                  <NavItem key={index} className={bem.e("nav-item")}>
                    <BSNavLink
                      id={`navItem-${name}-${index}`}
                      className="text-uppercase"
                      to={to}
                      activeClassName="active"
                      exact={exact}
                    >
                      <Icon className={bem.e("nav-item-icon")} />
                      <span className="">{name}</span>
                    </BSNavLink>
                  </NavItem>
                </Link>
              ))}
            </Collapse>

            {this.props.user.user_role === 0 && (
              <>
                <NavItem
                  className={bem.e("nav-item")}
                  onClick={this.handleClick("User")}
                  className={this.state.isOpenUser ? "active" : ""}
                >
                  <BSNavLink className={bem.e("nav-item-collapse")}>
                    <div className="d-flex">
                      <MdExtension className={bem.e("nav-item-icon")} />
                      <span>Users</span>
                    </div>
                    <MdKeyboardArrowDown
                      className={bem.e("nav-item-icon")}
                      style={{
                        padding: 0,
                        transform: this.state.isOpenUser
                          ? "rotate(0deg)"
                          : "rotate(-90deg)",
                        transitionDuration: "0.3s",
                        transitionProperty: "transform",
                      }}
                    />
                  </BSNavLink>
                </NavItem>
                <Collapse isOpen={this.state.isOpenUser}>
                  {userComponents.map(({ to, name, exact, Icon }, index) => (
                    <Link href={to}>
                      <NavItem key={index} className={bem.e("nav-item")}>
                        <BSNavLink
                          id={`navItem-${name}-${index}`}
                          className="text-uppercase"
                          to={to}
                          activeClassName="active"
                          exact={exact}
                        >
                          <Icon className={bem.e("nav-item-icon")} />
                          <span className="">{name}</span>
                        </BSNavLink>
                      </NavItem>
                    </Link>
                  ))}
                </Collapse>
              </>
            )}
          </Nav>
        </div>
      </aside>
    );
  }
}

export default Sidebar;
