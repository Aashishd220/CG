import React from 'react'
import Link from 'next/link'
import {
    Col,
    Card,
    CardBody,
    Row
  } from 'reactstrap';
const NotificationDetail = ({ product }) => {
    return (
        <div className="page-body ">
            <div className="product-page">
                <div className="container-fluid">
            <h1>Notification</h1>
            
                <Row>
                <Col lg={2} md={6} sm={6} xs={12} >
            </Col>
                <Col lg={2} md={6} sm={6} xs={12} className="mb-3 website-img">
                    <Card className="h-100">
                        <img className="img-fluid" src={product.images && product.images !== "" ? (product.images.trim().substr(1, product.images.length - 2).split(', ').map(e => e.trim()))[0] : ""} alt="" />
                        <CardBody className="position-relative d-flex flex-column">


                            <h3 className="text-primary ">{product.dealer === "konga.com" ? product.price.replace("?", "₦") : product.dealer === "jumia.co.gh" ? product.price.replace("?", "₵") : product.price.replace("?", "₦")}</h3>
                            <div className="rating text-warning">
                                <i className="fa fa-star" aria-hidden="true"></i>
                                <i className="fa fa-star" aria-hidden="true"></i>
                                <i className="fa fa-star" aria-hidden="true"></i>
                                <i className="fa fa-star" aria-hidden="true"></i>
                                <i className="fa fa-star-half-o" aria-hidden="true"></i>
                            </div>
                            <h4>{product.name}</h4>
                            <Link href={"/product-detail?code=" + product.ID}>
                                <div className="btn btn-primary btn-block mt-auto">
                                    <i className="fa fa-eye" aria-hidden="true"></i>
Product Detail
</div>
                            </Link>
                        </CardBody>
                    </Card>
                </Col>

                <Col lg={6} md={6} sm={6} xs={12} className="mb-3 website-img notification-text">
                <Card className="h-100">
                <CardBody className="position-relative d-flex flex-column">
                <h5>{product.notification_message}</h5> <span>{product.created_date.substring(0, 10)}</span>
               </CardBody>
                </Card>
                </Col>
                </Row>
                </div>
                </div>
           
        </div>
    )
}
export default NotificationDetail