import React from 'react'
import dynamic from 'next/dynamic'
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class PurchasePriceGraph extends React.Component {

  constructor(props) {
    super(props);
    this.state = {}
  }

  static getDerivedStateFromProps(props, state) {
    return {
    series: [{
        name: "",
        data: props.purchasePrice,
        product:props.product,
        platform:props.platform
    }],
    options: {
      chart: {
        height: 350,
        type: 'line',
        zoom: {
          enabled: false
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth'
      },
      title: {
        text: 'Purchase Price',
        align: 'center'
      },
      grid: {
        row: {
          colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
          opacity: 0.5
        },
      },
      xaxis: {
        categories: props.date,
      },
      tooltip: {
        enabled: true,          
        y: {
          formatter: function(value, opts) {
            return (
              'Purchase Price: '+
              opts.series[opts.seriesIndex][opts.dataPointIndex] +
              ', Name:  ' +
              opts.w.config.series[opts.seriesIndex].product[opts.dataPointIndex]+
              ', Platform:  ' +
              opts.w.config.series[opts.seriesIndex].platform[opts.dataPointIndex]
            )
          }
        }
        
      }
    },
    
  
 

    }
  }
  render() {
    return (
      <div >
        { this.state && <ReactApexChart options={this.state.options} series={this.state.series} type="area" width={this.props.purchasePrice.length > 10 ? 850 : 300} height={350} />}
      </div>
    )
  }
}
export default PurchasePriceGraph

