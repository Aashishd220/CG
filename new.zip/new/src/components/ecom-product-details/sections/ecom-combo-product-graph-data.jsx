import React from 'react'
import Dropdown from '../../../shared/component/Dropdown';
import ProductGraph from './ecom-product-graph';
import PurchasePriceGraph from './ecom-purchase-price-date-graph';
import SellingPriceGraph from './ecom-selling-price-date-graph';

class ComboGraphData extends React.Component {

  constructor(props) {
    super(props)
    this.state = { quantity: [], date: [], purchasePrice: [], sellingPrice: [], product: [], platform: [],invalidDateMsg:'' }
  }

  componentDidMount() {
    let d = new Date();
    let month = d.getMonth();
    month += 1;
    if (month < 10) {
      month = '0' + month
    }
    let year = d.getFullYear();
    let strDate = year.toString().concat("-").concat(month)
    this.setQuantityAndDate(strDate);
  }

  setQuantityAndDate = (strDate) => {
    let quantityArray = [];
    let purchasePriceArray = [];
    let sellingPriceArray = [];
    let productArray = [];
    let platformArray = [];
    let dateArray = [];
    let skuArray = [];
    let quantArr = [];
    let prodArray = [];
    let purPriceArray = [];
    let sellPriceArray = [];

    let filteredProducts = this.props.comboProduct.filter(product => product.insert_date.includes(strDate))
    filteredProducts.map((product) => {
      skuArray = product.products_sku.split(',')
      quantArr = product.quantity.split(',')
      prodArray = product.combo_items.split(',')
      purPriceArray = product.purchase_price.split(',')
      sellPriceArray = product.selling_price.split(',')

      for (var i = 0; i < skuArray.length; i++) {
        if (skuArray[i].trim() == this.props.sku) {
          quantityArray = [...quantityArray, quantArr[i]]
          purchasePriceArray = [...purchasePriceArray, purPriceArray[i]]
          sellingPriceArray = [...sellingPriceArray, sellPriceArray[i]]
          productArray = [...productArray, prodArray[i]]
        }
      }
      prodArray = [];
      skuArray = [];
      quantArr = [];
      purPriceArray = [];
      sellPriceArray = [];
      platformArray = [...platformArray, product.platform]
      dateArray = [...dateArray, product.insert_date.substring(0, 10)]
    })
    this.setState({ platform: platformArray, product: productArray, quantity: quantityArray, date: dateArray, sellingPrice: sellingPriceArray, purchasePrice: purchasePriceArray })
  }

  getMonthAndYear = (month, year) => {
    let d = new Date();
    let currentMonth = d.getMonth();
    currentMonth += 1;
    let currentYear = d.getFullYear();
    if(month>currentMonth && year==currentYear){
      this.setState({invalidDateMsg:'*Selected Date cannot be greater than than the current date.'})
    }
    else{
      this.setState({invalidDateMsg:''})
    }
    let strdate = year.toString().concat("-").concat(month);
    this.setQuantityAndDate(strdate);
  }

  render() {
   
    return (
      <div className=" p-4 ">
        <div className="analytic-graph-D">
        <Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />
        </div>
        <div className="d-flex justify-content-around pt-4 mt-4">
        {this.state.invalidDateMsg &&  <div className="error-msg"><h3>{this.state.invalidDateMsg}</h3></div>}
          {this.state.quantity.length ? <ProductGraph platform={this.state.platform} product={this.state.product} quantity={this.state.quantity} date={this.state.date} /> :!this.state.invalidDateMsg && <h4 className="error-msg ">No data for the selected month and year of combo uploaded products.</h4>}
          {/* {this.state.purchasePrice.length ? <PurchasePriceGraph platform={this.state.platform} product={this.state.product} purchasePrice={this.state.purchasePrice} date={this.state.date} /> :!this.state.invalidDateMsg && <h4>No data for the selected month and year of single uploaded products.</h4>} */}
          {this.state.sellingPrice.length ? <SellingPriceGraph platform={this.state.platform} product={this.state.product} purchasePrice={this.state.purchasePrice} sellingPrice={this.state.sellingPrice} date={this.state.date} /> :!this.state.invalidDateMsg && <h4 className="error-msg ">No data for the selected month and year of single uploaded products.</h4>}
        </div>
      </div>
    )
  }
}
export default ComboGraphData

