import React from 'react'
import dynamic from 'next/dynamic'
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class ProductGraph extends React.Component {

  constructor(props) {
    super(props);
    this.state = {}
  }

  static getDerivedStateFromProps(props, state) {
    return {
      series: [{
         name: '',
        data: props.quantity,
        product:props.product,
        platform:props.platform
      }],
      options: {
        chart: {
          height: 350,
          type: 'bar',
        },
        plotOptions: {
          bar: {
            horizontal: false,
            startingShape: 'flat',
            endingShape: 'flat',
            columnWidth: props.product.length>5?'60%':props.product.length<=2?'20%':'60%',
            barHeight: '70%',
            distributed: false,
            rangeBarOverlap: true,
            rangeBarGroupRows: false,
            dataLabels: {
              position: 'center',  
              orientation:'vertical'          
            },
          
          }
        },
        dataLabels: {
          enabled: false,
          formatter: function (val) {
            return val;
          },
          offsetY: -20,
          style: {
            fontSize: '12px',
            colors: ["#304758"]
          }
        },
        xaxis: {
          categories: props.date,
          position: 'bottom',
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          },
          crosshairs: {
            fill: {
              type: 'gradient',
              gradient: {
                colorFrom: '#D8E3F0',
                colorTo: '#BED1E6',
                stops: [0, 100],
                opacityFrom: 0.4,
                opacityTo: 0.5,
              }
            }
          },      
        },
        tooltip: {
          enabled: true,          
          y: {
            formatter: function(value, opts) {
              return (
                'Quantity:  ' +
                opts.series[opts.seriesIndex][opts.dataPointIndex] +
                ', Name:  ' +
                opts.w.config.series[opts.seriesIndex].product[opts.dataPointIndex]+
                ', Platform:  ' +
                opts.w.config.series[opts.seriesIndex].platform[opts.dataPointIndex]
              )
            }
          }
          
        },
        yaxis: {
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false,
          },
          labels: {
            show: false,
            formatter: function (val) {
              return val;
            }
          }

        },
        grid: {
          row: {
            colors: ['#f3f3f3', 'transparent'], 
            opacity: 0.5
          },
        },
        yaxis: [
          {
            title: {
              text: 'Quantity',
            },
          },
         
        ],
        fill: {
          type: 'gradient',
          colors: ['#6a82fb', '#6a82fb', '#6a82fb'],
          gradient: {
            shade: 'dark',
            type: "horizontal",
            shadeIntensity: 0.5,
            gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
            inverseColors: true,
            opacityFrom: 1,
            opacityTo: 1,
            stops: [0, 50, 100],
            colorStops: []
          }
        },
       dataLabels: {
        style: {
          colors: ['#fff', '#E91E63', '#9C27B0']
        }
      },
        title: {
          text: '',
          floating: true,
          align: 'center',
          style: {
            color: '#444',

          }
        }
      },
    }
  }
  render() {
    return (
      <div className="ant-graph">
        { this.state && <ReactApexChart options={this.state.options} series={this.state.series} type="bar" width={this.props.quantity.length > 10 ? 850 : 300} height={350} />}
      </div>
    )
  }
}
export default ProductGraph

