import React from 'react'
import Dropdown from '../../../shared/component/Dropdown';
import PurchasePriceGraph from './ecom-purchase-price-date-graph';
import ProductGraph from './ecom-product-graph';
import SellingPriceGraph from './ecom-selling-price-date-graph';

class GraphData extends React.Component {

  constructor(props) {
    super(props)
    this.state = { quantity: [], date: [] ,currency: '',purchasePrice:[],sellingPrice:[],product:[],platform:[],invalidDateMsg:''}
  }

  componentDidMount() {
    let d = new Date();
    let month = d.getMonth();
    month += 1;
    if (month < 10) {
      month = '0' + month
    }
    let year = d.getFullYear();
    let strDate = year.toString().concat("-").concat(month)
    this.setQuantityAndDate(strDate);
    
  }

  setQuantityAndDate = (strDate) => {
    let quantityArray = [];
    let dateArray = [];
    let priceArray=[];
    let sellingPriceArray=[];
    let productArray=[];
    let platformArray=[];
    let filteredProducts = this.props.products.filter(product => product.order_created_date.includes(strDate))
    filteredProducts.map((product) => {
      productArray=[...productArray,product.item_name]
      platformArray=[...platformArray,product.platform]
      quantityArray = [...quantityArray, product.quantity]
      priceArray=[...priceArray,product.purchase_price]
      sellingPriceArray=[...sellingPriceArray,product.selling_price]
      dateArray = [...dateArray, product.order_created_date.substring(0, 10)]
    })
   
    this.setState({platform:platformArray, product:productArray, date: dateArray,quantity: quantityArray,purchasePrice: priceArray, sellingPrice:sellingPriceArray }) 
    

  }

  getMonthAndYear = (month, year) => {
    let d = new Date();
    let currentMonth = d.getMonth();
    currentMonth += 1;
    let currentYear = d.getFullYear();
    if(month>currentMonth && year==currentYear){
      this.setState({invalidDateMsg:'*Selected Date cannot be greater than than the current date.'})
    }
    else{
      this.setState({invalidDateMsg:''})
    }
    let strdate = year.toString().concat("-").concat(month);
    this.setQuantityAndDate(strdate);
  }

  render() {
    return (
      <div className="p-4 ">
          <div className="analytic-graph-D">
        <Dropdown getMonthAndYear={(month, year) => this.getMonthAndYear(month, year)} />
        </div>
        <div className="d-flex justify-content-around pt-4 mt-4">
        {this.state.invalidDateMsg &&  <div className="error-msg"><h3>{this.state.invalidDateMsg}</h3></div>}

        {this.state.quantity.length ? <ProductGraph platform={this.state.platform} product={this.state.product} quantity={this.state.quantity} date={this.state.date} /> :!this.state.invalidDateMsg && <h4 className="error-msg ">No data for the selected month and year of single uploaded products.</h4>}
        {/* {this.state.purchasePrice.length ? <PurchasePriceGraph platform={this.state.platform} product={this.state.product}  purchasePrice={this.state.purchasePrice} date={this.state.date} /> :!this.state.invalidDateMsg && <h4>No data for the selected month and year of single uploaded products.</h4>} */}
       {this.state.sellingPrice.length ? <SellingPriceGraph platform={this.state.platform} product={this.state.product} purchasePrice={this.state.purchasePrice} sellingPrice={this.state.sellingPrice} date={this.state.date} /> :!this.state.invalidDateMsg && <h4 className="error-msg ">No data for the selected month and year of single uploaded products.</h4>}
        
        </div>
      </div>
    )
  }
}
export default GraphData

