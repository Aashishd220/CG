import React from 'react'
import dynamic from 'next/dynamic'
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

class SellingPriceGraph extends React.Component {

  constructor(props) {
    super(props);
    this.state = {}
  }

  static getDerivedStateFromProps(props, state) {
    return {
    // series: [{
    //     name: "",
    //     data: props.sellingPrice,
    //     product:props.product,
    //     platform:props.platform
    // }],
    series: [{
      name: 'Selling Price',
      type: 'bar',
      data: props.sellingPrice,
      product:props.product,
      platform:props.platform
    }, {
      name: 'Purchase Price',
      type: 'bar',
      data: props.purchasePrice,
      product:props.product,
      platform:props.platform
    }],
    options: {   
      chart: {
        height: 350,
        type: 'area',
        zoom: {
          enabled: false
        }
      },
      plotOptions: {
        bar: {
          horizontal: false,
          startingShape: 'flat',
          endingShape: 'flat',
          columnWidth: props.product.length>5?'60%':props.product.length<=2?'20%':'60%',

          barHeight: '70%',
          distributed: false,
          rangeBarOverlap: true,
          rangeBarGroupRows: false,
          dataLabels: {
            position: 'center',  
            orientation:'vertical'          
          },
        
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth'
      },
      title: {
        text: '',
        align: 'center'
      },
      grid: {
        row: {
          colors: ['#f3f3f3', 'transparent'], 
          opacity: 0.5
        },
      },
      xaxis: {
        categories: props.date,
      },
      yaxis: [
        {
          title: {
            text: 'Selling Price',
          },
        },
        {
          opposite: true,
          title: {
            text: 'Purchase Price',
          },
        },
      ],
      fill: {
        type: 'gradient',
        colors: ['#6a82fb', '#00E38E'],
        gradient: {
          shade: 'dark',
          type: "horizontal",
          shadeIntensity: 0.5,
          gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
          inverseColors: true,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 50, 100],
          colorStops: []
        }
      },
      dataLabels: {
        style: {
          colors: ['#fff', '#fff']
        }
      },
      tooltip: {
        enabled: true, 
                 
        y: {
          formatter: function(value, opts) {
            return (
             
              'Name:  ' +
              opts.w.config.series[opts.seriesIndex].product[opts.dataPointIndex]+
              ', Platform:  ' +
              opts.w.config.series[opts.seriesIndex].platform[opts.dataPointIndex]+ 
              ', Selling Price: '+
              opts.series[opts.seriesIndex][opts.dataPointIndex] 
              
            )
          }
        }
        
      }
    }
    }
  }
  render() {
    return (
      <div className="ant-graph" >
        { this.state && <ReactApexChart options={this.state.options} series={this.state.series} type="bar" width={this.props.sellingPrice.length > 10 ? 850 : 600} height={350} />}
      </div>
    )
  }
}
export default SellingPriceGraph

