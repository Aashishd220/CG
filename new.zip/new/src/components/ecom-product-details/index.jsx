import React from "react";
import ComboGraphData from "./sections/ecom-combo-product-graph-data";
import GraphData from "./sections/ecom-product-graph-data";
const EcomProductView = ({ product,productCombo,sku,combo }) => {
  if(combo=="true"){
    return (
      <div className="page-body">
        <div className="container-fluid">
      
          <h1 className="pt-2">Product SKU:{sku}</h1>
          <ComboGraphData  comboProduct={productCombo.data} sku={sku}/>
        </div>
      </div>
    )
  }
  else{
  return (
      <div className="page-body">
        <div className="container-fluid">
          
          <h1 className="pt-2">Product SKU : {product.data[0].product_sku}</h1>
          <GraphData products={product.data}/>
        </div>
      </div>
  
  );
        }
}

export default EcomProductView
