import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as eCommerceActions from '../../redux/actions/ecommerce-actions'
import ComboTable from '../../shared/component/Combo-Table'
import Loader from "../loader";


const columnsCombo = [
    {
        title: 'Sku',
        dataIndex: 'products_sku',
        key: 'products_sku',
        width: '0%',
        isSearch: true
    },
    {
        title: 'Combo name',
        dataIndex: 'combo_names',
        key: 'combo_names',
        width: '20%',
        isSearch: true
    },
    {
        title: 'Product Name',
        dataIndex: 'combo_items',
        key: 'combo_items',
        width: '20%',
        isSearch: true
    },
    {
        title: 'Quantity',
        dataIndex: 'quantity',
        key: 'quantity',
    },
    {
        title: 'Selling Price',
        dataIndex: 'selling_price',
        key: 'selling_price',
    }
    ,
    {
        title: 'Platform',
        dataIndex: 'platform',
        key: 'platform',
    }
    ,
    {
        title: 'Purchase price',
        dataIndex: 'purchase_price',
        key: 'purchase_price',
    },
    {
        title: 'Date',
        dataIndex: 'insert_date',
        key: 'insert_date',
        isDate: true
    }
];
const EcomComboProducts = ({  ecomComboProduct, deleteEcommerceComboProduct, updateEcommerceComboProduct }) => {
    const [updatedComboProducts, setComboProducts] = useState(ecomComboProduct)
    const [loading,setLoading]=useState(false)

    useEffect(() => {
        setComboProducts(ecomComboProduct)
    }, [])

    const deleteComboProduct = async (id) => {
        setLoading(true);
        await deleteEcommerceComboProduct(id).then((res) => {
            const newList = updatedComboProducts.filter((product) => product.ID !== id);
            setComboProducts(newList)
            setLoading(false)    
        })

    }


    const handleComboDataChange = async (dataObject) => {
        setLoading(true);
        await updateEcommerceComboProduct(dataObject).then((res) => {
            var products = updatedComboProducts.map(product => {
                if (product.ID == dataObject.ID) return { ...dataObject }
                else { return product }
            });
            setComboProducts(products)  
        })
        setLoading(false)

    }

    return loading ? (
      <Loader />
    ) : (
      <div className="comboproduct-table">
        <div className="page-body">
          <div className="container-fluid">
            <h1>Combo Products</h1>
            <ComboTable
              isDelete={true}
              handleComboDataChange={(dataObject) =>
                handleComboDataChange(dataObject)
              }
              handleDeleteClick={(productId) => deleteComboProduct(productId)}
              columns={columnsCombo}
              data={updatedComboProducts}
            />
          </div>
        </div>
      </div>
    );
}

function mapStateToProps(state) {
    return {
        ...state.ecommerce
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...eCommerceActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(EcomComboProducts)

