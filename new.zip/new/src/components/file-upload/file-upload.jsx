import React, { useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as eCommerceActions from '../../redux/actions/ecommerce-actions'
import Link from 'next/link'
import Loader from "../loader";
import {
  Row,
  Col,
  Button, 
  Card,
  CardHeader, 
  CardBody,
  FormFeedback,
  FormGroup,
  FormText,
  Input,
  Label,

} from 'reactstrap';
const fileUpload = (props) => {

    const [singleFile, setFile] = useState("");
    const [comboFile, setComboFile] = useState("");
    const [successMessage, setSuccessMessage] = useState("");
    const [failureMessage, setFailureMessage] = useState("");
    const [loading,setLoading]=useState(false)

    const onFileChange = async (event) => {
        setSuccessMessage('')
        setFailureMessage('')
        setFile(event.target.files[0]);
    };

    const onComboFileChange = async (event) => {
        setSuccessMessage('')
        setFailureMessage('')
        setComboFile(event.target.files[0])

    };

    const onSingleFileUpload = async () => {
        setSuccessMessage('')
        setFailureMessage('')
        const data = new FormData()
        data.append('file', singleFile)
        {
            setLoading(true)
            singleFile && (await props.saveEcommerceProductsData(data).then((res) => {
                if (res.payload && res.payload.status == true) {
                    setSuccessMessage(res.payload.message)
                    setFile('')
                }
                else {
                    { res.payload ? setFailureMessage(res.payload) : setFailureMessage('Please select a file') }
                    setFile('')
                }

            }))
            setLoading(false)
        }
    };

    const onComboFileUpload = async () => {
        setSuccessMessage('')
        setFailureMessage('')
        const data = new FormData()
        data.append('file', comboFile)
        {
            setLoading(true)
            comboFile && (await props.saveEcommerceComboProductsData(data).then((res) => {
                if (res.payload && res.payload.status == true) {
                    setSuccessMessage(res.payload.message)
                    setComboFile('')
                }
                else {
                    { res.payload ? setFailureMessage(res.payload) : setFailureMessage('Please select a file') }
                    setComboFile('')
                }

            }))
        }
        setLoading(false)
    };

    return (loading)?(<Loader/>): (
        <div className="page-body upload-file pt-4 container-fluid">
        <Row>
          <Col className="file-formet">
            <Card className="mb-3">
              <CardHeader>Check the file format here</CardHeader>
              <CardBody>
                <Row> 
                  <Col xl={3} lg={6} md={6} sm={12} xs={12}>
                    <Card body>
                      <Button color="primary" size="lg" block>
                      <Link className="links" href="/files/single-products.xlsx" target="_blank" download> XLSX Single Products</Link>

                      </Button>
                    </Card>
                  </Col>
                  <Col xl={3} lg={6} md={6} sm={12} xs={12}>
                    <Card body>
                      <Button color="primary" size="lg" block>
                      <Link className="links" href="/files/single-products-csv.csv" target="_blank" download> CSV Single Products</Link>
       
                      </Button>
                    </Card>
                  </Col>
                  <Col xl={3} lg={6} md={6} sm={12} xs={12}>
                    <Card body>
                      <Button color="primary" size="lg" block>
                      <Link className="links" href="/files/combo-products.xlsx" target="_blank" download> XLSX Combo Products</Link>

                      </Button>
                    </Card>
                  </Col>
                  <Col xl={3} lg={6} md={6} sm={12} xs={12}>
                    <Card body>
                      <Button color="primary" size="lg" block>
                      <Link className="links" href="/files/combo-products-csv.csv" target="_blank" download> CSV Combo Products</Link>

                      </Button>
                    </Card>
                  </Col>
                </Row>
                <p className="notes-text"><span>*</span>You need to upload the correct format of the file, for refernce please download the samle format from above links</p>
              </CardBody>
            </Card>
          </Col>
        </Row>

        <Row>
          <Col className="file-formet uploadF">
            <Card className="mb-3">
              <CardHeader>Upload a file </CardHeader>
              <CardBody>
                <Row> 
                  <Col xl={6} lg={6} md={12} sm={12} xs={12}>
                    <Card body>
                    <div className="d-flex">
                    <FormGroup>               
                    <Input type="file" name="file" onChange={onFileChange}/>                  
                     </FormGroup>
                     <Button color="primary" size="lg"  onClick={onSingleFileUpload}>
                     Upload Single File
                      </Button>
                      </div>
                   
                    </Card>
                  </Col>
                  <Col xl={6} lg={6} md={12} sm={12} xs={12}>
                  <Card body>
                    <div className="d-flex">
                    <FormGroup>               
                    <Input type="file" name="file" onChange={onComboFileChange} />                  
                     </FormGroup>
                     <Button color="primary" size="lg" onClick={onComboFileUpload}>
                     Upload Combo File
                      </Button>
                      </div>
                   
                    </Card>
                  </Col>                
                
                </Row>
                <h2 className="succes-msg">{successMessage && (
                successMessage
            )}
            </h2>
            <p  className="error-msg">{failureMessage && (
                failureMessage
            )}
            </p>
              </CardBody>
            </Card>
          </Col>
        </Row>
       
          
        </div>
    )
}

function mapStateToProps(state) {
    return {
        ...state.ecommerce,
    };
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({ ...eCommerceActions }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(fileUpload)
