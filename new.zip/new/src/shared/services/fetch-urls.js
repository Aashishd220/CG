import Config from "../../config"

const GetProductCategories = (website) => {
    return Config._API + "/products/get-categories?website=" + website
};

const GetAllProductCount = () => {
    return Config._API + "/products/get-product-count"
};

const getUserData = () => {
    return Config._API + "/user"
};

const getUniqueEcomProductsData = () => {
    return Config._API + "/ecom/get-uniq-ecomm-products";
}

const getUniqueEcomComboProductsData = () => {
    return Config._API + "/ecom/get-unique-ecomm-combo-products";
}
const getEcomProductsDetails = (productSku) => {
    return Config._API + "/ecom/get-uniq-ecomm-products?product_sku=" + productSku;
}

const getEcomComboProductsDetails = (productSku) => {
    return Config._API + "/ecom/get-single-ecomm-combo-products?product_sku=" + productSku;
}

// returns all the uniq-ecom-seller
const getUniqueEcomSellerData = () => {
    return Config._API + "/ecom/get-uniq-ecomm-seller";
}

// returns the ecom data against a given seller(shop_id)
const getEcomSellerDetails = (shopId) => {
    return Config._API + "/ecom/get-uniq-ecomm-seller?shop=" + shopId;
}

// returns the ecom data for a specific product(product_sku) against a given seller(shop_id)
const getEcomSellerProductsDetails = (shopId, productSku) => {
    return Config._API + "/ecom/get-uniq-ecomm-seller?shop=" + shopId + "&product_sku=" + productSku;
}

const getAllRoles = () => {
    return Config._API + "/users/get-all-roles"
};

const getProductDetail = (productCode) => {
    return Config._API + "/products/get-product-data?code=" + productCode
};

const GetAllUsers = () => {
    return Config._API + "/user/get-all-users"
};

const GetFavoriteProducts = (category, brands) => {
    return Config._API + "/products/get-fav-products-details"
};

const GetEcomProducts = () => {
    return Config._API + "/ecom/get-ecom-products"
};

const GetEcomComboProducts = () => {
    return Config._API + "/ecom/get-ecom-combo-products"
};

const getNotificationDetail = (ID) => {
    return Config._API + "/user/get-notification?ID=" + ID;
};


const getDatafromExternalApi = () => {
    return Config._API + "/external-api/get-metrics-data-from-api?action=GetMetrics";
};

// const getOrdersDatafromExternalApi = ( ) => {
//     return Config._API + "/external-api/get-orders-data-from-api";
// };

const getProductsDatafromExternalApi = () => {
    return Config._API + "/external-api/get-products-data-from-api?action=GetProducts";
};

const getStatisticsfromExternalApi = () => {
    return Config._API + "/external-api/get-statistics-data-from-api?action=GetStatistics";
};


const getBestWorstProductsfromExternalApi = () => {
    return Config._API + "/external-api/get-best-worst-product-from-api?action=GetOrders";
};
export {
    GetProductCategories,
    GetAllProductCount,
    getUserData,
    getUniqueEcomProductsData,
    getUniqueEcomComboProductsData,
    getEcomProductsDetails,
    getUniqueEcomSellerData,
    getEcomSellerDetails,
    getEcomSellerProductsDetails,
    getAllRoles,
    getProductDetail,
    GetAllUsers,
    GetFavoriteProducts,
    getEcomComboProductsDetails,
    GetEcomProducts,
    GetEcomComboProducts,
    getNotificationDetail,
    getDatafromExternalApi,
    // getOrdersDatafromExternalApi,
    getProductsDatafromExternalApi,
    getStatisticsfromExternalApi,
    getBestWorstProductsfromExternalApi
}