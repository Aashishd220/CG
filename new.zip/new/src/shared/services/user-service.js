import { setCookie, removeCookie, getCookie } from '../services/cookies';

function isLoggedIn() {
	let token = getToken();
	return token && token != 'undefined';
}

function logOut() {
	if (typeof window == 'undefined')
		localStorage.removeItem('user');
	removeCookie('token');
}

function logIn(token, expiration) {
	setCookie('token', token, expiration);
}

function getToken() {
	let token = getCookie('token');
	if (token) {
		return token;
	}
	return undefined;
}

module.exports = {
	getToken,
	isLoggedIn,
	logOut,
	logIn
};
