import React from 'react'

class Dropdown extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            months: [{ month: 'Jan', val: '01' }, { month: 'Feb', val: '02' }, { month: 'Mar', val: '03' }, { month: 'Apr', val: '04' }, { month: 'May', val: '05' }, { month: 'Jun', val: '06' }, { month: 'Jul', val: '07' }, { month: 'Aug', val: '08' }, { month: 'Sep', val: '09' }, { month: 'Oct', val: '10' }, { month: 'Nov', val: '11' }, { month: 'Dec', val: '12' }],
            years: ['2020'],
            selectedMonth: '',
            selectedYear: ''
        };
    }
    componentDidMount() {
        let yearArray = [];
        let date = new Date();
        let year = date.getFullYear();
        let month=date.getMonth()+1;
        month='0'+month
        for (var i = 2019; i <= year; i++) {
            yearArray = [...yearArray, i];
        }
        this.setState({ years: yearArray })

        this.setState({ selectedMonth:month })
        this.setState({ selectedYear: year })
    }

    handleMonthChange = (event) => {
        this.setState({ selectedMonth: event.target.value });
    }

    handleYearChange = (event) => {
        this.setState({ selectedYear: event.target.value });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.props.getMonthAndYear(this.state.selectedMonth, this.state.selectedYear)
    }

    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <form onSubmit={this.handleSubmit} className="chart-dropdown">
                            <select value={this.state.selectedMonth} onChange={this.handleMonthChange}>
                                {this.state.months.map((month) => (
                                    <option key={month.month} value={month.val}>{month.month}</option>
                                ))}
                            </select>
                            <select value={this.state.selectedYear} onChange={this.handleYearChange}>
                                {this.state.years.map((year) => (
                                    <option key={year} value={year}>{year}</option>
                                ))}
                            </select>
                            <input type="submit" value="Submit" />
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}
export default Dropdown;