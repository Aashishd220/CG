import React, { Component } from "react";
import moment from "moment";
import { Button, Row, Col, DatePicker, Input, Form, InputNumber } from "antd";

class EditProductView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      order_created_date: moment(props.product.order_created_date).format('YYYY-MM-DD'),
      product_sku: props.product.product_sku,
      item_name: props.product.item_name,
      quantity: props.product.quantity,
      quantity_per_carton: props.product.quantity_per_carton,
      selling_price: props.product.selling_price,
      platform: props.product.platform,
      purchase_price: props.product.purchase_price,
      ID: props.product.ID
    };

    this.handleChange = this.handleChange.bind(this);
    this.onFinish = this.onFinish.bind(this);
  }

  handleChange(e) {
    e.preventDefault();
    const { name, value } = e.target;
    this.setState({ [name]: value })
  }

  onFinish = (values) => {
    values = { ...values, ID: this.state.ID, order_created_date: this.state.order_created_date }
    this.props.handleDataChange(values)

  };

  handleDatePickerChange = (date) => {
    const selectedDate = moment(date).format('YYYY-MM-DD')
    this.setState({ order_created_date: selectedDate })
  }

  render() {
    return (
      <div>
        <Form
          name="basic"
          initialValues={{
            remember: true,
          }}
          onFinish={this.onFinish}
        >
          <Row gutter={24}>
            <Col span={6}>
              <Form.Item
                label="Product Sku"
                name="product_sku"
                initialValue={this.state.product_sku}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please enter  product sku!',
                  },
                ]}
              >
                <InputNumber min={1} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Product Name"
                name="item_name"
                initialValue={this.state.item_name}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please input your item name!',
                  },
                ]}
              >
                <Input />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Quantity"
                name="quantity"
                initialValue={this.state.quantity}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please enter  quantity!',

                  },
                ]}
              >
                <InputNumber min={0} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Quantity(Carton)"
                name="quantity_per_carton"
                initialValue={this.state.quantity_per_carton}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please enter quantity per carton!',
                  },
                ]}
              >
                <InputNumber min={0} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Selling Price"
                name="selling_price"
                initialValue={this.state.selling_price}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please enter selling price!',

                  },
                ]}
              >
                <InputNumber min={1} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Platform"
                name="platform"
                initialValue={this.state.platform}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please enter platform!',
                  },
                ]}
              >
                <Input />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Purchase Price"
                name="purchase_price"
                initialValue={this.state.purchase_price}
                onChange={this.handleChange}
                rules={[
                  {
                    required: true,
                    message: 'Please enter purchase price!',

                  },
                ]}
              >
                <InputNumber min={1} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                label="Order Created Date"
                name="date"
                initialValue={moment(this.state.order_created_date)}
                rules={[
                  {
                    required: true,
                    message: 'Please select date!',
                  },
                ]}
              >
                <DatePicker onChange={this.handleDatePickerChange} />
              </Form.Item>
            </Col>
          </Row>
          <Form.Item>
            <Button type="primary" htmlType="submit"  >
              Submit
        </Button>
          </Form.Item>
        </Form>
      </div>
    );
  }
}
export default EditProductView
