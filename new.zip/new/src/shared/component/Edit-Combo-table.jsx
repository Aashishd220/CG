import React, { Component } from "react";
import moment from "moment";
import { Button, Select, Row, Col, message, DatePicker, Input, Form, Checkbox, InputNumber } from "antd";

class EditComboProductView extends Component {
    constructor(props) {
        super(props);
        this.state = {

            ID: props.product.ID,
            combo_items: props.product.combo_items,
            combo_names: props.product.combo_names,
            insert_date: moment(props.product.insert_date).format('YYYY-MM-DD'),
            platform: props.product.platform,
            products_sku: props.product.products_sku,
            purchase_price: props.product.purchase_price,
            quantity: props.product.quantity,
            selling_price: props.product.selling_price
        };

        this.handleChange = this.handleChange.bind(this);
        this.onFinish = this.onFinish.bind(this);
    }

    handleChange(e) {
        e.preventDefault();
        const { name, value } = e.target;
        this.setState({ [name]: value })
    }

    onFinish = (values) => {
        values = { ...values, ID: this.state.ID, insert_date: this.state.insert_date }
        this.props.handleComboDataChange(values)

    };

    handleDatePickerChange = (date, dateString) => {
        const selectedDate = moment(date).format('YYYY-MM-DD');
        this.setState({ insert_date: selectedDate })
    }

    render() {
        return (
            <div>
                <Form
                    name="basic"
                    initialValues={{
                        remember: true,
                    }}
                    onFinish={this.onFinish}
                >
                    <Row gutter={24}>
                        <Col span={6}>
                            <Form.Item
                                label="Products Sku"
                                name="products_sku"
                                initialValue={this.state.products_sku}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please enter  product sku!',
                                    },
                                ]}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Combo Name"
                                name="combo_names"
                                initialValue={this.state.combo_names}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your combo name!',
                                    },
                                ]}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Product Name"
                                name="combo_items"
                                initialValue={this.state.combo_items}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please enter  products name!',

                                    },
                                ]}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Quantity"
                                name="quantity"
                                initialValue={this.state.quantity}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please enter quantity!',
                                    },
                                ]}
                            >
                                <Input min={0} />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Selling Price"
                                name="selling_price"
                                initialValue={this.state.selling_price}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please enter selling price!',

                                    },
                                ]}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Platform"
                                name="platform"
                                initialValue={this.state.platform}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please enter platform!',
                                    },
                                ]}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Purchase Price"
                                name="purchase_price"
                                initialValue={this.state.purchase_price}
                                onChange={this.handleChange}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please enter purchase price!',

                                    },
                                ]}
                            >
                                <Input min={1} />
                            </Form.Item>
                        </Col>
                        <Col span={6}>
                            <Form.Item
                                label="Order Created Date"
                                name="date"
                                initialValue={moment(this.state.insert_date)}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please select date!',
                                    },
                                ]}
                            >
                                <DatePicker onChange={this.handleDatePickerChange} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Form.Item>
                        <Button type="primary" htmlType="submit"  >
                            Submit
        </Button>
                    </Form.Item>
                </Form>


            </div>
        );
    }
}
export default EditComboProductView