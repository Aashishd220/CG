import { Table, Input, Button, Space } from 'antd';
import Highlighter from 'react-highlight-words';
import { SearchOutlined } from '@ant-design/icons';
import EditComboProductView from "./Edit-Combo-table"
import moment from "moment";

export default class DataTable extends React.Component {
    state = {
        searchText: '',
        searchedColumn: '',
    };

    getColumnSearchProps = dataIndex => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
            <div style={{ padding: 8 }}>
                <Input
                    ref={node => {
                        this.searchInput = node;
                    }}
                    placeholder={`Search ${dataIndex}`}
                    value={selectedKeys[0]}
                    onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    onPressEnter={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                    style={{ width: 188, marginBottom: 8, display: 'block' }}
                />
                <Space>
                    <Button
                        type="primary"
                        onClick={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                        icon={<SearchOutlined />}
                        size="small"
                        style={{ width: 90 }}
                    >
                        Search
          </Button>
                    <Button onClick={() => this.handleReset(clearFilters)} size="small" style={{ width: 90 }}>
                        Reset
          </Button>
                </Space>
            </div>
        ),
        filterIcon: filtered => <SearchOutlined style={{ color: filtered ? '#1890ff' : undefined }} />,
        onFilter: (value, record) =>
            record[dataIndex]
                ? record[dataIndex].toString().toLowerCase().includes(value.toLowerCase())
                : '',
        onFilterDropdownVisibleChange: visible => {
            if (visible) {
                setTimeout(() => this.searchInput.select(), 100);
            }
        },
        render: text =>
            this.state.searchedColumn === dataIndex ? (
                <Highlighter
                    highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
                    searchWords={[this.state.searchText]}
                    autoEscape
                    textToHighlight={text ? text.toString() : ''}
                />
            ) : (
                    text
                ),
    });

    handleSearch = (selectedKeys, confirm, dataIndex) => {
        confirm();
        this.setState({
            searchText: selectedKeys[0],
            searchedColumn: dataIndex,
        });
    };

    handleReset = clearFilters => {
        clearFilters();
        this.setState({ searchText: '' });
    };

    _bindColumns = () => {
        let columns = []
        this.props.columns.map((column, index) => {
            if (column.isSearch) {
                const col =
                {
                    title: column.title,
                    dataIndex: column.dataIndex,
                    key: column.key,
                    width: column.width,
                    ...this.getColumnSearchProps(column.key),
                }

                columns.push(col)
            } else if (column.isDate) {
                const col =
                {
                    title: column.title,
                    dataIndex: column.dataIndex,
                    key: column.key,
                    width: column.width,
                    render: (text, product) => (
                        moment(product.insert_date).format('YYYY-MM-DD')
                    )
                }
                columns.push(col)
            }
            else {
                columns.push(column)
            }

        })
        if (this.props.isDelete) {
            columns.push({
              title: "",
              dataIndex: "ID",
              key: "ID ",
              render: (text, product) => (
                <Button
                  onClick={(e) => {
                    this.props.handleDeleteClick(product.ID, e);
                  }}
                  className="ant-btn  transhbtn"
                >
                  <i class="fa fa-trash" aria-hidden="true"></i>
                </Button>
              ),
            });
        }

        return columns
    }

    render() {
        return <Table
            columns={this._bindColumns()}
            dataSource={this.props.data}
            rowKey="ID"
            expandedRowRender={product => (
                <EditComboProductView
                    product={product} handleComboDataChange={(dataObject) => this.props.handleComboDataChange(dataObject)}
                />
            )}

        />;
    }
}
