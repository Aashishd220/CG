import React from 'react'

class YearDropDown extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            years: ['2018'],
            selectedYear: ''
        };
    }
    componentDidMount() {
        let yearArray = [];
        let date = new Date();
        let year = date.getFullYear();
        for (var i = 2018; i <= year; i++) {
            yearArray = [...yearArray, i];
        }
        this.setState({ years: yearArray })
        this.setState({ selectedYear: year })
    }


    handleYearChange = (event) => {
        this.setState({ selectedYear: event.target.value });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.props.getYear( this.state.selectedYear)
    }

    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <form onSubmit={this.handleSubmit} className="chart-dropdown">      
                            <select value={this.state.selectedYear} onChange={this.handleYearChange}>
                                {this.state.years.map((year) => (
                                    <option key={year} value={year}>{year}</option>
                                ))}
                            </select>
                            <input type="submit" value="Submit" />
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}
export default YearDropDown;