import React from 'react'

class WebsitesDropdown extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            websites: ['jumia.com.ng', 'jumia.co.ke', 'jumia.com.gh'],
            selectedWebsite: 'jumia.com.ng'
        }
    }
  
    handleChange=(event)=> {
        this.setState({ selectedWebsite: event.target.value });
        this.props.handleWebsiteChange(event.target.value)

    }

    handleSubmit=(event) =>{
        event.preventDefault();
    }
    render() {
        return (
            <div className="chart-dropdown pt-2 pr-4 mr-4">    
                    <select value={this.state.selectedWebsite} onChange={this.handleChange}>
                       
                        {this.state.websites.map((website) => (
                            <option key={website} value={website}>{website}</option>
                        ))}
                    </select>
            </div>
        )
    }
}

export default WebsitesDropdown