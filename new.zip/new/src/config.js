module.exports = {
    _API: process.env.API ? process.env.API : 'http://localhost:8081',
};
