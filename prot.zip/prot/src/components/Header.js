import React from "react";
import "../style/header.css";
const Header = () => {
  return (
      <div>
    <header>
      <div className="container d-flex justify-content-between align-items-center">
        <h1>Rani Lakshmi Bai</h1>
      
        <ul className="navbar-nav navbar-expand-lg main-nav">
          <li className="nav-item p-4">ABOUT</li>
          <li className="nav-item p-4">SKILLS</li>
          <li className="nav-item p-4">PROJECT</li>
          <li className="nav-item p-4">EXPERIENCE</li>
          <li className="nav-item p-4">CONTACT</li>
        </ul>
      
        {/* <nav className="navbar navbar-expand-lg "> */}
       
        {/* </nav> */}
      </div>
    </header>
    <section className=" banner  d-flex align-items-center">
        
        </section>
</div>
  );
};

export default Header;
