import React from 'react'

function Skills() {
    return (
        <div>
            Skills
        </div>
    )
}

export default Skills
