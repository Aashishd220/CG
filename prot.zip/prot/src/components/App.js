import React from 'react'
import Header from './Header'
import Projects from './Projects'
import Experience from './Experience'
import Contact from './Contact'
import Skills from './Skills'
// import {BrowserRouter, Route} from 'react-router-dom'

const App=()=> {
    return (
        <div>
            <Header/>
            <Skills/>
            <Projects/>
            <Experience/>
            <Contact/>
        </div>
    )
}

export default App
