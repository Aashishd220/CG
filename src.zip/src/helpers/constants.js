import Img1 from "../assets/images/activity/2133.png";
import Img2 from "../assets/images/activity/33580.png";
import Img3 from "../assets/images/activity/OQ1YBG0.png";
import Img4 from "../assets/images/activity/1213.png";
import Img5 from "../assets/images/activity/362.png";
import Img6 from "../assets/images/activity/1480.png";
import Img7 from "../assets/images/activity/9745.png";
import Img8 from "../assets/images/activity/5.png";
import Img9 from "../assets/images/activity/984.png";
import Img10 from "../assets/images/activity/948.png";
import Img11 from "../assets/images/activity/3155.png";
import Img12 from "../assets/images/activity/33580.png";
import Img13 from "../assets/images/activity/393.png";
import Img14 from "../assets/images/activity/121.png";
import Img15 from "../assets/images/activity/1928.png";
import Img16 from "../assets/images/activity/2388.png";
import Img17 from "../assets/images/activity/10.png";
import Img18 from "../assets/images/activity/1094.png";
import Img19 from "../assets/images/activity/11.png";

// Constants
export const GOOGLE = "google";
export const LOGIN = "login";
export const REGISTER = "register";
export const FACEBOOK = "facebook";

// Messages
export const VERIFY_EMAIL =
  "Please verify your email address we have send verification to your registered email address.";
export const ACCOUNT_SUSPENDED =
  "Your account is suspended please contact Expeditions Support";

export const ToolBarOptions = {
  options: ["list", "inline"],
  inline: {
    options: ["bold", "italic", "underline", "strikethrough"],
  },
  list: {
    options: ["unordered"],
  },
};

export const quillModules = {
  toolbar: [["bold", "italic", "underline"], [{ list: "bullet" }]],
};

export const quillFormats = ["bold", "italic", "underline", "list", "bullet"];

export const expertiseList = [
  {
    id: 1,
    name: "Bird Photographer",
  },
  {
    id: 2,
    name: "Wildlife Photographer",
  },
  {
    id: 3,
    name: "Outdoor Photographer",
  },
  {
    id: 4,
    name: "Wildlife Filmmaker",
  },
  {
    id: 5,
    name: "Wildlife Photographer and Filmmaker",
  },
  {
    id: 6,
    name: "Nature Guide",
  },
  {
    id: 7,
    name: "Birder",
  },
  {
    id: 8,
    name: "Diving Instructor",
  },
  {
    id: 9,
    name: "Oceanographer",
  },
  {
    id: 10,
    name: "Adventure Guide",
  },
  {
    id: 11,
    name: "Rock Climbing Guide",
  },
  {
    id: 12,
    name: "Alpine Guide",
  },
  {
    id: 13,
    name: "Mountain Guide",
    icon: "mountainbike",
    isFeatured: true,
  },
  {
    id: 14,
    name: "Outdoor Instructor",
  },
  {
    id: 15,
    name: "Mountaineering Instructor"
  },
  {
    id: 16,
    name: "Ski and Snowboard Instructor",
  },
  {
    id: 17,
    name: "Snowboard Instructor",
  },
  {
    id: 18,
    name: "Ski Instructor",
  },
  {
    id: 19,
    name: "Researcher",
  },
  {
    id: 20,
    name: "Conservationist",
  },
  {
    id: 21,
    name: "Scientists",
  },
  {
    id: 22,
    name: "Biologists",
  },
  {
    id: 23,
    name: "Journalist",
  },
  {
    id: 24,
    name: "Social Worker",
  },
  {
    id: 25,
    name: "Wildlife and Conservation Photographer",
  },
  {
    id: 26,
    name: "Kayak Coach",
  },
  {
    id: 27,
    name: "Sea Kayaker",
  },
  {
    id: 28,
    name: "Mountain Bike Expert",
  },
  {
    id: 29,
    name: "Mountain Biking Guide",
  },
  {
    id: 31,
    name: "Canoeing Instructor",
  },
  {
    id: 32,
    name: "Cycling Coach",
  },
  {
    id: 33,
    name: "Others",
  },
];

export const Triptype = [
  {
    id: 1,
    name: "Active",
  },
  {
    id: 2,
    name: "Family",
  },
  {
    id: 3,
    name: "Journeys",
  },
  {
    id: 4,
    name: "Private Expedition",
  },
  {
    id: 5,
    name: "Private Jet",
  },
  {
    id: 6,
    name: "River",
  },
  {
    id: 7,
    name: "Expedition Cruise",
  },
  {
    id: 8,
    name: "Signature Land",
  },
  {
    id: 9,
    name: "Train",
  },
];

export const ActivityList = [
  {
    id: 0,
    name: "Rock Climbing",
    url: Img1,
    checked: false,
  },
  {
    id: 1,
    name: "Mountaineering",
    url: Img2,
    checked: false,
    icon: "mountaineering",
    isFeatured: true,
  },
  {
    id: 2,
    name: "Trekking",
    url: Img3,
    checked: false,
  },
  {
    id: 3,
    name: "Skiing",
    url: Img4,
    checked: false,
  },
  {
    id: 4,
    name: "Off piste skiing",
    url: Img5,
    checked: false,
  },
  {
    id: 5,
    name: "Ski Touring",
    url: Img6,
    checked: false,
    icon: "ski",
    isFeatured: true,
  },
  {
    id: 6,
    name: "Via Ferrata",
    url: Img7,
    checked: false,
  },
  {
    id: 7,
    name: "Alpinism",
    url: Img8,
    checked: false,
  },
  {
    id: 8,
    name: "Ice climbing",
    url: Img9,
    checked: false,
  },
  {
    id: 9,
    name: "Hiking",
    url: Img10,
    checked: false,
  },
  {
    id: 10,
    name: "Camping",
    url: Img11,
    checked: false,
  },
  {
    id: 11,
    name: "Caving",
    url: Img12,
    checked: false,
  },
  {
    id: 12,
    name: "Backpacking",
    url: Img13,
    checked: false,
  },
  {
    id: 13,
    name: "Conservation",
    url: Img14,
    checked: false,
  },
  {
    id: 14,
    name: "Nature & Wildlife",
    url: Img15,
    checked: false,
  },
  {
    id: 15,
    name: "Skiing, Snowboarding",
    url: Img16,
    checked: false,
  },
  {
    id: 16,
    name: "Birdwatching",
    url: Img17,
    checked: false,
  },
  {
    id: 17,
    name: "Safari",
    url: Img18,
    checked: false,
  },
  {
    id: 18,
    name: "Wildlife Photography and Filmmaking",
    url: Img19,
    checked: false,
  },
  {
    id: 19,
    name: "Fishing",
    url: Img19,
    checked: false,
  },
  {
    id: 20,
    name: "Fly Fishing",
    url: Img19,
    checked: false,
  },
  {
    id: 21,
    name: "Scuba-Diving",
    url: Img19,
    checked: false,
    icon: "scubadiving",
    isFeatured: true,
  },
  {
    id: 22,
    name: "Snorkelling",
    url: Img19,
    checked: false,
  },
  {
    id: 23,
    name: "Spearfishing",
    url: Img19,
    checked: false,
  },
  {
    id: 24,
    name: "Underwater Photography",
    url: Img19,
    checked: false,
  },
  {
    id: 25,
    name: "Rafting",
    url: Img19,
    checked: false,
  },
  {
    id: 26,
    name: "Sailing",
    url: Img19,
    checked: false,
  },
  {
    id: 27,
    name: "Rowing",
    url: Img19,
    checked: false,
  },
  {
    id: 28,
    name: "Surfing",
    url: Img19,
    checked: false,
    icon: "ski",
    isFeatured: true,
  },
  {
    id: 29,
    name: "Canoeing",
    url: Img19,
    checked: false,
  },
  {
    id: 30,
    name: "Motorbike",
    url: Img19,
    checked: false,
  },
  {
    id: 31,
    name: "Cycling",
    url: Img19,
    checked: false,
  },

  {
    id: 31,
    name: "Mountain Biking",
    url: Img19,
    checked: false,
    icon: 'mountainbike',
    isFeatured: true,
  },
  {
    id: 32,
    name: "Cultural and Archeological Expedition",
    url: Img19,
    checked: false,
  },
  {
    id: 33,
    name: "Wildlife Photography",
    url: Img19,
    checked: false,
    icon: "wildphoto",
    isFeatured: true
  },
  {
    id: 34,
    name: "Wildelife Filmmaking",
    url: Img19,
    checked: false,
  },
  {
    id: 35,
    name: "Avalanche Safety",
    url: Img19,
    checked: false,
  },
  {
    id: 37,
    name: "Kayaking",
    url: Img19,
    checked: false,
  },
  {
    id: 38,
    name: "Windsurfing",
    url: Img19,
    checked: false,
  },
  {
    id: 39,
    name: "Kitesurfing",
    url: Img19,
    checked: false,
  },
  {
    id: 36,
    name: "Others",
    url: Img19,
    checked: false,
  },
];

export const SuitableFor = [
  {
    name: "All",
    value: "all",
  },
  {
    name: "Solo",
    value: "individuals",
  },
  {
    name: "Couples",
    value: "couples",
  },
  {
    name: "Families",
    value: "families",
  },
  {
    name: "Groups",
    value: "groups",
  },
  {
    name: "Friends",
    value: "friends",
  },
];

export const InterestedList = [
  {
    id: 1,
    name: "Adventure Learning and Education",
  },
  {
    id: 2,
    name: "Adventure Experiences",
  },
  {
    id: 3,
    name: "Networking with like-minded people",
  },
  {
    id: 4,
    name: "Connecting with Experts",
  },
  {
    id: 5,
    name: "Events and Talks",
  },
  {
    id: 6,
    name: "Others",
  }
];

export const DifficultyList = [
  {
    name: "Light",
    value: "0",
  },
  {
    name: "Moderate",
    value: "25",
  },
  {
    name: "Difficult",
    value: "50",
  },
  {
    name: "Tough",
    value: "75",
  },
  {
    name: "All",
    value: "100",
  }
];

export const SkillsList = [
  {
    name: "Beginner",
    value: "0",
  },
  {
    name: "Medium",
    value: "33",
  },
  {
    name: "Advanced",
    value: "66",
  },
  {
    name: "All",
    value: "100",
  }
];


export const DISPLAY_RESULT = parseInt(12);
export const DISPLAY_PER_PAGE = parseInt(30);
export const DISPLAY_PER_PAGE_MOBILE = parseInt(5);


export const FILE_SIZE = {
  EXPERT_COVER: 200,
  ERR_EXPERT_COVER: "Cover picture can not bigger than 200 MB.",

  EXPERT_PROFILE: 50,
  ERR_EXPERT_PROFILE: "Profile picture can not bigger than 50 MB.",

  TRIP_WORKSHOP_COVER: 200,
  ERR_TRIP_WORKSHOP_COVER: "Cover picture can not bigger than 200 MB.",

  ALBUM: 500,
  ERR_ALBUM: "Max. upload limited of 500 MB has reached.",

  ENTHU_PROFILE: 50,
  ERR_ENTHU_PROFILE: "Profile picture can not bigger than 50 MB.",
};


export const PAGINATION_OPTIONS = [30, 50, 100]
export const BLOG_URL = "https://blog.expeditionsconnect.com/";
export const ABOUTUS_URL = "https://blog.expeditionsconnect.com/about-us/";

// This function will return the sentence for no record found message based on type
// Function Name: notFound
// Function Parameters
// Created By : Ravi Khunt
// Parameter | Required | Description
// ----------------------------------------------------------------------------------------------
// type          YES		  trip, workshop 
// lableType     YES		  itineary, acomodation, extra, inclusionExclusion

export const notFound = (type, lableType) => {
  let res = "";
  if (lableType === "acomodation") {
    res = "No Accommodation exists for this " + type + ".";
  } else if (lableType === "extra") {
    res = "No Additional details found for this " + type + "."
  } else if (lableType === "itineary") {
    res = "No Itinerary exists for this " + type + "."
  } else if (lableType === "inclusionExclusion") {
    res = "No details found" + ".";
  }
  return res;
};
