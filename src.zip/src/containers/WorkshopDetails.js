import React, { useEffect, useCallback, useState, Fragment } from "react";
import {
  Row,
  Col,
  List,
  Avatar,
  Radio,
  Form,
  Card,
  Menu,
  message,
  Button,
} from "antd";
import { Link } from "react-router-dom";
import ReactHtmlParser from "react-html-parser";
import { useSelector } from "react-redux";
import OwlCarousel from "react-owl-carousel";

// Image Import
import Location_Img from "../assets/images/country_ic.png";
import Skill from "../assets/images/skill_ic_filled.png";
import Star from "../assets/images/men.png";
import Participate from "../assets/images/participants_ic_filled.png";

import Clock from "../assets/images/duration_ic_filled.png";
import Activity from "../assets/images/activity_ic_filled.png";
import Speak from "../assets/images/speaks_ic.png";

import Lang from "../assets/images/followers_ic.png";
import { GetLearningDetails, getSimilarLearnings } from "../services/expert";
import {
  CaptalizeFirst,
  formatDate,
  removeNewLines,
  commaSepratorString,
  DayorDaysNightOrNights,
  getCityFromLocation,
  skillLevelText,
  getCurrencySymbol,
} from "../helpers/methods";
import TripMap from "../components/Trips/Map";
import {
  FacebookShareButton,
  TwitterShareButton,
  WhatsappShareButton,
} from "react-share";

import Facebook from "../assets/images/fb_ic.png";
import WhatsApp from "../assets/images/whatsapp_ic.png";
import Twitter from "../assets/images/twitter_ic.png";

import Reservation from "../components/Trips/Reservation";
import Interested from "../components/Trips/Interested";
import Cancellation from "../components/Trips/Cancellation";
import MoreDetails from "../components/Learning/Moredetails";

import AccommodationPhotoViewPopup from "../components/Trips/AccommodationPhotoView";

import AppLoader from "../components/Loader";
import ReactPlayer from 'react-player';
import TripWorkshopAllCardsCarousel from "../components/common/TripWorkshopAllCardsCarousel";
import LikeAndShare from "../components/common/Likeandshare";



const ApiKey = process.env.REACT_APP_GOOGLE_MAP_API_KEY;
const URL =
  "http://expeditions-connect-app.s3-website.eu-central-1.amazonaws.com";


// Header Section
const data = [
  {
    title: "Location",
    title3: "Duration",
    title2: "Difficulty level",
    title4: "Activity",
    title5: "Expedition Type",
  },
];

// const expeditionsOptions = {
//   items: 5,
//   nav: true,
//   loop: false,
//   responsiveClass: true,
//   responsive: {
//     0: {
//       items: 1,
//       nav: true,
//       dots: false,
//     },
//     768: {
//       items: 2,
//       nav: true,
//       dots: false,
//     },
//     991: {
//       items: 3,
//       nav: true,
//       dots: false,
//     },
//   },
// };

const sliderOptions = {
  margin: 10,
  nav: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dotsEach: 3,
    },
    768: {
      items: 2,
      nav: true,
    },
    991: {
      items: 3,
      nav: true,
    },
  },
};

const WorkShopDetails = (props) => {
  const {
    match: {
      params: { id },
    },
  } = props;
  const [showContent, setShowContent] = useState(false);
  const [learning, setLearning] = useState(null);
  const [similarLearning, setSimilarLearnings] = useState(null);
  const [similarLoader, setSimilarLoader] = useState(false);
  const [slot, setSlot] = useState(null);
  const [showR, setShowR] = useState(false);
  const [showInterest, setShowInterest] = useState(false);
  const [showCanc, setShowCanc] = useState(false);
  const isLogin = useSelector((state) => state.auth.isLogin);
  const role = useSelector((state) => state.auth.role);
  const [datePrice, setDatePrice] = useState("");
  const [datePriceCurrency, setDatePriceCurrency] = useState("");
  const [moreDetail, setMoreDetails] = useState(false);
  const [
    accommodationPhotoViewPopup,
    setAccommodationPhotoViewPopup,
  ] = useState(false);
  const [currentViewImage, setCurrentViewImage] = useState(0);
  const [currentPhotoView, setCurrentPhotoView] = useState("accomo");
  const [currentDateType, setCurrentDateType] = useState(1); //1=Date, 2=Flexi Date

  const onCloseClick = () => {
    setShowR(false);
    setShowCanc(false);
    setMoreDetails(false);
    setAccommodationPhotoViewPopup(false);
  };
  const onInstCloseClick = () => setShowInterest(false);

  const onReserveClick = () => {
    if (!slot && currentDateType === 1) {
      return message.error(
        "Please select date slot to make reservation request"
      );
    }

    if (isLogin) {
      if (role !== "enthusiasts") {
        return message.error(
          "You must be logged in as enthusiasts to send request"
        );
      }
      setShowR(true);
    } else {
      message.error("Please login to make reservation request");
    }
  };

  const selectDate = (date, price, priceCurrency) => {
    setSlot(date);
    setDatePrice(price);
    setDatePriceCurrency(priceCurrency);
  };

  const onIntseretClick = () => {
    if (isLogin) {
      if (role !== "enthusiasts") {
        return message.error(
          "You must be logged in as enthusiasts to send request"
        );
      }
      setShowInterest(true);
    } else {
      message.error("Please login to make reservation request");
    }
  };

  const menu = (
    <Menu className="share_btn_box">
      <Menu.Item>
        <FacebookShareButton url={`${URL}/learning-details/${id}`}>
          <img src={Facebook} alt="facebook" className="pr10" />
          Facebook
        </FacebookShareButton>
      </Menu.Item>
      <Menu.Item>
        <WhatsappShareButton url={`${URL}/learning-details/${id}`}>
          <img src={WhatsApp} alt="twitter" className="pr10" />
          WhatsApp
        </WhatsappShareButton>
      </Menu.Item>
      <Menu.Item>
        <TwitterShareButton
          url={`${URL}/trips-details/${id}`}
          style={{ border: "none" }}
        >
          <img src={Twitter} alt="twitter" className="pr10" />
          Twitter
        </TwitterShareButton>
      </Menu.Item>
    </Menu>
  );

  const getData = useCallback(async (id) => {
    const result = await GetLearningDetails(id);
    if (result.status === 200) {
      setShowContent(true);
      let learningRes = result.data.data;

      learningRes.inclusion = removeNewLines(learningRes.inclusion);
      learningRes.exclusion = removeNewLines(learningRes.exclusion);

      if (typeof learningRes.accomodation === "undefined" || learningRes.accomodation.trim() === "<p><br></p>" || learningRes.accomodation === "") {
        learningRes.accomodation = ""
      }

      if (typeof learningRes.meetingPoint === "undefined" || learningRes.meetingPoint === "null") {
        learningRes.meetingPoint = "";
      }

      if (typeof learningRes.itenary === "undefined" || (typeof learningRes.itenary !== "undefined" && learningRes.itenary.length > 0 && (typeof learningRes.itenary[0].value === "undefined" || learningRes.itenary[0].value === ""))) {
        learningRes.itenary = [];
      }

      if (typeof learningRes.extras === "undefined" || learningRes.extras.trim() === "<p><br></p>" || learningRes.extras.trim() === "null" || learningRes.extras === "") {
        learningRes.extras = "";
      }

      setCurrentDateType(learningRes.dateType)

      setLearning(learningRes);
    }
    const data = { activity: JSON.stringify(result.data.data.activity) };
    const st = await getSimilarLearnings(data);
    if (st.status === 200) {

      setSimilarLearnings(st.data.data);
      setSimilarLoader(true);
      setDatePrice(st.data.data.price);
    }
  }, []);

  useEffect(() => {
    getData(id);
  }, [getData, id]);

  const onAccommoImageClick = (index, view) => {
    setCurrentPhotoView(view);
    setCurrentViewImage(index);
    setAccommodationPhotoViewPopup(true);
  };

  const onClickDate = (d) => {
    if (isLogin) {
      if (role !== "enthusiasts") {
        return message.error(
          "You must be logged in as enthusiasts to send request"
        );
      }

      selectDate(d.fromDate, d.price, d.priceCurrency);
      setShowR(true);
    } else {
      message.error("Please login to make reservation request");
    }
  };

  const displayLang = (lang) => {
    let resLang = "";
    if (lang.length > 0) {
      lang.map((a, index) => {
        let addCooma = "";
        if (lang.length !== index + 1) {
          addCooma = ", ";
        }
        resLang += CaptalizeFirst(a) + addCooma;
      });
    }

    return resLang;
  };

  if (showContent && learning) {
    return (
      <div className="header-container w_bg workshop_view_edit_page workshop_mobile_view">
        <div
          className="gallery_bg"
          style={{ backgroundImage: `url(${learning.cover})` }}
        ></div>
        <div className="container align-center">
          <div className="expedition_bg">
            <div className="gallery_sec fix_to_top">
              <Row gutter={20}>
                <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                  <h1 className="an-36 medium-text text_skill cover-img-main-title fw-600">
                    {CaptalizeFirst(learning.title)}
                  </h1>
                  {(learning.country !== 'undefined' && learning.country !== "") && (
                    <h4 className="an-18 medium-text work_title trip_border_btm fw-600">
                      <Avatar src={Location_Img} />{" "}
                      {getCityFromLocation(learning.address)}
                      {CaptalizeFirst(learning.country)}
                    </h4>
                  )}
                  {learning.workshopMedium === "online" && (
                    <h4 className="an-18 medium-text work_title trip_border_btm fw-600">
                      <Avatar src={Location_Img} /> Online
                    </h4>
                  )}
                </Col>
                <Col
                  xs={24}
                  sm={24}
                  md={16}
                  lg={16}
                  xl={16}
                  className="cover_img_data cover-img-icon"
                >
                  <Row gutter={20}>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Clock} />}
                              title="Duration"
                              description={`${
                                learning.duration
                                } ${DayorDaysNightOrNights(
                                  "w",
                                  learning.duration,
                                  learning.durationType
                                )}`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={10} lg={10} xl={10}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Activity} />}
                              title="Activity"
                              description={commaSepratorString(
                                learning.activity
                              )}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Speak} />}
                              title="Languages"
                              description={displayLang(learning.langauges)}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar
                                  src={Skill}
                                  className="pl5 fill-width"
                                />
                              }
                              title="Skills Level"
                              description={skillLevelText(learning.skill)}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={10} lg={10} xl={10}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar src={Star} className="pl5 fill-width" />
                              }
                              title="Workshop Type"
                              description={learning.workshopType}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar
                                  src={Participate}
                                  className="pl5 fill-width"
                                />
                              }
                              title="Group Size"
                              description={`Upto ${learning.participants} People`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                  </Row>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8} xl={8} className="trip_reser_card">
                  <div className='date_sec br5'>
                    <Row className="header_per_txt work-trip-detail-page">
                      <Col span={13}>
                        <h2 className="an-30 medium-text mb10">
                          {getCurrencySymbol(
                            datePriceCurrency || learning.priceCurrency
                          )}{" "}
                          {datePrice || learning.price}
                        </h2>
                        <p className="mb10 an-14 medium-text">Per Person</p>
                      </Col>
                      <LikeAndShare allLikes={learning.likes} id={learning._id} pageType={"workshop"} designType="single"/>
                      {/* <Col span={4}>
                        <div className="share_btn">
                          <Dropdown overlay={menu} placement="topLeft">
                            <img alt="share" src={Share} />
                          </Dropdown>
                        </div>
                      </Col>
                      <Col span={4}>
                        <div className="share_btn">
                          <img alt="share_heart" src={Heart} />
                        </div>
                      </Col> */}
                    </Row>
                    <Row>
                      <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                        <div className="select_date mt10">
                          {learning.dateTime.length > 0 ? (
                            <Fragment>
                              <p className="an-14 medium-text pt10 fill-width">
                                Select Date
                              </p>
                              {learning.dateTime.length > 3 && (
                                <Button
                                  type="primary"
                                  htmlType="submit"
                                  className="trip_more_detail"
                                  onClick={() => setMoreDetails(true)}
                                >
                                  More Dates
                                </Button>
                              )}
                            </Fragment>
                          ) : (
                              <p className="an-14 medium-text pb10 fill-width flexible-txt">
                                This workshop has flexible dates. Please contact
                                expert for more information.
                            </p>
                            )}
                        </div>
                      </Col>
                      <Col>
                        {learning.dateTime.length > 0 && (
                          <Row className="trip_date_group">
                            <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                              <Form.Item>
                                <Radio.Group initialValue={0}>
                                  {learning.dateTime.map((d, i) => {
                                    if (i === 0 || i === 1 || i === 2) {
                                      return (
                                        <Radio.Button
                                          key={d._id}
                                          value={i}
                                          onClick={() =>
                                            selectDate(
                                              d.fromDate,
                                              d.price,
                                              d.priceCurrency
                                            )
                                          }
                                        >
                                          {formatDate(d.fromDate)}
                                        </Radio.Button>
                                      );
                                    } else {
                                      return null;
                                    }
                                  })}
                                </Radio.Group>
                              </Form.Item>
                            </Col>
                          </Row>
                        )}
                        <div className="btn_head">
                          <span
                            onClick={onIntseretClick}
                            className="yellow_btn mr10 cursor-pointer"
                          >
                            I’m Interested
                          </span>
                          <span
                            onClick={onReserveClick}
                            className="green_btn cursor-pointer"
                          >
                            Reserve
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </div>
                </Col>
              </Row>
            </div>
            <Row gutter={20} className="pt60 trip_view_edit_detail">
              <Col
                className="trip_desc_detail justify "
                xs={24}
                sm={24}
                md={16}
                lg={16}
                xl={16}
              >
                <Row>
                  <Col span={24}>
                    <h3 className=" an-22 medium-text pb10 workshop_detail_txt">
                      Workshop Details
                    </h3>
                  </Col>
                  <Col span={20}>
                    <div className="trip_detail_des">
                      <h4 className="medium-text an-18">About This Workshop</h4>
                    </div>
                  </Col>
                </Row>

                <div className="trip_detail_des editor_text_display">
                  <span className="lh-30">
                    {learning.description &&
                      learning.description.trim() !== "null"
                      ? ReactHtmlParser(learning.description)
                      : ""}
                  </span>
                </div>

                {learning.whatLearn && learning.whatLearn.trim() !== "null" ? (
                  <>
                    <Row>
                      <Col span={20}>
                        <div className="trip_detail_des">
                          <h4 className="medium-text an-18">
                            What will you learn ?
                          </h4>
                        </div>
                      </Col>
                    </Row>

                    <div className="trip_detail_des editor_text_display">
                      <span className="lh-30">
                        {learning.whatLearn &&
                          learning.whatLearn.trim() !== "null"
                          ? ReactHtmlParser(learning.whatLearn)
                          : ""}
                      </span>
                    </div>
                  </>
                ) : (
                    ""
                  )}

                {learning.attend && learning.attend.trim() !== "null" ? (
                  <>
                    <Row>
                      <Col span={20}>
                        <div className="trip_detail_des">
                          <h4 className="medium-text an-18">
                            Who should attend ?
                          </h4>
                        </div>
                      </Col>
                    </Row>

                    <div className="trip_detail_des editor_text_display">
                      <span className="lh-30">
                        {learning.attend && learning.attend.trim() !== "null"
                          ? ReactHtmlParser(learning.attend)
                          : ""}
                      </span>
                    </div>
                  </>
                ) : (
                    ""
                  )}
              </Col>

              <Col xs={24} sm={24} md={8} lg={8} xl={8}>
                <div className="trip_exp_bg br20 text-center pb40">
                  <h4 className="sub_title text-center">About This Expert</h4>
                  <img
                    src={learning.expert.profile}
                    alt="profile"
                    className="br10 right_side_image"
                  />
                  <h5 className="an-15 medium-text pt20 mb20">{`${CaptalizeFirst(
                    learning.expert.firstName
                  )} ${CaptalizeFirst(learning.expert.lastName)}`}</h5>
                  <p className="grn_txt medium-text an-15">
                    {commaSepratorString(learning.expert.experties)}
                  </p>
                  <p className="pt5 mb5 blanck-Color">
                    <img
                      src={Location_Img}
                      alt=""
                      className="pb10"
                      id="location_img"
                    />
                    {getCityFromLocation(learning.expert.city)}
                    {CaptalizeFirst(learning.expert.country)}
                  </p>
                  <p className="pt5 pb10 blanck-Color">
                    <img
                      src={Lang}
                      alt="Lang"
                      className="pb10"
                      id="location_img"
                    />
                    {displayLang(learning.expert.speaks)}
                  </p>
                  <p></p>
                  <Link
                    to={`/expert-profile/${learning.expert._id}`}
                    className="ex__primary_btn pt20 pb20 br5"
                  >
                    View Profile
                  </Link>
                </div>
              </Col>
            </Row>

            {learning.workshopMedium !== "online" && (
              <Row>
                <Col className='day_sec metting_point_trip justify' xs={24} sm={24} md={16} lg={16} xl={16}>
                  <Row className='pt20'>
                    <Col span={20}>
                      <h3 className='an-22 medium-text pb10'>Location</h3>
                    </Col>
                    <Col span={20}>

                      <p className="pt5 mb0 trip_location_des">
                        {CaptalizeFirst(learning.address)}
                      </p>

                    </Col>

                    <Col span={16} className="trip_meeting_point">
                      <div className='trip_detail_des'>
                        <h4 className='medium-text an-18 meting-text'>Meeting Point</h4>
                        <p className='lh-30 desc'>{learning.meetingPoint ? learning.meetingPoint : ""}</p>
                      </div>
                    </Col>

                  </Row>
                  <Row className='pt0 map_trip_edit'>
                    <Col span={24} className='map pb30 pr30'>
                      <TripMap
                        center={learning.location.coordinates}
                        zoom={5}
                        ApiKey={ApiKey}
                      />
                    </Col>
                  </Row>
                </Col>
              </Row>
            )}

            {learning.workshopMedium !== "online" && <>
              {typeof learning.itenary !== "undefined" && learning.itenary.length > 0 &&
                < Row className="Itinerary_trip_edit justify">
                  <Col className="Itinerary_trip_edit_box" xs={24} sm={24} md={16} lg={16} xl={16}>
                    <Row>
                      <Col span={18}>
                        <div className='trip_detail_des title'>
                          <h4 className='medium-text an-18 pt30'>Itinerary</h4>
                        </div>
                      </Col>
                    </Row>
                    <div className='trip_detail_des'>
                      {learning.itenary &&
                        learning.itenary.map((i, index) => {
                          if (typeof i.value !== "undefined" && i.value !== "") {
                            return (
                              <div className='day_sec' key={index}>
                                <h4
                                  className='sub_title font-weight-600 an-14'
                                  style={{ paddingTop: 20, paddingBottom: 20 }}
                                >
                                  Day {index + 1}
                                </h4>
                                <p className='lh-30'>{i.value}</p>
                              </div>
                            )
                          }
                        })
                      }
                    </div>
                  </Col>
                </Row>
              }

              <Row className="Accommodation_trip_edit justify">
                <Fragment>
                  {(learning.accomodation !== "" || (typeof learning.accomodationPhotos !== "undefiend" && learning.accomodationPhotos.length > 0)) &&
                    <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                      <Row className="trip_pad_fix">
                        <Col span={20}>
                          <div className='trip_detail_des'>
                            <h4 className='medium-text an-18 Accommodation_text'>Accommodation</h4>
                          </div>
                        </Col>
                      </Row>
                    </Col>
                  }

                  {learning.accomodation !== "" &&
                    <Col className="Accommodation_detail_text pb40" xs={24} sm={24} md={16} lg={16} xl={16}>
                      <div className='trip_detail_des title'>
                        <div className='lh-30'>
                          {ReactHtmlParser(learning ?.accomodation)}
                        </div>
                      </div>
                    </Col>
                  }

                  {typeof learning.accomodationPhotos !== "undefiend" && learning.accomodationPhotos.length > 0 &&

                    <Col xs={24} sm={24} md={16} lg={16} xl={16} className="pb40 pt15">

                      <OwlCarousel
                        className="owl-theme accommodation_img_view slider_prev_next"
                        {...sliderOptions}
                      >
                        {learning.accomodationPhotos.map((t, index) => (

                          <Col
                            xs={24}
                            sm={24}
                            md={24}
                            lg={24}
                            xl={24}
                            key={index}
                            className="gutter-row"
                          >
                            <Card
                              hoverable
                              cover={
                                <img
                                  onClick={() => onAccommoImageClick(index, "accomo")}
                                  alt="example"
                                  src={t}
                                />
                              }
                            >
                            </Card>
                          </Col>
                        ))}
                      </OwlCarousel>
                    </Col>
                  }
                </Fragment>

              </Row>
            </>
            }
            {learning.extras && learning.extras !== "" &&
              <>
                <Row>
                  <Col xs={24} sm={24} md={16} lg={16} xl={16} className="pt40 border-top">
                    <Col span={20}>
                      <div className='trip_detail_des'>
                        <h4 className='medium-text an-18'>Additional Details</h4>
                      </div>
                    </Col>
                  </Col>
                </Row>
                <Row className="worlshop-extra-desc justify">
                  <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                    <div className='trip_detail_des'>
                      <span className='lh-30'>
                        {learning.extras && learning.extras.trim() !== 'null'
                          ? ReactHtmlParser(learning.extras)
                          : ''}
                      </span>
                    </div>
                  </Col>
                </Row>
              </>
            }

            <Row gutter={20} className="mt40 mb40 Inclusions_title_fix">
              {learning.inclusion && learning.inclusion.trim() !== 'null' && learning.inclusion.trim() !== "" && (
                <Col
                  className="Inclusions_section"
                  xs={24}
                  sm={24}
                  md={8}
                  lg={8}
                  xl={8}
                >
                  <div className="trip_inclusion_sec trip_detail_des brder_sec">
                    <Row className="border_btm mb15">
                      <Col span={12}>
                        <h4 className="medium-text an-18 pb20 brder_nn">
                          Inclusions
                        </h4>
                      </Col>
                    </Row>
                    <div className="lh-30 list_off">
                      {ReactHtmlParser(learning.inclusion)}
                    </div>
                  </div>
                </Col>
              )}

              {learning.exclusion && learning.exclusion.trim() !== 'null' && learning.exclusion.trim() !== "" && (
                <Col xs={24} sm={24} md={8} lg={8} xl={8}>
                  <div className="trip_inclusion_sec trip_detail_des brder_sec trip_exclusion_sec">
                    <Row className="border_btm mb15">
                      <Col span={12}>
                        <h4 className="medium-text an-18 pb20 brder_nn">
                          Exclusions
                        </h4>
                      </Col>
                    </Row>
                    <div className="lh-30 list_off">
                      {ReactHtmlParser(learning.exclusion)}
                    </div>
                  </div>
                </Col>
              )}
            </Row>

            <Row>
              <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                <div className="person_sec">
                  <div className="fill-width">
                    <h1 className="medium-text an-28 mb0">
                      {getCurrencySymbol(
                        datePriceCurrency || learning.priceCurrency
                      )}{" "}
                      {datePrice || learning.price}
                    </h1>
                    <p className="an-14 medium-text">Per Person</p>
                  </div>
                  <div className="fill-width text-right">
                    <span
                      onClick={onIntseretClick}
                      className="yellow_btn mr10 cursor-pointer"
                    >
                      I’m Interested
                    </span>
                    <span
                      onClick={onReserveClick}
                      className="green_btn cursor-pointer"
                    >
                      Reserve
                    </span>
                    {learning.cancellantion && (
                      <h6
                        className="an-14 cursor-pointer"
                        onClick={() => setShowCanc(true)}
                      >
                        *Terms & Conditions
                      </h6>
                    )}
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col>
                <div className="photoandvideo slider_prev_next">
                  <Row className="pb40">
                    <Col>
                      <Row>
                        {learning.images.length > 0 ? (
                          <Col span={12}>
                            <h4 className="sub_title">
                              Pictures and Videos from Past Workshops
                            </h4>
                          </Col>
                        ) : (
                            ""
                          )}
                      </Row>
                      <Row gutter={[40]}>
                        <OwlCarousel
                          className="owl-theme photo_video_sec"
                          {...sliderOptions}
                        >
                          {/* {learning.images.length > 0 &&
                            learning.images.map((img, index) => {
                              return (
                                <Col
                                  xs={24}
                                  sm={24}
                                  md={24}
                                  lg={24}
                                  xl={24}
                                  className="gutter-row pb25"
                                >
                                  {img.search(".mp4") != -1 ? (
                                    <ReactPlayer
                                      className="video_edit_page"
                                      url={img}
                                      onClick={() =>
                                        onAccommoImageClick(index, "photos")
                                      }
                                    />
                                  ) : (
                                    <img
                                      src={img}
                                      alt=""
                                      onClick={() =>
                                        onAccommoImageClick(index, "photos")
                                      }
                                    />
                                  )}
                                </Col>
                              );
                            })}
                          {learning.images.length === 0 && (
                            <>
                              <Col
                                xs={24}
                                sm={24}
                                md={24}
                                lg={24}
                                xl={24}
                                className="gutter-row pb25"
                              >
                                <img src={Placeholder} alt="" />
                              </Col>
                              <Col
                                xs={24}
                                sm={24}
                                md={24}
                                lg={24}
                                xl={24}
                                className="gutter-row pb25"
                              >
                                <img src={Placeholder} alt="" />
                              </Col>
                              <Col
                                xs={24}
                                sm={24}
                                md={24}
                                lg={24}
                                xl={24}
                                className="gutter-row pb25"
                              >
                                <img src={Placeholder} alt="" />
                              </Col>
                            </>
                          )} */}
                          {
                            learning.images.length > 0
                              ? learning.images.map((img, index) => {
                                return (
                                  <Col
                                    xs={24}
                                    sm={24}
                                    md={24}
                                    lg={24}
                                    xl={24}
                                    className="gutter-row pb25"
                                  >
                                    {img.search(".mp4") != -1 ? (
                                      <ReactPlayer
                                        className="video_edit_page"
                                        url={img}
                                        onClick={() =>
                                          onAccommoImageClick(index, "photos")
                                        }
                                      />
                                    ) : (
                                        <img
                                          src={img}
                                          alt=""
                                          onClick={() =>
                                            onAccommoImageClick(index, "photos")
                                          }
                                        />
                                      )}
                                  </Col>
                                );
                              })
                              : ""
                            // (
                            //     <>
                            //       <Col
                            //         xs={24}
                            //         sm={24}
                            //         md={24}
                            //         lg={24}
                            //         xl={24}
                            //         className="gutter-row pb25"
                            //       >
                            //         <img src={Placeholder} alt="" />
                            //       </Col>
                            //       <Col
                            //         xs={24}
                            //         sm={24}
                            //         md={24}
                            //         lg={24}
                            //         xl={24}
                            //         className="gutter-row pb25"
                            //       >
                            //         <img src={Placeholder} alt="" />
                            //       </Col>
                            //       <Col
                            //         xs={24}
                            //         sm={24}
                            //         md={24}
                            //         lg={24}
                            //         xl={24}
                            //         className="gutter-row pb25"
                            //       >
                            //         <img src={Placeholder} alt="" />
                            //       </Col>
                            //     </>
                            //   )
                          }
                        </OwlCarousel>
                      </Row>
                    </Col>
                  </Row>

                  {similarLearning && similarLearning.length >= 3 && (
                    <>
                      <Row className=" pt30 common-top-border">
                        <Col span={12}>
                          <h4 className="sub_title">Similar Workshops</h4>
                        </Col>
                        <Col span={12}>
                          <div className="text-right mt30">
                            <Link
                              to="/learning"
                              className="ex__primary_btn br5"
                            >
                              View More
                            </Link>
                          </div>
                        </Col>
                      </Row>

                      <Row gutter={10} className="pb40 workshop_similar all_page_card">
                        {similarLearning && similarLoader &&
                          <TripWorkshopAllCardsCarousel
                            items={similarLearning}
                            customType={'worskhop'}
                          />
                        }
                      </Row>
                    </>
                  )}
                </div>
              </Col>
            </Row>
          </div>
        </div>
        {moreDetail && (
          <MoreDetails
            visible={moreDetail}
            data={learning.dateTime}
            onIntseretClick={onIntseretClick}
            onReserveClick={onReserveClick}
            onClickDate={(d) => onClickDate(d)}
            onCloseClick={onCloseClick}
          />
        )}
        {showCanc && (
          <Cancellation
            visible={showCanc}
            data={learning.cancellantion}
            onCloseClick={onCloseClick}
          />
        )}
        {showR && (
          <Reservation
            visible={showR}
            trip={learning.title}
            slot={slot}
            onCloseClick={onCloseClick}
            id={id}
            name={`${CaptalizeFirst(
              learning.expert.firstName
            )} ${CaptalizeFirst(learning.expert.lastName)}`}
            type="learnings"
          />
        )}
        {showInterest && (
          <Interested
            visible={showInterest}
            trip={learning.title}
            onCloseClick={onInstCloseClick}
            id={id}
            type="learnings"
          />
        )}

        {accommodationPhotoViewPopup && (
          <AccommodationPhotoViewPopup
            visible={accommodationPhotoViewPopup}
            onCloseClick={onCloseClick}
            id={id}
            allPhotos={
              currentPhotoView === "accomo"
                ? learning.accomodationPhotos
                : learning.images
            }
            currentViewImage={currentViewImage}
          />
        )}
      </div>
    );
  } else {
    return (
      <div className="text-center py20 loader-absolute-class">
        <AppLoader />
      </div>
    );
  }
};
export default WorkShopDetails;
