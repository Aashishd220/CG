import React, { useEffect, useRef } from "react";
import { Route, Switch } from "react-router-dom";
import { useSelector } from "react-redux";

/**
 * App Imports
 */
import { Logout } from "../services/expert";

import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import ProtectedRoutes from "../routes/Protected";
import {
  PublicRoutes,
  PrivateRoutes,
  PrivateUserRoutes,
} from "../routes/routes";

const BaseLayout = () => {
  const enthu = useSelector((state) => state.enthu);
  const expert = useSelector((state) => state.expert);
  const { role, accessToken } = useSelector((state) => state.auth);

  const prevExpert = useRef();
  const prevEnthu = useRef();

  useEffect(() => {
    prevExpert.current = expert;
    prevEnthu.current = enthu;
  }, [expert, enthu]);

  if (!accessToken) {
    if (prevExpert.current) Logout(prevExpert.current.id);
    if (prevEnthu.current) Logout(prevEnthu.current.id);
  }

  return (
    <section className="home-layout">
      <header className="top-header">
        <Header />
      </header>
      <main className="main-content">
        <Switch>
          {PublicRoutes.map((props, key) => {
            return (
              <Route
                exact
                path={props.path}
                component={props.component}
                key={key}
              />
            );
          })}
          <ProtectedRoutes>
            {role === "user"
              ? PrivateUserRoutes.map((props, key) => {
                  return (
                    <Route
                      exact
                      path={props.path}
                      component={props.component}
                      key={key}
                    />
                  );
                })
              : PrivateRoutes.map((props, key) => {
                  return (
                    <Route
                      exact
                      path={props.path}
                      component={props.component}
                      key={key}
                    />
                  );
                })}
          </ProtectedRoutes>
        </Switch>
      </main>
      <footer className="footer">
        <Footer />
      </footer>
    </section>
  );
};

export default BaseLayout;
