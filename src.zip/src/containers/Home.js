import React, { useState, useEffect, useCallback } from "react";
import { Link, withRouter } from "react-router-dom";
import TextLoop from "react-text-loop";
import { compose } from "redux";

import { Dropdown, Input, Menu, Button, Search, Icon } from "antd";
import beMoreConnectedImage from "assets/images/home/expert_ss.png";
import getinspierd from "assets/images/home/getinspierd.png";
import leavePositiveImpact from "assets/images/home/leave_positive_impact.png";
import beMoreInspiredImage from "assets/images/home/beMoreInspiredImage.png";
import LeftArrow from "assets/images/newicon/left_arrow.svg";
import LearningDetails from "assets/images/home/learnig_details.png";
import Cource1 from "assets/images/newicon/cource1.png";
import Cource2 from "assets/images/newicon/cource2.png";
import Cource3 from "assets/images/newicon/cource3.png";
import Cource4 from "assets/images/newicon/cource4.png";
import Why1 from "assets/images/newicon/why1.svg";
import Why2 from "assets/images/newicon/why2.svg";
import Why3 from "assets/images/newicon/why3.svg";
import Why4 from "assets/images/newicon/why4.svg";
import Cource1Icon from "assets/images/newicon/cource1_icon.svg";
import Cource2Icon from "assets/images/newicon/cource2_icon.svg";
import Cource3Icon from "assets/images/newicon/cource3_icon.svg";
import Cource4Icon from "assets/images/newicon/cource4_icon.svg";
import locatorIcon from "../assets/images/newicon/locator.svg";
import locatorIconActive from "../assets/images/newicon/locator_active.svg";


import beMoreSustainableImage from "assets/images/home/beMoreSustainableImage.png";
import callingAllExpertsBackground from "assets/images/home/callingAllExpertsBackground.svg";
import callingOurExperts_Image1 from "assets/images/home/callingOurExperts_Image1.png";
import callingOurExperts_Image2 from "assets/images/home/callingOurExperts_Image2.png";
import callingOurExperts_Image3 from "assets/images/home/callingOurExperts_Image3.png";
import exploreWithExperts_Image1 from "assets/images/home/exploreWithExperts_Image1.png";
import exploreWithExperts_Image2 from "assets/images/home/exploreWithExperts_Image2.png";
import exploreWithExperts_Image3 from "assets/images/home/exploreWithExperts_Image3.png";
import exploreWithExperts_Image4 from "assets/images/home/exploreWithExperts_Image4.png";
import joinTheExpeditionBackground from "assets/images/home/joinTheExpeditionBackground.svg";
import joinTheExpedition_compas from "assets/images/home/joinTheExpedition_compas.png";
import joinTheExpedition_flashlight from "assets/images/home/joinTheExpedition_flashlight.png";
import joinTheExpedition_Hummer from "assets/images/home/joinTheExpedition_Hummer.png";
import learningWithExperts_feature1 from "assets/images/home/learningWithExperts_feature1.gif";
import learningWithExperts_feature2 from "assets/images/home/learningWithExperts_feature2.gif";
import learningWithExperts_feature3 from "assets/images/home/learningWithExperts_feature3.gif";
import learningWithExperts_feature4 from "assets/images/home/learningWithExperts_feature4.gif";
import learningWithExperts_feature5 from "assets/images/home/learningWithExperts_feature5.gif";
import learningWithExperts_feature6 from "assets/images/home/learningWithExperts_feature6.gif";
import locationPinIcon from "assets/images/home/locationPinIcon.svg";
import mailIcon from "assets/images/home/mailIcon.svg";
import quoteCloseIcon from "assets/images/home/quoteCloseIcon.svg";
import quoteOpenIcon from "assets/images/home/quoteOpenIcon.svg";
import trackingImage from "assets/images/home/trackingImage.png";
import whatFacinatesYouImage2 from "assets/images/home/whatFacinatesYouImage2.png";
import whatFacinatesYouImage3 from "assets/images/home/whatFacinatesYouImage3.png";
import whatFacinatesYouImage4 from "assets/images/home/whatFacinatesYouImage4.png";
import cx from "classnames";
import ActivityCardSlider from "components/Basic/ActivityCardSlider";
import WatchVideoReveal from "components/Basic/WatchVideoReveal";
import watchVideoIconMobile from "assets/images/home/watchVideoIconMobile.svg";
import { Subscribe } from '../services/expert';
import NewsletterModal from 'components/common/NewsletterModal';
import { getLeraningPlusTrip } from "../services/expert";
import AppLoader from "components/Loader";


/**
 * Auth Modal
 */
import AuthModal from "../components/Auth/AuthModal";
import { useMediaQuery } from "react-responsive";

const allCategoriesCardsData = [
	{
		days: 5,
		activityType: "Climbing & Trekking",
		activityName: "Alpine Climbing Course",
		location: "Chamonix, France",
		price: 1800,
		priceCurrency: "USD",
		activityLevel: "easy",
		rating: 5,
		image: whatFacinatesYouImage3,
	},
	{
		days: 3,
		activityType: "Nature & Wildlife",
		activityName: "Wildlife Photography Workshop",
		location: "Scotland",
		price: 2000,
		priceCurrency: "USD",
		activityLevel: "medium",
		rating: 5,
		image: whatFacinatesYouImage2,
		label: "Online",
	},
	{
		days: 1,
		activityType: "Climbing & Trekking",
		activityName: "Avalanche Safety Course",
		location: "Online",
		price: 150,
		priceCurrency: "USD",
		activityLevel: "difficult",
		rating: 5,
		image: trackingImage,
		label: "Online",
	},
	{
		days: 3,
		activityType: "Diving & Snorkelling",
		activityName: "Learn Open Water Diving",
		location: "Malta",
		price: 500,
		priceCurrency: "USD",
		activityLevel: "easy",
		rating: 5,
		image: whatFacinatesYouImage4,
	},
];

const exploreWithExpertsData = [
	{
		days: 10,
		activityType: "Climbing & Trekking",
		activityName: "Everest Basecamp Trek",
		location: "Nepal",
		price: 7500,
		priceCurrency: "USD",
		activityLevel: "easy",
		rating: 5,
		image: exploreWithExperts_Image1,
	},
	{
		days: 6,
		activityType: "Climbing & Trekking",
		activityName: "Kilimanjaro Climbing Expedition",
		location: "Tanzania",
		price: 2750,
		priceCurrency: "USD",
		activityLevel: "medium",
		rating: 5,
		image: exploreWithExperts_Image2,
	},
	{
		days: 7,
		activityType: "Nature & Wildlife",
		activityName: "The Great Migration Photo Safari",
		location: "Kenya",
		price: 4500,
		priceCurrency: "USD",
		activityLevel: "difficult",
		rating: 5,
		image: exploreWithExperts_Image3,
	},
	{
		days: 8,
		activityType: "Nature & Wildlife",
		activityName: "Birding in Costa Rica",
		location: "Costa Rica",
		price: 2600,
		priceCurrency: "USD",
		activityLevel: "easy",
		rating: 5,
		image: exploreWithExperts_Image4,
	},
];

const Home = (props) => {
	const [showLogin, setShowLogin] = useState(false);
	const openSignup = () => setShowLogin(true);
	const [isFullScreenVideo, setIsFullScreenVideo] = useState(false);
	const [isShowMoreCategories, setIsShowMoreCategories] = useState(false);
	const isMaxWidth1200 = useMediaQuery({ query: "(max-width: 1200px)" });
	const isMaxWidth992 = useMediaQuery({ query: "(max-width: 992px)" });
	const isMaxWidth768 = useMediaQuery({ query: "(max-width: 768px)" });
	const [email, setEmail] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [successPopup, setSuccessPopup] = useState(false);

	const [adventure, setAdventure] = useState('group');
	const [tripAndAdventure, setTripAndAdventure] = useState([]);
	const [mapTrips, setMapTrips] = useState([])
	const [loader, setLoader] = useState(false);
	const [initialLoader, setInitialLoader] = useState(true);
	const [pageNo, setPageNo] = useState(1);
	const [perPage, setPerPage] = useState(6);



	const getAllTripsHandlerForAll = useCallback(async (value) => {
		try {
			setLoader(true);
			const result = await getLeraningPlusTrip(value, true);
			if (result.status === 200) {
				setTripAndAdventure(result.data.data.data);
				setLoader(false);
			} else {
				setLoader(false);
			}
		} catch (err) {
			setLoader(false);
		}
	}, []);


	useEffect(() => {
		refreshResult();
	}, [pageNo, perPage]);

	const refreshResult = (sortBy = "") => {
		const allSearch = { pageNo, perPage, adventure };
		getAllTripsHandlerForAll(allSearch);
	}


	const handleSubmit = async e => {
		e.preventDefault();
		let valid = false;

		let val = document.getElementById('email-input-box').value;
		let element = document.getElementById('subscribe-error');
		document.getElementById('subscribe-success').style.display = "none";

		if (email.trim() === "") {
			element.style.display = "block";
		} else if (email.trim() !== "" && !/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(val)) {
			element.innerHTML = 'Please enter valid email address';
			element.style.display = "block";
			valid = false;
		} else {
			element.style.display = "none";
			valid = true;
		}

		if (valid) {
			setIsLoading(true);
			const formData = new FormData();
			formData.append("email", val);
			formData.append("subscribe", true);
			const result = await Subscribe(formData);
			setEmail('');
			if (result.data.status === "SUCCESS") {
				setSuccessPopup(true);
			} else if (result.data.status === "FAIL") {
				element.innerHTML = "This email already exists. Please enter a new email address.";
				element.style.display = "block";
				setTimeout(() => {
					element.style.display = "none";
				}, 10000);
			}

			setIsLoading(false);
		}

	};

	const handleChange = e => {
		setEmail(e.target.value);
		document.getElementById('subscribe-success').style.display = "none";
		if (e.target.value === "") {
			document.getElementById('subscribe-error').style.display = "block";
		} else {
			document.getElementById('subscribe-error').style.display = "none";
		}
	}


	return (
		<div className="mainhomepage">
			<div className="expert_head_bg expert_head_bg_color">
				<div className="expert_header_info">
					<div className="bg-title">
						<span className="first-txt">Join </span><span className="second-txt">Expeditions Connect</span> <span>for free</span>
					</div>
					<div className="bg-sub-title">
						<span>Explore the best adventure courses, workshops and expeditions<br /> directly crafted by professionals.</span>
					</div>
					<div className="search-textbox">
						<Input addonAfter={<><Icon type="search" /> <span>&nbsp;Search</span></>} placeholder='Search "Sailing"' />
					</div>
					<div className="extra-filters">
						<div className="extra-parent">
							<div className={`extra-child active`} > <span><img src={locatorIconActive} alt="Map Icon" /></span>  Adventures Near Me </div>
						</div>
						<div className="extra-parent">
							<div className={`extra-child`} > <span><img src={require('../assets/images/newicon/expertise/mountaineering.svg')} alt="Map Icon" /></span>  Mountaineering</div>
						</div>
						<div className="extra-parent">
							<div className={`extra-child`} > <span><img src={require('../assets/images/newicon/expertise/ski.svg')} alt="Map Icon" /></span>  Skiing </div>
						</div>
						<div className="extra-parent">
							<div className={`extra-child`} > <span><img src={require('../assets/images/newicon/expertise/scubadiving.svg')} alt="Map Icon" /></span>  Scuba Diving </div>
						</div>
					</div>
				</div>

			</div>

			<div className="section2">
				{loader &&( <div className="text-center py20 loader-position-relative">
					<AppLoader />
				</div>)}
				{!loader &&
					<>
						<h2 className="rubik-54-medium header">Learn what fascinates you</h2>
						<div className="mb45 section-2-subtitle">Whatever it is that fascinates you, you’ll find a course or expedition to broaden your horizons and ignite your wanderlust.<br /> Discover a new passion with Expeditions Connect.</div>
						<div className="categories">
							<div className="active category all-category">All categories</div>
							<div className="other-categories">
								<div className="first-row">
									<Link className="category" to="/learning">
										Climbing and Trekking
              					</Link>
									<Link className="category" to="/learning">
										Nature and Wildlife
								</Link>
									<Link className="category" to="/learning">
										Scuba-Diving and Snorkelling
             					</Link>
									{/* {!isMaxWidth992 && (
										<div className="see-more-button-container">
											<Button
												className="category"
												onClick={() => {
													setIsShowMoreCategories(!isShowMoreCategories);
												}}
											>
												....
                  					</Button>
										</div>
									)}

									{isMaxWidth992 && (
										<Link className="category" to="/learning">
											Skiing and Snowboarding
             				  			 </Link>
									)} */}
								</div>
								{isShowMoreCategories && (
									<Link className="category" to="/learning">
										Skiing and Snowboarding
             				 </Link>
								)}
							</div>
						</div>
						<ActivityCardSlider
							className="activity-cards"
							data={allCategoriesCardsData}
							cardRedirectURL="/learning"
						/>
						{/* <br/>
						<br/>
						<br/>
						<ActivityCardSlider
							className="activity-cards"
							data={allCategoriesCardsData}
							cardRedirectURL="/learning"
						/> */}
					</>
				}
			</div>

			{/* Join the Expedition */}
			<div className="join-the-expedition">
				<img src={joinTheExpeditionBackground} alt="" className="bgImage" />
				<div className="join-the-expedition-content">
					<h1 className="header rubik-54-medium">Join the Expedition</h1>
					<div className="our-aim">
						{/* Images */}
						<div className="our-aim-images">
							<img
								src={joinTheExpedition_flashlight}
								alt=""
								className="flashlight"
							/>
							<img src={joinTheExpedition_Hummer} alt="" className="hammer" />
						</div>

						{/* Text */}
						<p className="our-aim-text">
							<img
								src={joinTheExpedition_compas}
								alt=""
								className="compassImage"
							/>
							<img src={quoteOpenIcon} alt="" className="quoteOpen" />
							<img src={quoteCloseIcon} alt="" className="quoteClose" />
							<b>Our aim</b> is to connect enthusiasts with expert adventurers.
              <br />
							<br />
							We are on a mission to create a sustainable future for our planet
							by creating a community of like-minded passionate explorers - a
							place where those seeking their wanderlust can learn from
							experienced professionals.
            </p>
					</div>
				</div>
			</div>

			{/* Be more sections */}
			<div className="be-more-sections">
				{/* Be more connected */}
				<div className="be-more-section">
					<div className="be-more-section-body">
						<div className="be-more-content">
							<div>
								<div className="be-more-summary">
									<div>Discover & connect with <br />Experts Worldwide</div>
								</div>
								<div className="border-bottom-yellow"></div>
								<div className="be-more-description">
									As part of the community you’ll be able to connect with adventure
									professionals anywhere in the world. You can also share your passion
									for adventure with fellow explorers from across the globe.
               					 </div>
								<button
									className="ex__primary_btn be-more-button"
									onClick={() => props.history.push("/get-inspired")}
								>
									BROWSE EXPERTS <span><img src={LeftArrow} className="left-arrow" alt="left arrow" /></span>
								</button>
							</div>
						</div>
						<div className="be-more-image-container">
							<img src={beMoreConnectedImage} alt="" />
						</div>
					</div>
					<div className="be-more-section-footer">
						<div className="dash" />
						<div className="text">
							Ignite your wanderlust and learn from passionate and experienced professionals
							in your area of interest. Whatever your level or ability, they’ll help you reach your adventure goals through personal experiences.
            			</div>
					</div>
				</div>

				{/* Be more Inspired */}
				<div className="be-more-section be-more-inspired">
					<div className="be-more-section-body">
						<div className="be-more-image-container-left">
							<img src={getinspierd} alt="get inspierd" />
						</div>

						<div className="be-more-content">
							<div className="ml100">
								<div className="be-more-summary">
									<div>Once-in-a-lifetime <br />adventures led by true field experts</div>
								</div>
								<div className="border-bottom-yellow"></div>
								<div className="be-more-description">
									Discover amazing experiences for all budgets and abilities, designed and led by adventure professionals who know how to keep you safe. Learn about the natural world, leave a positive impact and make memories to last a lifetime.
                				</div>
								<button
									className="ex__primary_btn be-more-button"
									onClick={() => props.history.push("/all-adventure")}
								>
									BROWSE ADVENTURES <img src={LeftArrow} className="left-arrow" alt="left arrow" />
								</button>
							</div>
						</div>
					</div>
					<div className="be-more-section-footer adventure">
						<div className="dash" />
						<div className="text">
							Find seasoned adventure experts to guide you on your next expedition. Bypass the one-size-fit-all mass-market tours and activities sold by agents. Discover once-in-a-lifetime adventures you won’t find anywhere else.
           			 </div>
					</div>
				</div>

				{/* Be more Sustainable */}
				<div className="be-more-section be-more-sustainable">
					<div className="be-more-section-body">
						<div className="be-more-content">
							<div>
								<div className="be-more-summary">
									<div>Learn from the most <br /> experienced professionals</div>
								</div>
								<div className="border-bottom-yellow"></div>
								<div className="be-more-description">
									Whatever your area of interest may be, with Expeditions Connect you’ll find online and on-the- ground courses, workshops and many other learning materials to broaden your horizons. You can experience real-life expeditions in incredible locations across the globe.<br /><br /> You can even sign up for globally recognised adventure accreditations to kick start a career. Every single one of our experiences is carefully crafted and thought-out by expert adventurers.
								</div>
								<div className="be-more-experience">
									<div className="child">
										<img className="main-img" src={Cource1} alt="" />
										<div className="main-child-img"><img className="main-img-above" src={Cource1Icon} alt="" /></div>
										<div class="main-img-txt">Courses</div>
									</div>
									<div className="child">
										<img className="main-img" src={Cource2} alt="" />
										<div className="main-child-img"><img className="main-img-above" src={Cource2Icon} alt="" /></div>
										<div class="main-img-txt">Workshops</div>
									</div>
									<div className="child">
										<img className="main-img" src={Cource3} alt="" />
										<div className="main-child-img"><img className="main-img-above" src={Cource3Icon} alt="" /></div>
										<div class="main-img-txt">Expeditions</div>
									</div>
									<div className="child">
										<img className="main-img" src={Cource4} alt="" />
										<div className="main-child-img"><img className="main-img-above" src={Cource4Icon} alt="" /></div>
										<div class="main-img-txt">Webinars</div>
									</div>

								</div>
							</div>
						</div>
						<div className="be-more-image-container">
							<img src={LearningDetails} alt="" />
						</div>
					</div>
				</div>

				{/* Explore with experts */}
				<div className="explore-with-experts">
					<h1 className="rubik-54-medium">Meet our Experts</h1>
					<p className="description">
						Our adventure experts are leaders in their fields and they’re always keen to share their knowledge and experience with you. Whatever fascinates you, from mountaineering to scuba diving, there’s a world-class expert on Expeditions Connect who is eager to share their skills and passion.
         			 </p>
					<ActivityCardSlider
						data={exploreWithExpertsData}
						cardRedirectURL="/expeditions"
					/>

				</div>

				{/* Calling All Experts  */}
				<div className="expert_calling">
					<div className="expert_calling_info">
						<div className="bg-title">
							<span className="first-txt">Calling All Experts</span>
						</div>
						<div className="border-bottom-yellow"></div>
						<div className="bg-sub-title">
							<span>Share your knowledge, skills and expertise with people from around the globe. Inspire passionate explorers to discover the wonders of the natural world through travel, adventure and education. Are you offering a trip, running a course, event or workshop, or publishing new content? Share it with adventure enthusiasts all over the world.</span>
						</div>
						<button
							className="ex__primary_btn be-an-expert"
							onClick={() => props.history.push("/create-expert-profile")}>
							BECOME AN EXPERT <span><img src={LeftArrow} className="left-arrow" alt="left arrow" /></span>
						</button>


					</div>

				</div>

				{/*Leave Positive Impact */}
				<div className="be-more-section be-more-inspired leave-positive-impact mb90 ">
					<div className="be-more-section-body">

						<img src={leavePositiveImpact} alt="get inspierd" className="positive-impract-img" />

						<div className="be-more-content">
							<div className="ml80">
								<div className="be-more-summary">
									<div>Leave a positive impact on <br />the planet</div>
								</div>
								<div className="border-bottom-yellow"></div>
								<div className="be-more-description">
									Learning and education are core principles of the Expeditions Connect community. Through education, we aim to bring like-minded adventurers closer to the environment, empowering them to create positive change. Together we can protect our precious environment in the face of an uncertain future. <br /><br />Through Expeditions Connect, you can enjoy extraordinary learning experiences whilst contributing towards a brighter, more sustainable future.
                				</div>
								<button
									className="ex__primary_btn be-more-button"
									onClick={() => props.history.push("/")}
								>
									READ OUR STORY <img src={LeftArrow} className="left-arrow" alt="left arrow" />
								</button>
							</div>
						</div>
					</div>
				</div>

				{/*Why Choose */}
				<div className="mb90 why-choose-us">
					<h1 className="why-choose-main-title mb90">Why Choose Expeditions Connect</h1>
					<div>
						<div className="why-choose-main">
							<img src={Why1}></img>
							<div className="why-title">World Class Experts</div>
							<div className="border-bottom-yellow"></div>
							<div className="why-choose-txt">Discover top adventure experts and mentors from around the globe, all under one roof.</div>
						</div>
						<div className="why-choose-main">
							<img src={Why2}></img>
							<div className="why-title">Direct Connection</div>
							<div className="border-bottom-yellow"></div>
							<div className="why-choose-txt">No middleman, no hassle. Direct connection with the best professionals in your chosen field.</div>
						</div>
						<div className="why-choose-main">
							<img src={Why3}></img>
							<div className="why-title">More Than Just Adventures</div>
							<div className="border-bottom-yellow"></div>
							<div className="why-choose-txt">Access a wide range of workshops, courses and a whole host of learning opportunities directly crafted by experts.</div>
						</div>
						<div className="why-choose-main">
							<img src={Why4}></img>
							<div className="why-title">100% Free to Join</div>
							<div className="border-bottom-yellow"></div>
							<div className="why-choose-txt">It’s totally free to join and explore our community. You only pay when you book an experience or activity.</div>
						</div>
					</div>
				</div>

			</div>
			{
				showLogin && (
					<AuthModal visible={showLogin} onCancel={() => setShowLogin(false)} />
				)
			}
			{
				successPopup &&
				<NewsletterModal
					visible={successPopup}
					onClose={() => setSuccessPopup(false)}
				/>
			}

		</div >
	);
};
export default compose(withRouter)(Home);
