import React, { useState, useEffect, useCallback } from "react";
import { Row, Col, Card, Rate, Badge, Button, Dropdown, Popover } from "antd";
import { withRouter } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { compose } from "redux";
import OwlCarousel from "react-owl-carousel";

/**
 * App Imports
 */
import AppLoader from "../components/Loader";
import Slider from "../components/Utils/Slider";
import shareOption from "../containers/commonContainer/shareOption";
import { ModalActions } from "../../src/redux/models/events";

/**
 * Image Imports
 */
import Location_Img from "../assets/images/country_ic.png";
import {
  getAllExperts,
  getAllRecentTrips,
  getAllLearnings,
} from "../services/expert";
import { CaptalizeFirst, commaSepratorString, getCityFromLocation } from "../helpers/methods";
import Share from "../assets/images/share_ic.png";
import SkillRed from "../assets/images/skill_red.svg";
import SkillGreen from "../assets/images/skill_green.svg";
import SkillOrange from "../assets/images/skill_orange.svg";
import { DISPLAY_RESULT } from "helpers/constants";
import { getColorLogoURL } from '../helpers/methods';
import languageIcon from '../assets/images/speaks_ic_2x.png';
import followersIcon from '../assets/images/followers_ic.png';
import TripWorkshopAllCardsCarousel from "../components/common/TripWorkshopAllCardsCarousel";

const {
  openApprovalModal,
  closeApprovalModal,
} = ModalActions;

const expeditionsOptions = {
  items: 3,
  nav: true,
  loop: false,
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dots: false,
    },
    768: {
      items: 2,
      nav: true,
      dots: false,
    },
    991: {
      items: 3,
      nav: true,
      dots: false,
    },
  },
};
const options = {
  items: 2,
  nav: true,
  loop: false,
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dots: false,
    },
    768: {
      items: 2,
      nav: true,
      dots: false,
    },
    991: {
      items: 2,
      nav: true,
      dots: false,
    },
  },
};

const expertsOptions = {
  items: 3,
  nav: true,
  loop: false,
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dots: false,
    },
    768: {
      items: 2,
      nav: true,
      dots: false,
    },
    991: {
      items: 3,
      nav: true,
      dots: false,
    },
  },
};

const sliderOptions = {
  margin: 10,
  nav: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dotsEach: 3,
    },
    768: {
      items: 2,
      nav: true,
    },
    991: {
      items: 3,
      nav: true,
    },
  },
};

const ExpertsHomePanel = (props) => {

  const dispatch = useDispatch();
  const [experts, setExpert] = useState([]);
  const [country, setCountry] = useState("");
  const [activity, setActivity] = useState([]);
  const [langauge, setLangauge] = useState([]);
  const [sortBy, setSortBy] = useState(-1);
  const { role } = useSelector((state) => state.auth);
  const [loader, setLoader] = useState(false);
  const [trips, setTrips] = useState([]);
  const token = useSelector((state) => state.auth.accessToken);
  const [workshops, setWorkshops] = useState([]);
  const { picture, approved } = useSelector((state) => state.expert);
  const [loaderTrip, setLoaderTrip] = useState(false);
  const [loaderWorkshop, setLoaderWorkshop] = useState(false);

  const getAllExpertsHandler = useCallback(async (value) => {
    try {
      setLoader(true);
      const result = await getAllExperts(value);
      if (result.status === 200) {
        const data = result.data.data.filter((expert) => !expert.approved === false);
        setExpert(data);
      }
      setLoader(false);
    } catch (err) {
      console.log(err);
      setLoader(false);
    }
  }, []);

  const getAllTripsHandler = useCallback(async () => {
    try {
      setLoaderTrip(true);
      const result = await getAllRecentTrips();
      if (result.status === 200) {
        setTrips(result.data.data); 
      }
      setTimeout(() => {
        setLoaderTrip(false);
      }, 200);
    } catch (err) { setLoaderTrip(false);}
  }, []);

  const getWorkshops = useCallback(async () => {
    try {
      setLoaderWorkshop(true);
    const result = await getAllLearnings();
    if (result.status === 200) {
      setWorkshops(result.data.data.data);
    }
    setTimeout(() => {
      setLoaderWorkshop(false)
    }, 200);
    } catch (err) {
      console.log(err);
      setLoaderWorkshop(false);
    }
    
  }, []);

  useEffect(() => {
    const data = { country, activity, langauge, sortOrder: sortBy };
    getAllExpertsHandler(data);
    getAllTripsHandler();
    getWorkshops();

  }, [
    activity,
    country,
    langauge,
    sortBy,
    token,
    getAllExpertsHandler,
    getAllTripsHandler,
    getWorkshops,
  ]);

  const onCardClick = (id, type) => {
    switch (type) {
      case "trip":
        props.history.push(`/trips-details/${id}`);
        break;
      case "workshop":
        props.history.push(`/learning-details/${id}`);
        break;
      case "expert":
        props.history.push(`/expert-profile/${id}`);
        break;
      default:
        break;
    }
  };
  const onExpeditionsClick = (id) => {
    if (!approved) {
      dispatch(openApprovalModal("trip"));
    } else {
      props.history.push(`/create-trips`);
    }


  }
  const onViewExpeditionsClick = (id) => props.history.push(`/expeditions`);
  const onViewWorkshopsClick = (id) => props.history.push(`/learning`);
  const onExpertsClick = (id) => props.history.push(`/experts`);
  const onCreateWorkshopClick = (id) => {
    if (!approved) {
      dispatch(openApprovalModal("workshop"));
    } else {
      props.history.push(`/create-learnings`);
    }
  }


  const displayCommaSeprate = (lang) => {
    let resLang = ""
    if (lang.length > 0) {
      lang.map((a, index) => {
        let addCooma = "";
        if (lang.length !== index + 1) {
          addCooma = ", "
        }
        resLang += CaptalizeFirst(a) + addCooma;
      });

    }

    return resLang;
  }


  return (
    <div>
      <div className="header_banner">
        <Slider {...props} role={role} />
      </div>
      <div className="header-container">
        <div className="container align-center">
          <div className="banner_txt">
            <h1 className="an-45 medium-text" style={{ marginTop: role !== "expert" ? "55px" : "auto" }}>
              Welcome{" "}
              {props.expert.firstName
                ? props.expert.firstName
                : props.enthu.name} !
              
            </h1>
            {role === "expert" && (
              <p className="an-18 medium-text">
                You can now start adding courses, workshops and trips to your account. <br></br>Share it with adventure enthusiasts all over the world.
            </p>
            )}

            {role === "expert" && (
              <>
                <Button
                  className="view-more-trips an-20 mt10 mr15"
                  onClick={onExpeditionsClick}
                >
                  Create Trip
              </Button>

                <Button
                  className="view-more-trips an-20 mt10"
                  onClick={onCreateWorkshopClick}
                >
                  Create Workshop
              </Button>
              </>
            )}

          </div>
        </div>
        <div className="container align-center pb30 expert-home-page">
          {loader ? (
            <div className="text-center py20 loader-absolute-class">
              <AppLoader />
            </div>
          ) : (
              <>
                <Row className="pb20 pt15">
                  <Col xs={12} sm={12} md={18} lg={18} xl={18}>
                    <div className="expidition_bg">
                      <h4 className="sub_title expert-trip">
                        Discover Experts Worldwide
                </h4>
                    </div>
                  </Col>
                  <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                    <div className="view_more_position vm_homepage">
                      <Button
                        className="view-more-trips an-20 mt10 button_set"
                        onClick={() =>
                          props.history.push(
                            `/experts`
                          )
                        }
                      >
                        View More
                  </Button>
                    </div>
                  </Col>
                </Row>
                <Row gutter={40} className="Worldwide">
                  <Col className="meet_expert_home" span={24}>
                    <div className="expert_bg">
                      <Row justify="space-between" gutter={[10, 20]}>
                        {loader ? (
                          <div className="text-center py20 loader-absolute-class">
                            <AppLoader />
                          </div>
                        ) : experts.length === 0 ? (
                          <div className="mb10 an-14 medium-text text-left">
                            <h4>Currently, there are no experts</h4>
                          </div>
                        ) : (
                              <Row gutter={40} className="pb20 margin_fix_mobile slider_prev_next">
                                <OwlCarousel
                                  className="owl-theme"
                                  {...sliderOptions}
                                >
                                  {experts.slice(0, DISPLAY_RESULT).map((expert, index) => (
                                    <Col xs={24} sm={24} md={24} lg={24} xl={24} key={index} className="mb15 pl15 pr15">
                                      <Card
                                        hoverable
                                        onClick={() => onCardClick(expert.id)}
                                        cover={<img alt="example" src={expert.profile} />}
                                      >
                                        <div className="trip_price_sec">
                                          <h5 className="mb10 an-16 medium-text fnt-rubik-bold blk-color">{`${CaptalizeFirst(
                                            expert.firstName
                                          )} ${CaptalizeFirst(expert.lastName)}`}</h5>
                                          <h5 className="an-16 mb10 an-16 fnt-rubik-bold color-green expert-title">
                                            <Popover placement="bottom" content={`${commaSepratorString(expert.experties)}`} trigger="hover">
                                              {`${commaSepratorString(expert.experties)}`}
                                            </Popover>

                                          </h5>
                                          <p className="mb10 fnt-rubik blk-color">
                                            <img src={Location_Img} alt="location" className="location_icon" />{" "}
                                            {getCityFromLocation(expert.city)}{CaptalizeFirst(expert.country)}
                                          </p>
                                          <p className="mb10 fnt-rubik blk-color">
                                            <img
                                              src={languageIcon}
                                              alt=''
                                              className=''
                                              id='languageIcon'

                                            />
                                            {commaSepratorString(expert.speaks)}

                                          </p>
                                          <p className="mb10  followerIcon blk-color">
                                            <img
                                              src={followersIcon}
                                              alt=''
                                              className=''
                                              id='followerIcon'

                                            />

                                            {/* <span className="blk-color fnt-rubik">0 Followers &nbsp;</span> */}
                                            <Rate
                                              allowHalf
                                              defaultValue={0}
                                              className="an-14"
                                            />

                                          </p>



                                          <div className="mt55 mb20 text-center">
                                            <a href="#!" className="ex__primary_btn view_profile"
                                              onClick={() =>
                                                props.history.push(
                                                  `/expert-profile/${expert.id}`
                                                )
                                              }>View Profile	 </a>
                                          </div>
                                        </div>
                                      </Card>
                                    </Col>
                                  ))}
                                </OwlCarousel>
                              </Row>
                            )}
                      </Row>
                    </div>
                  </Col>
                </Row>
              </>
            )
          }

          {loaderTrip ? (
            <div className="text-center py20 loader-absolute-class">
              <AppLoader />
            </div>
          ) : (
              <><Row className="pb20">
                <Col xs={12} sm={12} md={18} lg={18} xl={18}>
                  <div className="expidition_bg">
                    <h4 className="sub_title expert-trip">
                      {CaptalizeFirst("Browse Expeditions")}
                    </h4>
                  </div>
                </Col>
                <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                  <div className="view_more_position vm_homepage">
                    <Button
                      className="view-more-trips an-20 mt10 button_set"
                      onClick={() =>
                        props.history.push(
                          `/expeditions`
                        )
                      }
                    >
                      View More
                    </Button>
                  </div>
                </Col>
              </Row>
                <Row gutter={20}>
                  <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                    <div className="expidition_bg expendition">
                      <Row justify="space-between" gutter={[10, 20]}>
                        {loaderTrip ? (
                          <div className="text-center py20 loader-absolute-class">
                            <AppLoader />
                          </div>
                        ) : trips.length === 0 ? (
                          <div className="no_trips_found mb15">
                            <div className="mb10 an-14 medium-text text-left">
                              <h4>Currently, there are no trips</h4>
                            </div>
                            {role === "expert" && (
                              <Button
                                className="view-more-trips an-20 mt10"
                                onClick={onExpeditionsClick}
                              >
                                Create Trip
                              </Button>
                            )}
                          </div>
                        ) : (
                              <Row gutter={40} className="pb20 margin_fix_mobile all_page_card slider_prev_next">
                                <TripWorkshopAllCardsCarousel
                                  view="trip"
                                  items={trips}
                                />
                              </Row>
                            )}
                      </Row>
                    </div>
                  </Col>
                </Row>
              </>
            )}

          {loaderWorkshop ? (
            <div className="text-center py20 loader-absolute-class">
              <AppLoader />
            </div>
          ) : (
              <>
                <Row className="pb20">
                  <Col xs={12} sm={12} md={18} lg={18} xl={18}>
                    <div className="expidition_bg">
                      <h4 className="sub_title expert-trip">
                        {CaptalizeFirst("Browse Workshops")}
                      </h4>
                    </div>
                  </Col>
                  <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                    <div className="view_more_position vm_homepage">
                      <Button
                        className="view-more-trips an-20 mt10 button_set"
                        onClick={() => props.history.push(`/learning`)}
                      >
                        View More
                  </Button>
                    </div>
                  </Col>
                </Row>
                <Row gutter={20}>
                  <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                    <div className="expidition_bg expendition">
                      <Row justify="space-between" gutter={[10, 20]}>
                        {loaderWorkshop ? (
                          <div className="text-center py20 loader-absolute-class">
                            <AppLoader />
                          </div>
                        ) : workshops.length === 0 ? (
                          <div className="no_trips_found mb15">
                            <div className="mb10 an-14 medium-text text-left">
                              <h4>Currently, there are no workshops</h4>
                            </div>
                            {role === "expert" && (
                              <Button
                                className="view-more-trips an-20 mt10"
                                onClick={onCreateWorkshopClick}
                              >
                                Create workshop
                              </Button>
                            )}
                          </div>
                        ) : (
                              <Row gutter={40} className="pb20 margin_fix_mobile all_page_card slider_prev_next">
                                <TripWorkshopAllCardsCarousel
                                  view="workshop"
                                  items={workshops}
                                />
                              </Row>
                            )}
                      </Row>
                    </div>
                  </Col>
                </Row>
              </>
            )}

        </div>
      </div>
    </div>
  );
};

export default compose(withRouter)(ExpertsHomePanel);
