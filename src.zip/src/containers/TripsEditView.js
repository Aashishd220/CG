import React, { useEffect, useCallback, useState, Fragment } from 'react';
import { Card, Row, Col, List, Avatar, Radio, Form, message, Button, Upload } from 'antd';
import { Link } from 'react-router-dom';
import ReactHtmlParser from 'react-html-parser';
import { withRouter } from 'react-router-dom';
import { compose } from 'redux';
import { useSelector } from 'react-redux';
import { UploadOutlined } from '@ant-design/icons';
import OwlCarousel from "react-owl-carousel";


// Image Import
import Placeholder from '../assets/images/placeholder.png';
import Location_Img from '../assets/images/country_ic.png';
import Share from '../assets/images/share_ic.png';
import Skill from '../assets/images/skill_ic_filled.png';
import languageIcon from '../assets/images/speaks_ic_2x.png';
import Star from '../assets/images/men.png';
import Participate from '../assets/images/participants_ic_filled.png';
import { CaptalizeFirst, formatDate, removeNewLines, difficultyLevelDisplay, commaSepratorString, DayorDaysNightOrNights, addSpaceAfterComma, getCityFromLocation, displayDifficultyText, commaSepratorStringCaps, getCurrencySymbol } from '../helpers/methods';
import TripMap from '../components/Trips/Map';
import AppLoader from '../components/Loader';

import { getTripDetail, getMyAlbums } from '../services/expert';

import Reservation from '../components/Trips/Reservation';
import Interested from '../components/Trips/Interested';
import Cancellation from '../components/Trips/Cancellation';
import MoreDetails from '../components/Learning/Moredetails';
import AddPhoto from '../components/Trips/AddPhoto';

import Clock from '../assets/images/duration_ic_filled.png';
import Activity from '../assets/images/activity_ic_filled.png';
import Speak from '../assets/images/speaks_ic.png';
import AccommodationPhoto from '../components/Trips/AccommodationPhoto';
import AccommodationPhotoViewPopup from '../components/Trips/AccommodationPhotoView';
import ReactPlayer from 'react-player';
import LikeAndShare from "../components/common/Likeandshare";
import { notFound } from "../helpers/constants";


const ApiKey = process.env.REACT_APP_GOOGLE_MAP_API_KEY;

// Header Section
const data = [
  {
    title: 'Location',
    title3: 'Duration',
    title2: 'Difficulty level',
    title4: 'Activity',
    title5: 'Expedition Type',
  },
];

const expeditionsOptions = {
  items: 5,
  nav: true,
  loop: false,
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dots: false,
    },
    768: {
      items: 2,
      nav: true,
      dots: false,
    },
    991: {
      items: 3,
      nav: true,
      dots: false,
    },
  },
};


const sliderOptions = {
  className: "owl-theme accommodation_img_view slider_prev_next",
  margin: 10,
  nav: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dotsEach: 3,
    },
    768: {
      items: 2,
      nav: true,
    },
    991: {
      items: 3,
      nav: true,
    },
  },
};


const TripsEditView = (props) => {
  const {
    match: {
      params: { id },
    },
    publicAlbums
  } = props;

  const token = useSelector(state => state.auth.accessToken);

  const [loader, setLoader] = useState(true);
  const [trip, setTrip] = useState(null);
  const [slot, setSlot] = useState(null);
  const isLogin = useSelector((state) => state.auth.isLogin);
  const role = useSelector((state) => state.auth.role);

  const [showCanc, setShowCanc] = useState(false);
  const [datePrice, setDatePrice] = useState('');
  const [datePriceCurrency, setDatePriceCurrency] = useState('');
  const [moreDetail, setMoreDetails] = useState(false);
  const [photoPopUp, setPhotoPopUp] = useState(false);
  const [showInterest, setShowInterest] = useState(false);
  const [showR, setShowR] = useState(false);
  const [accommoPopUp, setAccommoPopUp] = useState(false);
  const [accommodationPhotoViewPopup, setAccommodationPhotoViewPopup] = useState(false);
  const [currentViewImage, setCurrentViewImage] = useState(0);
  const [albums, setAlbums] = useState([]);
  const [currentPhotoView, setCurrentPhotoView] = useState("accomo");
  const [imageLoading,setImageLoading]=useState(true)
  const [imageCover,setImageCover]=useState(null)

  const onCloseClick = () => {
    setShowR(false);
    setShowCanc(false);
    setMoreDetails(false);
    setPhotoPopUp(false);
    setAccommoPopUp(false);
    setAccommodationPhotoViewPopup(false);

  };

  const onInstCloseClick = () => setShowInterest(false);

  const checkImage=(url)=>{
    const id = setInterval(()=>{
      fetch(url)
     .then((res)=>{
       if(res.status===200){
         setImageCover(url)
         setImageLoading(false)
       return;
       }
      })
    },1000)
  }

  const getData = useCallback(async (id) => {
    const result = await getTripDetail(id);
    // checkImage(result.data.data.cover)
    
    if (result.status === 200) {
      let tripRes = result.data.data;
      tripRes.language = addSpaceAfterComma(tripRes.language);
      tripRes.inclusion = removeNewLines(tripRes.inclusion);
      tripRes.exclusion = removeNewLines(tripRes.exclusion);

      if (typeof tripRes.accomodation === "undefined" || tripRes.accomodation.trim() === "<p><br></p>") {
        tripRes.accomodation = ""
      }
      if (typeof tripRes.meetingPoint === "undefined" || tripRes.meetingPoint === "null") {
        tripRes.meetingPoint = "";
      }

      if (typeof tripRes.extras === "undefined" || tripRes.extras.trim() === "<p><br></p>" || tripRes.extras.trim() === "null" || tripRes.extras === "") {
        tripRes.extras = "";
      }

      if (typeof tripRes.itenary === "undefined" || (typeof tripRes.itenary !== "undefined" && tripRes.itenary.length > 0 && (typeof tripRes.itenary[0].value === "undefined" || tripRes.itenary[0].value === ""))) {
        tripRes.itenary = [];
      }

      tripRes.whatLearn = (tripRes.whatLearn && tripRes.whatLearn.trim() !== 'null' && tripRes.whatLearn.trim() !== '' && tripRes.whatLearn.trim() !== "<p><br></p>") ? tripRes.whatLearn : "";
      tripRes.attend = (tripRes.attend && tripRes.attend.trim() !== 'null' && tripRes.attend.trim() !== '' && tripRes.attend.trim() !== "<p><br></p>") ? tripRes.attend : "";
    
      setTrip(tripRes);
      setLoader(false);
      getAlbumData();
    }

  }, []);

  const getAlbumData = useCallback(async () => {
    const result = await getMyAlbums(token);
    if (result.status === 200) {
      let finalList = [];
      if (result.data.data !== undefined && result.data.data.length > 0) {
        finalList = result.data.data.filter(item => item.isDelete === false)
      }
      setAlbums(finalList);
    }
  }, []);

  const selectDate = (date, price, priceCurrency) => {
    setSlot(date);
    setDatePrice(price);
    setDatePriceCurrency(priceCurrency);
  };

  const onIntseretClick = () => {
    if (isLogin) {
      if (role !== 'enthusiasts') {
        return message.error(
          'You must be logged in as enthusiasts to send request',
        );
      }
      setShowInterest(true);
    } else {
      message.error('Please login to make reservation request');
    }
  };

  const onReserveClick = () => {
    if (!slot) {
      return message.error(
        'Please select date slot to make reservation request',
      );
    }
    if (isLogin) {
      if (role !== 'enthusiasts') {
        return message.error(
          'You must be logged in as enthusiasts to send request',
        );
      }
      setShowR(true);
    } else {
      message.error('Please login to make reservation request');
    }
  };

  const onClickDate = (d) => {
    if (!slot) {
      return message.error(
        'Please select date slot to make reservation request',
      );
    }
    if (isLogin) {
      if (role !== 'enthusiasts') {
        return message.error(
          'You must be logged in as enthusiasts to send request',
        );
      }
      selectDate(d.fromDate, d.price, d.priceCurrency);
      setShowR(true);
    } else {
      message.error('Please login to make reservation request');
    }

  }

  useEffect(() => {
    getData(id);
  }, [getData, id]);

  useEffect(() => {
    getAlbumData();
  }, [getAlbumData, token]);


  const addPhoto = () => {
    setPhotoPopUp(true);
  }

  const addAccommoPopUp = () => {
    setAccommoPopUp(true);
  }

  const uploadProps = {
    name: 'file',
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    headers: {
      authorization: 'authorization-text',
    },
    onChange(info) {
      if (info.file.status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (info.file.status === 'done') {

        message.success(`${info.file.name} file uploaded successfully`);
      } else if (info.file.status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  const onAccommoImageClick = (index, view) => {
    setCurrentPhotoView(view);
    setCurrentViewImage(index);
    setAccommodationPhotoViewPopup(true);
  };

  const getRefreshTrip = async () => {
    setLoader(true);
    const result = await getTripDetail(id);
    if (result.status === 200) {
      setTrip(result.data.data);
      setLoader(false);
    }
  }

  if (loader) {
    return (
      <div className='text-center py20 loader-absolute-class'>
        <AppLoader />
      </div>
    );
  } else {
    return (
      <div className='header-container w_bg set_trip_mobile trip_mobile_view'>
        <div
          className='gallery_bg'
          style={{ backgroundImage: `url(${trip.cover})` }}
        ></div>
         {/* <div
          className="gallery_bg"
          style={{ backgroundImage: `url(${imageCover})` }}
      >{imageLoading===true && <AppLoader/>}</div> */}
     
        <div className='container align-center section_mobile'>
          <div className='expedition_bg tripedit_view'>
            <div className='gallery_sec section_mobile fix_to_top'>
              <Row gutter={20}>
                <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                  <h1 className='an-36 medium-text fw-600'>
                    {CaptalizeFirst(trip.title)}
                  </h1>
                  {trip.country !== 'undefined' && (
                    <h4 className='an-18 medium-text work_title trip_border_btm font-weight-600'>
                      <Avatar src={Location_Img} />{' '}
                      {getCityFromLocation(trip.address)}{CaptalizeFirst(trip.country)}
                    </h4>
                  )}
                </Col>

                <Col xs={24} sm={24} md={16} lg={16} xl={16} className="cover_img_data cover-img-icon">
                  <Row gutter={20}>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout='horizontal'
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Clock} />}
                              title='Duration'
                              className='pl5'
                              description={`${trip.duration} ${DayorDaysNightOrNights('t', trip.duration, trip.durationType)}`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={10} lg={10} xl={10}>
                      <List
                        itemLayout='horizontal'
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Activity} />}
                              title='Activity'
                              description={commaSepratorString(trip.activity)}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout='horizontal'
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Speak} />}
                              title='Language'
                              description={`${trip.language}`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout='horizontal'
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar
                                  src={Skill}
                                  className='pl5 fill-width'
                                />
                              }
                              title='Difficulty Level'
                              // description={difficultyLevelDisplay(trip.difficulty)}
                              description={displayDifficultyText(trip.difficulty)}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={14} sm={12} md={10} lg={10} xl={10} className="trip_cover_detail">
                      <List
                        itemLayout='horizontal'
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar
                                  src={Participate}
                                  className='pl5 fill-width'
                                />
                              }
                              title='Group Size'
                              description={`Upto ${trip.participants} People`}

                            />
                          </List.Item>
                        )}
                      />
                    </Col>

                  </Row>
                  <Row>
                    <Col span={24}>
                      <div className='text-right edt_btn_sec header_edit'>
                        <Link to={`/update-trip/${id}`}>
                          <i className='fas fa-pencil-alt'></i> Edit
                        </Link>
                      </div>
                    </Col>
                  </Row>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8} xl={8} className="trip_reser_card">
                  <div className='date_sec br5'>
                    <Row className='header_per_txt work-trip-detail-page'>
                      <Col span={13}>
                        <h2 className='an-30 medium-text mb10'>
                          {getCurrencySymbol(datePriceCurrency || trip.priceCurrency)} {datePrice || trip.price}
                        </h2>
                        <p className='mb10 an-14 medium-text'>Per Person</p>
                      </Col>
                      <LikeAndShare allLikes={trip.likes} id={trip._id} pageType={"trip"} designType="single" />
                      <Col span={24} className="edit-btn">
                        <div className="edt_btn_sec">
                          <Link to={`/update-trip/${id}`}>
                            <i class="fas fa-pencil-alt"></i> Edit
                          </Link>
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                        <div className='select_date mt10'>
                          {trip.dateTime.length > 0 ? (
                            <Fragment>
                              <p className='an-14 medium-text pt10 fill-width'>
                                Select Date
                              </p>
                              {trip.dateTime.length > 3 && (
                                <Button type="primary" htmlType="submit" className="trip_more_detail" onClick={() => setMoreDetails(true)}>
                                  More Dates
                                </Button>
                              )}
                            </Fragment>
                          ) : (
                              <p className='an-14 medium-text pt10 fill-width'>
                                This trip has flexible dates. Please contact expert for more information.
                              </p>
                            )}
                        </div>
                      </Col>
                      <Col>
                        {trip.dateTime.length > 0 && (
                          <Row className="trip_date_group">
                            <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                              <Form.Item>
                                <Radio.Group initialValue={0}>
                                  {trip.dateTime.map((d, i) => {
                                    if (i === 0 || i === 1 || i === 2) {
                                      return (
                                        <Radio.Button
                                          key={d._id}
                                          value={i}
                                          onClick={() =>
                                            selectDate(d.fromDate, d.price, d.priceCurrency)
                                          }
                                        >
                                          {formatDate(d.fromDate)}
                                        </Radio.Button>
                                      );
                                    } else {
                                      return null;
                                    }
                                  })}
                                </Radio.Group>
                              </Form.Item>
                            </Col>
                          </Row>
                        )}
                        <div className='btn_head'>
                          <span
                            onClick={onIntseretClick}
                            className='yellow_hover_fix yellow_btn mr10 cursor-pointer fix_button_mobile'
                          >
                            I’m Interested
                          </span>
                          <span
                            onClick={onReserveClick}
                            className='green_hover_fix green_btn cursor-pointer'
                          >
                            Reserve
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </div>
                </Col>
              </Row>
            </div>
            <Row gutter={20} className='pt60 trip_view_edit_detail'>
              <Col className="trip_desc_detail justify " xs={24} sm={24} md={16} lg={16} xl={16}>
                <Row>
                  <Col span={24}>
                    <h3 className=' an-22 medium-text pb10 heading_trip_detail'>Trip Details</h3>
                  </Col>
                  <Col span={18}>
                    <div className='trip_detail_des'>
                      <h4 className='medium-text an-18'>About This trip</h4>
                    </div>
                  </Col>
                  <Col span={6}>
                    <div className=' text-right edt_btn_sec'>
                      <Link to={`/update-trip/${id}`}>
                        <i class='fas fa-pencil-alt'></i> Edit
                    </Link>
                    </div>
                  </Col>
                </Row>
                <div className='trip_detail_des editor_text_display'>
                  <span className='lh-30'>
                    {/* {console.log('trip.description => ', trip.description.split("\r"))}
                    {ReactHtmlParser(trip.description)} */}
                    {trip.description && trip.description.trim() !== 'null'
                      ? ReactHtmlParser(trip.description)
                      : ''}
                  </span>
                </div>

                <Row>
                  <Col span={18}>
                    <div className='trip_detail_des'>
                      <h4 className='medium-text an-18'>What will you learn ?</h4>
                    </div>
                  </Col>
                  <Col span={6}>
                    <div className=' text-right edt_btn_sec'>
                      <Link to={`/update-trip/${id}`}>
                        <i class='fas fa-pencil-alt'></i> Edit
                  </Link>
                    </div>
                  </Col>
                </Row>

                <div className='trip_detail_des editor_text_display'>
                  <span className='lh-30'>
                    {trip.whatLearn.trim() !== '' ? ReactHtmlParser(trip.whatLearn) : ''}
                    {trip.whatLearn.trim() === "" && "No Details has found"}
                  </span>
                </div>

                <Row>
                  <Col span={18}>
                    <div className='trip_detail_des'>
                      <h4 className='medium-text an-18'>Who should attend ?</h4>
                    </div>
                  </Col>
                  <Col span={6}>
                    <div className=' text-right edt_btn_sec'>
                      <Link to={`/update-trip/${id}`}>
                        <i class='fas fa-pencil-alt'></i> Edit
                            </Link>
                    </div>
                  </Col>
                </Row>

                <div className='trip_detail_des editor_text_display'>
                  <span className='lh-30'>
                    {trip.attend.trim() !== '' ? ReactHtmlParser(trip.attend) : ''}
                    {trip.attend.trim() === '' && "No Details has found"}
                  </span>
                </div>
              </Col>

              <Col xs={24} sm={24} md={8} lg={8} xl={8} >
                <div className='trip_exp_bg trip_right_side_fix bg_set_trip br20 text-center pb40'>
                  <h4 className='sub_title text-center'>About This Expert</h4>
                  <img
                    src={trip.expert.profile}
                    alt='profile'
                    className='br10 right_side_image'
                  />
                  <h5 className='an-15 medium-text pt20 mb20'>{`${CaptalizeFirst(
                    trip.expert.firstName,
                  )} ${CaptalizeFirst(trip.expert.lastName)}`}</h5>
                  <p className='grn_txt medium-text an-15'>
                    {commaSepratorString(trip.expert.experties)}
                  </p>
                  <p className="pt5 mb5 blanck-Color">
                    <img
                      src={Location_Img}
                      alt=''
                      className='pb10'
                      id='location_img'
                    />
                    {getCityFromLocation(trip.expert.city)}{CaptalizeFirst(trip.expert.country)}
                  </p>
                  <p className="pt5 pb10 blanck-Color">
                    <img
                      src={languageIcon}
                      alt=''
                      className='pb10'
                      id='languageIcon'

                    />
                    {trip.language}
                  </p>
                  <p></p>
                  <Link
                    to={`/expert-profile/${trip.expert._id}`}
                    className='ex__primary_btn pt20 pb20 br5 hover_fix_trip'
                  >
                    View Profile
                  </Link>
                </div>
              </Col>
            </Row>
            <Row>
              <Col className='day_sec metting_point_trip' xs={24} sm={24} md={16} lg={16} xl={16}>
                <Row className='pt20 pr30'>
                  <Col span={18}>
                    <h3 className='an-22 medium-text pb10'>Location</h3>
                  </Col>
                  <Col span={6}>
                    <div className=' text-right edt_btn_sec'>
                      <Link to={`/update-trip/${id}`}>
                        <i class='fas fa-pencil-alt'></i> Edit
                      </Link>
                    </div>
                  </Col>
                  <Col span={20}>

                    <p className="pt5 mb0 trip_location_des">
                      {CaptalizeFirst(trip.address)}
                    </p>

                  </Col>

                  <Col span={16} className="trip_meeting_point">
                    <div className='trip_detail_des'>
                      <h4 className='medium-text an-18 meting-text'>Meeting Point</h4>
                      <p className='lh-30 desc'>{trip ?.meetingPoint}</p>
                    </div>
                  </Col>

                </Row>
                <Row className='pt0 map_trip_edit'>
                  <Col span={24} className='map pb30 pr30'>
                    <TripMap
                      center={trip.location.coordinates}
                      zoom={5}
                      ApiKey={ApiKey}
                    />
                  </Col>
                </Row>
              </Col>
            </Row>
            <Row className="Itinerary_trip_edit justify">
              <Col className="Itinerary_trip_edit_box" xs={24} sm={24} md={16} lg={16} xl={16}>
                <Row>
                  <Col span={18}>
                    <div className='trip_detail_des'>
                      <h4 className='medium-text an-18 pt30'>Itinerary</h4>
                    </div>
                  </Col>
                  <Col span={6}>
                    <div className=' text-right edt_btn_sec pt30 edit_right'>
                      <Link to={`/update-trip/${id}`}>
                        <i class='fas fa-pencil-alt'></i> Edit
                      </Link>
                    </div>
                  </Col>
                </Row>
                <div className='trip_detail_des'>
                  {trip.itenary && trip.itenary.length === 0 &&
                    <p className="regular-text an-16 mt30 pb35 no-data-found-txt">{notFound('trip', 'itineary')}</p>
                  }

                  {trip.itenary && trip.itenary.map((i, index) => {
                    if (typeof i.value !== "undefined" && i.value !== "") {
                      return (
                        <div className='day_sec' key={index}>
                          <h4 className='sub_title font-weight-600 an-14' style={{ paddingTop: 20, paddingBottom: 20 }}  > Day {index + 1} </h4>
                          <p className='lh-30'>{i.value}</p>
                        </div>
                      )
                    } else {
                      return (<p className="regular-text an-16 mt30  pb35 no-data-found-txt">{notFound('trip', 'itineary')}</p>)
                    }
                  })
                  }

                </div>
              </Col>
            </Row>
            <Row className="Accommodation_trip_edit justify">

              <Fragment>
                <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                  <Row className="trip_pad_fix border-top-condition">
                    <Col span={17}>
                      <div className='trip_detail_des'>
                        <h4 className='medium-text an-18 Accommodation_text'>Accommodation</h4>
                      </div>
                    </Col>
                    <Col span={4}>
                      <div className='fix_top_pad text-right edt_btn_sec adit_fix' onClick={addAccommoPopUp}>
                        <i class='fas fa-pencil-alt'></i> Add Photos
                        </div>
                    </Col>
                    <Col span={3}>
                      <div className=' text-right edt_btn_sec edit_right'>
                        <Link to={`/update-trip/${id}`}>
                          <i class='fas fa-pencil-alt'></i> Edit
                          </Link>
                      </div>
                    </Col>
                  </Row>
                </Col>

                {trip.accomodation !== "" &&
                  <Col className="Accommodation_detail_text pb35" xs={24} sm={24} md={16} lg={16} xl={16}>
                    <div className='trip_detail_des'>
                      <div className='lh-30'>
                        {ReactHtmlParser(trip ?.accomodation)}
                      </div>
                    </div>
                  </Col>
                }

                {trip.accomodation === "" &&
                  <Col className="Accommodation_detail_text pb35" xs={24} sm={24} md={16} lg={16} xl={16}>
                    <div className='trip_detail_des'>
                      <div className='lh-30'>
                        <p className="an-16 regular-text no-data-found-txt">{notFound('trip', 'acomodation')}</p>
                      </div>
                    </div>
                  </Col>
                }

                {typeof trip.accomodationPhotos !== "undefiend" && trip.accomodationPhotos.length > 0 &&
                  <Col xs={24} sm={24} md={16} lg={16} xl={16} className="pb30 border-bottom">

                    <OwlCarousel {...sliderOptions}>
                      {trip.accomodationPhotos.map((t, index) => (

                        <Col
                          xs={24}
                          sm={24}
                          md={24}
                          lg={24}
                          xl={24}
                          key={index}
                          className="gutter-row"
                        >
                          <Card
                            hoverable
                            cover={
                              <img
                                onClick={() => onAccommoImageClick(index, "accomo")}
                                alt="example"
                                src={t}
                              />
                            }
                          >
                          </Card>
                        </Col>
                      ))}
                    </OwlCarousel>
                  </Col>
                }
              </Fragment>

            </Row>


            <Row className="extra_info_trip justify">
              <Col xs={24} sm={24} md={16} lg={16} xl={16} className="border-top">
                <Col span={18} className="">
                  <div className='trip_detail_des'>
                    <h4 className='medium-text an-18 pt35 pb25'>
                      Additional Details
                      </h4>
                  </div>
                </Col>
                <Col span={6}>
                  <div className=' text-right edt_btn_sec pt35 pb25'>
                    <Link to={`/update-trip/${id}`}>
                      <i class='fas fa-pencil-alt'></i> Edit
                      </Link>
                  </div>
                </Col>

                <Col span={24}>
                  <div className='trip_detail_des'>
                    <div className='lh-30'>
                      {trip.extras && trip.extras.trim() !== 'null' && trip.extras !== "" &&
                        ReactHtmlParser(trip.extras)
                      }
                      {trip.extras === "" && <p>{notFound('trip', 'extra')}</p>}
                    </div>
                  </div>
                </Col>
              </Col>
            </Row>

            <Row gutter={20} className='mt40 mb40 Inclusions_title_fix'>
              <Col className="Inclusions_section" xs={24} sm={24} md={8} lg={8} xl={8}>
                <div className='trip_inclusion_sec trip_detail_des brder_sec'>
                  <Row className='border_btm mb15'>
                    <Col span={12}>
                      <h4 className='medium-text an-18 pb20 brder_nn'>
                        Inclusions
                        </h4>
                    </Col>
                    <Col span={12}>
                      <div className=' text-right edt_btn_sec'>
                        <Link to={`/update-trip/${id}`}>
                          <i class='fas fa-pencil-alt'></i> Edit
                          </Link>
                      </div>
                    </Col>
                  </Row>
                  <div className='lh-30 list_off'>
                    {trip.inclusion && trip.inclusion.trim() !== 'null' && trip.inclusion.trim() !== "" &&
                      <>
                        {ReactHtmlParser(trip.inclusion)}
                      </>
                    }
                     {trip.inclusion.trim() === "" && <p className="no-bullet">{notFound('trip', 'inclusionExclusion')}</p>}
                  </div>
                </div>
              </Col>

              <Col xs={24} sm={24} md={8} lg={8} xl={8}>
                <div className='trip_inclusion_sec trip_detail_des brder_sec trip_exclusion_sec'>
                  <Row className='border_btm mb15'>
                    <Col span={12}>
                      <h4 className='medium-text an-18 pb20 brder_nn'>
                        Exclusions
                        </h4>
                    </Col>
                    <Col span={12}>
                      <div className=' text-right edt_btn_sec'>
                        <Link to={`/update-trip/${id}`}>
                          <i class='fas fa-pencil-alt'></i> Edit
                          </Link>
                      </div>
                    </Col>
                  </Row>
                  <div className='lh-30 list_off'>
                    {trip.exclusion && trip.exclusion.trim() !== 'null' && trip.exclusion.trim() !== "" &&
                      <>
                        {ReactHtmlParser(trip.exclusion)}
                      </>
                    }
                    {trip.exclusion.trim() === "" && <p className="no-bullet">{notFound('trip', 'inclusionExclusion')}</p>}
                  </div>
                </div>
              </Col>

            </Row>

            <Row className="trip_prize_section justify">
              <Col xs={24} sm={24} md={16} lg={16} xl={16} >
                <div className='person_sec'>
                  <div className='fill-width'>
                    <h1 className='medium-text an-28 mb0'>
                      {getCurrencySymbol(datePriceCurrency || trip.priceCurrency)} {datePrice || trip.price}
                    </h1>
                    <p className='an-14 medium-text'>Per Person</p>
                  </div>
                  <div className='fill-width text-right'>
                    <span
                      onClick={onIntseretClick}
                      className='yellow_btn mr10 cursor-pointer '
                    >
                      I’m Interested
                    </span>
                    <span
                      onClick={onReserveClick}
                      className='green_btn cursor-pointer'
                    >
                      Reserve
                    </span>
                    {trip.cancellations && (
                      <h6
                        className='an-14 cursor-pointer'
                        onClick={() => setShowCanc(true)}
                      >
                        *Terms & Conditions
                      </h6>
                    )}
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col className="trip_photoset">
                <div className='photo_sec'>
                  <Row>
                    <Col>
                      <Row className="pb20">
                        <Col span={12}>
                          <h4 className='sub_title'>
                            Pictures and Videos from Past Trips
                          </h4>
                        </Col>
                        <Col className="fix_adit_button" span={12}>
                          <div className='fix_top_pad text-right edt_btn_sec adit_fix' onClick={addPhoto}>
                            <i class='fas fa-pencil-alt'></i> Add Photos
                          </div>
                        </Col>
                      </Row>
                      <Row gutter={[40]}>
                        <OwlCarousel
                          {...sliderOptions}
                        >
                          {trip.images.length > 0 && trip.images.map((img, index) => {
                            return (

                              < Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25" >
                                {
                                  img.search(".mp4") != -1 ?

                                    (<ReactPlayer className="video_edit_page" url={img} onClick={() => onAccommoImageClick(index, 'photos')} />)

                                    : (<img src={img} alt="" onClick={() => onAccommoImageClick(index, 'photos')} />)
                                }
                              </Col>
                            )
                          })}
                          {trip.images.length === 0 &&
                            <>
                              <Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25">
                                <img src={Placeholder} alt="" />
                              </Col>
                              <Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25">
                                <img src={Placeholder} alt="" />
                              </Col>
                              <Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25">
                                <img src={Placeholder} alt="" />
                              </Col>
                            </>
                          }

                        </OwlCarousel>

                      </Row>
                      {/* <Row className="margin_fix_trip_edit" gutter={[40]}>
                        <Col className='gutter-row' xs={24} sm={24} md={8} lg={8} xl={8}>
                          <img src={Placeholder} alt='' />
                        </Col>
                        <Col className='gutter-row' xs={24} sm={24} md={8} lg={8} xl={8}>
                          <img src={Placeholder} alt='' />
                        </Col>
                        <Col className='gutter-row' xs={24} sm={24} md={8} lg={8} xl={8}>
                          <img src={Placeholder} alt='' />
                        </Col>
                      </Row> */}
                    </Col>
                  </Row>
                </div>
              </Col>
            </Row>
          </div>
        </div>
        {
          moreDetail && (
            <MoreDetails
              visible={moreDetail}
              data={trip.dateTime}
              onIntseretClick={onIntseretClick}
              onReserveClick={onReserveClick}
              onClickDate={(d) => onClickDate(d)}
              onCloseClick={onCloseClick}
            />
          )
        }
        {
          showCanc && (
            <Cancellation
              visible={showCanc}
              data={trip.cancellations}
              onCloseClick={onCloseClick}
            />
          )
        }
        {
          showR && (
            <Reservation
              visible={showR}
              trip={trip.title}
              slot={slot}
              onCloseClick={onCloseClick}
              id={id}
            />
          )
        }
        {
          showInterest && (
            <Interested
              visible={showInterest}
              trip={trip.title}
              onCloseClick={onInstCloseClick}
              id={id}
            />
          )
        }
        {
          photoPopUp && (
            <AddPhoto
              visible={photoPopUp}
              onCloseClick={onCloseClick}
              albumList={albums}
              id={id}
              currentImages={trip.images}
              getRefreshTrip={getRefreshTrip}
              type="trip"
            />
          )
        }
        {
          accommoPopUp && (
            <AccommodationPhoto
              visible={accommoPopUp}
              onCloseClick={onCloseClick}
              id={id}
              getRefreshTrip={getRefreshTrip}
              type="trip"
              allPhotos={trip.accomodationPhotos}
              selectedAlbum={trip.accomodationPhotos}
            />
          )
        }

        {
          accommodationPhotoViewPopup && (
            <AccommodationPhotoViewPopup
              visible={accommodationPhotoViewPopup}
              onCloseClick={onCloseClick}
              id={id}
              allPhotos={currentPhotoView === "accomo" ? trip.accomodationPhotos : trip.images}
              currentViewImage={currentViewImage}
            />
          )
        }


      </div >
    );
  }
};
export default compose(withRouter)(TripsEditView);
