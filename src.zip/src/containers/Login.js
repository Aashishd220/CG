import React, { useState } from 'react';
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import { useDispatch } from 'react-redux';

import { Redirect } from 'react-router-dom';
import { ModalActions } from '../redux/models/events';

const Login = props => {
  const [showModel, setShowModel] = useState(false);

  const dispatch = useDispatch();
  const { openAuthModal } = ModalActions;
  dispatch(openAuthModal())

  const handleClick = () => {
    setShowModel(false);
    dispatch(openAuthModal())
  }

  return (
    <div>
        <Redirect to={"/"} visible={showModel} handleClick={handleClick} />
    </div>
  )
}

export default compose(withRouter)(Login);
