import React from "react";
import privacyPolicy from "assets/images/privacyPolicy.svg";

export default function PrivacyPolicy() {
  return (
    <div className="privacy-policy">
      <img src={privacyPolicy} alt="" />
    </div>
  );
}
