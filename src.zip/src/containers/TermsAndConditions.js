import React from "react";
import termsAndConditions from "assets/images/termsAndConditions.svg";

function TermsAndConditions() {
  return (
    <div className="privacy-policy">
      <img src={termsAndConditions} alt="" />
    </div>
  );
}

export default TermsAndConditions;
