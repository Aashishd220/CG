import React, { useEffect, useCallback, useState, Fragment } from "react";
import {
  Row,
  Col,
  List,
  Avatar,
  Radio,
  Form,
  Card,
  Rate,
  message,
  Badge,
  Dropdown,
  Popover,
} from "antd";
import { Link } from "react-router-dom";
import ReactHtmlParser from "react-html-parser";
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import moment from "moment";
import { useSelector } from "react-redux";
import OwlCarousel from "react-owl-carousel";

// Image Import
import Placeholder from "../assets/images/placeholder.png";
import Location_Img from "../assets/images/country_ic.png";
import Share from "../assets/images/share_ic.png";
import languageIcon from "../assets/images/speaks_ic_2x.png";
import Heart from "../assets/images/save_ic.png";
import Skill from "../assets/images/skill_ic_filled.png";
import Star from "../assets/images/men.png";
import Participate from "../assets/images/participants_ic_filled.png";
import {
  CaptalizeFirst,
  formatDate,
  removeNewLines,
  difficultyLevelDisplay,
  getColorLogoURL,
  commaSepratorString,
  DayorDaysNightOrNights,
  addSpaceAfterComma,
  commaSepratorStringCaps,
  displayDifficultyText,
  getCityFromLocation,
  getCurrencySymbol,
} from "../helpers/methods";
import TripMap from "../components/Trips/Map";
import AppLoader from "../components/Loader";
import SkillRed from "../assets/images/skill_red.svg";
import SkillGreen from "../assets/images/skill_green.svg";
import SkillOrange from "../assets/images/skill_orange.svg";
import shareOption from "../containers/commonContainer/shareOption";

import { getTripDetail, getSimilarTrips } from "../services/expert";

import Reservation from "../components/Trips/Reservation";
import Interested from "../components/Trips/Interested";
import Cancellation from "../components/Trips/Cancellation";
import MoreDetails from "../components/Learning/Moredetails";

import Clock from "../assets/images/duration_ic_filled.png";
import Activity from "../assets/images/activity_ic_filled.png";
import Speak from "../assets/images/speaks_ic.png";
import AccommodationPhotoViewPopup from "../components/Trips/AccommodationPhotoView";
import { DISPLAY_RESULT } from "helpers/constants";
import ReactPlayer from 'react-player';
import TripWorkshopAllCardsCarousel from "../components/common/TripWorkshopAllCardsCarousel";
import LikeAndShare from "../components/common/Likeandshare";


const ApiKey = process.env.REACT_APP_GOOGLE_MAP_API_KEY;

// Header Section
const data = [
  {
    title: "Location",
    title3: "Duration",
    title2: "Difficulty level",
    title4: "Activity",
    title5: "Expedition Type",
  },
];

const expeditionsOptions = {
  items: 5,
  nav: true,
  loop: false,
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dots: false,
    },
    768: {
      items: 2,
      nav: true,
      dots: false,
    },
    991: {
      items: 3,
      nav: true,
      dots: false,
    },
  },
};

const sliderOptions = {
  margin: 10,
  nav: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dotsEach: 3,
    },
    768: {
      items: 2,
      nav: true,
    },
    991: {
      items: 3,
      nav: true,
    },
  },
};

const TripsPublicView = (props) => {
  const {
    match: {
      params: { id },
    },
  } = props;
  const [loader, setLoader] = useState(true);
  const [similarTrip, setSimilarTrips] = useState([]);
  const [SimilarTripLoader, setSimilarTripLoader] = useState(false);
  const [trip, setTrip] = useState(null);
  const [slot, setSlot] = useState(null);
  const [slotn, setSlotn] = useState(null);
  const isLogin = useSelector((state) => state.auth.isLogin);
  const role = useSelector((state) => state.auth.role);

  const [showCanc, setShowCanc] = useState(false);
  const [datePrice, setDatePrice] = useState("");
  const [datePriceCurrency, setDatePriceCurrency] = useState("");
  const [moreDetail, setMoreDetails] = useState(false);
  const [showInterest, setShowInterest] = useState(false);
  const [showR, setShowR] = useState(false);
  const [
    accommodationPhotoViewPopup,
    setAccommodationPhotoViewPopup,
  ] = useState(false);
  const [currentViewImage, setCurrentViewImage] = useState(0);
  const [currentPhotoView, setCurrentPhotoView] = useState("accomo");
  const [currentDateType, setCurrentDateType] = useState(1); //1=Date, 2=Flexi Date

  const onCloseClick = () => {
    setShowR(false);
    setShowCanc(false);
    setMoreDetails(false);
    setAccommodationPhotoViewPopup(false);
  };

  const onInstCloseClick = () => setShowInterest(false);

  const colors = ["yellow"];

  const getData = useCallback(async (id) => {
    const result = await getTripDetail(id);
    if (result.status === 200) {

      let tripRes = result.data.data;
      tripRes.language = addSpaceAfterComma(tripRes.language);
      tripRes.inclusion = removeNewLines(tripRes.inclusion);
      tripRes.exclusion = removeNewLines(tripRes.exclusion);

      if (typeof tripRes.whatLearn === "undefined" || tripRes.whatLearn.trim() === "<p><br></p>" || tripRes.whatLearn.trim() === "null") {
        tripRes.whatLearn = "";
      }

      if (typeof tripRes.attend === "undefined" || tripRes.attend.trim() === "<p><br></p>" || tripRes.attend.trim() === "null") {
        tripRes.attend = "";
      }

      if (typeof tripRes.accomodation === "undefined" || tripRes.accomodation.trim() === "<p><br></p>") {
        tripRes.accomodation = ""
      }

      if (typeof tripRes.extras === "undefined" || tripRes.extras.trim() === "<p><br></p>" || tripRes.extras.trim() === "null" || tripRes.extras === "") {
        tripRes.extras = "";
      }

      if (typeof tripRes.itenary === "undefined" || (typeof tripRes.itenary !== "undefined" && tripRes.itenary.length > 0 && (typeof tripRes.itenary[0].value === "undefined" || tripRes.itenary[0].value === ""))) {
        tripRes.itenary = [];
      }


      setCurrentDateType(tripRes.dateType)
      setTrip(tripRes);

      setLoader(false);
    }
    const data = {
      activity: JSON.stringify(result.data.data.activity),
      type: JSON.stringify(result.data.data.type),
    };
    setSimilarTripLoader(true);
    const st = await getSimilarTrips(data);
    if (st.status === 200) {

      setSimilarTrips(st.data.data);
      setSimilarTripLoader(false);
    }
  }, []);


  const selectDate = (date, price, num, priceCurrency = 'USD') => {
    setSlot(date);
    setDatePrice(price);
    setDatePriceCurrency(priceCurrency);
    setSlotn(num);
  };


  const onIntseretClick = () => {
    if (isLogin) {
      if (role !== "enthusiasts") {
        return message.error(
          "You must be logged in as enthusiasts to send request"
        );
      }
      setShowInterest(true);
    } else {
      message.error("Please login to make reservation request");
    }
  };

  const onReserveClick = () => {
    if (!slot && currentDateType == 1) {
      return message.error(
        "Please select date slot to make reservation request"
      );
    }
    if (isLogin) {
      if (role !== "enthusiasts") {
        return message.error(
          "You must be logged in as enthusiasts to send request"
        );
      }
      setShowR(true);
    } else {
      message.error("Please login to make reservation request");
    }
  };

  const onClickDate = (d, i) => {
    if (!slot) {
      return message.error(
        "Please select date slot to make reservation request"
      );
    }
    if (isLogin) {
      if (role !== "enthusiasts") {
        return message.error(
          "You must be logged in as enthusiasts to send request"
        );
      }
      setShowR(true);
      selectDate(d.fromDate, d.price, i, d.priceCurrency);
      setShowR(true);
    } else {
      message.error("Please login to make reservation request");
    }
  };

  useEffect(() => {
    getData(id);
  }, [getData, id]);

  const onAccommoImageClick = (index, view) => {
    setCurrentPhotoView(view);
    setCurrentViewImage(index);
    setAccommodationPhotoViewPopup(true);
  };

  const displayLang = (lang) => {
    let resLang = "";
    if (lang.length > 0) {
      lang.map((a, index) => {
        let addCooma = "";
        if (lang.length !== index + 1) {
          addCooma = ", ";
        }
        resLang += CaptalizeFirst(a) + addCooma;
      });
    }

    return resLang;
  };

  if (loader) {
    return (
      <div className="text-center py20 loader-absolute-class">
        <AppLoader />
      </div>
    );
  } else {
    return (
      <div className="header-container w_bg trip_mobile_view">
        <div
          className="gallery_bg"
          style={{ backgroundImage: `url(${trip.cover})` }}
        ></div>
        <div className="container align-center">
          <div className="expedition_bg trip_view_detail_edit">
            <div className="gallery_sec main_head_text fix_to_top">
              <Row>
                <Col>
                  <h1 className="an-36 medium-text cover-img-main-title text_skill ">
                    {CaptalizeFirst(trip.title)}
                  </h1>
                  {trip.country !== "undefined" && (
                    <h4 className="an-18 medium-text work_title trip_border_btm fw-600">
                      <Avatar src={Location_Img} />{" "}
                      {getCityFromLocation(trip.address)}
                      {CaptalizeFirst(trip.country)}
                    </h4>
                  )}
                </Col>
              </Row>
              <Row gutter={20}>
                <Col
                  xs={24}
                  sm={24}
                  md={16}
                  lg={16}
                  xl={16}
                  className="trip_cover_detail cover_img_data cover-img-icon"
                >
                  <Row gutter={20}>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Clock} />}
                              title="Duration"
                              className="pl5"
                              description={`${
                                trip.duration
                                } ${DayorDaysNightOrNights(
                                  "t",
                                  trip.duration,
                                  trip.durationType
                                )}`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={10} lg={10} xl={10}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Activity} />}
                              title="Activity"
                              description={commaSepratorString(trip.activity)}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={<Avatar src={Speak} />}
                              title="Language"
                              description={`${trip.language}`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={7} lg={7} xl={7}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar
                                  src={Skill}
                                  className="pl5 fill-width"
                                />
                              }
                              title="Difficulty Level"
                              description={displayDifficultyText(
                                trip.difficulty
                              )}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                    <Col xs={14} sm={12} md={10} lg={10} xl={10}>
                      <List
                        itemLayout="horizontal"
                        dataSource={data}
                        renderItem={(item) => (
                          <List.Item>
                            <List.Item.Meta
                              avatar={
                                <Avatar
                                  src={Participate}
                                  className="pl5 fill-width"
                                />
                              }
                              title="Group Size"
                              description={`Upto ${trip.participants} People`}
                            />
                          </List.Item>
                        )}
                      />
                    </Col>
                  </Row>
                </Col>
                <Col
                  xs={24}
                  sm={24}
                  md={8}
                  lg={8}
                  xl={8}
                  className="trip_reser_card"
                >
                  <div className="date_sec br5">
                    <Row className="header_per_txt work-trip-detail-page">
                      <Col span={13}>
                        <h2 className="an-30 medium-text mb10">{getCurrencySymbol(datePriceCurrency || trip.priceCurrency)} {datePrice || trip.price} </h2>
                        <p className="mb10 an-14 medium-text">Per Person</p>
                      </Col>
                      <LikeAndShare allLikes={trip.likes} id={trip._id} pageType={"trip"} designType="single" />                     
                    </Row>
                    <Row>
                      <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                        <div className="select_date mt10">
                          {trip.dateTime.length > 0 ? (
                            <Fragment>
                              <p className="an-14 medium-text pt10 fill-width">
                                Select Date
                              </p>
                              {trip.dateTime.length > 3 && (
                                <button
                                  className="trip_more_detail"
                                  onClick={() => setMoreDetails(true)}
                                >
                                  More Dates
                                </button>
                              )}
                            </Fragment>
                          ) : (
                              <p className="an-14 medium-text pt10 fill-width">
                                This trip has flexible dates. Please contact
                                expert for more information.
                            </p>
                            )}
                        </div>
                      </Col>
                      <Col>
                        {trip.dateTime.length > 0 && (
                          <Row>
                            <Col
                              className="trip_date_group"
                              xs={24}
                              sm={24}
                              md={24}
                              lg={24}
                              xl={24}
                            >
                              <Form.Item>
                                <Radio.Group initialValue={0}>
                                  {trip.dateTime.map((d, i) => {
                                    if (i === 0 || i === 1 || i === 2) {
                                      return (
                                        <Radio.Button
                                          key={d._id}
                                          value={i}
                                          onClick={() =>
                                            selectDate(
                                              d.fromDate,
                                              d.price,
                                              i,
                                              d.priceCurrency
                                            )
                                          }
                                        >
                                          {formatDate(d.fromDate)}
                                        </Radio.Button>
                                      );
                                    } else {
                                      return null;
                                    }
                                  })}
                                </Radio.Group>
                              </Form.Item>
                            </Col>
                          </Row>
                        )}
                        <div className="btn_head">
                          <span
                            onClick={onIntseretClick}
                            className="yellow_hover_fix yellow_btn mr10 cursor-pointer tripdetaile_button_top"
                          >
                            I’m Interested
                          </span>
                          <span
                            onClick={onReserveClick}
                            className="green_btn cursor-pointer green_hover_fix"
                          >
                            Reserve
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </div>
                </Col>
              </Row>
            </div>
            <Row gutter={20} className="pt60">
              <Col
                xs={24}
                sm={24}
                md={16}
                lg={16}
                xl={16}
                className="padding-right justify"
              >
                <Row>
                  <Col span={24}>
                    <h3 className=" an-22 medium-text pb10 detail_view top_detaile_head">
                      Trip Details
                    </h3>
                  </Col>
                </Row>
                <div className="trip_detail_des abot_trip_detail editor_text_display ">
                  <h4 className="medium-text an-18">About This trip</h4>
                  <div className="lh-30">
                    {ReactHtmlParser(trip.description)}
                  </div>
                </div>
                {trip.whatLearn && trip.whatLearn.trim() !== "null" ? (
                  <>
                    <div className="trip_detail_des editor_text_display">
                      <h4 className="medium-text an-18">
                        What will you learn ?
                      </h4>
                      <div className="lh-30">
                        {ReactHtmlParser(trip.whatLearn)}
                      </div>
                    </div>
                  </>
                ) : (
                    ""
                  )}

                {trip.attend && trip.attend.trim() !== "null" ? (
                  <>
                    <div className="trip_detail_des editor_text_display">
                      <h4 className="medium-text an-18">Who should attend ?</h4>
                      <div className="lh-30">
                        {ReactHtmlParser(trip.attend)}
                      </div>
                    </div>
                  </>
                ) : (
                    ""
                  )}

                <Row>
                  <Col
                    className="day_sec"
                    xs={24}
                    sm={24}
                    md={24}
                    lg={24}
                    xl={24}
                  >
                    <Row className="pt20 location_fix_tripdetail">
                      <Col span={24}>
                        <h3 className="an-22 medium-text pb10 location_text">
                          Location
                        </h3>
                      </Col>
                      <Col span={24}>
                        <p className="pt5 mb0 trip_location_des">
                          {CaptalizeFirst(trip.address)}
                        </p>
                      </Col>

                      <Col span={24} className="trip_meeting_point">
                        <div className="trip_detail_des pb0">
                          <h4 className="medium-text an-18 meeting_poit_text">
                            Meeting Point
                          </h4>
                          {trip.meetingPoint !== "" && (
                            <p className="lh-30 about_pargrap">
                              {trip ?.meetingPoint}
                            </p>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row className="pt0 detail_map_trip">
                      <Col
                        span={24}
                        className="map pb30 pr30 fix_detail_location"
                      >
                        <TripMap
                          center={trip.location.coordinates}
                          zoom={5}
                          ApiKey={ApiKey}
                        />
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
              <Col xs={24} sm={24} md={8} lg={8} xl={8}>
                <div className="trip_exp_bg trip_right_side_fix br20 text-center pb40">
                  <h4 className="sub_title text-center">About This Expert</h4>
                  <img
                    src={trip.expert.profile}
                    alt="profile"
                    className="br10 right_side_image"
                  />
                  <h5 className="an-15 medium-text pt20 mb20">{`${CaptalizeFirst(
                    trip.expert.firstName
                  )} ${CaptalizeFirst(trip.expert.lastName)}`}</h5>
                  <p className="grn_txt medium-text an-15">
                    {commaSepratorString(trip.expert.experties)}
                  </p>
                  <p className="pt5 mb5 blanck-Color">
                    <img
                      src={Location_Img}
                      alt=""
                      className="pb10"
                      id="location_img"
                    />
                    {getCityFromLocation(trip.expert.city)}
                    {CaptalizeFirst(trip.expert.country)}
                  </p>
                  <p className="pt5 pb10 blanck-Color">
                    <img
                      src={languageIcon}
                      alt=""
                      className="pb10"
                      id="languageIcon"
                    />
                    {trip.language}
                  </p>
                  <Link
                    to={`/expert-profile/${trip.expert._id}`}
                    className="ex__primary_btn pt20 pb20 br5 fix_the_hover"
                  >
                    View Profile
                  </Link>
                </div>
              </Col>
            </Row>

            {typeof trip.itenary !== "undefined" && trip.itenary.length > 0 &&
              <Row className="Itinerary_tripdetail justify">
                <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                  <div className="trip_detail_des pad_tripdestal pb0">
                    <h4 className="medium-text an-18 pt30 Itinerary_text">Itinerary</h4>
                    {trip.itenary && trip.itenary.length === 0 &&
                      <p className="regular-text an-16 mt20 mb0 no-data-found-txt">This trip has no itinerary</p>
                    }
                    {trip.itenary && trip.itenary.map((i, index) => {
                      if (typeof i.value !== "undefined" && i.value !== "") {
                        return (
                          <div className="day_sec Itinerary_text_p" key={index}>
                            <h4 className="sub_title an-14" style={{ paddingTop: 20, paddingBottom: 20 }}>Day {index + 1}</h4>
                            <p className="lh-30">{i.value}</p>
                          </div>
                        )
                      }
                    })
                    }
                  </div>
                </Col>
              </Row>
            }

            <Row className="Accommodation_trip_edit justify">
              <Fragment>
                {(trip.accomodation !== "" || (typeof trip.accomodationPhotos !== "undefiend" && trip.accomodationPhotos.length > 0)) &&
                  <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                    <Row className="trip_pad_fix">
                      <Col span={20}>
                        <div className='trip_detail_des'>
                          <h4 className='medium-text an-18 Accommodation_text'>Accommodation</h4>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                }

                {trip.accomodation !== "" &&
                  <Col className="Accommodation_detail_text pb25" xs={24} sm={24} md={16} lg={16} xl={16}>
                    <div className='trip_detail_des'>
                      <div className='lh-30'>
                        {ReactHtmlParser(trip ?.accomodation)}
                      </div>
                    </div>
                  </Col>
                }

                {typeof trip.accomodationPhotos !== "undefiend" && trip.accomodationPhotos.length > 0 &&
                  <Col xs={24} sm={24} md={16} lg={16} xl={16} className="pb30">

                    <OwlCarousel
                      className="owl-theme accommodation_img_view slider_prev_next"
                      {...sliderOptions}
                    >
                      {trip.accomodationPhotos.map((t, index) => (

                        <Col xs={24} sm={24} md={24} lg={24} xl={24} key={index} className="gutter-row">
                          <Card
                            hoverable
                            cover={
                              <img
                                onClick={() => onAccommoImageClick(index, 'accomo')}
                                alt="example"
                                src={t}
                              />
                            }
                          >
                          </Card>
                        </Col>
                      ))}
                    </OwlCarousel>
                  </Col>
                }
              </Fragment>

            </Row>

            {trip.extras && trip.extras !== "" &&
              <Row className="extra_info_trip justify">
                <Col xs={24} sm={24} md={16} lg={16} xl={16} className="border-top">
                  <Col span={18} className="">
                    <div className='trip_detail_des'>
                      <h4 className='medium-text an-18 pt40'>
                        Additional Details
                  </h4>
                    </div>
                  </Col>
                  <Col span={24}>
                    <div className='trip_detail_des'>
                      <div className='lh-30'>
                        {ReactHtmlParser(trip ?.extras)}
                      </div>
                    </div>
                  </Col>
                </Col>
              </Row>
            }
            <Row gutter={20} className="mt40 mb40 Inclusions_title_fix">
              <Col xs={24} sm={24} md={16} lg={16} xl={16}>
                {trip.inclusion && trip.inclusion.trim() !== 'null' && trip.inclusion.trim() !== "" && (
                  <Col
                    className="Inclusions_section"
                    xs={24}
                    sm={12}
                    md={12}
                    lg={10}
                    xl={12}
                  >
                    <div className="trip_inclusion_sec trip_detail_des">
                      <h4 className="medium-text an-18 pb30">Inclusions</h4>
                      <div className="lh-30 list_off">
                        {ReactHtmlParser(trip.inclusion)}
                      </div>
                    </div>
                  </Col>
                )}

                <Col xs={24} sm={12} md={12} lg={10} xl={12}>
                  {trip.exclusion && trip.exclusion.trim() !== 'null' && trip.exclusion.trim() !== "" && (
                    <div className="trip_inclusion_sec trip_exclusion_sec trip_detail_des">
                      <h4 className="medium-text an-18 pb30">Exclusions</h4>
                      <div className="lh-30 list_off">
                        {ReactHtmlParser(trip.exclusion)}
                      </div>
                    </div>
                  )}
                </Col>
              </Col>
            </Row>

            <Row>
              <Col
                className="Per_Person_blog justify"
                xs={24}
                sm={24}
                md={16}
                lg={16}
                xl={16}
              >
                <div className="person_sec">
                  <div className="fill-width">
                    <h1 className="medium-text an-28 mb0">
                      {getCurrencySymbol(
                        datePriceCurrency || trip.priceCurrency
                      )}{" "}
                      {datePrice || trip.price}
                    </h1>
                    <p className=" an-14 medium-text">Per Person</p>
                  </div>
                  <div className="fill-width text-right">
                    <span
                      onClick={onIntseretClick}
                      className="yellow_hover_fix yellow_btn mr10 cursor-pointer "
                    >
                      I’m Interested
                    </span>
                    <span
                      onClick={onReserveClick}
                      className="green_hover_fix green_btn cursor-pointer"
                    >
                      Reserve
                    </span>
                    {trip.cancellations && (
                      <h6
                        className=" an-14 cursor-pointer"
                        onClick={() => setShowCanc(true)}
                      >
                        *Terms & Conditions
                      </h6>
                    )}
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col>
                <div className="tripdetail_photo">
                  <Row className="pb40">
                    <Col>
                      <Row>
                        {trip.images.length > 0 ? (
                          <Col span={12}>
                            <h4 className="sub_title photo_trip_head">
                              Pictures and Videos from Past Trips
                            </h4>
                          </Col>
                        ) : (
                            ""
                          )}
                      </Row>
                      <Row gutter={[40]}>
                        <OwlCarousel
                          className="owl-theme owl-dots slider_prev_next photo_video_sec"
                          {...sliderOptions}
                        >
                          {trip.images.length > 0
                            ? trip.images.map((img, index) => {
                              return (
                                <Col
                                  xs={24}
                                  sm={24}
                                  md={24}
                                  lg={24}
                                  xl={24}
                                  className="gutter-row pb25"
                                >
                                  {img.search(".mp4") != -1 ? (
                                    <ReactPlayer
                                      className="video_edit_page"
                                      url={img}
                                      onClick={() =>
                                        onAccommoImageClick(index, "photos")
                                      }
                                    />
                                  ) : (
                                      <img
                                        src={img}
                                        alt=""
                                        onClick={() =>
                                          onAccommoImageClick(index, "photos")
                                        }
                                      />
                                    )}
                                </Col>
                              );
                            })
                            : ""}
                          {/* {trip.images.length === 0 &&
                            <>
                              <Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25">
                                <img src={Placeholder} alt="" />
                              </Col>
                              <Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25">
                                <img src={Placeholder} alt="" />
                              </Col>
                              <Col xs={24} sm={24} md={24} lg={24} xl={24} className="gutter-row pb25">
                                <img src={Placeholder} alt="" />
                              </Col>
                            </>
                          } */}
                        </OwlCarousel>
                      </Row>
                    </Col>
                  </Row>
                  {similarTrip && similarTrip.length >= 3 && (
                    <>
                      <Row className=" pt30 Similar_Tripsdetail">
                        <Col span={12}>
                          <h4 className="sub_title">Similar Trips</h4>
                        </Col>
                        <Col span={12}>
                          <div className="text-right mt30 photo_trip_button">
                            <Link
                              to="/expeditions"
                              className="ex__primary_btn br5"
                            >
                              View More
                            </Link>
                          </div>
                        </Col>
                      </Row>
                      <Row gutter={10} className="pb40 margin_fix_mobile slider_prev_next">
                        <TripWorkshopAllCardsCarousel
                          items={similarTrip}
                        />
                      </Row>
                    </>
                  )}
                </div>
              </Col>
            </Row>
          </div>
        </div>
        {
          moreDetail && (
            <MoreDetails
              visible={moreDetail}
              data={trip.dateTime}
              onIntseretClick={onIntseretClick}
              onReserveClick={onReserveClick}
              onCloseClick={onCloseClick}
              onClickDate={(d, i) => onClickDate(d, i)}
            />
          )
        }
        {
          showCanc && (
            <Cancellation
              visible={showCanc}
              data={trip.cancellations}
              onCloseClick={onCloseClick}
            />
          )
        }
        {
          showR && (
            <Reservation
              name={`${CaptalizeFirst(trip.expert.firstName)} ${CaptalizeFirst(
                trip.expert.lastName
              )}`}
              slotnum={slotn}
              visible={showR}
              trip={trip.title}
              slot={slot}
              onCloseClick={onCloseClick}
              id={id}
            />
          )
        }
        {
          showInterest && (
            <Interested
              visible={showInterest}
              trip={trip.title}
              onCloseClick={onInstCloseClick}
              id={id}
            />
          )
        }

        {
          accommodationPhotoViewPopup && (
            <AccommodationPhotoViewPopup
              visible={accommodationPhotoViewPopup}
              onCloseClick={onCloseClick}
              id={id}
              allPhotos={
                currentPhotoView === "accomo"
                  ? trip.accomodationPhotos
                  : trip.images
              }
              currentViewImage={currentViewImage}
            />
          )
        }
      </div >
    );
  }
};
export default compose(withRouter)(TripsPublicView);
