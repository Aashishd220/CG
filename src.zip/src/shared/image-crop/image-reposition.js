import React, { useState, useCallback } from 'react'
import Cropper from 'react-easy-crop'
import { Button } from "antd";
import getCroppedImg from './crop-image'

const ImageReposition = ({ originalCover, page, setCover,isZoom,setReposition }) => {
    const [crop, setCrop] = useState({ x: 0, y: 0 })
    const [zoom, setZoom] = useState(isZoom?1:1)
    const [croppedAreaPixels, setCroppedAreaPixels] = useState(null)

    //on completing reposition
    const onCropComplete = useCallback((croppedArea, croppedAreaPixels) => {
        setCroppedAreaPixels(croppedAreaPixels)
    }, [])


    //url to dataURL
    const toDataURL = url => fetch(url)
        .then(response => response.blob())
        .then(blob => new Promise((resolve, reject) => {
            const reader = new FileReader()
            reader.onloadend = () => resolve(reader.result)
            reader.onerror = reject
            reader.readAsDataURL(blob)
        }))

    //dataURL to File
    const dataURLtoFile = (dataurl, filename) => {
        var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new File([u8arr], filename, { type: mime });
    }

    //set the cropped image
    const setCroppedImage = useCallback(async () => {
        try {
            const croppedImage = await getCroppedImg(
                originalCover,
                croppedAreaPixels,
            )
            await toDataURL(croppedImage)
                .then(dataUrl => {
                    var fileData = dataURLtoFile(dataUrl, "imageName.jpg");
                    if (page !== 'Trips') {
                        const formData = new FormData();
                        formData.append("cover", fileData);
                        setCover(formData, "edit");
                    }else{
                        setCover(fileData, "edit");
                    }
                })


        } catch (e) {
            console.error(e)
        }
    }, [croppedAreaPixels])

    return (
        <>
            <div className="">
                <Cropper
                    image={originalCover}
                    crop={crop}
                    zoom={zoom}
                    aspect={16 / 7}
                    cropSize={isZoom?{width:165,height:165}:''}
                    onCropChange={setCrop}
                    onCropComplete={onCropComplete}
                    onZoomChange={setZoom}

                />
            </div>

            <div className="save-res-div">
                <Button
                    type="primary"
                    onClick={setCroppedImage}
                    className="save-reposition an-14 medium-text"
                >
                    Save Changes
          </Button>
          <Button
                    type="primary"
                    onClick={()=>setReposition(false)}
                    className="save-reposition an-14 medium-text"
                >
                    Cancel
          </Button>
          
            </div>
        </>
    )
}

export default ImageReposition