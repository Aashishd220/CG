export const getRole = state => state.auth.role;
export const getToken = state => state.auth.accessToken;