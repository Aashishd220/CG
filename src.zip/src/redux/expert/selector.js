export const getAllData = state => state.expert;
export const getToken = state => state.auth.accessToken;
export const getLearningId = state => state.learning.id
export const getTripId = state => state.trips.id;