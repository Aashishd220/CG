import BaseLayout from "../containers/BaseLayout";

const indexRoutes = [
  { path: '/', component: BaseLayout },
];

export default indexRoutes;
