import React from "react";
import { NavLink, Link } from "react-router-dom";

/**
 * App Imports
 */
import footerLogoWhite from "../../assets/images/footerLogoWhite.svg";
import { useMediaQuery } from "react-responsive";
import { useMemo } from "react";
import { BLOG_URL } from "../../helpers/constants";

const Footer = () => {
  const isMobile = useMediaQuery({ query: "(max-width: 992px)" });

  const navigations = useMemo(
    () => (
      <>
        <div>
          <h5 className="navigation-title">Navigations</h5>
          <ul>
            <li>
              <NavLink to="/experts" className="regular-text an-14">
                Experts
              </NavLink>
            </li>
            <li>
              <NavLink to="/expeditions" className="regular-text an-14">
                Expeditions
              </NavLink>
            </li>
            <li>
              <NavLink to="/learning" className="regular-text an-14">
                Learning
              </NavLink>
            </li>
            <li>
              <a href={BLOG_URL} className="an-14 regular-text">
                Blog
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h5 className="navigation-title">Company</h5>
          <ul>
            <li>
              <NavLink to="/" className="an-14 regular-text">
                Home
              </NavLink>
            </li>
            <li>
              <a href="/about-us" className="an-14 regular-text">
                About Us
              </a>
            </li>
            <li>
              <a
                href="mailto:contact@expeditionsconnect.com"
                className="regular-text an-14"
              >
                Contact Us
              </a>
            </li>
          </ul>
        </div>
      </>
    ),
    []
  );

  const termsAndConditionsLinks = useMemo(
    () => (
      <>
        <Link className="link" to="/terms-and-conditions">
          Terms of Service{" "}
        </Link>
        <Link className="link" to="/privacy-policy">
          Privacy Policy{" "}
        </Link>
      </>
    ),
    []
  );

  return (
    <section className="footer_bg_sec">
      <div className="container">
        <div>
          <NavLink to="/">
            <img className="mb5" src={footerLogoWhite} alt="logo" />
          </NavLink>
          <div className="copyright">
            <div className="copyright__first">
              © {new Date().getFullYear()} Expeditions Connect.{" "}
            </div>
            <div>All rights reserved.</div>
          </div>
        </div>
        <div className="navigation">
          {isMobile && (
            <div className="navigationsAndCompanyContainer">{navigations}</div>
          )}
          {!isMobile && navigations}

          <div>
            {isMobile && (
              <div className="termsAndConditionsLinks">
                {termsAndConditionsLinks}
              </div>
            )}
            {!isMobile && termsAndConditionsLinks}
            <div className="social_btn pt10">
              <a
                rel="noopener noreferrer"
                target="_blank"
                href="https://www.facebook.com/expeditionsconnect"
              >
                <i
                  className="fab fa-facebook social_round"
                  aria-hidden="true"
                ></i>
              </a>
              <a
                rel="noopener noreferrer"
                target="_blank"
                href="https://twitter.com/ExpeditionsC"
              >
                <i
                  className="fab fa-twitter social_round"
                  aria-hidden="true"
                ></i>
              </a>
              <a
                rel="noopener noreferrer"
                target="_blank"
                href="https://www.instagram.com/expeditionsconnects"
              >
                <i
                  className="fab fa-instagram social_round"
                  aria-hidden="true"
                ></i>
              </a>
              <a
                rel="noopener noreferrer"
                target="_blank"
                href="https://www.linkedin.com/company/expeditionsconnect"
              >
                <i
                  className="fab fa-linkedin social_round"
                  aria-hidden="true"
                ></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default Footer;
