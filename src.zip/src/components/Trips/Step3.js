import React, { useState, Fragment, useCallback, useEffect } from 'react';
import {
  Form,
  Row,
  Col,
  Button,
  Breadcrumb,
  Input,
  Icon,
  message,
  Upload,
} from 'antd';
import { CloseCircleFilled } from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';

/**
 * App Imports
 */
import { TripsEvents } from '../../redux/trips/events';
import { getBase64, beforeUpload } from '../../helpers/methods';
import ReactQuill from 'react-quill';
import { quillFormats, quillModules } from '../../helpers/constants';
import { removeLinebreaks, removeLinebr } from '../../helpers/methods';


import 'react-quill/dist/quill.snow.css';

const { TextArea } = Input;

const Step3 = (props) => {
  const { step3, changeTab, update } = TripsEvents;

  const { getFieldDecorator, getFieldValue, setFieldsValue } = props.form;

  const [accommodation, setAccommodation] = useState('');
  const [inclusion, setInclusion] = useState('');
  const [exclusion, setExclusion] = useState('');
  const [cancellations, setCancellations] = useState('');
  const [extras, setExtras] = useState('');
  const [fileList, setFileList] = useState([]);
  const [imageUrl, setImageUrl] = useState('');
  const [isEdit, setIsEdit] = useState(false);

  const dispatch = useDispatch();
  const trips = useSelector((state) => state.trips);
  const loader = useSelector((state) => state.trips.loader);

  const { editMode } = trips;

  const addItinerary = () => {
    const keys = getFieldValue('itinerary');
    const nextKeys = keys.concat(new Date().getTime());
    setFieldsValue({ itinerary: nextKeys });
  };

  const removeItinerary = (k) => {
    const keys = getFieldValue('itinerary');
    setFieldsValue({ itinerary: keys.filter((key) => key !== k) });
  };

  const setEditors = useCallback((data) => {
    // setAccommodation(data.accommodation || "");
    setInclusion(data.inclusion || '');
    setExtras(data.extras || '');
    setExclusion(data.exclusion || '');
    setCancellations(data.cancellations || '');
  }, []);

  useEffect(() => {
    setEditors(trips);
    setFieldsValue({
      itinerary:
        trips.itinerary && trips.itinerary.length !== 0
          ? JSON.parse(trips.itinerary)
          : [{}],
    });
    setAccommodation(removeLinebr(trips.accommodation));
    let finalData = [];

    if (
      isEdit === false &&
      trips.accomodationPhotos &&
      trips.accomodationPhotos.length > 0
    ) {
      trips.accomodationPhotos.map((img, index) => {
        finalData.push({
          uid: index,
          name: img.split('photos/')[1],
          status: 'done',
          url: img,
        });
        if (trips.accomodationPhotos.length === index + 1) {
          setFileList(finalData);
          setIsEdit(true);
        }
      });
    }
  }, [trips, setEditors, setFieldsValue]);

  getFieldDecorator('itinerary', { initialValue: [{}] });
  const itineraryFields = getFieldValue('itinerary');
  const itenaryItems = itineraryFields.map((key, i) => (
    <Fragment key={i}>
      <div className='flex-x align-end'>
        <Form.Item className='mb0 flex-1'>
          {getFieldDecorator(`itinerary-${i}`, {
            initialValue: key.value,
            rules: [{ required: true, message: 'Please enter itinerary' }],
          })(<TextArea placeholder={`Day ${i + 1}`} />)}
        </Form.Item>
      </div>
      <Icon
        className='delete-icon work_delete'
        type='close'
        onClick={() => removeItinerary(key)}
      />

    </Fragment>
  ));

  const handleSubmit = (e) => {
    e.preventDefault();
    props.form.validateFields((err, values) => {
      if (!err) {

        if (!cancellations || cancellations.trim() === "<p><br></p>") {
          return message.error('Please fill out Terms & Conditions field');
        }
        const itinerary = [];
        values.itinerary.map((key, i) => {
          itinerary.push({ day: i, value: values[`itinerary-${i}`] });
          return null;
        });
        const Obj = {
          ...trips,
          coordinates: JSON.stringify(trips.coordinates),
          inclusion: inclusion,
          exclusion: exclusion,
          cancellations: cancellations,
          extras: extras,
          accomodation: removeLinebreaks(accommodation),
          itenary: JSON.stringify(itinerary),
          active: true,
        };
        let formData = new FormData();
        for (const property in Obj) {
          if (property === 'cover') {
            if (typeof Obj[property] !== 'string') {
              formData.append(
                property,
                Obj[property]
                // Obj[property].fileList[0].originFileObj,
              );
            }
            else{
              formData.append(property,'')
            }
            
          } 

          else if (property === 'originalCover') {
            if (typeof Obj[property] !== 'string') {
              formData.append(
                property,
                Obj[property]
                // Obj[property].fileList[0].originFileObj,
              );
            }
            else {
              formData.append(property, '');
            }
            
          } else {
            formData.append(property, Obj[property]);
          }
          
         
        }
        formData.append(
          'accomodationPhotoList',
          JSON.stringify(
            fileList.map((dd) => {
              return `photos/${dd.name}`;
            }),
          ),
        );
        if (fileList.length > 0) {
          fileList.map((pic, i) => {
            formData.append('accomodationPhotos', pic.originFileObj);
            if (fileList.length === i + 1) {
              setIsEdit(false);
              if (editMode) {
                dispatch(update(formData));
              } else {
                dispatch(step3(formData));
              }
            }
          });
        } else {
          setIsEdit(false);
          if (editMode) {
            dispatch(update(formData));
          } else {
            dispatch(step3(formData));
          }
        }
      }
    });
  };

  const onChangeImg = ({ fileList: newFileList }) => {
    if (newFileList[0].originFileObj) {
      getBase64(newFileList[0].originFileObj, (imageUrl) => {
        setImageUrl(imageUrl);
      });
    }
    setFileList(newFileList);
  };

  const onPreview = async (file) => {
    let src = file.url;
    if (!src) {
      src = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow.document.write(image.outerHTML);
  };

  const removeByAttr = function (arr, attr, value) {
    var i = arr.length;
    while (i--) {
      if (
        arr[i] &&
        arr[i].hasOwnProperty(attr) &&
        arguments.length > 2 &&
        arr[i][attr] === value
      ) {
        arr.splice(i, 1);
      }
    }
    setFileList([...arr]);
    if (arr.length > 0) {
      if (arr[0].originFileObj) {
        getBase64(arr[0].originFileObj, (imageUrl) => {
          setImageUrl(imageUrl);
        });
      } else {
        setImageUrl(arr[0].url);
      }
    } else {
      setImageUrl('');
    }
    return arr;
  };

  return (
    <div className='step-1-expert-form step-2'>
      <Breadcrumb separator='>'>
        <Breadcrumb.Item className='an-20 medium-text success--text step-title'>
          Create Trip
        </Breadcrumb.Item>
        <Breadcrumb.Item className='an-16 regular-text pt10'>
          Additional Details
        </Breadcrumb.Item>
      </Breadcrumb>
      <Form
        className='ant-advanced-search-form creacte_rip_section_step_3'
        onSubmit={handleSubmit}
      >
        <div className='form-profile-container pt20'>
          {/* <Row gutter={24}>
            <Col xs={24} sm={24} md={24} lg={24} xl={24}>
              <Form.Item label="Accommodation">
                <ReactQuill
                  theme="snow"
                  value={accommodation || ''}
                  modules={quillModules}
                  formats={quillFormats}
                  onChange={(data) => setAccommodation(data)}
                  placeholder="Write here..."
                />
              </Form.Item>
            </Col>
          </Row> */}
          <Row gutter={24}>
            <Col
              className='accommodation'
              xs={24}
              sm={24}
              md={24}
              lg={24}
              xl={24}
            >
              <div className='py15 medium-text flex-x space-between pt30'>
                <div>
                  {/* <div className='an-14 medium-text step-title ant-form-item-required '>
                    Accommodation
                  </div> */}

                  <Form.Item className='mb0 flex-1' label='Accommodation'>
                    {getFieldDecorator(`accommodation`, {
                      rules: [
                        {
                          required: false,
                          message: 'Please fill accommodation',
                        },
                      ],
                    })(
                      <>
                        <TextArea
                          placeholder={`Accommodation`}
                          value={accommodation}
                          onChange={(e) => [
                            setFieldsValue({ accommodation: e.target.value }),
                            setAccommodation(e.target.value),
                          ]}
                        />
                      </>,
                    )}
                  </Form.Item>

                  {/* <Upload
                    accept={'image/*'}
                    listType={'picture-card'}
                    multiple={true}
                    showUploadList={{
                      showPreviewIcon: false,
                      showDownloadIcon: false,
                    }}
                    fileList={fileList}
                    onChange={onChangeImg}
                    onPreview={onPreview}
                    beforeUpload={beforeUpload}
                    customRequest={({ file, onSuccess }) => {
                      setTimeout(() => onSuccess('ok'), 0);
                    }}
                    className='uplord_img'
                    onRemove={(d) => removeByAttr(fileList, 'uid', d.uid)}
                  >
                   {fileList.length <= 5 && <Button shape='round' className='award-add-btn mb-24'>
                      Upload Image
                  </Button> }
                  </Upload> */}
                </div>
              </div>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col
              className='trip_itinerary'
              xs={24}
              sm={24}
              md={24}
              lg={24}
              xl={24}
            >
              <div className="step3_itinerary">
                <div className='pt15 pb5 flex-x space-between pt24'>
                  <div className='medium-text step-title ant-form-item-required'>
                    <label className="itinerary_txt_trip">Itinerary</label>
                  </div>
                  <div>
                    <Button
                      shape='round'
                      icon='plus'
                      className='award-add-btn mb-24'
                      onClick={addItinerary}
                    >
                      Add
                  </Button>
                  </div>
                </div>
                {itenaryItems}
              </div>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col
              className=''
              xs={24}
              sm={24}
              md={24}
              lg={24}
              xl={24}
            >
              <Form.Item label='Inclusions'>
                <ReactQuill
                  theme='snow'
                  value={inclusion || ''}
                  modules={quillModules}
                  formats={quillFormats}
                  onChange={(data) => setInclusion(data)}
                  placeholder='Write here...'
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col
              className=''
              xs={24}
              sm={24}
              md={24}
              lg={24}
              xl={24}
            >
              <Form.Item label='Exclusions'>
                <ReactQuill
                  theme='snow'
                  value={exclusion || ''}
                  modules={quillModules}
                  formats={quillFormats}
                  onChange={(data) => setExclusion(data)}
                  placeholder='Write here...'
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col
              className=''
              xs={24}
              sm={24}
              md={24}
              lg={24}
              xl={24}
            >
              <Form.Item
                label='Terms & Conditions'
                className='ant-form-item-required'
              >
                <ReactQuill
                  theme='snow'
                  value={cancellations || ''}
                  modules={quillModules}
                  formats={quillFormats}
                  onChange={(data) => setCancellations(data)}
                  placeholder='Write here...'
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col
              className='set_textarea'
              xs={24}
              sm={24}
              md={24}
              lg={24}
              xl={24}
            >
              <Form.Item label='Additional Details'>
                <ReactQuill
                  theme='snow'
                  value={extras || ''}
                  modules={quillModules}
                  formats={quillFormats}
                  onChange={(data) => setExtras(data)}
                  placeholder='Write here...'
                />
              </Form.Item>
            </Col>
          </Row>
        </div>
        <Form.Item className='mb0 pt40'>
          <Button
            loading={loader}
            type='primary'
            htmlType='submit'
            className='ex__primary_btn'
          >
            Submit
          </Button>
          <Button
            type='primary'
            className='ex_grey_btn ml40'
            onClick={() => dispatch(changeTab(2))}
          >
            Back
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

const WrappedCreateStep3 = Form.create({ name: 'createTrips' })(Step3);

export default WrappedCreateStep3;
