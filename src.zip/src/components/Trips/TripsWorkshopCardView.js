import React, { Fragment, useEffect, useState } from 'react';
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import { Row, Col, Rate, Card, Popover, Dropdown } from 'antd';

/**
 * App Imports
 */
import { CaptalizeFirst, getColorLogoURL, DayorDaysNightOrNights, displayDifficultyText, skillLevelText, getCurrencySymbol } from "../../helpers/methods";
import Share from "../../assets/images/share_ic.png";
import MoreTripOption from "../../assets/images/more_vert-24px.svg";
import SkillRed from "../../assets/images/skill_red.svg";
import SkillGreen from "../../assets/images/skill_green.svg";
import SkillOrange from "../../assets/images/skill_orange.svg";
import shareOption from "../../containers/commonContainer/shareOption";
import Map from "../../components/Trips/Map";
import LikeAndShare from "../../components/common/Likeandshare";

const ApiKey = process.env.REACT_APP_GOOGLE_MAP_API_KEY;


const TripsWorkshopCardView = (props) => {
  const { role, view, upcomingTrip, pageMinValue, pageMaxValue, isLogin, activeTrip, inActiveTrip, copyTrip, isPublicView, activeWorkshop, inActiveWorkshop, travelMap } = props;
  
  const [load, setLoad] = useState(false);

  const onTripClick = (id) => {
    if (isPublicView) {
      props.history.push(`/trips-details/${id}`);
      return;
    }
    props.history.push(`/trip-edit/${id}`)
  };

  const onWorkshopClick = (id) => {
    if (isPublicView) {
      props.history.push(`/learning-details/${id}`);
      return;
    }
    props.history.push(`/learning-edit/${id}`)
  };

  useEffect(() => {
    setLoad(true);
    setTimeout(() => {
      setLoad(false);
    }, 100);
  }, [pageMinValue, pageMaxValue])

  const tripsOption = (t) => {
    var id = t._doc ? t._doc._id : t.id
    var detail = t._doc ? t._doc : t;
    return (
      <div className="profile_bg trip_poppop">
        {/* <div className="primary--text py5 cursor-pointer">
          Trip Fully Booked
      </div>
        <div className="border_bottom"></div> */}
        <div className="primary--text py5 cursor-pointer" onClick={() => props.history.push(`/update-trip/${id}`)}>
          Edit Trip
      </div>
        <div className="primary--text py5 cursor-pointer" onClick={() => copyTrip(detail)}>
          Copy Trip
      </div>
        <div className="primary--text py5 cursor-pointer" onClick={() => t.active ? inActiveTrip(id) : activeTrip(id)}>
          {detail.active ? "Deactivate Trip" : "Activate Trip"}
        </div>
        {/* <div className="border_bottom"></div>
        <div className="primary--text py5 cursor-pointer">
          Delete Trip
      </div> */}
      </div>
    )
  }

  const workshopsOption = (t) => {
    return (
      <div className="profile_bg trip_poppop">
        {/* <div className="primary--text py5 cursor-pointer">
          Workshop Fully Booked
      </div>
        <div className="border_bottom"></div> */}
        <div className="primary--text py5 cursor-pointer" onClick={() => props.history.push(`/update-learning/${t.id}`)}>
          Edit Workshop
      </div>
        <div className="primary--text py5 cursor-pointer" onClick={() => props.copyWorkShop(t)}>
          Copy Workshop
      </div>
        <div className="primary--text py5 cursor-pointer" onClick={() => t.active ? inActiveWorkshop(t.id) : activeWorkshop(t.id)}>
          {t.active ? "Deactivate Workshop" : "Activate Workshop"}
        </div>
        {/* <div className="border_bottom"></div>
        <div className="primary--text py5 cursor-pointer">
          Delete Workshop
      </div> */}
      </div>
    )
  }

  const displayLang = (lang) => {
    let resLang = ""
    if (lang.length > 0) {
      lang.map((a, index) => {
        let addCooma = "";
        if (lang.length !== index + 1) {
          addCooma = ", "
        }
        resLang += CaptalizeFirst(a) + addCooma;
      });

    }

    return resLang;
  }

  if (upcomingTrip) {
    return (
      <Fragment>
        <Row>
          <Col xs={24} sm={24} md={24} lg={24} xl={24}>
            <div className="expidition_bg expendition">
              <Row gutter={[15, 25]}>
                {upcomingTrip.slice(pageMinValue, pageMaxValue).map((t, index) => (
                  <Col xs={24} sm={24} md={12} lg={8} xl={8} key={index} className="gutter-row trips_blog">
                    <Card
                      key={index}
                      hoverable
                      cover={<img alt="example" data={t.suitable} src={t.cover} />}
                      cover={<img onClick={() => view === "trips" ? onTripClick(t._doc ? t._doc._id : t.id) : onWorkshopClick(t.id)} alt="example" src={t.cover} />}
                      extra={isLogin && isPublicView === false &&
                        <div>
                          <Popover
                            placement="bottom"
                            content={view === "trips" ? tripsOption(t._doc ? t._doc : t) : workshopsOption(t)}
                            trigger="hover">
                            <div className="more_icon_upcoming_tips">
                              <img src={MoreTripOption} alt="MoreTrip_Option" />
                            </div>
                          </Popover>
                          <div className="onilne_trip_inactive_fix">
                            {t.active === false &&
                              <div className="inactive_online_button">
                                <span href="#!" className="inactive edit_btn medium-text an-14 pull-right mt30">
                                  Deactive
                                    </span>
                              </div>
                            }
                            {view === "trips" ? <></> :
                              t.medium === "online" &&
                              <div className="inactive_online_button">
                                <span className="inactive edit_btn medium-text an-14 pull-right mt30">  {CaptalizeFirst(typeof t.medium !== "undefined" ? t.medium : t.medium)}{" "} </span>
                              </div>
                            }
                          </div>
                        </div>
                      }>
                      {isPublicView === true && typeof t.medium !== undefined && t.medium === "online" && (
                        <span className="online_tag an-10 medium-text">
                          {CaptalizeFirst(typeof t.medium !== "undefined" ? t.medium : t.medium)}{" "}
                        </span>
                      )}
                      <div className="price_sec card_details" onClick={() => view === "trips" ? onTripClick(t._doc ? t._doc._id : t.id) : onWorkshopClick(t.id)}>
                        <div className="mt5 mb10 an-13 card-main-des">

                          <span>{t.duration ? t.duration : ""} {DayorDaysNightOrNights('w', t.duration ? t.duration : "", t.durationType)}&nbsp;&nbsp;</span>
                          <span className="secondLine">&nbsp;{((typeof t.country !== "undefined" && t.country !== "undefined") && t.country !== "") ? CaptalizeFirst(t.country) : CaptalizeFirst(t.medium)} &nbsp;<span className="secondLine"></span>{" "}</span>
                          <span> &nbsp;{typeof t.activity !== "undefined" && t.activity.length > 0 ? displayLang(t.activity) : ""}</span>

                        </div>
                        <p className="mb10 an-15 medium-text card-main-title">
                          {CaptalizeFirst(t._doc ? t._doc.title : t.title)}
                        </p>
                        <Row className="price_line">
                          <Col xs={18} sm={18} md={18} lg={18} xl={18}>
                            <h3 className="medium-text an-16 price-tag">
                              <span className="spance_between_dollar">{getCurrencySymbol(t._doc ? t._doc.priceCurrency : t.priceCurrency)}</span>
                              <span className="spance_between_txt">{t._doc ? t._doc.price : t.price}</span>

                            </h3>
                          </Col>
                          <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                            <div className="text-right">
                              <Popover placement="bottom" content={`${t.pageType == "trip" ? displayDifficultyText(t._doc ? t._doc.difficulty : t.difficulty) : skillLevelText(t._doc ? t._doc.skill : t.skill)}`} trigger="hover">
                                <img
                                  src={t.pageType == "trip" ? getColorLogoURL("trip", t._doc ? t._doc.difficulty : t.difficulty) : getColorLogoURL("workshop", t._doc ? t._doc.skill : t.skill)}
                                  alt="Skil level"
                                />
                              </Popover>
                            </div>
                          </Col>
                        </Row>
                      </div>
                      {!load && <LikeAndShare allLikes={t.likes} id={t.id} pageType={t.pageType} designType="multiple" />}
                      {load && <LikeAndShare allLikes={t.likes} id={t.id} pageType={t.pageType} designType="multiple"/>}
                      
                      {/* <LikeAndShare allLikes={t.likes} id={t.id} pageType={t.pageType} /> */}
                      {/* <Row>
                          <Col xs={16} sm={16} md={16} lg={16} xl={16}>
                            <Rate
                              allowHalf
                              defaultValue={0}
                              className="an-14"
                            />
                          </Col>
                          <Col xs={8} sm={8} md={8} lg={8} xl={8}>
                            <div className="heart_fill trip_set_icon">
                              <input type="checkbox" id="like1" />
                              <div className="text-right">
                                <Dropdown overlay={shareOption} placement="bottomCenter">
                                  <img
                                    src={Share}
                                    alt="Social Share"
                                    className="share_icn"
                                  />
                                </Dropdown>
                                <label htmlFor="like1"><svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32c-5.15-4.67-8.55-7.75-8.55-11.53 0-3.08 2.42-5.5 5.5-5.5 1.74 0 3.41.81 4.5 2.09 1.09-1.28 2.76-2.09 4.5-2.09 3.08 0 5.5 2.42 5.5 5.5 0 3.78-3.4 6.86-8.55 11.54l-1.45 1.31z"></path></svg></label>
                              </div>

                            </div>
                          </Col>
                        </Row> */}
                    </Card>
                  </Col>
                ))}
              </Row>
            </div>
          </Col>
        </Row>
      </Fragment>
    )
  } else {
    return null;
  }
}

export default compose(withRouter)(TripsWorkshopCardView)
