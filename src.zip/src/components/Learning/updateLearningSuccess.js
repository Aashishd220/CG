import React from "react";
import { Modal, Button } from "antd";
import { NavLink, withRouter } from "react-router-dom";
import {useDispatch, useSelector} from 'react-redux';
import { compose } from "redux";

/**
 * Image Import
 */
import Success from "../../assets/images/success_ic.png";

/**
 * App Imports
 */
import { ModalActions } from '../../redux/models/events';

const CreateLearningSuccess = (props) => {
  const dispatch = useDispatch();
  const learning=useSelector(state => state.learning);
  const { closeUpdateModal } = ModalActions;

  const handleClick = () => {
    dispatch(closeUpdateModal());
    props.history.push('/learning-edit/' + learning.id);
  }

  return (
    <Modal
      centered
      className="auth-modal success-modal"
      width={380}
      closable={false}
      maskClosable={false}
      visible={props.visible}
    >
      <div className="text-center">
        <img src={Success} alt="" />
        <h1 className="text-upper medium-text an-26 text-success mb15 mt15">
          Successfully Updated
        </h1>
        <p className="an-18 mb20 regular-text">
          Your workshop is updated
        </p>
        <Button type="primary" className="done_btn medium-text an-16 ex__primary_btn" onClick={handleClick}>
          View
        </Button>
        {/* <NavLink to="" className="done_btn medium-text an-16">
        </NavLink> */}
      </div>
    </Modal>
  );
};

export default compose(withRouter)(CreateLearningSuccess);
