import React, { useState, useEffect, useCallback } from 'react';
import { Form, Input, Row, Col, Select, Button, Upload, DatePicker } from "antd";
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { withRouter } from 'react-router-dom';
import { compose } from "redux";
import uploadIcon from '../../assets/images/upload-icon.png';

import { getBase64, beforeUpload } from '../../helpers/methods';
import { PhoneValidator, PhoneValidatorEnthu } from '../../helpers/validations';
import langauges from '../../helpers/langauges';
import countries from '../../helpers/countries';
import { EnthuEvents } from '../../redux/enthu/events';
import { FILE_SIZE } from '../../helpers/constants';
import ImageUpload from 'shared/image-upload/image-upload';


const { Option } = Select;

const Step1 = (props) => {
  const { getFieldDecorator, setFieldsValue } = props.form;
  const { picture,originalPicture, name, country, address, phone, dob, isEditMode, firstName, lastName, city, speaks } = useSelector(state => state.enthu);
  const allData = useSelector(state => state.enthu);
  const [imageUrl, setImageUrl] = useState();
  const [imageUrlObject, setImageUrlObject] = useState();
  const [reposition, setReposition] = useState(false)
  const [imageCover, setImageCover] = useState(originalPicture);
  const [imageCoverObject, setImageCoverObject] = useState();
  const [deleteCheck,setDeleteCheck]=useState(false)

  const dispatch = useDispatch();

  const { step1 } = EnthuEvents;

  useEffect(() => {
    if (originalPicture !== null) {
      setImageCover(originalPicture)
    }
  }, [originalPicture])

  const setPicture = useCallback(
    (picture) => {
      if (picture !== null && picture !== undefined) {
        if (typeof picture === "string") {
          setImageUrl(picture);
        } else {
          getBase64(picture, (imageUrl) => {
            setImageUrl(imageUrl);
          });
        }
      }
    }, [isEditMode])

  useEffect(() => {
    setPicture(picture);
    setFieldsValue({
      picture: picture,
      originalPicture: originalPicture,
      name,
      address,
      country,
      phone,
      dob: dob ? moment(dob) : null,
      firstName,
      lastName,
      city,
      speaks
    });
  }, [address, country, dob, name, phone, picture,originalPicture, setFieldsValue, setPicture, firstName, lastName, city, speaks])
  

  const toDataURL = url => fetch(url)
  .then(response => response.blob())
  .then(blob => new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onloadend = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(blob)
  }))

  function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  const handleFormSubmit = e => {
    e.preventDefault();
    props.form.validateFields(async(err, values) => {

      if(!imageUrlObject){
        alert('Please add image')
        return;
      }

      if (imageCoverObject && imageUrlObject) {
        values = { ...values, originalPicture: imageCoverObject, picture: imageUrlObject }

      }
      else if (imageUrlObject) {
        await toDataURL(originalPicture)
          .then(dataUrl => {
            var fileData = dataURLtoFile(dataUrl, "imageName.jpg");
            values = { ...values, picture: imageUrlObject, originalPicture: fileData }

          })
      }
      else{
        if(deleteCheck===true){
        values = { ...values, originalPicture:'', picture:'' }
        }
        else{
          values = { ...values, originalPicture, picture }
        }
      }
      if (!err) {
        window.scrollTo({ top: document.getElementById('scroll-to-here'), behavior: 'smooth' });
        dispatch(step1(values))
      }
    });
  };

  const handleChangePicture = info => {
    if (info.file.status === "uploading") {
      return;
    }
    if (info.file.status === "done") {
      getBase64(info.file.originFileObj, imageUrl => {
        setImageUrl(imageUrl);
      });
    }
  };


  const setCoverImage = (file, check) => {
    if(check!=='delete'){
    getBase64(file, (imageUrl) => {
      if (check === 'upload') {
        setImageCover(imageUrl)
        setImageCoverObject(file)
        setReposition(true)
      }
      else {
        setImageUrl(imageUrl);
        setImageUrlObject(file)
        setReposition(false)
      }
    })}
    else{
      setImageCover('')
    setImageCoverObject('')
    setImageUrl('');
    setImageUrlObject('')
    setReposition(false)
    setDeleteCheck(true)
    }
  }
  return (
    <div className="step-1-expert-form height_sec_enthu">
      <div className="an-20 medium-text success--text step-title">
        PERSONAL INFO
      </div>
      <div className="an-16 regular-text pt10">
        Please fill in the details below to create your enthusiast profile
      </div>
      <div className="profile-picture-style">
        {
          (reposition === false && <img
            className={imageUrl ? `profile-img` : `profile-img-default`}
            src={imageUrl || uploadIcon}
            alt="avatar"
            style={{
              width: imageUrl ? "100%" : "",
              height: imageUrl ? "100%" : "",
              objectFit: "fill",
            }}
          />)
        }
      </div>
      <Form className="ant-advanced-search-form" onSubmit={handleFormSubmit}>
        <div className="form-profile-container pt20">
          <div className="pr20">
            <Form.Item label="" className="mb0">
              <div className="profile-image-reposition">

                {
                  // getFieldDecorator("picture", { rules: [{ required: true, message: "Please Upload Your Profile!" }] })

                  (
                    <ImageUpload
                      originalCover={imageCover}
                      setCoverImage={(file, editOrUpload) =>
                        setCoverImage(file, editOrUpload)
                      }
                      page="Trips"
                      reposition={reposition}
                      setReposition={(evt) => setReposition(evt)}
                      setZoom="true"
                    />)
                }
              </div>
            </Form.Item>
          </div>
          <div>
            <div className="pt60">
              <Row gutter={24}>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="First Name">
                    {getFieldDecorator("firstName", { rules: [{ required: true, message: 'First Name is required' }] })
                      (<Input placeholder="Enter First Name" />)}
                  </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Last Name">
                    {getFieldDecorator("lastName", { rules: [{ required: true, message: 'Last Name is required' }] })
                      (<Input placeholder="Enter Last Name" />)}
                  </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Country">
                    {getFieldDecorator("country", { rules: [{ required: true, message: "Please select your country!" }] })
                      (<Select showSearch placeholder="Select Your Country">
                        {countries.map((con, i) => <Option key={i} value={con.name}>{con.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col>

                {/* <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="City">
                    {getFieldDecorator("city", { rules: [{ required: true, message: "Please select your city!" }] })
                      (<Select showSearch placeholder="Select Your City">
                        {countries.map((con, i) => <Option key={i} value={con.name}>{con.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col> */}

                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="City">
                    {getFieldDecorator("city", { rules: [{ required: true, message: 'City is required' }] })
                      (<Input placeholder="Enter City" />)}
                  </Form.Item>
                </Col>


                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Address">
                    {getFieldDecorator("address", { rules: [{ required: false, message: 'Address is required' }] })
                      (<Input placeholder="Enter Address" />)}
                  </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Phone Number">
                    {getFieldDecorator("phone", PhoneValidatorEnthu)
                      (<Input placeholder="Enter Phone Number" />)}
                  </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Languages">
                    {getFieldDecorator("speaks", { rules: [{ required: false }] })
                      (<Select mode="multiple" showSearch placeholder="Select Your Languages">
                        {langauges.map((lang, i) => <Option key={i} value={lang.name}>{lang.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col>


                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Date of Birth">
                    {getFieldDecorator("dob", { rules: [{ required: true, message: 'Please Enter Date of Birth' }] })
                      (<DatePicker format="YYYY-MM-DD" className="fill-width" placeholder="DD/MM/YYYY" />)
                    }
                  </Form.Item>
                </Col>


              </Row>
            </div>
          </div>
        </div>
        <Form.Item className="mb0 pt25">
          <Button type="primary" htmlType="submit" className="ex__primary_btn">
            Next
          </Button>
        </Form.Item>
      </Form>
    </div>
  )
}

const WrappedCreateEnthStep1 = Form.create({ name: "createProfile" })(Step1);

export default compose(withRouter)(WrappedCreateEnthStep1);