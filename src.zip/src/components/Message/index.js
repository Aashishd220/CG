export {default as Sidebar} from './Sidebar.js';
export {default as Mainarea} from './Main';