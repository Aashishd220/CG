import React, { useState, useEffect, useCallback } from 'react';
import { Form, Input, Row, Col, Select, Button } from "antd";
import { useSelector, useDispatch } from 'react-redux';
import uploadIcon from '../../assets/images/upload-icon.png';

import { getBase64, beforeUpload } from '../../helpers/methods';
import countries from '../../helpers/countries';
import langauges from '../../helpers/langauges';
import { expertiseList, FILE_SIZE } from '../../helpers/constants';
import { ActivityList } from '../../helpers/constants';
import { ExpertEvents } from '../../redux/expert/events';
import { FirstNameValidator, LastNameValidator } from '../../helpers/validations';
import PlacesAutocomplete from 'react-places-autocomplete';
import ImageUpload from 'shared/image-upload/image-upload';

const { Option } = Select;

const CreateExpertStepPersonalInfo = (props) => {
  const { getFieldDecorator, setFieldsValue } = props.form;
  const [imageUrl, setImageUrl] = useState();
  const [imageUrlObject, setImageUrlObject] = useState();
  const [reposition, setReposition] = useState(false)

  // const [city, setCity] = useState('');

  const { picture, originalPicture, firstName, lastName, country, city, experties, speaks, skills, isEditMode } = useSelector(state => state.expert);
  const [imageCover, setImageCover] = useState(originalPicture);
  const [imageCoverObject, setImageCoverObject] = useState();
  const [deleteCheck,setDeleteCheck]=useState(false)

  const { stepPersonalInfo } = ExpertEvents;
  const dispatch = useDispatch();

  useEffect(() => {
    if (originalPicture !== null) {
      setImageCover(originalPicture)
    }
  }, [originalPicture])


  const setPicture = useCallback(
    (picture) => {
      if (picture !== null && picture !== undefined) {
        if (typeof picture === "string") {
          setImageUrl(picture);
        } else {
          getBase64(picture, (imageUrl) => {
            setImageUrl(imageUrl);
          });
        }
      }
    }, [isEditMode])

  useEffect(() => {
    setPicture(picture);
    setFieldsValue({
      picture: picture,
      originalPicture: originalPicture,
      firstName: firstName,
      lastName: lastName,
      experties: experties,
      speaks: speaks,
      country: country,
      city: city,
      skills: skills
    });
  }, [country, city, experties, firstName, lastName, picture, originalPicture, setFieldsValue, setPicture, speaks, skills])

  const onCityChange = city => setFieldsValue({ city });

  const onSelectCity = city => setFieldsValue({ city });


  const toDataURL = url => fetch(url)
    .then(response => response.blob())
    .then(blob => new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onloadend = () => resolve(reader.result)
      reader.onerror = reject
      reader.readAsDataURL(blob)
    }))

  function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  const handleFormSubmit = e => {
    e.preventDefault();
    props.form.validateFields(async (err, values) => {

      if (imageCoverObject && imageUrlObject) {
        values = { ...values, originalPicture: imageCoverObject, picture: imageUrlObject }

      }
      else if (imageUrlObject) {
        await toDataURL(originalPicture)
          .then(dataUrl => {
            var fileData = dataURLtoFile(dataUrl, "imageName.jpg");
            values = { ...values, picture: imageUrlObject, originalPicture: fileData }

          })
      }
      else{
        if(deleteCheck===true){
        values = { ...values, originalPicture:'', picture:'' }
        }
        else{
          values = { ...values, originalPicture, picture }
        }
      }
      if (!err) {
        window.scrollTo({ top: document.getElementById('scroll-to-here'), behavior: 'smooth' });
        dispatch(stepPersonalInfo({ ...values }));
      }
    });
  };

 
  const setCoverImage = (file, check) => {
    if(check!=='delete'){
    getBase64(file, (imageUrl) => {
      if (check === 'upload') {
        setImageCover(imageUrl)
        setImageCoverObject(file)
        setReposition(true)
      }
      else {
        setImageUrl(imageUrl);
        setImageUrlObject(file)
        setReposition(false)
      }
    })}
    else{
      setImageCover('')
    setImageCoverObject('')
    setImageUrl('');
    setImageUrlObject('')
    setReposition(false)
    setDeleteCheck(true)
    }
  }
  
 

  return (
    <div className="step-1-expert-form height_sec profile-crop">
      <div className="an-20 medium-text success--text step-title">
        Create Expert Profile <span className="an-16">  Personal Info</span>
      </div>
      <div className="an-16 regular-text pt10">
        Please fill in the details below to create your expert profile
      </div>
      <div className="profile-picture-style">
        {
          (reposition === false && <img
            className={imageUrl?`profile-img`:`profile-img-default`}
            src={imageUrl || uploadIcon}
            alt="cover"
            style={{
              width: imageUrl ? "100%" : "",
              height: imageUrl ? "100%" : "",
              objectFit: "fill",
            }}
          />)
        }
      </div>
      <Form className="ant-advanced-search-form" onSubmit={handleFormSubmit}>
        <div className="form-profile-container ">
          <div className="pr20">
            <Form.Item label="" className="mt20 mb20">
            <div className="profile-image-reposition">

              {
                // getFieldDecorator("picture", { rules: [{ required: true, message: "Please Upload Your Profile!" }] })
               
                (
                  <ImageUpload
                    originalCover={imageCover}
                    setCoverImage={(file, editOrUpload) =>
                      setCoverImage(file, editOrUpload)
                    }
                    page="Trips"
                    reposition={reposition}
                    setReposition={(evt) => setReposition(evt)}
                    setZoom="true"
                  />)
              }
                  </div>

            </Form.Item>
          </div>
          <div>
            <div className="pt20">
              <Row gutter={24}>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="First Name">
                    {getFieldDecorator("firstName", FirstNameValidator)
                      (<Input placeholder="Enter First Name" />)}
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Last Name">
                    {getFieldDecorator("lastName", LastNameValidator)
                      (<Input placeholder="Enter Last Name" />)}
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Country">
                    {getFieldDecorator("country", { rules: [{ required: true, message: "Please select your country!" }] })
                      (<Select showSearch showArrow placeholder="Select Your Country">
                        {countries.map((con, i) => <Option key={i} value={con.name}>{con.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item
                    label='City, Location'
                  >
                    {getFieldDecorator("city", { initialValue: city, rules: [{ required: true, message: "Please enter your city!" }] })
                      (<PlacesAutocomplete
                        onChange={onCityChange}
                        onSelect={onSelectCity}
                      >
                        {({
                          getInputProps,
                          suggestions,
                          getSuggestionItemProps,
                          loading,
                        }) => (
                            <div>
                              <Input
                                {...getInputProps({
                                  placeholder: 'Search Places ...',
                                  className: 'location-search-input',
                                })}
                              />
                              <div className='autocomplete-dropdown-container'>
                                {loading && (
                                  <div style={{ marginTop: 20 }}>Loading...</div>
                                )}
                                {suggestions.map((suggestion) => {
                                  const className = suggestion.active
                                    ? 'suggestion-item--active'
                                    : 'suggestion-item';
                                  return (
                                    <div
                                      {...getSuggestionItemProps(suggestion, {
                                        className,
                                      })}
                                    >
                                      <span>{suggestion.description}</span>
                                      <br />
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                      </PlacesAutocomplete>)}
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Languages">
                    {getFieldDecorator("speaks", { rules: [{ required: true, message: "Please select your Languages!" }] })
                      (<Select mode="multiple" showArrow placeholder="Select Your Languages">
                        {langauges.map((lang, i) => <Option key={i} value={lang.name}>{lang.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                  <Form.Item label="Expertise">
                    {getFieldDecorator("experties", { rules: [{ required: true, message: "Please select your expertise!" }] })
                      (<Select mode="multiple" showSearch showArrow placeholder="Select Your Expertise">
                        {expertiseList.map((exp, i) => <Option key={i} value={exp.name}>{exp.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                  <Form.Item label="Skills">
                    {getFieldDecorator("skills", { rules: [{ required: true, message: "Please enter your skills!" }] })
                      (<Select mode="tags" showSearch placeholder="Enter Your Skills">
                        {ActivityList.map((exp, i) => <Option key={i} value={exp.name}>{exp.name}</Option>)}
                      </Select>)}
                  </Form.Item>
                </Col>
              </Row>
            </div>
          </div>
        </div>
        <Form.Item className="mb0 pt25 mt30">
          <Button type="primary" htmlType="submit" className="ex__primary_btn">
            Next
          </Button>
        </Form.Item>
      </Form>
    </div>
  )
}

const WrappedCreateExpertStepPersonalInfo = Form.create({ name: "createProfile" })(CreateExpertStepPersonalInfo);

export default WrappedCreateExpertStepPersonalInfo;
