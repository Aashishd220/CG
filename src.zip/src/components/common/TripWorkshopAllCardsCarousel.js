import React, { Fragment, useState } from 'react';
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import { useSelector } from "react-redux";
import { Row, Col, Rate, Card, Popover, Dropdown, Button } from 'antd';
import { addorRemoveLikeForTrip } from "../../services/expert";

/**
 * App Imports
 */
import { CaptalizeFirst, getColorLogoURL, DayorDaysNightOrNights, displayDifficultyText, skillLevelText, getCurrencySymbol, commaSepratorStringCaps } from "../../helpers/methods";
import OwlCarousel from "react-owl-carousel";
import { DISPLAY_RESULT } from "helpers/constants";

import Share from "../../assets/images/share_ic.png";
import shareOption from "../../containers/commonContainer/shareOption";
import LikeAndShare from "./Likeandshare";

const sliderOptions = {
  margin: 10,
  nav: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
      dotsEach: 3,
    },
    768: {
      items: 2,
      nav: true,
    },
    991: {
      items: 3,
      nav: true,
    },
  },
};


const getLikeStatus = (id, likes) => {
  let likeStatus = false;

  if (typeof likes !== "undefined" && likes.length > 0) {
    likes.forEach((like) => {
      if (like.userId === id || likeStatus) {
        likeStatus = true;
      }
    });
  }
  return likeStatus;
};


const TripWorkshopAllCards = (props) => {
  let { items, view } = props;

  const displayCommaSeprate = (lang) => {
    let resLang = ""
    if (lang.length > 0) {
      lang.map((a, index) => {
        let addCooma = "";
        if (lang.length !== index + 1) {
          addCooma = ", "
        }
        resLang += CaptalizeFirst(a) + addCooma;
      });

    }

    return resLang;
  }

  const onTripClick = (type, id) => {

    if (type == "trip") {
      props.history.push(`/trips-details/${id}`);
      return;
    } else {
      props.history.push(`/learning-details/${id}`);
    }

  };
  return (
    <Fragment>
      <OwlCarousel
        className="owl-theme modular-card"
        {...sliderOptions}
        dots={true}
      >
        {items.slice(0, DISPLAY_RESULT).map((l, index) => {

          return (
            <Col xs={24} sm={24} md={24} lg={24} xl={24} key={l.id} className="gutter-row pb25 similar_card_main">
              <Card
                className="price_sec"
                hoverable
                cover={<img alt="example" className="card_cover" src={l.cover} onClick={() => l.pageType === "trip" ? onTripClick("trip", l.id) : onTripClick("workshop", l.id)} />}
              >
                {typeof l.medium !== undefined && l.medium === "online" && (
                  <span className="online_tag an-10 medium-text">
                    {CaptalizeFirst(typeof l.medium !== "undefined" ? l.medium : l.medium)}{" "}
                  </span>
                )}
                <div className="price_sec card_details" onClick={() => l.pageType === "trip" ? onTripClick("trip", l.id) : onTripClick("workshop", l.id)}>
                  <div className="mt5 mb10 an-13 card-main-des">
                    <Popover placement="bottom" content={typeof l.activity !== "undefined" && l.activity.length > 0 ? displayCommaSeprate(l.activity) : ""} trigger="hover">
                      <span>{l.duration ? l.duration : ""} {DayorDaysNightOrNights('t', l.duration ? l.duration : "", l.durationType)}&nbsp;&nbsp;</span>
                      <span className="secondLine">&nbsp;{((typeof l.country !== "undefined" && l.country !== "undefined") && l.country !== "") ? CaptalizeFirst(l.country) : CaptalizeFirst(l.medium)} &nbsp;<span className="secondLine"></span>{" "}</span>
                      <span> &nbsp;{typeof l.activity !== "undefined" && l.activity.length > 0 ? displayCommaSeprate(l.activity) : ""}</span>
                    </Popover>
                  </div>

                  <p className="mb10 an-15 medium-text card-main-title">
                    {CaptalizeFirst(l.title ? l.title : "")}
                  </p>
                  <Row className="price_line">
                    <Col xs={18} sm={18} md={18} lg={18} xl={18}>
                      <h3 className="medium-text an-16 price-tag">
                        <span className="spance_between_dollar">{getCurrencySymbol(l.priceCurrency)}</span>
                        <span className="spance_between_txt">{l.price ? l.price : ""}</span>
                      </h3>
                    </Col>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                      <div className="text-right">
                        <Popover placement="bottom" content={`${l.pageType == "trip" ? displayDifficultyText(l._doc ? l._doc.difficulty : l.difficulty) : skillLevelText(l._doc ? l._doc.skill : l.skill)}`} trigger="hover">
                          <img
                            src={l.pageType == "trip" ? getColorLogoURL("trip", l._doc ? l._doc.difficulty : l.difficulty) : getColorLogoURL("workshop", l._doc ? l._doc.skill : l.skill)}
                            alt="Skil level"
                          />
                        </Popover>
                      </div>
                    </Col>
                  </Row>
                </div>
                <LikeAndShare allLikes={l.likes} id={l.id} pageType={l.pageType} designType="multiple" />
              </Card>
            </Col>
          )
        })}
      </OwlCarousel>

    </Fragment>
  )

}

export default compose(withRouter)(TripWorkshopAllCards)
