import React, { Fragment } from 'react';
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import { Row, Col, Rate, Card, Popover, Dropdown, Button, Icon } from 'antd';

/**
 * App Imports
 */
import { CaptalizeFirst, getColorLogoURL, DayorDaysNightOrNights, displayDifficultyText, skillLevelText, getCurrencySymbol, commaSepratorString } from "../../helpers/methods";
import Share from "../../assets/images/share_ic.png";
import MoreTripOption from "../../assets/images/more_vert-24px.svg";
import SkillRed from "../../assets/images/skill_red.svg";
import SkillGreen from "../../assets/images/skill_green.svg";
import SkillOrange from "../../assets/images/skill_orange.svg";
import shareOption from "../../containers/commonContainer/shareOption";
import Map from "../../components/Trips/Map";
import LikeAndShare from "./LikeandshareSingle";
import ReactHtmlParser from "react-html-parser";


const ApiKey = process.env.REACT_APP_GOOGLE_MAP_API_KEY;


const SingleCard = (props) => {
    const { t, view, index, type, onMouseEnter, onMouseLeave, closeCard } = props;

    const onTripClick = (type, id) => {
        if (type == "trip") {
            props.history.push(`/trips-details/${id}`);
            return;
        } else {
            props.history.push(`/learning-details/${id}`);
        }

    };

    return (
        <Fragment>
            <Card
                key={"card_" + index}
                hoverable
                onMouseEnter={() => type == 'mapCard' ? onMouseEnter(t.id) : ''}
                onMouseLeave={() => type == 'mapCard' ? onMouseLeave(t.id) : ''}
                cover={<>
                    <img onClick={() => t.pageType === "trip" ? onTripClick("trip", t.id) : onTripClick("workshop", t.id)} alt="example" src={t.cover} />
                    <div className="image_text_set_on_card">
                        <div className="an-13 card-1st-line">
                            <span className="duration-lowercase">{t.duration ? t.duration : ""} {DayorDaysNightOrNights('t', t.duration ? t.duration : "", t.durationType)}</span>
                            <span className="secondLine">{((typeof t.country !== "undefined" && t.country !== "undefined") && t.country !== "") ? CaptalizeFirst(t.country) : CaptalizeFirst(t.medium)}<span className="secondLine"></span></span>
                            <span>{typeof t.activity !== "undefined" && t.activity.length > 0 ? commaSepratorString(t.activity) : ""}</span>
                        </div>
                    </div>
                </>}
            >
                {typeof t.medium !== "undefined" && t.medium !== "classroom" && (
                    <span className="card_tag an-10 medium-text">
                        {CaptalizeFirst(typeof t.medium !== "undefined" ? t.medium : t.medium)}{" "}
                    </span>
                )}
                {type === "googleMapCard" &&
                    <span className="card_close_tag an-10 medium-text">
                        <Icon type="close-circle" onClick={() => closeCard()} />
                    </span>
                }
                <div className="" onClick={() => t.pageType === "trip" ? onTripClick("trip", t.id) : onTripClick("workshop", t.id)}>

                    {/* On Card Like, Share and Save section */}
                    {type !== "googleMapCard" &&
                        <div className="like-and-share-card">
                            <LikeAndShare allLikes={t.likes} id={t.id} pageType={t.pageType} designType="directoryPage" />
                        </div>
                    }

                    {/* title of trip or workshop */}
                    <p className="mb10 an-15 medium-text card-main-title">
                        {CaptalizeFirst(t._doc ? t._doc.title : t.title)}
                    </p>

                    {type !== "googleMapCard" &&
                        <p className="mb15 an-15 medium-text card-main-description">
                            {ReactHtmlParser(typeof t.description !== "undefined" && t.description !== "" ? t.description.replace(/<[^>]+>/g, '') : "")}
                        </p>
                    }
                    <Row className="price_line">
                        <Col xs={18} sm={18} md={18} lg={21} xl={21}>
                            <h3 className="an-16 price-tag">
                                <span className="price_txt">From &nbsp;{getCurrencySymbol(t._doc ? t._doc.priceCurrency : t.priceCurrency)}</span>
                                <span className="price_txt">&nbsp;{t._doc ? t._doc.price : t.price}</span>
                            </h3>
                            <Rate
                                allowHalf
                                defaultValue={5}
                                className="an-14"
                                style={{ color: "#FFBC00" }}
                            /><span className="review-text">10 reviews</span>
                        </Col>

                        {/* Trip and workshop difficulty and skill level logos */}
                        {type !== "googleMapCard" &&
                            <Col xs={6} sm={6} md={6} lg={3} xl={3}>
                                <div className="text-right">
                                    <Popover placement="bottom" content={`${t.pageType == "trip" ? displayDifficultyText(typeof t.difficulty !== "undefined" ? t.difficulty : "") : skillLevelText(typeof t.skill !== "undefined" ? t.skill : "")}`} trigger="hover">
                                        <img
                                            src={t.pageType == "trip" ? getColorLogoURL("trip", typeof t.difficulty !== "undefined" ? t.difficulty : "", 'new') : getColorLogoURL("workshop", typeof t.skill !== "undefined" ? t.skill : "", 'new')}
                                            alt="Skil level" className="skill-level-img"
                                        />
                                    </Popover>
                                </div>
                            </Col>
                        }
                    </Row>
                </div>

            </Card>
        </Fragment >
    )

}

export default compose(withRouter)(SingleCard)
