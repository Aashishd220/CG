import React, { Fragment } from 'react';
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import { Row, Col, Rate, Card, Popover, Dropdown, Button, Icon } from 'antd';

/**
 * App Imports
 */
import { CaptalizeFirst, getColorLogoURL, DayorDaysNightOrNights, displayDifficultyText, skillLevelText, getCurrencySymbol, commaSepratorString, getCityFromLocation, commaSepratorStringCaps } from "../../helpers/methods";
import Share from "../../assets/images/share_ic.png";
import MoreTripOption from "../../assets/images/more_vert-24px.svg";
import SkillRed from "../../assets/images/skill_red.svg";
import SkillGreen from "../../assets/images/skill_green.svg";
import SkillOrange from "../../assets/images/skill_orange.svg";
import shareOption from "../../containers/commonContainer/shareOption";
import Map from "../../components/Trips/Map";
import LikeAndShare from "./LikeandshareSingle";
import ReactHtmlParser from "react-html-parser";
import languageIcon from '../../assets/images/speaks_ic_2x.png';
import followersIcon from '../../assets/images/newicon/followers_icon.png';
import locationIcon from "../../assets/images/newicon/location_icon.png";



const ApiKey = process.env.REACT_APP_GOOGLE_MAP_API_KEY;


const SingleCard = (props) => {
    const { expert, view, index, type, onMouseEnter, onMouseLeave, closeCard } = props;


    const onCardClick = (id) => props.history.push(`/expert-profile/${id}`);


    return (
        <Fragment>
            <Card
                hoverable
                onClick={() => onCardClick(expert.id)}
                onMouseEnter={() => type == 'mapCard' ? onMouseEnter(expert.id) : ''}
                onMouseLeave={() => type == 'mapCard' ? onMouseLeave(expert.id) : ''}
                cover={<img alt="example" src={expert.profile} />}
            >

                {type === "googleMapCard" &&
                    <span className="card_close_tag an-10 medium-text">
                        <Icon type="close-circle" onClick={() => closeCard()} />
                    </span>
                }
                <div className="">

                    <div className="expert_card_details">
                        <p className="mb10 expert-title">{`${CaptalizeFirst(expert.firstName)} ${CaptalizeFirst(expert.lastName)}`}</p>

                        <p className="mb20 expert_card_title">
                            <Popover placement="bottomLeft" content={`${commaSepratorString(expert.experties)}`} trigger="hover" overlayClassName="card-title-hover">
                                {`${commaSepratorString(expert.experties)}`}
                            </Popover>

                        </p>
                        <p className="mb10 expert_card_loc">
                            <img src={locationIcon} alt="location" className="location_icon" />{" "}
                            {getCityFromLocation(expert.city)}{CaptalizeFirst(expert.country)}
                        </p>
                        <p className="mb10 expert_card_lang">
                            <img src={languageIcon} alt='language' className='languageIcon' id='languageIcon' />
                            {commaSepratorStringCaps(expert.speaks)}

                        </p>
                        <p className="mb10 expert_card_follow">
                            <img src={followersIcon} alt='followerIcon' className='followerIcon' />
                            678 followers
                        </p>
                        <p className="mb10 expert_review-text">
                            <Rate
                                allowHalf
                                defaultValue={5}
                                className="an-14"
                                style={{ color: "#FFBC00" }}
                            /><span className="review-text-expert">10 reviews</span>
                        </p>

                        {/* <span className="blk-color fnt-rubik">0 Followers &nbsp;</span> */}

                    </div>
                </div>

            </Card>
        </Fragment >
    )

}

export default compose(withRouter)(SingleCard)
