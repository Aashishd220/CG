import React from "react";
import { Modal, Button } from "antd";
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import singleLogo2 from '../../assets/images/single-logo2.png';

/**
 * Image Import
 */
import Success from "../../assets/images/success_ic.png";

const NewsletterModal = (props) => {

  const handleClick = () => {
    props.onClose();
  }

  return (
    <Modal
      centered
      className="auth-modal success-modal news-letter-modal"
      width={380}
      closable={false}
      maskClosable={true}
      visible={props.visible}
      onCancel={handleClick}
    >
      <div className="text-center">
        <h1 className="text-upper medium-text an-30 text-success mb20 mt15">
          Welcome to the Expeditions Connect!
        </h1>
        <img src={singleLogo2} alt="" />
        <p className="an-20 mb20 mt20 regular-text">
          You’ll be the first to hear of our latest news, tips, tricks and updates.
        </p>
      </div>
    </Modal>
  );
};

export default compose(withRouter)(NewsletterModal);
