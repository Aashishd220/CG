import React, { useState } from "react";
import { Modal, Button } from "antd";
import Cookies from "universal-cookie";
import { useSelector, useDispatch } from "react-redux";
import {
  getCurrencySymbol,
  setPreferredCurrency,
  getCurrencies,
} from "helpers/methods";
import { updatePreferredCurrency } from "services/auth";
import { AuthActions } from "redux/auth/events";

const CurrencySelection = (props) => {
  const [visible, setVisible] = useState(false);
  const dispatch = useDispatch();
  const { isLogin } = useSelector((state) => state.auth);
  const { setPreferedCurrency } = AuthActions;

  const onChangeCurrency = async (currency) => {
    setPreferredCurrency(currency);
    dispatch(setPreferedCurrency(currency));
    if (isLogin) {
      await updatePreferredCurrency(currency);
    }
    setVisible(false);
    window.location.reload();
  };

  const currencies = getCurrencies();
  const popularCurrencies = getCurrencies(true);

  const cookies = new Cookies();

  const preferredCurrency = cookies.get("preferredCurrency") || "USD";

  const showModal = () => {
    setVisible(true);
  };

  const handleCancel = () => {
    setVisible(false);
  };

  return (
    <>
      <Button
        onClick={showModal}
        className="medium-text an-16 currency-selection__button"
      >
        {getCurrencySymbol(preferredCurrency) || preferredCurrency}
      </Button>
      <Modal
        centered
        title="Select Your Preferred Currency"
        width={"70vw"}
        footer={null}
        closable={true}
        onCancel={handleCancel}
        visible={visible}
      >
        <div className="currency-selection-container">
          <div className="section__header">Popular Currencies</div>
          {popularCurrencies
            .map((currency) => {
              return (
                <div className="currency-item" key={currency.alpha3Code}>
                  <div
                    className="currency"
                    onClick={() => onChangeCurrency(currency.currencyCode)}
                  >
                    <span className="currency__text">
                      {currency.currencySymbol || currency.currencyCode}
                    </span>
                    <span className="currency__secondary-text">
                      {currency.currencyName}
                    </span>
                  </div>
                </div>
              );
            })}
          <div className="section__header">All Currencies</div>
          {currencies
            .map((currency) => {
              return (
                <div className="currency-item" key={currency.alpha3Code}>
                  <div
                    className="currency"
                    onClick={() => onChangeCurrency(currency.currencyCode)}
                  >
                    <span className="currency__text">
                      {currency.currencySymbol || currency.currencyCode}
                    </span>
                    <span className="currency__secondary-text">
                      {currency.currencyName}
                    </span>
                  </div>
                </div>
              );
            })}
        </div>
      </Modal>
    </>
  );
};

export default CurrencySelection;
