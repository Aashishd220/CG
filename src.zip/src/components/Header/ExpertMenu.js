import React from 'react';
import { NavLink } from 'react-router-dom';
import { Popover } from 'antd';
import { CaretDownOutlined } from '@ant-design/icons';
import CurrencySelectionModal from "./CurrencySelectionModal";

const disabledClass = "flex-x align-center medium-text text-upper an-16 header-nav-list another mr20 disabled-menu";
const enableClass = "flex-x align-center medium-text text-upper an-16 header-nav-list another mr20";

const ExpertMenu = (props) => {
 
  const { isProfileCompleted, tmpRole } = props;

  const handleClick = () => {
    props.onClose();
  };

  // const cookies = new Cookies();

  // const preferredCurrency = cookies.get('preferredCurrency') || "USD";

  // const onChangeCurrency = async (e) => {
  //   setPreferredCurrency(e);
  //   // cookies.set('preferredCurrency', e);
  //   await updatePreferredCurrency(e);
  //   window.location.reload();
  // }

  const expertContent = (
    <div className='profile_bg'>
      <div onClick={handleClick} className='primary--text py5 cursor-pointer'>
        {
          (!isProfileCompleted && tmpRole === "expert") ?
            <NavLink to="/create-expert-profile">Home</NavLink>
            :
            (!isProfileCompleted && tmpRole === "enthusiest") ?
              <NavLink to="/create-enthusiest-profile">Home</NavLink>
              :
              <NavLink to="/home">Home</NavLink>
        }
      </div>
      <div onClick={handleClick} className='primary--text py5 cursor-pointer'>
        <NavLink to='/experts'>Get Inspired</NavLink>
      </div>
      <div onClick={handleClick} className='primary--text py5 cursor-pointer'>
        <NavLink to='/expeditions'>Explore</NavLink>
      </div>
      <div onClick={handleClick} className='primary--text py5 cursor-pointer'>
        <NavLink to='/learning'>Learn</NavLink>
      </div>
    </div >
  );

  return (
    <div className='mobile_menu' style={{ display: 'flex' }}>
      <div className='flex-x align-center medium-text text-upper an-16 header-nav-list another mr20'>
        <Popover placement='topLeft' content={expertContent} trigger="click">
          <div><span style={{ color: '#000', fontFamily: 'rubik', fontSize: '18px' }}>Browse</span>
            <CaretDownOutlined />
          </div>
        </Popover>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to='/profile-expeditions?2'>
          <div>My Trips</div>
        </NavLink>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to='/profile-workshops?3'>
          <div>My Workshops</div>
        </NavLink>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to='/messages'>
          <div>My Messages ({props.count})</div>
        </NavLink>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to='/bookings'>
          <div>Bookings</div>
        </NavLink>
      </div>
      <div className="flex-x align-center medium-text an-16 header-nav-list mr20">
        {/* <Select defaultValue={preferredCurrency} onChange={onChangeCurrency} className="currencyCode">
          {currencies.map(currency => (<Option value={currency.currencyCode}>{currency.currencyCode}</Option>))}
        </Select> */}
        <CurrencySelectionModal></CurrencySelectionModal>
      </div>
    </div>
  );
};

export default ExpertMenu;
