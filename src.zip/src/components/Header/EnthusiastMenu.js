import React from "react";
import { NavLink } from "react-router-dom";
import { Popover, Select } from "antd";
import { CaretDownOutlined } from "@ant-design/icons";
import Cookies from 'universal-cookie';
import { updatePreferredCurrency } from '../../services/auth';
import currencies from "../../helpers/currencies";
import { setPreferredCurrency } from "helpers/methods";
import CurrencySelectionModal from "./CurrencySelectionModal";

const { Option } = Select;
const disabledClass = "flex-x align-center medium-text text-upper an-16 header-nav-list another mr20 disabled-menu";
const enableClass = "flex-x align-center medium-text text-upper an-16 header-nav-list another mr20";

const EnthusiastMenu = (props) => {
  const { isProfileCompleted } = props;
  const handleClick = () => {
    props.onClose();
  };

  const cookies = new Cookies();

  const preferredCurrency = cookies.get('preferredCurrency') || "USD";

  // const onChangeCurrency = async (e) => {
  //   setPreferredCurrency(e);
  //   // cookies.set('preferredCurrency', e);
  //   await updatePreferredCurrency(e);
  //   window.location.reload();
  // }

  const enthuContent = (
    <div className="profile_bg">
      <div onClick={handleClick} className="primary--text py5 cursor-pointer">
        <NavLink to="/home">Home</NavLink>
      </div>
      <div onClick={handleClick} className="primary--text py5 cursor-pointer">
        <NavLink to="/experts">Get Inspired</NavLink>
      </div>
    </div>
  );

  return (
    <div className="mobile_menu" style={{ display: "flex" }}>
      {/* <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <Popover placement="topLeft" content={enthuContent} trigger="click">
          <span style={{ color: '#000', fontFamily: 'rubik', fontSize: '18px' }}>Browse</span>
          <CaretDownOutlined />
        </Popover>
      </div> */}
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to="/home">
          <div>Home</div>
        </NavLink>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to="/experts">
          <div>Get Inspired</div>
        </NavLink>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to="/learning">
          <div>Learn</div>
        </NavLink>
      </div>
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to="/expeditions">
          <div>Explore</div>
        </NavLink>
      </div>
      {/* <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to="/enthusiest-profile">
          <div>My Profile</div>
        </NavLink>
      </div> */}
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink onClick={handleClick} to="/messages">
          <div>Messages ({props.count})</div>
        </NavLink>
      </div>
      {/* <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink to="/bookings">
          <div>My Bookings</div>
        </NavLink>
      </div> */}
      <div className="flex-x align-center medium-text an-16 header-nav-list mr20">
        {/* <Select defaultValue={preferredCurrency} onChange={onChangeCurrency} className="currencyCode">
          {currencies.map(currency => (<Option value={currency.currencyCode}>{currency.currencyCode}</Option>))}
        </Select> */}
        <CurrencySelectionModal></CurrencySelectionModal>
      </div>
    </div>
  );
};

export default EnthusiastMenu;
