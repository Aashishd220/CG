import React, { useEffect, useState } from "react";
import { NavLink, withRouter, useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import Cookies from 'universal-cookie';
import { compose } from "redux";
import { Button, Popover, Avatar, Drawer, Select } from "antd";

/**
 * Logo Image import
 */
import headerLogo from "../../assets/images/headerLogo.png";
import playOutlineIcon from "../../assets/images/playOutlineIcon.svg";
import hamburgerMenuIcon from "../../assets/images/hamburgerMenuIcon.png";

/**
 * App Imports
 */
import Auth from "../Auth/AuthModal";
import ChooseProfile from "../Auth/ChooseProfileModal";
import PendingApproval from "./PendingApproval";
import { ModalActions } from "../../redux/models/events";
import { AuthActions } from "../../redux/auth/events";
import { ExpertEvents } from "../../redux/expert/events";
import { EnthuEvents } from "../../redux/enthu/events";
import { useMediaQuery } from "react-responsive";
import ExpertMenu from "./ExpertMenu";
import EnthusiastMenu from "./EnthusiastMenu";
import { getMessageUreadCount, updatePreferredCurrency, updateUserRole } from '../../services/auth';
import currencies from "../../helpers/currencies";
import { setPreferredCurrency } from "helpers/methods";
import CurrencySelection from "./CurrencySelectionModal";

const { Option } = Select;
const disabledClass = "primary--text py5 cursor-pointer disabled-menu";
const enableClass = "primary--text py5 cursor-pointer";

const Header = (props) => {
  const dispatch = useDispatch();
  const showAuth = useSelector((state) => state.modal.authModal);
  const showChooseProfile = useSelector((state) => state.modal.chooseProfile);
  const showApprovalProfile = useSelector((state) => state.modal.approvalModal);
  const showApprovalProfileViewType = useSelector((state) => state.modal.viewType);
  const { isLogin, role, accessToken, preferredCurrency = "USD", isCompleted, isProfileCompleted, tmpRole } = useSelector((state) => state.auth);
  const all = useSelector((state) => state.auth);
  const { picture, approved } = useSelector((state) => state.expert);
  const history = useHistory();
  const enthu = useSelector((state) => state.enthu);

  const query = new URLSearchParams(props.location.search);
  const isLoginShow = query.get('login')


  const [count, setCount] = useState(0);

  const { changeTmpRole } = AuthActions;
  const {
    openAuthModal,
    closeAuthModal,
    closeChooseProfileModal,
    openApprovalModal,
    closeApprovalModal,
    openChooseProfileModal,
  } = ModalActions;
  const { getProfile, logout, setPreferedCurrency } = AuthActions;
  const { nullExpert } = ExpertEvents;
  const { nullEnthu } = EnthuEvents;
  const isMaxWidth992 = useMediaQuery({ query: "(max-width: 992px)" });

  const cookies = new Cookies();

  useEffect(() => {

    if (isLogin) {
      if (isCompleted || isProfileCompleted) {
        localStorage.removeItem('userType');
      } else {
        if (tmpRole === "user" && tmpRole !== "") {
          dispatch(openChooseProfileModal());
        } else {
          if (tmpRole === "expert") {
            return props.history.push("/create-expert-profile");
          } else if (tmpRole === "enthusiest") {
            return props.history.push("/create-enthusiest-profile");
          }
        }
      }

      if (role !== null && role !== "user") {
        dispatch(getProfile());
        if (accessToken) {
          const interval = setInterval(() => {
            getMessageUreadCount(accessToken, role).then((resp) => {
              if (resp.status === 200)
                setCount(resp.data.data);
            }).catch(err => console.log(err));
          }, 2000);
          return () => clearInterval(interval);
        };
      }
    }
  }, [dispatch, getProfile, isLogin, role, isCompleted]);

  const onProfileChoose = (type) => {
    dispatch(closeChooseProfileModal());
    dispatch(closeAuthModal());
    if (type === 0) {
      dispatch(changeTmpRole('expert'));
      updateUserRole(accessToken, "expert");
      return props.history.push("/create-expert-profile");
    } else {
      dispatch(changeTmpRole('enthusiest'));
      updateUserRole(accessToken, "enthusiest");
      return props.history.push("/create-enthusiest-profile");
    }
  };

  const checkDisabedTrip = (e) => {
    if (!approved) {
      e.preventDefault();
      dispatch(openApprovalModal("trip"));
    }
  };

  const checkDisabedWorkshop = (e) => {
    if (!approved) {
      e.preventDefault();
      dispatch(openApprovalModal("workshop"));
    }
  };

  const logOut = () => {
    dispatch(nullEnthu());
    dispatch(nullExpert());
    dispatch(logout());
    history.push("/");
  };

  const [visible, setVisible] = useState(false);
  const showDrawer = () => {
    setVisible(true);
  };
  const onClose = () => {
    setVisible(false);
  };

  const content = (
    <div className="profile_bg">
      <div className="primary--text py5 cursor-pointer">
        {role === "expert" ? (
          <NavLink to="/profile-expert?1" className='disabled-link'>Profile</NavLink>
        ) : (
            !isProfileCompleted && tmpRole === "expert" ?
              <NavLink to="/create-expert-profile">Profile</NavLink>
              :
              !isProfileCompleted && tmpRole === "enthusiest" ?
                <NavLink to="/create-enthusiest-profile">Profile</NavLink>
                :
                <NavLink to="/enthusiest-profile">Profile</NavLink>

          )}
      </div>
      {role === "expert" && <div className="border_bottom"></div>}
      {role === "expert" && (
        <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
          <NavLink onClick={checkDisabedTrip} to="/create-trips">
            Create Trip
          </NavLink>
        </div>
      )}
      {role === "expert" && (
        <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
          <NavLink onClick={checkDisabedWorkshop} to="/create-learnings">
            Create Workshop
          </NavLink>
        </div>
      )}
      {/*role === "expert" && (
        <div className="primary--text py5 cursor-pointer">
          <NavLink to="/profile-expert?tab=5">Messages</NavLink>
        </div>
      )*/}
      <div className={`${!isProfileCompleted ? disabledClass : enableClass}`}>
        <NavLink to="/settings" className={`${!isProfileCompleted ? 'disabled-menu' : ''}`}>Settings</NavLink>
      </div>
      <div className="border_top"></div>
      <div className="primary--text py5 cursor-pointer" onClick={logOut}>
        Logout
      </div>
    </div>
  );

  let Menu = (
    <>
      <div className="flex-x align-center medium-text  an-16 header-nav-list mr20">
        <NavLink to="/" exact onClick={onClose}>
          <div>Home</div>
        </NavLink>
      </div>
      <div className="flex-x align-center medium-text  an-16 header-nav-list mr20">
        <NavLink to="/experts" onClick={onClose}>
          <div>Get Inspired</div>
        </NavLink>
      </div>
      <div className="flex-x align-center medium-text an-16 header-nav-list mr20">
        <NavLink to="/learning" onClick={onClose}>
          <div>Learn</div>
        </NavLink>
      </div>
      <div className="flex-x align-center medium-text an-16 header-nav-list mr20">
        <NavLink to="/expeditions" onClick={onClose}>
          <div>Explore</div>
        </NavLink>
      </div>
      <div className="flex-x align-center medium-text an-16 header-nav-list mr20">
        {/* <Select defaultValue={preferredCurrency} onChange={onChangeCurrency} className="currencyCode">
          {currencies.map(currency => (<Option value={currency.currencyCode}>{currency.currencyCode}</Option>))}
        </Select> */}
        <CurrencySelection></CurrencySelection>
      </div>
      {isLogin ? (
        <div className="flex-x align-center an-16 header-nav-list mr20">
          <Popover placement="topRight" content={content} trigger={`${isMaxWidth992 ? 'click' : 'hover'}`}>
            <Avatar
              shape="square"
              className="cursor-pointer"
              size={32}
              src={role === "expert" ? picture : enthu.picture}
            />
          </Popover>
        </div>
      ) : (
          <div className="flex-x align-center an-14 medium-text header-nav-list cursor-pointer">
            <div className="get-started-btn-container">
              <div className="line" />
              <Button
                type="primary"
                className="ex__primary_btn text-upper get-started-btn"
                onClick={() => {
                  dispatch(openAuthModal(true));
                  onClose();
                }}
              >
                Get Started
              <img src={playOutlineIcon} alt="" />
              </Button>
              <div className="line" />
            </div>
          </div>
        )}
    </>
  );

  if (isLogin) {
    Menu = role === "enthusiasts" ? <EnthusiastMenu onClose={onClose} count={count} isProfileCompleted={isProfileCompleted} tmpRole={tmpRole} /> : <ExpertMenu onClose={onClose} count={count} isProfileCompleted={isProfileCompleted} tmpRole={tmpRole} />;
  }

  useEffect(() => {
    if (!isLogin && isLoginShow) {
      dispatch(openAuthModal(true));
    }
  }, [])
  const MyDrawer = (
    <Drawer
      title={<img className="mb5" width="170" src={headerLogo} alt="logo" />}
      placement="right"
      closable={true}
      onClose={onClose}
      visible={visible}
      className="mobile-drawer header-nav-list"
    >
      {Menu}
    </Drawer>
  );

  return (
    <div className="header-container1">
      <div className="container flex-x align-center">
        <div className="header-logo pr10 flex-1">
          <NavLink
            to="/"
            onClick={() => {
              setTimeout(() => {
                isProfileCompleted && window.location.reload();
              });
              onClose();
            }}
          >
            <img className="mb5" width="170" src={headerLogo} alt="logo" />
          </NavLink>
        </div>
        {!isMaxWidth992 && Menu}
        {isMaxWidth992 && (
          <>
            {!isLogin &&
              <Button
                type="primary"
                className="ex__primary_btn mobile-login-btn"
                onClick={() => {
                  dispatch(openAuthModal(true));
                  onClose();
                }}
              >
                Login
            </Button>
            }
            <Button onClick={showDrawer} className="toggle-drawer-btn">
              <img src={hamburgerMenuIcon} alt="" />
            </Button>
          </>
        )}
        {isLogin && (
          <>
            <div className="flex-x align-center an-16 header-nav-list mr20  profile_detail">
              <Popover placement="topRight" content={content} trigger={`${isMaxWidth992 ? 'click' : 'hover'}`}>
                <Avatar
                  shape="square"
                  className="cursor-pointer"
                  size={32}
                  src={role === "expert" ? picture : enthu.picture}
                />
              </Popover>
            </div>
          </>
        )}
      </div>
      {MyDrawer}
      {showAuth && (
        <Auth
          visible={showAuth}
          onCancel={() => dispatch(closeAuthModal(false))}
          isLoginShow={isLoginShow}
        />
      )}
      {showChooseProfile && (
        <ChooseProfile visible={showChooseProfile} onChoose={onProfileChoose} />
      )}
      {showApprovalProfile && (
        <PendingApproval
          visible={showApprovalProfile}
          viewType={showApprovalProfileViewType}
          onCancel={() => dispatch(closeApprovalModal(false))}
        />
      )}
    </div>
  );
};

export default compose(withRouter)(Header);
