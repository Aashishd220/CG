import React from 'react'
import ReactDOM from 'react-dom'
import App from './components/App'
import './style.css'
import './script.js'
ReactDOM.render(<App/>,document.querySelector('#root'))