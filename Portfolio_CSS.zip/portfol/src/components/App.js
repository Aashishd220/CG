import React,{BrowserRouter,Link,Router} from 'react'
import NavBar from './NavBar';
import Home from './Home';
import About from './About';
import Skills from './Skills';
import Project from './Project';
import Contact from './Contact';
import Footer from './Footer';

const App=()=>{
    return(
        <div>
            <NavBar/>
            <Home/>
            {/* <About/>
            <Skills/>
            <Project/>
            <Contact/>
            <Footer/> */}
        </div>
    )
}

export default App;