import React from 'react'
import '../styling/Home.css'
function Home() {
    return (
        <div>
            <section className="home" id="home">
      <div className="max-width">
        <div className="home-content">
          <div className="text1">Hello, my name is</div>
          <div className="text2">Aashish Dhalla</div>
          <div className="text3">And I'm a <span className="typing"></span></div>
          <a href="#">Hire me</a>
        </div>
      </div>
    </section>
        </div>
    )
}

export default Home
