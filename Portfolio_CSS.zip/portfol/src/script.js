import React from 'react'

const script=()=>{
  
  
  return(
    <div>

      


  </div>

//   // slide-up script
//   $('.scroll-up-btn').click(function(){
//     $('html').animate({scrollTop: 0});
//     // removing smooth scroll on slide-up button click
//     $('html').css("scrollBehavior", "auto");
// });

// // typing text animation script
// var typed = new Typed(".typing", {
//   strings: [ "Developer"],
//   typeSpeed: 100,
//   backSpeed: 60,
//   loop: true
// });

// var typed = new Typed(".typing-2", {
//   strings: [ "Developer"],
//   typeSpeed: 100,
//   backSpeed: 60,
//   loop: true
// });

//   // toggle menu/navbar script
//   $(".menu-btn").click(function () {
//     $(".navbar .menu").toggleClass("active");
//     $(".menu-btn i").toggleClass("active");
//   });
// });


    
  )
}

export default script