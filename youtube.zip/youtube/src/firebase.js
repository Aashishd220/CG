const firebaseConfig = {
    apiKey: "AIzaSyAxXUELakxsovUtjXRPgp6FxhxAKBacUh4",
    authDomain: "clone-a3ff1.firebaseapp.com",
    databaseURL: "https://clone-a3ff1.firebaseio.com",
    projectId: "clone-a3ff1",
    storageBucket: "clone-a3ff1.appspot.com",
    messagingSenderId: "380162276140",
    appId: "1:380162276140:web:0841ecf8e68267a91c8a89",
    measurementId: "G-QRMZ6LLBP8"
  };