import {DATA} from '../actions/types'
 
 export default (state={},action)=>{
     switch(action.type){
        case DATA:
            return {...state,videos:action.payload}
        default:
            return state;
     }
    
 }