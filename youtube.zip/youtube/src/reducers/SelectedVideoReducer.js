
import {SELECTED_VIDEO} from '../actions/types'
 
 export default (state={},action)=>{
    switch(action.type){
        case SELECTED_VIDEO:
            return {...state,video:action.payload}
       default:
           return state;
    }
   
}

