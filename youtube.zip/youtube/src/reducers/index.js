import {combineReducers} from 'redux'
import data from './SearchReducer'
import video from './SelectedVideoReducer'

export default combineReducers({
    data,
    video,
    
})