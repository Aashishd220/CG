import React from 'react'
import SidebarRow from './SidebarRow'
import {Link} from 'react-router-dom';
import  '../styleComponents/Sidebar.css'
import HomeSharpIcon from '@material-ui/icons/HomeSharp';
import WhatshotIcon from '@material-ui/icons/Whatshot';
import SubscriptionsSharpIcon from '@material-ui/icons/SubscriptionsSharp';
import VideoLibrarySharpIcon from '@material-ui/icons/VideoLibrarySharp';
import HistorySharpIcon from '@material-ui/icons/HistorySharp';
import OndemandVideoSharpIcon from '@material-ui/icons/OndemandVideoSharp';
import WatchLaterSharpIcon from '@material-ui/icons/WatchLaterSharp';
import ThumbUpAltSharpIcon from '@material-ui/icons/ThumbUpAltSharp';
import ExpandMoreSharpIcon from '@material-ui/icons/ExpandMoreSharp';

function SideBar() {
    return (
        <div className="sidebar">
            <Link to="/"><SidebarRow selected title="Home" Icon={HomeSharpIcon}/></Link>
            <SidebarRow title="Trending" Icon={WhatshotIcon}/>
            <SidebarRow title="Subscription" Icon={SubscriptionsSharpIcon}/>
            <hr/>
            <SidebarRow title="Library" Icon={VideoLibrarySharpIcon}/>
            <SidebarRow title="History" Icon={HistorySharpIcon}/>
            <SidebarRow title="Your Videos" Icon={OndemandVideoSharpIcon}/>
            <SidebarRow title="Watch Later" Icon={WatchLaterSharpIcon}/>
            <SidebarRow title="Liked Videos" Icon={ThumbUpAltSharpIcon}/>
            <SidebarRow title="Show more" Icon={ExpandMoreSharpIcon}/>
            <hr/>
        </div>
    )
}

export default SideBar
