import React from 'react'
import '../styleComponents/VideoRow.css'

function VideoRow(props) {
    const {image,title,channel,description}=props
    return (
        <div className="videoRow" >
             <img className="videoRow__thumbnail" src={image} alt="thumbnail"/>
            <div className="videoRow__text">
                <h3>{title}</h3>
                <p>{channel}</p>
                <p className="videoRow__description">{description}</p>
                </div>
        </div>
    )
}

export default VideoRow
