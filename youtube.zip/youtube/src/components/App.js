import React,{useEffect, useState} from 'react'
import Header from './Header'
import RecomendedVideo from './RecomendedVideo'
import SearchedVideos from './SearchedVideos'
import Sidebar from './Sidebar'
import '../styleComponents/App.css'
import {Router,Switch,Route} from 'react-router-dom'
import history from '../history'
import ErrorPage from './ErrorPage'
import SelectedVideo from './SelectedVideo'
import RightSuggestions from './RightSuggestions'

function App(props) {
    const [data, setData] = useState([])

    const getData=(data)=>{
        setData(data)
    }
    return (
        <div className="app">
           <Router history={history}>
           <Header/>
            <Switch>          
                <Route exact path="/">             
                 <div className="app__page">
                      <Sidebar/>
                      <RecomendedVideo getData={getData}/>
                 </div>
                </Route>

                <Route exact path="/search/:term">              
                 <div className="app__page">
                      <Sidebar/>
                      <SearchedVideos/>
                 </div>
                </Route>
                
                <Route exact path="/watch/:new">              
                 <div className="app__page">
                      <SelectedVideo/>
                      <RightSuggestions randomVideos={data}/>
                 </div>
                </Route>

                <Route path="*" component={ErrorPage} />
            </Switch>
           </Router>
            
        </div>

    )
}


export default App
