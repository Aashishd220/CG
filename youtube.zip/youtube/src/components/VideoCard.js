import React from 'react'
import '../styleComponents/VideoCard.css'
function VideoCard(props) {
    const {image,title,channel}=props
    return (
        <div className="videoCard">
            <img className="videoCard__thumbnail" src={image} alt="thumbnail"/>
            <div className="video__info">
                <h4>{title}</h4>
                <p>{channel}</p>
            </div>
        </div>
    )
}

export default VideoCard
