import React,{useState} from 'react'
import {connect} from 'react-redux'
import {getTerm} from '../actions'
import '../styleComponents/SearchBar.css'
function SearchBar(props) {
   
    const [term,setTerm]=useState('')
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(term!=''){
            props.getTerm(term);
        }

        
    }
   
   
    return (
        <form onSubmit={handleSubmit} >
            <input className="form__input" value={term} onChange={(e)=>{setTerm(e.target.value)}} type="text"/>
        </form>
    )
}
const mapStateToProps=(state)=>{
    return {
        data:state.data
    }
}
export default connect(mapStateToProps,{getTerm})(SearchBar)
