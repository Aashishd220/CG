import React from 'react'
import {connect} from 'react-redux'
import '../styleComponents/SelectedVideo.css'
import ThumbUpAltSharpIcon from '@material-ui/icons/ThumbUpAltSharp';
import ThumbDownAltSharpIcon from '@material-ui/icons/ThumbDownAltSharp';
import ShareSharpIcon from '@material-ui/icons/ShareSharp';
import DehazeSharpIcon from '@material-ui/icons/DehazeSharp';
import MoreHorizSharpIcon from '@material-ui/icons/MoreHorizSharp';
import history from '../history'
function SelectedVideo(props)
 {
    if(props.video===undefined){
       history.push('/')
    }
    
    
    const videoUrl=`https://youtube.com/embed/${props.video.id.videoId}`;
    return (
        <div className="selectedVideo">

            <iframe className="videoTag" src={videoUrl}/>
           <h3> {props.video.snippet.title}</h3>
          
           <div className="icons">
            <ThumbUpAltSharpIcon className="icon"/>
            <ThumbDownAltSharpIcon className="icon"/>
            <ShareSharpIcon className="icon"/>
            <DehazeSharpIcon className="icon"/>
            <MoreHorizSharpIcon className="icon"/>
           </div>
           <hr/>
        </div>
    )
}
const mapStateToProps=(state)=>{
    return {
        video:state.video.video
    }
}
export default connect(mapStateToProps,{})(SelectedVideo)
