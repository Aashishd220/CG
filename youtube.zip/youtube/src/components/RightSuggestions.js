import React from 'react'
import {connect} from 'react-redux'
import { getSelectedVideo } from '../actions';
import VideoCard from './VideoCard';
import '../styleComponents/RightSuggestions.css'


function RightSuggestions(props) {

    const selectedVideo=(video)=>{
        props.getSelectedVideo(video);
     }

    const renderVideos= Object.keys(props.data).length!=0?
        props.data.videos.slice(2, 4).map((video)=>{
               return (  
                   <div className="videoRowDiv" onClick={()=>selectedVideo(video)} key={video.id.videoId}>
                       <VideoCard title={video.snippet.title} description={video.snippet.description} image={video.snippet.thumbnails.high.url} channel={video.snippet.channelTitle}/>
                   </div>
               )
           }):  props.randomVideos.slice(2, 4).map((video)=>{
            return (
              
                <div className="videoRowDiv" onClick={()=>selectedVideo(video)} key={video.id.videoId}>
                    <VideoCard title={video.snippet.title} description={video.snippet.description} image={video.snippet.thumbnails.high.url} channel={video.snippet.channelTitle}/>
                </div>
            )
        })
 
    return (
        <div className="rightSuggestions">
           {renderVideos}
        </div>
    )
}

const mapStateToProps=(state)=>{
    return{
        data:state.data
    }
}
export default connect(mapStateToProps,{getSelectedVideo})(RightSuggestions)
