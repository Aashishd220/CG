import React,{useEffect,useState} from 'react'
import '../styleComponents/RecomendedVideo.css'
import VideoCard from './VideoCard'
import youtube from '../apis/youtube'
import ErrorPage from './ErrorPage'
import {connect} from 'react-redux'

import { getSelectedVideo, initialData } from '../actions'

function RecomendedVideo(props) {

const [data,setData]=useState([])

    useEffect(()=>{
         youtube.get('/search')
         .then((res)=>{
          setData(res.data.items)
         })
         .catch((err)=>{
             console.log(err)
         })
    },[])

if(data.length!=0){
    props.getData(data)
}


const selectedVideo=(video)=>{
    props.getSelectedVideo(video);
 }
    const renderVideos= data.length===0?<ErrorPage/>:  data.map((video)=>{
            return (
                <div onClick={()=>selectedVideo(video)} key={video.id.videoId}>
                    <VideoCard title={video.snippet.title} image={video.snippet.thumbnails.high.url} channel={video.snippet.channelTitle}/>
                </div>
            )
        })
   
    return (
        <div className="recomendedVideo">
          <h2>Recomended Videos</h2>
          <div className="recomendedVideos__videos">
           {data.length===0? <div>Loading...</div>: renderVideos}
          </div>
        </div>
    )
}

export default connect(null,{getSelectedVideo})(RecomendedVideo)
