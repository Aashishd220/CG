import React from 'react'
import {connect} from 'react-redux'
import VideoCard from './VideoCard'
import '../styleComponents/SearchedVideos.css'
import ErrorPage from './ErrorPage'
import VideoRow from './VideoRow'
import { Link } from 'react-router-dom'
import { getSelectedVideo } from '../actions'
import SelectedVideo from './SelectedVideo'
import history from '../history'

function SearchedVideos(props) {

    const selectedVideo=(video)=>{
       props.getSelectedVideo(video);
    }
    const renderVideos= Object.keys(props.data).length!=0? props.data.videos.map((video)=>{
            return (    
                <div className="videoRowDiv" onClick={()=>selectedVideo(video)} key={video.id.videoId}>
                    <VideoRow title={video.snippet.title} description={video.snippet.description} image={video.snippet.thumbnails.high.url} channel={video.snippet.channelTitle}/>
                </div>
            )
        }):history.push('/')


    return (
        <div className="searchedVideos">
          <h2>Searched Videos</h2>
          <div className="searchedVideos__video">
              {renderVideos}
          </div>
        </div>
    )
}

const mapStateToProps=(state)=>{
    return {
        data:state.data
    }
}
export default connect(mapStateToProps,{getSelectedVideo})(SearchedVideos)
