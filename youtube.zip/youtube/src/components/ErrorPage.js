import React from 'react'

function ErrorPage() {
    return (
        <div>
         Sorry!!! Api Call failed.
        </div>
    )
}

export default ErrorPage
