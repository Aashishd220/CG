export const SELECTED_VIDEO='SELECTED_VIDEO'
export const DATA='DATA'