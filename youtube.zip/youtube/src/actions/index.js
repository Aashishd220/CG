import youtube from '../apis/youtube'
import history from '../history'
import {DATA,SELECTED_VIDEO} from './types'

export const getTerm=(term)=>{
    return async (dispatch)=>{
        const response= await youtube.get('/search',
        {
            params:{
             q:term
            }
        })
        dispatch({
            type:DATA,
            payload:response.data.items
        })
        history.push(`/search/${term}`)
    }
}

export const getSelectedVideo=(video)=>{
    return (dispatch)=>{
       dispatch({
        type:SELECTED_VIDEO,
        payload:video
       })
       history.push('/watch/selectedVideo')
   
    }
   
}
