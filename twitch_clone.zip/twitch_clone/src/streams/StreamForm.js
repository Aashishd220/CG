import React from "react";
import {Field,reduxForm} from 'redux-form'
import '../style/StreamCreate.css'
 
class StreamForm extends React.Component {
    renderInput({input,label,meta}){
        return(
            <div className="inputField">
                
                <label>{label}</label>
                 <input {...input} autoComplete="off" />
               {meta.touched && <div>{meta.error}</div>}
            </div>
        )
   
   }

   onSubmit=(formValues)=>{
   this.props.onSubmit(formValues);
   console.log(formValues)
   }
 render(){
    return (
        <form onSubmit={this.props.handleSubmit(this.onSubmit)}>
            <Field name="title" label="title" component={this.renderInput}/>
            <Field name="description" label="description" component={this.renderInput}/>   
            <button className="btn">Submit</button>   
        </form>
        
    )
 }
}

const validate=(formValues)=>{
    const error={};
    if(!formValues.title){
         error.title="Enter a title";
    }
     if(!formValues.description){
        error.description="Enter a description";    
    }

    return error;
}

export default  reduxForm({
    form:'streamCreate',
    validate
})(StreamForm)

