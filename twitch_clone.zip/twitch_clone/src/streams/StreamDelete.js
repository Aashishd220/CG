import React from "react";

function StreamDelete() {
  return <div>StreamDelete</div>;
}

export default StreamDelete;
