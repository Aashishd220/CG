import React from "react";

function StreamShow() {
  return <div>StreamShow</div>;
}

export default StreamShow;
